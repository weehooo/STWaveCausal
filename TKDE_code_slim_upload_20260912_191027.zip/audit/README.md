# Counterfactual Audit Protocol

This directory packages the counterfactual diagnostics used in the TKDE
submission. Run the commands from the repository root unless a wrapper changes
directory explicitly. The protocol is intentionally allowed to return negative
results: a failed probe limits the interpretation of the effect head instead of
being hidden.

## One-command runner

```bash
PAPERS_BASE="$PWD" bash audit/run_all.sh
```

Set any `RUN_<STAGE>=0` variable to skip a stage. The default is intended for a
machine that already contains the preprocessed datasets and trained checkpoints
under `data/`.

## Audit families

| Family | Entry point | Main outputs |
|---|---|---|
| Synthetic recovery | `eval_synth_new.py`, `build_synthetic_ood_graphctx.py` | `synthetic_recovery_new.json`, `synthetic_recovery_ood.json` |
| Matching balance | `run_psm_propensity.py`, `run_psm_fitted_closedloop.py` | `psm_propensity_results.json`, `psm_fitted_closedloop_results.json` |
| Structure recovery | `eval_dag_recovery.py` | `dag_recovery_results.json` |
| Placebo and robust ranks | `eval_placebo_calibration_results.py`, `eval_event_rank_robust.py` | `placebo_calibration_results.json`, `eval_event_rank_robust_results.json` |
| External event stress | `build_real_event_registry.py`, `eval_real_event_validation.py` | `real_event_registry.json`, `real_event_validation_results.json` |

## Manifest

After audits complete, create a reproducibility manifest with software versions,
UTC timestamps, SHA-256 hashes, and byte sizes:

```bash
"$PYTHON" audit/make_manifest.py
```

The manifest does not replace the individual result files; it records which
artifacts were present when the paper was packaged.

## Interpretation rules

1. In-distribution synthetic calibration cannot by itself support real-world
   causal claims.
2. If fitted propensity matching violates the balance target, distance-matched
   and propensity-matched estimands are reported as different targets.
3. The event-combination encoder is never described as a DAG learner because it
   fails directed-edge recovery.
4. External-event enrichment must survive placebo and stratified controls before
   it is used as supporting evidence.
5. All null outcomes remain in the final report and submission package.
