"""Create a reproducibility manifest for counterfactual audit artifacts."""
import argparse
import hashlib
import json
import os
import platform
from datetime import datetime, timezone
from pathlib import Path


ARTIFACTS = [
    "synthetic_recovery_new.json",
    "synthetic_recovery_ood.json",
    "psm_propensity_results.json",
    "psm_fitted_closedloop_results.json",
    "dag_recovery_results.json",
    "placebo_calibration_results.json",
    "eval_event_rank_robust_results.json",
    "real_event_registry.json",
    "real_event_pairs_selected.json",
    "real_event_validation_results.json",
    "eval_h1_flow_baselines_results.json",
    "h1_uncertainty_efficiency.json",
    "h1_cluster_robust.json",
    "collision_stress_results.json",
    "pemsbay_incident_results.json",
    "localized_stress_protocol.json",
    "pemsbay_incident_protocol.json",
    "SUBMISSION_README.md",
]


def describe_json(path):
    try:
        with path.open(encoding="utf-8") as handle:
            data = json.load(handle)
    except Exception as exc:
        return {"parse_error": str(exc)}
    if not isinstance(data, dict):
        return {"top_level": type(data).__name__}
    keys = {}
    for key in ("seed", "seeds", "split", "splits", "protocol"):
        if key in data:
            keys[key] = data[key]
    return keys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=os.environ.get("PAPERS_BASE", "."))
    parser.add_argument("--output", default="audit/audit_manifest.json")
    args = parser.parse_args()
    root = Path(args.root).resolve()

    versions = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "numpy": _optional_version("numpy"),
        "scipy": _optional_version("scipy"),
        "torch": _optional_version("torch"),
        "sklearn": _optional_version("sklearn"),
    }
    artifacts = []
    for name in ARTIFACTS:
        path = root / name
        if not path.is_file():
            artifacts.append({"name": name, "present": False})
            continue
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        artifacts.append({
            "name": name,
            "present": True,
            "sha256": digest.hexdigest(),
            "bytes": path.stat().st_size,
            "modified_utc": datetime.fromtimestamp(
                path.stat().st_mtime, tz=timezone.utc).isoformat(),
            **describe_json(path),
        })

    output = {
        "manifest_version": 1,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "software": versions,
        "artifacts": artifacts,
    }
    destination = root / args.output
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("w", encoding="utf-8") as handle:
        json.dump(output, handle, indent=2)
    print(destination)


def _optional_version(module_name):
    try:
        import importlib
        module = importlib.import_module(module_name)
        return getattr(module, "__version__", "unknown")
    except Exception:
        return "not-installed"


if __name__ == "__main__":
    main()
