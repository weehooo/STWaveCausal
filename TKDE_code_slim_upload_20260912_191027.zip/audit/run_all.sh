#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${PAPERS_BASE:-$(dirname "$SCRIPT_DIR")}"
cd "$ROOT"
mkdir -p cloud_logs

run_stage() {
  local name="$1"
  shift
  local flag="RUN_${name}"
  if [[ "${!flag:-1}" == "1" ]]; then
    echo "=== audit:${name} ==="
    "$@" 2>&1 | tee "cloud_logs/audit_${name}.log"
  fi
}

run_stage SYNTHETIC python eval_synth_new.py \
  --output synthetic_recovery_new.json

if [[ "${RUN_OOD_SYNTHETIC:-0}" == "1" ]]; then
  python build_synthetic_ood_graphctx.py --n-samples 2000 --ctx-mode mean \
    --out synthetic_pairs_v3_graphctx_ood.npy
  python eval_synth_new.py \
    --synthetic data/nyc_taxi/processed/synthetic_pairs_v3_graphctx_ood.npy \
    --output synthetic_recovery_ood.json
fi

run_stage MATCHING python run_psm_propensity.py --epochs 200 \
  --max-fit 50000 --max-events 30000
run_stage PSM_CLOSEDLOOP python run_psm_fitted_closedloop.py
run_stage DAG_RECOVERY python eval_dag_recovery.py
run_stage PLACEBO python eval_placebo_calibration_results.py
run_stage ROBUST_RANK python eval_event_rank_robust.py --n-perm 10000

if [[ "${RUN_EXTERNAL_EVENTS:-0}" == "1" ]]; then
  python build_real_event_registry.py
  python eval_real_event_validation.py
fi

python audit/make_manifest.py
echo "ALL AUDIT STAGES DONE"
