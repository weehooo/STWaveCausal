# Pre-registered Audit Protocol

This file freezes the intervention definitions, evaluation metrics, and
failure conditions used by the TKDE revision. New experiments must follow
these settings and report both positive and boundary results.

## Datasets

- NYC Taxi: 2011-01 to 2013-12, 30-minute windows, 265 zones, 6 channels.
- PEMS-BAY: 2017-01 to 2017-06, 5-minute windows, 325 sensors, 8 channels.
- PEMS08: 62 days, 5-minute windows, 170 sensors, 1 channel.
- PEMS04: 16,992 windows, 307 sensors, 1 channel.

All datasets use chronological 80/10/10 splits.

## Intervention labels

- INTERVENTION: both the z-score rule and the per-sensor Hawkes residual rule
  flag the same time-sensor pair.
- RESPONSE: both rules agree that no intervention occurred.
- UNCERTAIN: the two rules disagree; these pairs are excluded from matched-pair
  training.

The annotation is a precision-first control selector. Event-level effect
analyses may use external event records and do not inherit the low recall of
this selector.

## Matching

- Match each intervention to a no-intervention window at the same sensor.
- Require a time buffer of at least 3 windows.
- Tune the caliper from {0.5, 0.3, 0.1} to the largest value that keeps the
  maximum standardized mean difference below 0.1.
- Report matched-pair count, matching rate, and SMD before and after matching.

## Prediction metrics

- MAE, RMSE, and MAPE on the raw output scale.
- Per-feature MAE as the cross-dataset comparator when feature dimensions
  differ.
- Standard single-step protocol is the primary prediction table.
- The matched-pair intervention benchmark is reported as a secondary,
  clearly labelled evaluation.

## Causal effect evaluation

- Synthetic recovery: correlation, median recovery ratio, and MAE.
- Real-data event study: treated-minus-donor post effect, 95% CI, pre-trend,
  dose-response, and placebo.
- External localization: documented-sensor top-k enrichment with
  Benjamini-Hochberg correction.
- Sensitivity: Rosenbaum Gamma for hidden confounding.

## Failure conditions

- A real-data effect claim is void if pre-trend or placebo cannot be rejected,
  or if dose-response contradicts the claimed mechanism.
- A synthetic recovery result alone never licenses a real-data causal claim;
  it must be composed with matching, structure, and external-event checks.
- If dose-response is null or unstable, the paper must report localization
  rather than effect quantification.

## Reproducibility

- Seeds: 42, 1, 2 for all three-seed statistics.
- Environment: Python 3.8/3.10, PyTorch 2.3.1, CUDA 12.1.
- All audit probes emit machine-readable JSON artifacts.
