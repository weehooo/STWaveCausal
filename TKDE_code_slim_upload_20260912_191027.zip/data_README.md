# Data

The submission package intentionally excludes large raw/processed data files.
The `processed` directories follow the same schema as the local project:

```text
data/<name>/processed/
  node_features.npy    (T, N, D)
  labels.npy           (T, N) in {-1, 0, 1}
  matched_pairs.npy    PSM matches
  psm_stats.txt        SMD + Rosenbaum output
  adj.npy              correlation-based adjacency (graph baselines)
  synthetic_pairs_v3.npy  known-effect benchmark
```

Sources:

- NYC taxi: TLC yellow taxi parquet files (2011-2013), processed with
  `src/preprocess/download_nyc_taxi.py` and `build_flow_matrix.py`.
- PEMS-BAY: `https://github.com/scchuy/pemsbay` (pems-bay.h5).
- PEMS08: official STAEformer release
  `https://github.com/XDZhelheim/STAEformer` (data/PEMS08/data.npz).

Recreate a processed directory with:

```bash
python src/preprocess/annotate.py --data-dir data/<name>
python src/preprocess/psm_matching.py --data-dir data/<name>
python build_synthetic_v3.py   # after pointing it at the dataset
```

See the root `README.md` for training commands.
