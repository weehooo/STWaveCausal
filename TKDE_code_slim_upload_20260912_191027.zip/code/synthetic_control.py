"""Synthetic control validation for natural events on NYC Taxi."""
import argparse
import os
import sys
from datetime import datetime

import numpy as np
import torch
from scipy.optimize import nnls

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, "src/model")

from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48
CF_OFFSET = 7 * 7 * 48
start = datetime(2011, 1, 1, 0, 0, 0)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--date", required=True)
    p.add_argument("--zone", type=int, required=True)
    p.add_argument("--ckpt", default="data/nyc_taxi/processed/stwave_causal_v3_full_best.pt")
    args = p.parse_args()

    t0 = int((datetime.strptime(args.date, "%Y-%m-%d") - start).total_seconds() / (30 * 60))
    feats = np.load("data/nyc_taxi/processed/node_features.npy", mmap_mode="r")
    T, N, D = feats.shape
    flow = feats[..., 0].astype(np.float32)

    pre = flow[t0 - 7 * 48:t0]
    post = flow[t0:t0 + 48]
    pre_mean = pre.mean(0)
    post_mean = post.mean(0)
    rel = np.abs(post_mean - pre_mean) / (pre_mean + 1.0)
    donors = [z for z in range(N) if z != args.zone and rel[z] < 0.05]
    print("Zone", args.zone, "event t0", t0, "donors", len(donors))

    y_pre = pre[:, args.zone]
    D_pre = pre[:, donors]          # (S, M)
    w, _ = nnls(D_pre, y_pre)
    if w.sum() > 0:
        w = w / w.sum()
    sc_post = post[:, donors] @ w
    sc_effect = float(np.mean(post[:, args.zone] - sc_post))
    print("Synthetic control effect (flow): %.3f" % sc_effect)

    model = STWaveCausalV3(n_zones=N, input_dim=D).to(device)
    model.load_state_dict(torch.load(args.ckpt, map_location=device))
    model.eval()
    t_star = t0 - CF_OFFSET
    if t_star <= SEQ:
        print("V3 ACE: unavailable (counterfactual before data start)")
        return

    def window(t):
        ts = max(0, t - SEQ)
        w = feats[ts:t, args.zone].copy()
        if len(w) < SEQ:
            w = np.concatenate([np.zeros((SEQ - len(w), D)), w])
        return w

    with torch.no_grad():
        zid = torch.full((1, SEQ), args.zone, dtype=torch.long, device=device)
        ff = torch.FloatTensor(window(t0)).unsqueeze(0).to(device)
        cf = torch.FloatTensor(window(t_star)).unsqueeze(0).to(device)
        _, pf = model(zid, ff)
        _, pcf = model(zid, cf)
    ace_v3 = float(np.mean(np.abs(pf[0].cpu().numpy() - pcf[0].cpu().numpy())))
    print("V3 prediction-difference ACE: %.3f" % ace_v3)
    print("Direction agreement:", np.sign(sc_effect) == np.sign(ace_v3))


if __name__ == "__main__":
    main()
