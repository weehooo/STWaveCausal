"""Model-free counterfactual evaluation for the XTraffic validation CSV."""
import json

import numpy as np
import pandas as pd


def main():
    df = pd.read_csv("real_incident_validation.csv")
    incidents = pd.read_csv(
        r"C:\Users\weehoo\.cache\kagglehub\datasets\gpxlcj\xtraffic"
        r"\versions\8\incidents_y2023.csv",
        sep="\t",
    )
    incidents["dt"] = pd.to_datetime(incidents["dt"])
    df["dt"] = pd.to_datetime(df["dt"])
    merged = df.merge(
        incidents[["incident_id", "DESCRIPTION", "duration"]],
        on="incident_id",
        how="left",
    )
    valid = merged.dropna(subset=["effect"]).copy()

    zero_mae = float(np.mean(np.abs(valid["effect"])))
    # Event-level aggregation: one effect per incident, nearest sensor only.
    event_level = valid.sort_values("dt").drop_duplicates("incident_id")
    baseline_zero = float(np.mean(np.abs(event_level["effect"])))
    negative_fraction = float((event_level["effect"] < 0).mean())

    type_rows = []
    for typ, grp in event_level.groupby("DESCRIPTION"):
        if len(grp) < 20:
            continue
        type_rows.append({
            "type": typ,
            "n": int(len(grp)),
            "mean_effect": float(grp["effect"].mean()),
            "median_effect": float(grp["effect"].median()),
            "negative_fraction": float((grp["effect"] < 0).mean()),
        })
    type_rows.sort(key=lambda r: r["n"], reverse=True)

    out = {
        "n_effects": int(len(valid)),
        "n_events": int(len(event_level)),
        "sensor_level_zero_mae": zero_mae,
        "event_level_zero_mae": baseline_zero,
        "negative_fraction": negative_fraction,
        "by_type": type_rows[:12],
    }
    with open("xtraffic_counterfactual_evaluation.json", "w",
              encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)


if __name__ == "__main__":
    main()
