"""Direction 1 empirical validation: recovery error vs protocol shift.

Splits the causal-head recovery error into (a) synthetic self-consistency
(in-distribution, shift ~ 0), (b) a shift term that grows with factor
deviation / duration / unseen-zone novelty, and reports (c) the residual
as the honest upper bound of the misspecification term.
"""
import json
import os
import sys

import numpy as np
import torch

os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "src/model")

from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"


def batch(samples, start, size):
    b = samples[start:start + size]
    zones = torch.zeros(len(b), 48, dtype=torch.long)
    ff = torch.zeros(len(b), 48, 12)
    cf = torch.zeros(len(b), 48, 12)
    ice = torch.zeros(len(b), 6)
    et = torch.full((len(b), 5), -1, dtype=torch.long)
    el = torch.zeros(len(b), 5, 2)
    etm = torch.zeros(len(b), 5)
    zs = torch.zeros(len(b), 5, 12)
    for i, d in enumerate(b):
        zones[i] = d["zone"]
        ff[i] = d["factual"]
        cf[i] = d["cf"]
        ice[i] = d["ice_true"]
        c = d["combo"]
        et[i] = c["event_types"]
        el[i] = c["event_locs"]
        etm[i] = c["event_times"]
        zs[i] = c["zone_states"]
    return {"zones": zones.to(device), "ff": ff.to(device),
            "cf": cf.to(device), "ice": ice.to(device), "et": et.to(device),
            "el": el.to(device), "etm": etm.to(device), "zs": zs.to(device)}


def recover(samples, model):
    ests, trues, protos = [], [], []
    with torch.no_grad():
        for i in range(0, len(samples), 64):
            b = batch(samples, i, 64)
            combo = {"event_types": b["et"], "event_locs": b["el"],
                     "event_times": b["etm"], "zone_states": b["zs"]}
            e = model.causal_effect(
                {"zone_ids": b["zones"], "features": b["ff"]},
                {"zone_ids": b["zones"], "features": b["cf"]}, combo)
            ests.append(e[:, 0].cpu().numpy())
            trues.append(b["ice"][:, 0].cpu().numpy())
            protos.extend([s.get("protocol") for s in samples[i:i + 64]])
    return (np.concatenate(ests), np.concatenate(trues),
            np.array([p if p else {"factor": None, "duration": None}
                      for p in protos], dtype=object))


def main():
    ckpt = "data/nyc_taxi/processed/rerun_v3_seed42.pt"
    ind = np.load("data/nyc_taxi/processed/"
                  "synthetic_pairs_v3_graphctx.npy", allow_pickle=True).item()
    ood = np.load("data/nyc_taxi/processed/"
                  "synthetic_pairs_v3_graphctx_ood.npy", allow_pickle=True).item()
    model = STWaveCausalV3(n_zones=265, input_dim=12, output_dim=6,
                           ctx_channels=6).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()

    est_i, true_i, _ = recover(ind["test"], model)
    est_o, true_o, protos = recover(ood["test"], model)
    err_i = np.abs(est_i - true_i)
    err_o = np.abs(est_o - true_o)

    # in-distribution baseline (shift ~ 0)
    eps_opt = float(err_i.mean())
    # training factor support center (geometric mean of 0.56, 0.7, 0.8)
    f_center = float(np.exp(np.mean(np.log([0.56, 0.7, 0.8]))))
    factors = np.array([p["factor"] for p in protos], dtype=float)
    durations = np.array([p["duration"] for p in protos], dtype=float)
    factor_dev = np.abs(np.log(factors) - np.log(f_center))

    def mae(mask):
        m = np.asarray(mask, dtype=bool)
        return float(err_o[m].mean()) if m.sum() else None

    by_dur = {int(d): mae(durations == d) for d in sorted(set(durations))}
    bins = {"low": factor_dev < np.quantile(factor_dev, 0.33),
            "mid": (factor_dev >= np.quantile(factor_dev, 0.33)) &
                   (factor_dev < np.quantile(factor_dev, 0.67)),
            "high": factor_dev >= np.quantile(factor_dev, 0.67)}
    by_factor = {k: mae(v) for k, v in bins.items()}
    by_dur_factor = {}
    for d in sorted(set(durations)):
        for k in bins:
            by_dur_factor["%d_%s" % (int(d), k)] = mae(
                (durations == d) & bins[k])

    corr_oe = float(np.corrcoef(err_o, factor_dev)[0, 1]) if np.std(factor_dev) > 0 else None
    out = {
        "baseline_in_dist": {"mae": eps_opt, "n": int(len(err_i))},
        "ood_aggregate": {"mae": float(err_o.mean()), "n": int(len(err_o)),
                          "corr_err_factor_dev": corr_oe},
        "ood_by_duration": by_dur,
        "ood_by_factor_dev_bin": by_factor,
        "ood_by_duration_x_factor": by_dur_factor,
        "factor_center": f_center,
    }
    with open("direction1_transfer_bound.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)


if __name__ == "__main__":
    main()
