"""Sharp partial-identification envelope under counterfactual-definition
uncertainty.

The observable-equivalent family in `direction2_misspec_bound.py` contains
four rules that reach the same target-zone factual effect through different
mechanisms. Without an external choice among those mechanisms, the real
counterfactual is only identified up to the finite-family envelope. This
script computes that envelope and its finite-sample uncertainty from the full
300-sample direction-2 artifact.
"""

import argparse
import json
import subprocess
import sys

import numpy as np


def bootstrap_ci(values, quantile=0.9, n_boot=1000, seed=20260907, alpha=0.05):
    rng = np.random.RandomState(seed)
    vals = np.asarray(values, dtype=float)
    qs = np.empty(n_boot, dtype=float)
    means = np.empty(n_boot, dtype=float)
    for i in range(n_boot):
        idx = rng.randint(0, len(vals), size=len(vals))
        sample = vals[idx]
        qs[i] = np.quantile(sample, quantile)
        means[i] = sample.mean()
    lo = float(np.quantile(means, alpha / 2))
    hi = float(np.quantile(means, 1 - alpha / 2))
    qlo = float(np.quantile(qs, alpha / 2))
    qhi = float(np.quantile(qs, 1 - alpha / 2))
    return {"mean_ci95": [lo, hi], "q90_ci95": [qlo, qhi]}


def compute_envelope(rows):
    epsilons = []
    widths = []
    endpoints = []
    covered = 0

    for row in rows:
        values = np.asarray([float(v) for v in row["est"].values()])
        truth = float(row["ice_true"])
        eps = float(np.max(np.abs(values - truth)))
        lo = float(values.min() - eps)
        hi = float(values.max() + eps)
        epsilons.append(eps)
        widths.append(hi - lo)
        endpoints.append((lo, hi))
        covered += int(lo <= truth <= hi)

    endpoints = np.asarray(endpoints, dtype=float)
    epsilons = np.asarray(epsilons, dtype=float)
    widths = np.asarray(widths, dtype=float)
    ci = bootstrap_ci(widths, quantile=0.9)
    return {
        "coverage_rate": float(covered / len(rows)),
        "epsilon_mean": float(epsilons.mean()),
        "epsilon_p90": float(np.quantile(epsilons, 0.90)),
        "width_mean": float(widths.mean()),
        "width_median": float(np.median(widths)),
        "width_p90": float(np.quantile(widths, 0.90)),
        "width_max": float(widths.max()),
        "width_bootstrap_ci95": ci["mean_ci95"],
        "width_q90_bootstrap_ci95": ci["q90_ci95"],
        "minimax_mean_half_width": float(widths.mean() / 2.0),
        "minimax_p90_half_width": float(np.quantile(widths, 0.90) / 2.0),
        "minimax_max_half_width": float(widths.max() / 2.0),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output",
                        default="direction4_partial_identifiability.json")
    parser.add_argument("--seeds", nargs="+", type=int, default=[42, 1, 2])
    parser.add_argument("--rng-seed", type=int, default=20260907)
    parser.add_argument("--n-eval", type=int, default=300)
    args = parser.parse_args()

    per_seed = {}
    for model_seed in args.seeds:
        checkpoint = (f"data/nyc_taxi/processed/rerun_v3_seed{model_seed}.pt")
        intermediate = f"direction2_misspec_bound_seed{model_seed}.json"
        subprocess.run(
            [sys.executable, "direction2_misspec_bound.py",
             "--checkpoint", checkpoint,
             "--output", intermediate,
             "--n-eval", str(args.n_eval),
             "--seed", str(args.rng_seed)],
            check=True,
        )
        d = json.load(open(intermediate, encoding="utf-8"))
        per_seed[str(model_seed)] = compute_envelope(d["per_sample"])

    width_means = np.asarray([per_seed[str(s)]["width_mean"]
                              for s in args.seeds])
    width_p90s = np.asarray([per_seed[str(s)]["width_p90"]
                             for s in args.seeds])
    lower_means = np.asarray([per_seed[str(s)]["minimax_mean_half_width"]
                              for s in args.seeds])
    out = {
        "protocol_name": "Sharp partial identification under "
                          "counterfactual-definition uncertainty",
        "status": "complete",
        "model_seeds": args.seeds,
        "n_eval_per_seed": args.n_eval,
        "rules": ["multiplicative", "additive", "spillover", "duration"],
        "per_seed": per_seed,
        "aggregate": {
            "width_mean_mean": float(width_means.mean()),
            "width_mean_std": float(width_means.std(ddof=1)),
            "width_p90_mean": float(width_p90s.mean()),
            "width_p90_std": float(width_p90s.std(ddof=1)),
            "minimax_mean_half_width_mean": float(lower_means.mean()),
            "minimax_mean_half_width_std": float(lower_means.std(ddof=1)),
        },
    }
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2, default=str), flush=True)


if __name__ == "__main__":
    main()
