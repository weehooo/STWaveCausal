"""P2: vectorized probe of per-dimension standardized-feature PSM counts/SMD."""
import sys
from pathlib import Path

import numpy as np

from src.preprocess.psm_matching import balance_check

BASE = Path(r"F:\xuexi\codex\papers")


def precompute_state(features, n_hist=3):
    T, N, D = features.shape
    state = np.zeros((T, N, D), dtype=np.float64)
    for t in range(T):
        lo = max(0, t - n_hist)
        hi = t + 1 if t < n_hist else t
        state[t] = features[lo:hi].mean(axis=0)
    return state


def psm_variant(state, labels, combo_map, caliper=0.1, time_buffer=3, seed=42):
    T, N, D = state.shape
    rng = np.random.RandomState(seed)
    matches = []
    int_events = [(t, z) for t in range(T)
                  if combo_map[t] for z in combo_map[t]["events"]]
    max_samp = 30000
    if len(int_events) > max_samp:
        idx = rng.choice(len(int_events), max_samp, replace=False)
        int_events = [int_events[i] for i in idx]
    for (t, z) in int_events:
        t_start = max(0, t - 7 * 48)
        t_end = min(T, t + 7 * 48)
        if t_end - t_start <= 0:
            continue
        idxs = np.arange(t_start, t_end)
        mask = np.abs(idxs - t) >= time_buffer
        mask = mask & (labels[idxs, z] == 0)
        if not mask.any():
            continue
        cand = idxs[mask]
        d = np.linalg.norm(state[cand, z] - state[t, z], axis=1)
        keep = d < caliper
        if not keep.any():
            continue
        best = int(cand[keep][np.argmin(d[keep])])
        matches.append({"t": int(t), "t_star": best, "zone": int(z),
                        "feature_dist": 0.0})
    return matches


def main():
    for name in ["nyc_taxi", "pems_bay", "pems08", "pems04"]:
        p = BASE / "data" / name / "processed"
        labels = np.load(str(p / "labels.npy"))
        features = np.load(str(p / "node_features.npy")).astype(np.float64)
        T, N, D = features.shape
        mu = features.mean(axis=(0, 1))
        sd = features.std(axis=(0, 1)) + 1e-8
        zf = (features - mu) / sd
        combo = {}
        for t in range(T):
            z = np.where(labels[t] == 1)[0]
            combo[t] = {"events": [int(x) for x in z]} if z.size else None
        state = precompute_state(zf)
        print("[%s] standardized matching..." % name, flush=True)
        m = psm_variant(state, labels, combo)
        bal = balance_check(m, zf)
        smd = list(bal["smd"].values())
        print("  pairs=%d max_smd=%.4f mean_smd=%.4f passed=%s" % (
            len(m), max(smd), float(np.mean(smd)), bal["passed"]), flush=True)


if __name__ == "__main__":
    sys.exit(main())
