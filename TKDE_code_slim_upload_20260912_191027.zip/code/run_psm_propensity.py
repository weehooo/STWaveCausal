"""Fitted-propensity-score matching for all four traffic datasets.

The paper's main PSM implementation uses covariate distance.  This companion
script estimates an explicit propensity score, matches on its caliper, and
reports overlap with the original matched set.  It writes separate outputs so
the original benchmark is never overwritten.
"""
import argparse
import gc
import json
import os
import sys

import numpy as np
import torch

BASE = os.environ.get("PAPERS_BASE", os.path.dirname(os.path.abspath(__file__)))
os.chdir(BASE)
sys.path.insert(0, ".")

from src.preprocess.psm_matching import balance_check

DATASETS = ["nyc_taxi", "pems_bay", "pems08", "pems04"]
CALIPERS = [0.01, 0.02, 0.05, 0.10]


def rolling_state(features, n_hist=3):
    x = np.asarray(features, dtype=np.float32)
    csum = np.cumsum(x, axis=0, dtype=np.float32)
    state = np.empty_like(x)
    state[:n_hist] = [csum[i] / (i + 1) for i in range(n_hist)]
    state[n_hist:] = (csum[n_hist:] - csum[:-n_hist]) / n_hist
    return state


def calendar_features(length):
    t = np.arange(length, dtype=np.float32)
    return np.stack([np.sin(2 * np.pi * t / 336),
                     np.cos(2 * np.pi * t / 336)], axis=1)


class LogisticPS(torch.nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.linear = torch.nn.Linear(dim, 1)

    def forward(self, x):
        return self.linear(x).squeeze(-1)


def fit_propensity(state, labels, seed=42, epochs=200, lr=1e-3, max_fit=50000):
    treated = np.argwhere(labels == 1)
    control_pool = np.argwhere(labels == 0)
    rng = np.random.RandomState(seed)
    if len(treated) > max_fit // 2:
        treated = treated[rng.choice(len(treated), max_fit // 2,
                                     replace=False)]
    if len(control_pool) > max_fit // 2:
        control_pool = control_pool[rng.choice(len(control_pool), max_fit // 2,
                                                replace=False)]
    fit_idx = np.concatenate([treated, control_pool])
    x_fit = np.concatenate([state[fit_idx[:, 0], fit_idx[:, 1]],
                            calendar_features(state.shape[0])[fit_idx[:, 0]]],
                           axis=1).astype(np.float32)
    y_fit = labels[fit_idx[:, 0], fit_idx[:, 1]].astype(np.float32)
    mu, sd = x_fit.mean(0), x_fit.std(0) + 1e-6
    x_fit = (x_fit - mu) / sd

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = LogisticPS(x_fit.shape[1]).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr,
                           weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    xt = torch.from_numpy(x_fit).to(device)
    yt = torch.from_numpy(y_fit).to(device)
    generator = torch.Generator(device="cpu").manual_seed(seed)
    model.train()
    batch = min(8192, len(xt))
    for _ in range(epochs):
        perm = torch.randperm(len(xt), generator=generator).to(device)
        for lo in range(0, len(xt), batch):
            idx = perm[lo:lo + batch]
            opt.zero_grad()
            loss = torch.nn.functional.binary_cross_entropy_with_logits(
                model(xt[idx]), yt[idx])
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
        sched.step()

    T, N = labels.shape
    prop = np.empty((T, N), dtype=np.float32)
    cal = calendar_features(T).astype(np.float32)
    with torch.no_grad():
        model.eval()
        for start in range(0, N, 32):
            stop = min(N, start + 32)
            block = np.concatenate(
                [state[:, start:stop], np.broadcast_to(cal[:, None, :],
                                                       (T, stop - start, 2))],
                axis=2).reshape(-1, x_fit.shape[1]).astype(np.float32)
            block = (block - mu) / sd
            out = []
            for lo in range(0, len(block), 65536):
                xb = torch.from_numpy(block[lo:lo + 65536]).to(device)
                out.append(torch.sigmoid(model(xb)).cpu().numpy())
            prop[:, start:stop] = np.concatenate(out).reshape(T, stop - start)
    return model, prop, {"mu": mu.tolist(), "sd": sd.tolist()}


def match_on_propensity(prop, labels, caliper, time_buffer=3, max_events=30000,
                        seed=42):
    events = np.argwhere(labels == 1)
    rng = np.random.RandomState(seed)
    if len(events) > max_events:
        events = events[rng.choice(len(events), max_events, replace=False)]
    matches = []
    for t, z in events:
        lo = max(0, t - 7 * 48)
        hi = min(labels.shape[0], t + 7 * 48)
        candidates = np.arange(lo, hi)
        candidates = candidates[(np.abs(candidates - t) >= time_buffer) &
                                (labels[candidates, z] == 0)]
        if not len(candidates):
            continue
        distances = np.abs(prop[candidates, z] - prop[t, z])
        keep = distances <= caliper
        if not keep.any():
            continue
        candidates = candidates[keep]
        distances = distances[keep]
        best = int(candidates[np.argmin(distances)])
        matches.append({"t": int(t), "t_star": best, "zone": int(z),
                        "propensity_distance": float(distances.min())})
    return matches


def pair_key_set(matches):
    return {(m["zone"], m["t"], m["t_star"]) for m in matches}


def process(name, args):
    path = os.path.join("data", name, "processed")
    features = np.load(os.path.join(path, "node_features.npy"), mmap_mode="r")
    labels = np.load(os.path.join(path, "labels.npy"))
    print("%s loading/cumsum" % name, flush=True)
    state = rolling_state(features)
    print("%s fitting propensity" % name, flush=True)
    _, prop, normalizer = fit_propensity(state, labels, seed=args.seed,
                                         epochs=args.epochs, max_fit=args.max_fit)
    treated = prop[labels == 1]
    control = prop[labels == 0]
    overlap = {
        "treated_mean": float(treated.mean()),
        "control_mean": float(control.mean()),
        "treated_p05": float(np.quantile(treated, 0.05)),
        "control_p95": float(np.quantile(control, 0.95)),
        "outside_common_support": float(np.mean((treated < np.quantile(control, 0.01)) |
                                                  (treated > np.quantile(control, 0.99)))),
    }

    attempts = {}
    chosen = None
    for caliper in CALIPERS:
        matches = match_on_propensity(prop, labels, caliper,
                                      time_buffer=args.time_buffer,
                                      max_events=args.max_events, seed=args.seed)
        balance = balance_check(matches, state)
        smd = list(balance["smd"].values())
        summary = {"pairs": len(matches), "caliper": caliper,
                   "max_smd": float(max(smd)), "mean_smd": float(np.mean(smd)),
                   "passed": bool(balance["passed"])}
        attempts[str(caliper)] = summary
        print("%s caliper=%.3f pairs=%d max_smd=%.4f passed=%s" %
              (name, caliper, len(matches), summary["max_smd"],
               summary["passed"]), flush=True)
        if chosen is None and balance["passed"]:
            chosen = (caliper, matches, summary, balance)
    if chosen is None:
        # Keep the largest balanced-attempt record rather than failing silently.
        best_caliper = min(attempts, key=lambda k: attempts[k]["max_smd"])
        matches = match_on_propensity(prop, labels, float(best_caliper),
                                      time_buffer=args.time_buffer,
                                      max_events=args.max_events, seed=args.seed)
        balance = balance_check(matches, state)
        chosen = (float(best_caliper), matches, attempts[best_caliper], balance)

    caliper, matches, summary, balance = chosen
    old_path = os.path.join(path, "matched_pairs.npy")
    if os.path.exists(old_path):
        try:
            old = list(np.load(old_path, allow_pickle=True))
            a = pair_key_set(old)
            b = pair_key_set(matches)
            union = a | b
            summary["overlap_with_covariate_matching"] = {
                "old_pairs": len(a), "propensity_pairs": len(b),
                "shared_pairs": len(a & b),
                "jaccard": round(len(a & b) / max(1, len(union)), 4)}
        except Exception as exc:
            summary["overlap_with_covariate_matching"] = str(exc)
    summary["balance_smd"] = {k: round(v, 5) for k, v in balance["smd"].items()}
    summary["overlap"] = overlap
    summary["normalizer_preview"] = normalizer["mu"][:3]
    np.save(os.path.join(path, "matched_pairs_propensity.npy"),
            np.array(matches, dtype=object))
    del state, prop
    gc.collect()
    return summary


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", nargs="+", default=DATASETS)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--epochs", type=int, default=200)
    ap.add_argument("--max-fit", type=int, default=50000)
    ap.add_argument("--max-events", type=int, default=30000)
    ap.add_argument("--time-buffer", type=int, default=3)
    args = ap.parse_args()

    out = {"seeds": {"fit_seed": args.seed}, "datasets": {}}
    for name in args.datasets:
        print("==", name, flush=True)
        out["datasets"][name] = process(name, args)
    with open("psm_propensity_results.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print("Saved psm_propensity_results.json", flush=True)


if __name__ == "__main__":
    main()
