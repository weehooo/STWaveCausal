"""Probabilistic audit-certificate composition demo.

The paper formalizes a certificate as a composable I/O object. This script
instantiates the statistical version: several external-evidence components
each emit a valid p-value, and the composite certificate controls the
family-wise error by union-bound / budget allocation. It reuses existing JSON
artifacts and does not launch new models.
"""

import argparse
import json

import numpy as np
from scipy import stats


def donor_event_study_p(path):
    d = json.load(open(path, encoding="utf-8"))
    rel = np.asarray(d["pooled_donor_robustness"]["relative_time"], dtype=float)
    mean = np.asarray(d["pooled_donor_robustness"]["mean_effect"], dtype=float)
    se = np.asarray(d["pooled_donor_robustness"]["se"], dtype=float)
    post = mean[rel > 0]
    post_se = se[rel > 0]
    mu = float(post.mean())
    se_mu = float(np.sqrt((post_se ** 2).mean() / len(post)))
    p = float(2 * stats.t.sf(abs(mu / se_mu), len(post) - 1))
    pre_p = float(d["pre_trend"]["pooled_p"])
    return p, pre_p


def incident_min_p(path):
    d = json.load(open(path, encoding="utf-8"))
    tests = d["summary"]["primary"]["tests"]
    p = min(float(t["p_upper"]) for t in tests)
    q = min(float(t["q_bh"]) for t in tests)
    return p, q


def placebo_min_p(path):
    d = json.load(open(path, encoding="utf-8"))
    p = min(float(r["p_one_sided"]) for r in d["pairs"])
    q = min(float(r["q_bh"]) for r in d["pairs"])
    return p, q


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output",
                        default="direction5_certificate_composition.json")
    parser.add_argument("--alpha", type=float, default=0.05)
    args = parser.parse_args()

    p_event, pre_p = donor_event_study_p("pemsbay_eventsudy_results.json")
    p_incident, q_incident = incident_min_p("pemsbay_incident_results.json")
    p_placebo, q_placebo = placebo_min_p("placebo_calibration_results.json")
    components = [
        {"name": "PEMS-BAY donor-matched event study (post effect)",
         "p_value": p_event,
         "artifact": "pemsbay_eventsudy_results.json"},
        {"name": "PEMS-BAY incident top-k enrichment",
         "p_value": p_incident,
         "artifact": "pemsbay_incident_results.json"},
        {"name": "Placebo-calibrated strongest zone",
         "p_value": p_placebo,
         "artifact": "placebo_calibration_results.json"},
    ]
    R = len(components)
    union_bound = float(sum(c["p_value"] for c in components))
    fisher_stat = float(-2.0 * sum(np.log(c["p_value"]) for c in components))
    fisher_p = float(stats.chi2.sf(fisher_stat, 2 * R))
    alpha_j = args.alpha / R
    all_pass = all(c["p_value"] <= alpha_j for c in components)

    out = {
        "protocol_name": "Probabilistic audit-certificate composition",
        "status": "complete",
        "alpha": args.alpha,
        "n_components": R,
        "components": components,
        "pre_trend_control": {
            "pooled_pre_slope_p": pre_p,
            "interpretation": "retained as a design check; not part of the "
                             "external localization rejection set",
        },
        "composition": {
            "budget_per_component": alpha_j,
            "union_bound_family_wise_error": union_bound,
            "fisher_combined_p": fisher_p,
            "composite_passes": all_pass,
            "comment": "Union bound is valid under arbitrary dependence; "
                       "Fisher's combination is reported under the "
                       "independence interpretation.",
        },
    }
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2, default=str), flush=True)


if __name__ == "__main__":
    main()
