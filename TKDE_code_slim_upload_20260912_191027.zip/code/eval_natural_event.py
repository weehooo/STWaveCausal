"""Generalized natural-event placebo test with the V3 model.

Usage: python eval_natural_event.py --date 2011-01-26
"""
import argparse
import os
import sys
from datetime import datetime, timedelta

import numpy as np
import torch
import torch.nn as nn

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, "src/model")

from stwave import STWaveBlock
from stwave_causal_v3 import STWaveCausalV3
from scipy.stats import norm

device = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48
CF_OFFSET = 7 * 7 * 48  # 7 weeks earlier
start = datetime(2011, 1, 1, 0, 0, 0)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--date", required=True, help="YYYY-MM-DD")
    p.add_argument("--ckpt", default="data/nyc_taxi/processed/stwave_causal_v3_full_best.pt")
    args = p.parse_args()
    event = datetime.strptime(args.date, "%Y-%m-%d")
    t0 = int((event - start).total_seconds() / (30 * 60))
    print("Event:", args.date, "t:", t0, flush=True)

    feats = np.load("data/nyc_taxi/processed/node_features.npy", mmap_mode="r")
    labels = np.load("data/nyc_taxi/processed/labels.npy", mmap_mode="r")
    model = STWaveCausalV3(n_zones=265, input_dim=6).to(device)
    model.load_state_dict(torch.load(args.ckpt, map_location=device))
    model.eval()

    def window(zone, t):
        ts = max(0, t - SEQ)
        w = feats[ts:t, zone].copy()
        if len(w) < SEQ:
            w = np.concatenate([np.zeros((SEQ - len(w), 6)), w])
        return w

    @torch.no_grad()
    def ace(zone, t, t_star):
        ff = torch.FloatTensor(window(zone, t)).unsqueeze(0).to(device)
        cf = torch.FloatTensor(window(zone, t_star)).unsqueeze(0).to(device)
        zid = torch.full((1, SEQ), zone, dtype=torch.long, device=device)
        _, pf = model(zid, ff)
        _, pcf = model(zid, cf)
        return float(np.mean(np.abs(pf[0].cpu().numpy() - pcf[0].cpu().numpy())))

    impacts = []
    for zone in range(265):
        pre = feats[t0 - SEQ:t0, zone, 0].mean()
        post = feats[t0:t0 + SEQ, zone, 0].mean()
        if abs(post - pre) > 0.3:
            impacts.append((zone, float(abs(post - pre)), float(pre), float(post)))
    impacts.sort(key=lambda x: x[1], reverse=True)
    print("Impacted zones:", len(impacts), flush=True)

    rng = np.random.RandomState(42)
    results = []
    for zone, imp, pre, post in impacts[:20]:
        t_star = t0 - CF_OFFSET
        if t_star <= SEQ:
            continue
        ace_event = ace(zone, t0, t_star)
        placebos = []
        for _ in range(200):
            t = int(rng.randint(SEQ + 1, feats.shape[0] - 1))
            if abs(t - t0) < 1000 or labels[t, zone] != 0:
                continue
            ts2 = t - CF_OFFSET
            if ts2 > SEQ:
                placebos.append(ace(zone, t, ts2))
        if len(placebos) < 50:
            continue
        mu, sd = float(np.mean(placebos)), float(np.std(placebos))
        z = (ace_event - mu) / (sd + 1e-8)
        results.append((zone, ace_event, mu, sd, z))
        print("Zone %3d: event ACE=%.3f placebo mean=%.3f std=%.3f z=%.2f"
              % (zone, ace_event, mu, sd, z), flush=True)

    zs = [r[4] for r in results]
    if zs:
        best = max(results, key=lambda r: r[4])
        print("Most-affected significant zone: %d z=%.2f p=%.4f"
              % (best[0], best[4], norm.sf(best[4])), flush=True)
        print("z>1.96 count: %d/%d, mean z=%.2f, median z=%.2f"
              % (sum(z > 1.96 for z in zs), len(zs), np.mean(zs), np.median(zs)),
              flush=True)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
