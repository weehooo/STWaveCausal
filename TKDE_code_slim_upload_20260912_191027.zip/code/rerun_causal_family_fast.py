"""P3-1 fast protocol: 3 seeds (42,1,2), seed-42-first feasibility gate.

Execution order: for each seed, run both models on all four datasets.  This
surfaces all seed-42 numbers within ~2 days so the new-pair results can be
checked against the old table before spending compute on seeds 1-2.
Completed runs are skipped via rerun_<tag>.done markers.
"""
import subprocess
import sys
import os
from datetime import datetime
from pathlib import Path

BASE = Path(os.environ.get("PAPERS_BASE", r"F:\xuexi\codex\papers"))
PY = os.environ.get("PYTHON_BIN", r"F:\Anaconda3\python.exe")
SEEDS = [42, 1, 2]

DATASETS = {
    "nyc_taxi": {"zones": 265, "dim": 6, "v3_epochs": 50, "v3_pretrain": 0,
                 "ctx_mode": "mean"},
    "pems_bay": {"zones": 325, "dim": 8, "v3_epochs": 70, "v3_pretrain": 50,
                 "ctx_mode": "gradient"},
    "pems08": {"zones": 170, "dim": 1, "v3_epochs": 90, "v3_pretrain": 70,
               "ctx_mode": "mean",
               "meta": "data/datasets/pems08_staeformer/data.npz"},
    "pems04": {"zones": 307, "dim": 1, "v3_epochs": 90, "v3_pretrain": 70,
               "ctx_mode": "mean",
               "meta": "data/datasets/pems04_staeformer/data.npz"},
}


def run(cmd, tag):
    out_log = BASE / ("rerun_%s_out.log" % tag)
    err_log = BASE / ("rerun_%s_err.log" % tag)
    print("[%s] start %s" % (datetime.now().strftime("%H:%M:%S"), tag),
          flush=True)
    with out_log.open("w") as fo, err_log.open("w") as fe:
        p = subprocess.Popen(cmd, cwd=str(BASE), stdout=fo, stderr=fe)
        code = p.wait()
    if code != 0:
        raise SystemExit("%s exited with code %d" % (tag, code))
    print("[%s] done  %s" % (datetime.now().strftime("%H:%M:%S"), tag),
          flush=True)


def v3_cmd(name, cfg, seed):
    data = str(BASE / "data" / name / "processed")
    out = str(Path(data) / ("rerun_v3_seed%d.pt" % seed))
    cmd = [
        PY, "train_causal_v3_full.py",
        "--data", data,
        "--synthetic", str(Path(data) / "synthetic_pairs_v3_graphctx.npy"),
        "--n-zones", str(cfg["zones"]),
        "--feature-dim", str(cfg["dim"]),
        "--epochs", str(cfg["v3_epochs"]),
        "--pretrain-epochs", str(cfg["v3_pretrain"]),
        "--out", out,
        "--seed", str(seed),
        "--graph-ctx",
        "--ctx-mode", cfg["ctx_mode"],
        "--ctx-gate",
    ]
    if cfg.get("meta"):
        cmd += ["--meta-file", str(BASE / cfg["meta"])]
    return cmd


def stid_cmd(name, cfg, seed):
    data = str(BASE / "data" / name / "processed")
    out = str(Path(data) / ("rerun_stid_seed%d.pt" % seed))
    return [
        PY, "train_causal_stid.py",
        "--data", data,
        "--synthetic", str(Path(data) / "synthetic_pairs_fullnode.npy"),
        "--n-zones", str(cfg["zones"]),
        "--feature-dim", str(cfg["dim"]),
        "--epochs", "130",
        "--pretrain-epochs", "110",
        "--batch-size", "8",
        "--out", out,
        "--seed", str(seed),
    ]


def main():
    for seed in SEEDS:
        for name, cfg in DATASETS.items():
            for model_cmd, model_tag in (
                    (v3_cmd, "v3"), (stid_cmd, "stid")):
                tag = "%s_%s_seed%d" % (name, model_tag, seed)
                done = BASE / ("rerun_%s.done" % tag)
                if done.exists():
                    print("skip (done): %s" % tag, flush=True)
                    continue
                run(model_cmd(name, cfg, seed), tag)
                done.write_text("done\n", encoding="utf-8")
    (BASE / "rerun_causal_family_fast.done").write_text("done\n",
                                                        encoding="utf-8")
    print("ALL FAST PROTOCOL RUNS DONE", flush=True)


if __name__ == "__main__":
    sys.exit(main())
