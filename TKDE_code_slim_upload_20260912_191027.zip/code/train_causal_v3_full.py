import argparse
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, "src/model")
os.chdir(os.path.dirname(os.path.abspath(__file__)))

from dataset import TrafficCausalDataset
from stwave_causal_v3 import STWaveCausalV3, collate_v3


def parse_args():
    p = argparse.ArgumentParser(
        description="V3 full training: prediction + contrastive + diversity + causal head")
    p.add_argument("--data", default="data/nyc_taxi/processed")
    p.add_argument("--synthetic", default=None)
    p.add_argument("--n-zones", type=int, default=265)
    p.add_argument("--feature-dim", type=int, default=6)
    p.add_argument("--hidden-dim", type=int, default=64,
                   help="STWave backbone hidden dimension")
    p.add_argument("--output-dim", type=int, default=None,
                   help="prediction/causal output dim (defaults to feature dim)")
    p.add_argument("--epochs", type=int, default=50)
    p.add_argument("--pretrain-epochs", type=int, default=0,
                   help="prediction-only epochs before full causal objective")
    p.add_argument("--out", default="stwave_causal_v3_full_best.pt")
    p.add_argument("--init", default=None,
                   help="checkpoint to resume from (state dict)")
    p.add_argument("--init-graphctx", default=None,
                   help="standard V3 checkpoint for graph-context warm start")
    p.add_argument("--start-epoch", type=int, default=0,
                   help="epoch to resume at (scheduler advanced accordingly)")
    p.add_argument("--pretrain-out", default=None,
                   help="save model right after prediction-only stage")
    p.add_argument("--lambda1", type=float, default=0.3,
                   help="contrastive weight (L_con^s + L_con^m)")
    p.add_argument("--lambda2", type=float, default=0.01,
                   help="diversity regularization weight")
    p.add_argument("--lambda3", type=float, default=0.3,
                   help="causal regression weight")
    p.add_argument("--batch-size", type=int, default=32)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--graph-ctx", action="store_true",
                   help="use graph-context input channels (raw + neighbor ctx)")
    p.add_argument("--ctx-mode", choices=["mean", "gradient"], default="mean",
                   help="graph-context aggregation mode")
    p.add_argument("--meta-file", default=None,
                   help="official data.npz for tod/dow time features")
    p.add_argument("--ctx-gate", action="store_true",
                   help="learn per-zone gating of the graph-context channels")
    p.add_argument("--max-batches", type=int, default=0,
                   help="limit batches per epoch (debug)")
    return p.parse_args()


SEQ_LEN = 48
MAX_EVENTS = 5


def to_device(d, device):
    return {k: v.to(device) if isinstance(v, torch.Tensor) else v
            for k, v in d.items()}


def make_synth_batch(samples, idx_start, batch_size, feature_dim, output_dim,
                     device, feats):
    batch = samples[idx_start:idx_start + batch_size]
    in_width = int(batch[0]["factual"].shape[-1])
    state_width = int(batch[0]["combo"]["zone_states"].shape[-1])
    factual_z = torch.zeros(len(batch), SEQ_LEN, dtype=torch.long)
    factual_f = torch.zeros(len(batch), SEQ_LEN, in_width)
    cf_z = torch.zeros(len(batch), SEQ_LEN, dtype=torch.long)
    cf_f = torch.zeros(len(batch), SEQ_LEN, in_width)
    targets = torch.zeros(len(batch), output_dim)
    ice = torch.zeros(len(batch), output_dim)
    event_types = torch.full((len(batch), MAX_EVENTS), -1, dtype=torch.long)
    event_locs = torch.zeros(len(batch), MAX_EVENTS, 2)
    event_times = torch.zeros(len(batch), MAX_EVENTS)
    zone_states = torch.zeros(len(batch), MAX_EVENTS, state_width)

    for i, d in enumerate(batch):
        z = d["zone"]
        t = int(d["t"])
        factual_z[i] = z
        factual_f[i] = d["factual"]
        cf_z[i] = z
        cf_f[i] = d["cf"]
        if feats is not None:
            targets[i] = torch.FloatTensor(feats[t, z])
        ice[i] = d["ice_true"]
        combo = d["combo"]
        event_types[i] = combo["event_types"]
        event_locs[i] = combo["event_locs"]
        event_times[i] = combo["event_times"]
        zone_states[i] = combo["zone_states"]
    return {
        "zone_ids": factual_z.to(device),
        "features": factual_f.to(device),
        "cf_zone_ids": cf_z.to(device),
        "cf_features": cf_f.to(device),
        "targets": targets.to(device),
        "ice_true": ice.to(device),
        "event_types": event_types.to(device),
        "event_locs": event_locs.to(device),
        "event_times": event_times.to(device),
        "zone_states": zone_states.to(device),
    }


def train_epoch(model, opt, real_loader, synth_samples, feats, args, device, epoch):
    model.train()
    totals = {"loss": 0.0, "pred": 0.0, "cs": 0.0, "cm": 0.0,
              "div": 0.0, "causal": 0.0}
    acc = {k: torch.zeros((), device=device) for k in totals}
    n = 0
    full = epoch >= args.pretrain_epochs
    for i, batch in enumerate(real_loader):
        factual, cf_single, cf_multi, combo, _ = batch
        factual = to_device(factual, device)
        cf_single = to_device(cf_single, device)
        cf_multi = to_device(cf_multi, device)
        combo = to_device(combo, device)

        if not full:
            _, pred = model(factual["zone_ids"], factual["features"])
            L_pred = F.mse_loss(pred, factual["targets"])
            loss = L_pred
            L_cs = L_cm = L_div = L_causal = torch.zeros((), device=device)
        else:
            cl = model.contrastive_loss(factual, cf_single, cf_multi, combo)
            L_pred = cl["L_pred"]
            L_cs = cl["L_con_single"]
            L_cm = cl["L_con_multi"]
            L_div = cl["L_div"]

            s_i = (i * args.batch_size) % len(synth_samples)
            sb = make_synth_batch(synth_samples, s_i, args.batch_size,
                                  args.feature_dim,
                                  args.output_dim or args.feature_dim,
                                  device, feats)
            combo_data = {
                "event_types": sb["event_types"],
                "event_locs": sb["event_locs"],
                "event_times": sb["event_times"],
                "zone_states": sb["zone_states"],
            }
            ice_est = model.causal_effect(
                {"zone_ids": sb["zone_ids"], "features": sb["features"]},
                {"zone_ids": sb["cf_zone_ids"], "features": sb["cf_features"]},
                combo_data)
            L_causal = F.mse_loss(ice_est, sb["ice_true"])
            loss = (L_pred + args.lambda1 * (L_cs + L_cm)
                    + args.lambda2 * L_div + args.lambda3 * L_causal)

        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()

        bs = factual["targets"].shape[0]
        acc["loss"] += loss.detach() * bs
        acc["pred"] += L_pred.detach() * bs
        acc["cs"] += L_cs.detach() * bs
        acc["cm"] += L_cm.detach() * bs
        acc["div"] += L_div.detach() * bs
        acc["causal"] += L_causal.detach() * bs
        n += bs

        if args.max_batches and i + 1 >= args.max_batches:
            break
    return {k: acc[k].item() / max(1, n) for k in totals}


@torch.no_grad()
def evaluate_real(model, loader, device):
    model.eval()
    mae = 0.0
    n = 0
    for batch in loader:
        factual, _, _, _, _ = batch
        f = {k: v.to(device) if isinstance(v, torch.Tensor) else v
             for k, v in factual.items()}
        _, pred = model(f["zone_ids"], f["features"])
        mae += F.l1_loss(pred, f["targets"], reduction="sum").item()
        n += pred.shape[0]
    return mae / n


@torch.no_grad()
def evaluate_synth_causal(model, samples, feature_dim, output_dim, device,
                          batch_size=64):
    model.eval()
    est_all = []
    true_all = []
    for i in range(0, len(samples), batch_size):
        sb = make_synth_batch(samples, i, batch_size, feature_dim, output_dim,
                              device, None)
        combo_data = {
            "event_types": sb["event_types"],
            "event_locs": sb["event_locs"],
            "event_times": sb["event_times"],
            "zone_states": sb["zone_states"],
        }
        ice_est = model.causal_effect(
            {"zone_ids": sb["zone_ids"], "features": sb["features"]},
            {"zone_ids": sb["cf_zone_ids"], "features": sb["cf_features"]},
            combo_data)
        est_all.append(ice_est[:, 0].cpu().numpy())
        true_all.append(sb["ice_true"][:, 0].cpu().numpy())
    est = np.concatenate(est_all)
    true = np.concatenate(true_all)
    corr = np.corrcoef(est, true)[0, 1]
    ratio = est / (true + 1e-6)
    return corr, float(np.median(ratio)), float(np.abs(est - true).mean())


def main():
    args = parse_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Device:", device, flush=True)
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    DATA_DIR = Path(args.data)
    if args.graph_ctx:
        from graphctx_dataset import GraphCtxCausalDataset as DatasetCls
        synthetic_path = (args.synthetic
                          or str(DATA_DIR / "synthetic_pairs_v3_graphctx.npy"))
        dataset_kwargs = {"ctx_mode": args.ctx_mode}
        if args.meta_file:
            raw_meta = np.load(args.meta_file)["data"][..., 1:3].astype(np.float32)
            meta = raw_meta[:, 0]
            dataset_kwargs["meta"] = meta
    else:
        from dataset import TrafficCausalDataset as DatasetCls
        synthetic_path = args.synthetic or str(DATA_DIR / "synthetic_pairs_v3.npy")
        dataset_kwargs = {}
    print("Data:", DATA_DIR, flush=True)
    print("Synthetic:", synthetic_path, flush=True)

    feats = np.load(str(DATA_DIR / "node_features.npy"),
                    mmap_mode="r").astype(np.float32)
    synthetic = np.load(synthetic_path, allow_pickle=True).item()

    td = DatasetCls(str(DATA_DIR), "train", SEQ_LEN, **dataset_kwargs)
    vd = DatasetCls(str(DATA_DIR), "val", SEQ_LEN, **dataset_kwargs)
    tl = torch.utils.data.DataLoader(
        td, batch_size=args.batch_size, shuffle=True,
        collate_fn=collate_v3, num_workers=0)
    vl = torch.utils.data.DataLoader(
        vd, batch_size=args.batch_size, shuffle=False,
        collate_fn=collate_v3, num_workers=0)

    ctx_channels = args.feature_dim if args.graph_ctx else 0
    meta_dim = 2 if args.meta_file else 0
    raw_dim = args.output_dim or args.feature_dim
    model = STWaveCausalV3(
        n_zones=args.n_zones,
        input_dim=args.feature_dim + ctx_channels + meta_dim,
        output_dim=raw_dim, hidden_dim=args.hidden_dim,
        ctx_channels=ctx_channels, ctx_gate=args.ctx_gate
    ).to(device)
    print("Params:", sum(p.numel() for p in model.parameters()), flush=True)
    init_path = args.init_graphctx or args.init
    if init_path:
        if args.graph_ctx and args.init_graphctx:
            sd = torch.load(init_path, map_location=device)
            cur = model.state_dict()
            filtered = {k: v for k, v in sd.items()
                        if k in cur and cur[k].shape == v.shape}
            model.load_state_dict(filtered, strict=False)
            raw_d = args.output_dim or args.feature_dim
            if "input_proj.weight" in sd:
                with torch.no_grad():
                    model.input_proj.weight.data[:, :raw_d] = (
                        sd["input_proj.weight"].to(device))
            print("Loaded graph-context warm start:", init_path, flush=True)
        else:
            model.load_state_dict(torch.load(init_path, map_location=device))
            print("Loaded init checkpoint:", init_path, flush=True)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=args.epochs)
    for _ in range(args.start_epoch):
        sched.step()

    best_mae = float("inf")
    best_state = None
    save_path = DATA_DIR / args.out

    for ep in range(args.start_epoch, args.epochs):
        t0 = time.time()
        m = train_epoch(model, opt, tl, synthetic["train"], feats,
                        args, device, ep)
        sched.step()
        val_mae = evaluate_real(model, vl, device)
        syn_corr, syn_ratio, syn_mae = evaluate_synth_causal(
            model, synthetic["val"], args.feature_dim,
            args.output_dim or args.feature_dim, device)

        if (ep + 1) % 5 == 0 or ep == 0:
            stage = "PRED" if ep < args.pretrain_epochs else "FULL"
            print(
                "Ep {:2d}/{} [{}] loss={:.4f} pred={:.4f} cs={:.4f} cm={:.4f} "
                "div={:.4f} causal={:.4f} valMAE={:.4f} synCorr={:.4f} "
                "synRatio={:.3f} synMAE={:.3f} ({:.1f}s)".format(
                    ep + 1, args.epochs, stage, m["loss"], m["pred"],
                    m["cs"], m["cm"], m["div"], m["causal"], val_mae,
                    syn_corr, syn_ratio, syn_mae, time.time() - t0),
                flush=True)

        if val_mae < best_mae:
            best_mae = val_mae
            best_state = {k: v.cpu() for k, v in model.state_dict().items()}
            torch.save(best_state, str(save_path))
            print("  * best val MAE {:.4f} saved".format(best_mae), flush=True)

        if (args.pretrain_out and args.pretrain_epochs > 0
                and ep == args.pretrain_epochs - 1):
            torch.save({k: v.cpu() for k, v in model.state_dict().items()},
                       args.pretrain_out)
            print("Saved pretrain-stage model:", args.pretrain_out, flush=True)

    print("Best val MAE:", best_mae, flush=True)
    c, r, mae = evaluate_synth_causal(
        model, synthetic["test"], args.feature_dim,
        args.output_dim or args.feature_dim, device)
    print("FINAL synthetic test: corr={:.4f} ratio={:.3f} mae={:.3f}".format(
        c, r, mae), flush=True)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
