"""Sensor-cluster block bootstrap for H1 ensemble-versus-baseline claims."""
import argparse
import gc
import json
import os
import sys
from datetime import datetime, timezone

import numpy as np
import torch

BASE = os.environ.get("PAPERS_BASE", os.path.dirname(os.path.abspath(__file__)))
os.chdir(BASE)
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from eval_h1_flow_baselines import CFGS, targets
from eval_same_split import (collate_ctx, collate_graph, collate_pred,
                             loader_for, preds_features, preds_predonly,
                             preds_stid, preds_stidgraph, preds_v3)
from graphctx_dataset import GraphCtxCausalDataset
from graph_dataset import GraphTrafficDataset
from dataset import TrafficCausalDataset


def abs_error(pred, target):
    return np.abs(pred - target).mean(axis=-1)


def build_loaders(name, cfg, split):
    data_dir = os.path.join("data", name, "processed")
    npz = os.path.join("data", "datasets", f"{name}_staeformer", "data.npz")
    meta = np.load(npz)["data"][..., 1:3][:, 0] if os.path.exists(npz) else None
    ctx = GraphCtxCausalDataset(data_dir, split, 48, ctx_mode=cfg["ctx_mode"],
                                meta=meta)
    graph = GraphTrafficDataset(data_dir, split, 48)
    traffic = TrafficCausalDataset(data_dir, split, 48)
    return loader_for(ctx, collate_ctx), loader_for(graph, collate_graph), \
        loader_for(traffic, collate_pred)


def cluster_ids(loader):
    values = []
    for batch in loader:
        values.append(batch["zone_ids"].numpy())
    return np.concatenate(values)


def prediction_errors(name, cfg, ctx_loader, graph_loader, traffic_loader):
    data_dir = os.path.join("data", name, "processed")
    target = targets(ctx_loader)
    families, baselines = {}, {}
    for seed in ["42", "1", "2"]:
        v3 = preds_v3(cfg["n_zones"], cfg["input_dim"], cfg["output_dim"],
                      cfg["ctx_channels"],
                      f"{data_dir}/rerun_v3_seed{seed}.pt", ctx_loader)
        stid = preds_stid(cfg["n_zones"], cfg["feature_dim"],
                          f"{data_dir}/rerun_stid_seed{seed}.pt",
                          graph_loader)
        ensemble = 0.5 * (v3 + stid)
        families.setdefault("Ens", []).append(abs_error(ensemble, target))
        predonly = preds_predonly(cfg["n_zones"], cfg["feature_dim"],
                                  f"{data_dir}/stwave_predonly_50ep_seed{seed}.pt",
                                  traffic_loader)
        stwave = preds_features(STWave, cfg["n_zones"], cfg["feature_dim"],
                                f"{data_dir}/stwave_best_seed{seed}.pt",
                                traffic_loader, hidden_dim=64, n_blocks=2,
                                seq_len=48)
        crossgnn = preds_features(CrossGNN, cfg["n_zones"],
                                  cfg["feature_dim"],
                                  f"{data_dir}/crossgnn_best_seed{seed}.pt",
                                  traffic_loader, hidden_dim=64, n_blocks=2,
                                  n_heads=4, seq_len=48)
        stidgraph = preds_stidgraph(cfg["n_zones"], cfg["feature_dim"],
                                    f"{data_dir}/stidgraph-{name}_seed{seed}_best.pt",
                                    graph_loader)
        baselines.setdefault("PredOnly", []).append(
            abs_error(predonly, target))
        baselines.setdefault("STWave", []).append(abs_error(stwave, target))
        baselines.setdefault("CrossGNN", []).append(
            abs_error(crossgnn, target))
        baselines.setdefault("STIDGraph", []).append(
            abs_error(stidgraph, target))
        del v3, stid, ensemble, predonly, stwave, crossgnn, stidgraph
        gc.collect()
        torch.cuda.empty_cache()
    family = np.concatenate(families["Ens"])
    return {key: np.concatenate(values) for key, values in
            baselines.items()}, family


def cluster_bootstrap(difference, clusters, n_boot=2000, seed=20260828):
    rng = np.random.RandomState(seed)
    unique = np.unique(clusters)
    rows = np.arange(len(clusters))
    means = np.empty(n_boot)
    for index in range(n_boot):
        chosen = rng.choice(unique, size=len(unique), replace=True)
        mask = np.isin(clusters, chosen)
        means[index] = difference[mask].mean()
    return {
        "mean_difference": float(difference.mean()),
        "ci95": [float(np.quantile(means, 0.025)),
                 float(np.quantile(means, 0.975))],
        "p_bootstrap_positive": float(np.mean(means > 0)),
        "n_clusters": int(len(unique)),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--datasets", nargs="+", default=["pems08", "pems04"])
    parser.add_argument("--output", default="h1_cluster_robust.json")
    args = parser.parse_args()
    output = {"metadata": {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "bootstrap": 2000, "seed": 20260828}, "datasets": {}}
    for name in args.datasets:
        cfg = CFGS[name]
        display = CFGS[name]["display"]
        output["datasets"][display] = {}
        for split in ["val", "test"]:
            ctx_loader, graph_loader, traffic_loader = build_loaders(
                name, cfg, split)
            baselines, family = prediction_errors(
                name, cfg, ctx_loader, graph_loader, traffic_loader)
            clusters = np.tile(cluster_ids(graph_loader), 3)
            output["datasets"][display][split] = {}
            for baseline, errors in baselines.items():
                difference = errors - family
                output["datasets"][display][split][baseline] = \
                    cluster_bootstrap(difference, clusters)
            del ctx_loader, graph_loader, traffic_loader, baselines, family
            gc.collect()
            torch.cuda.empty_cache()
    with open(args.output, "w", encoding="utf-8") as handle:
        json.dump(output, handle, indent=2)
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    from stwave import STWave
    from crossgnn import CrossGNN
    main()
