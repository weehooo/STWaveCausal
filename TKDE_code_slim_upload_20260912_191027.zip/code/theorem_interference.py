"""Simulation validation for the spatial-interference identifiability theorem."""
import numpy as np


def run(rng, gamma, n=30000, p_edge=0.3):
    N = 20
    A = (rng.rand(N, N) < p_edge).astype(np.float64)
    A = np.triu(A, 1)
    A = A + A.T
    deg = A.sum(1)
    d_max = int(deg.max())

    S = rng.uniform(0, 1, n)
    tau = 1.0 + 0.5 * S
    diffs = []
    nb_diff = []
    noise = rng.normal(0, 0.05, n)
    for i in range(n):
        unit = rng.randint(N)
        # neighbor treatments are more frequent at the treated time (spatial
        # clustering), which creates a systematic interference difference.
        T_t = rng.binomial(1, 0.5, N)
        T_c = rng.binomial(1, 0.3, N)
        nd = float(A[unit] @ (T_t - T_c))
        diffs.append(tau[i] + gamma * nd + noise[i])
        nb_diff.append(nd)
    diffs = np.array(diffs)
    nb_diff = np.array(nb_diff)

    naive_bias = float(np.abs(diffs.mean() - tau.mean()))
    # OLS slope for the interference term
    slope = np.polyfit(nb_diff, diffs, 1)[0]
    corrected = diffs - slope * nb_diff
    corrected_bias = float(np.abs(corrected.mean() - tau.mean()))
    bound = gamma * float(np.mean(np.abs(nb_diff)))
    return naive_bias, corrected_bias, bound, d_max


def main():
    rng = np.random.RandomState(42)
    print("p_edge, gamma, naive_bias, corrected_bias, bound, d_max")
    for p_edge in [0.1, 0.4]:
        for gamma in [0.0, 0.2, 0.5, 1.0]:
            nb, cb, bound, dmax = run(rng, gamma, p_edge=p_edge)
            print("%.1f %.2f %.5f %.5f %.5f %d"
                  % (p_edge, gamma, nb, cb, bound, dmax))


if __name__ == "__main__":
    main()
