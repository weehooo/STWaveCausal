"""Temporal dose-response of the V3 ACE during Hurricane Sandy (Zone 78)."""
import os
import sys
from datetime import datetime

import numpy as np
import torch

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, "src/model")

from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48
CF_OFFSET = 7 * 7 * 48
start = datetime(2011, 1, 1)
t0 = int((datetime(2012, 10, 29) - start).total_seconds() / (30 * 60))
zone = 78

feats = np.load("data/nyc_taxi/processed/node_features.npy", mmap_mode="r")
model = STWaveCausalV3(n_zones=265, input_dim=6).to(device)
model.load_state_dict(torch.load(
    "data/nyc_taxi/processed/stwave_causal_v3_full_best.pt", map_location=device))
model.eval()


def window(t):
    ts = max(0, t - SEQ)
    w = feats[ts:t, zone].copy()
    if len(w) < SEQ:
        w = np.concatenate([np.zeros((SEQ - len(w), 6)), w])
    return w


@torch.no_grad()
def ace(t):
    zid = torch.full((1, SEQ), zone, dtype=torch.long, device=device)
    ff = torch.FloatTensor(window(t)).unsqueeze(0).to(device)
    cf = torch.FloatTensor(window(t - CF_OFFSET)).unsqueeze(0).to(device)
    _, pf = model(zid, ff)
    _, pcf = model(zid, cf)
    return float(np.mean(np.abs(pf[0].cpu().numpy() - pcf[0].cpu().numpy())))


print("Sandy Zone 78 temporal dose-response (6-hour blocks)")
for b in range(4):
    idx = slice(b * 12, (b + 1) * 12)
    actual = float(np.mean(feats[t0 + b * 12:t0 + (b + 1) * 12, zone, 0]
                           - feats[t0 - CF_OFFSET + b * 12:t0 - CF_OFFSET + (b + 1) * 12,
                                   zone, 0]))
    ace_b = np.mean([ace(t0 + b * 12 + k) for k in range(12)])
    print("block %d (%02d:%02d-%02d:%02d): actual reduction=%.1f V3 ACE=%.2f"
          % (b + 1, b * 6, 0, (b + 1) * 6, 0, actual, ace_b))
