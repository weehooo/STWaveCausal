"""Build features for a frozen-backbone real-data magnitude head.

For every PEMS-BAY incident used by the model-free event study, this script
stores the frozen STWaveCausalV3 factual/counterfactual embeddings, the
predicted eight-channel effects, and incident covariates. The target is the
model-free event-study post effect, so the magnitude head can be trained and
evaluated with a chronological split.
"""
import json
import os
import sys

import numpy as np
import torch

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, "src/model")

from stwave_causal_v3 import STWaveCausalV3
from eval_pemsbay_eventsudy import load_incidents

device = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48
CF_OFFSET = 7 * 24 * 12
SPEED_CH = 0


def make_window(feats, adj, zone, t):
    t_start = max(0, t - SEQ)
    w_all = feats[t_start:t]
    if len(w_all) < SEQ:
        pad = np.zeros((SEQ - len(w_all), feats.shape[1], feats.shape[2]),
                       dtype=np.float32)
        w_all = np.concatenate([pad, w_all], axis=0)
    raw = w_all[:, zone].astype(np.float32)
    ctx = np.einsum("snd,n->sd", w_all.astype(np.float32),
                    adj[zone].astype(np.float32))
    ctx = ctx - raw
    return np.concatenate([raw, ctx], axis=-1)


def main():
    sensor_ids = [str(v) for v in
                  np.load("data/pems_bay/processed/sensor_ids.npy",
                          allow_pickle=True)]
    idx = {sensor_id: i for i, sensor_id in enumerate(sensor_ids)}
    feats = np.load("data/pems_bay/processed/node_features.npy",
                    mmap_mode="r")
    adj = np.load("data/pems_bay/processed/adj.npy").astype(np.float32)
    adj = adj / np.maximum(adj.sum(axis=1, keepdims=True), 1e-6)

    model = STWaveCausalV3(
        n_zones=325, input_dim=16, output_dim=8, ctx_channels=8,
        ctx_gate=False,
    ).to(device)
    model.load_state_dict(torch.load(
        "data/pems_bay/processed/stwave_causal_v3_graphctx_grad_pemsbay_best.pt",
        map_location=device,
    ))
    model.eval()

    events = load_incidents(
        "data/pems_bay/raw/kaggle_extract/pems_bay_incidents.csv")
    study = json.load(open("pemsbay_eventsudy_results.json", encoding="utf-8"))
    by_id = {r["incident_id"]: r for r in study["per_event"]}

    rows = []
    with torch.no_grad():
        for e in events:
            sid = e["sensor_id"]
            if sid not in idx or e["incident_id"] not in by_id:
                continue
            z = idx[sid]
            t0 = e["start_idx"]
            t_cf = t0 - CF_OFFSET
            if t0 < SEQ or t_cf < 0:
                continue
            ff = torch.FloatTensor(
                make_window(feats, adj, z, t0)).unsqueeze(0).to(device)
            cf = torch.FloatTensor(
                make_window(feats, adj, z, t_cf)).unsqueeze(0).to(device)
            zid = torch.full((1, SEQ), z, dtype=torch.long, device=device)
            h_f, pred_f = model(zid, ff)
            h_cf, pred_cf = model(zid, cf)
            study_row = by_id[e["incident_id"]]
            curve = study_row["curve"]
            post_effect = float(np.mean(curve[6:]))
            severity = int(study_row["type"] in {
                "1183-Trfc Collision-Unkn Inj",
                "1182-Trfc Collision-No Inj",
                "1179-Trfc Collision-1141 Enrt",
                "1181-Trfc Collision-Minor Inj",
                "20001-Hit and Run w/Injuries",
            })
            features = np.concatenate([
                h_f[0].cpu().numpy(),
                h_cf[0].cpu().numpy(),
                pred_f[0].cpu().numpy(),
                pred_cf[0].cpu().numpy(),
                np.array([
                    float(study_row["duration_minutes"]),
                    float(severity),
                    float((t0 % 288) / 288.0),
                    float(((t0 // 288) % 7) / 7.0),
                ], dtype=np.float32),
            ])
            rows.append({
                "incident_id": e["incident_id"],
                "start_idx": int(t0),
                "features": features,
                "post_effect": post_effect,
            })

    rows.sort(key=lambda r: r["start_idx"])
    X = np.stack([r["features"] for r in rows]).astype(np.float32)
    y = np.array([r["post_effect"] for r in rows], dtype=np.float32)
    starts = np.array([r["start_idx"] for r in rows], dtype=np.int32)
    ids = np.array([r["incident_id"] for r in rows])
    np.savez("pemsbay_magnitude_features.npz", X=X, y=y, starts=starts,
             ids=ids)
    with open("pemsbay_magnitude_features_meta.json", "w",
              encoding="utf-8") as f:
        json.dump({"n_events": int(len(rows)), "feature_dim": int(X.shape[1])},
                  f, indent=2)
    print("saved", X.shape, y.shape, flush=True)


if __name__ == "__main__":
    main()
