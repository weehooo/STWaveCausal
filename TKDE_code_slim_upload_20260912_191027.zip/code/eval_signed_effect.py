"""Evaluate a signed, model-based effect estimator on synthetic pairs.

The V3 CausalEffectHead is constrained to non-negative magnitudes. This script
evaluates a complementary signed estimator: predicted counterfactual flow minus
predicted factual flow from the same STWaveCausalV3 backbone. The synthetic
benchmark injects flow reductions, so the signed estimate should be positive
and should recover the known ICE on feature 0.
"""
import json
import os
import sys

import numpy as np
import torch

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, "src/model")

from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"
syn = np.load(
    "data/nyc_taxi/processed/synthetic_pairs_v3_graphctx.npy",
    allow_pickle=True,
).item()
test = syn["test"]


def make_batch(samples, start, size):
    batch = samples[start:start + size]
    zones = torch.zeros(len(batch), 48, dtype=torch.long)
    ff = torch.zeros(len(batch), 48, 12)
    cf = torch.zeros(len(batch), 48, 12)
    ice = torch.zeros(len(batch), 6)
    for i, d in enumerate(batch):
        zones[i] = d["zone"]
        ff[i] = d["factual"]
        cf[i] = d["cf"]
        ice[i] = d["ice_true"]
    return zones, ff, cf, ice


def main():
    model = STWaveCausalV3(
        n_zones=265,
        input_dim=12,
        output_dim=6,
        ctx_channels=0,
    ).to(device)
    model.load_state_dict(torch.load(
        "data/nyc_taxi/processed/stwave_causal_v3_graphctx_nyc_best.pt",
        map_location=device,
    ))
    model.eval()

    signed_estimates = []
    factual_estimates = []
    counterfactual_estimates = []
    true_effects = []
    with torch.no_grad():
        for i in range(0, len(test), 64):
            zones, ff, cf, ice = make_batch(test, i, 64)
            zones = zones.to(device)
            ff = ff.to(device)
            cf = cf.to(device)
            _, pred_f = model(zones, ff)
            _, pred_cf = model(zones, cf)
            # Positive when the intervention reduces flow, matching ICE_true.
            signed = pred_cf - pred_f
            signed_estimates.append(signed[:, 0].cpu().numpy())
            factual_estimates.append(pred_f[:, 0].cpu().numpy())
            counterfactual_estimates.append(pred_cf[:, 0].cpu().numpy())
            true_effects.append(ice[:, 0].cpu().numpy())

    signed = np.concatenate(signed_estimates)
    factual = np.concatenate(factual_estimates)
    counterfactual = np.concatenate(counterfactual_estimates)
    true = np.concatenate(true_effects)

    def metrics(name, est):
        corr = float(np.corrcoef(est, true)[0, 1])
        ratio = float(np.median(est / (true + 1e-6)))
        mae = float(np.abs(est - true).mean())
        print("%-28s corr=%.4f ratio=%.3f MAE=%.3f" % (name, corr, ratio, mae),
              flush=True)
        return {"corr": corr, "median_ratio": ratio, "mae": mae}

    out = {
        "signed_prediction_difference": metrics("Signed prediction difference",
                                                signed),
        "factual_prediction": metrics("Factual prediction", factual),
        "counterfactual_prediction": metrics("Counterfactual prediction",
                                             counterfactual),
    }
    with open("signed_effect_results.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print("Wrote signed_effect_results.json", flush=True)


if __name__ == "__main__":
    main()
