"""Direction 2 empirical DN: observable-equivalent counterfactual family and
the misspecification residual `delta_max`.

The synthetic supervisor calibrates the CausalEffectHead to a *multiplicative
injection on the target zone*. On real data the "no-event" counterfactual is
not observed and a practitioner could define it differently: an additive offset
of the same magnitude, a graph-neighbour spillover, or an effect spread over a
duration. At the target-zone level these constructions are *observable-
equivalent* (they reach the same individual effect on the target), yet through
different mechanisms. The head, trained on only one of them, produces a
different estimate under each. That in-family spread is an empirical,
conservative lower bound on the theorem's misspecification term `delta_max`
(Sec. V-D, Assumption `ass:misspec`).

To keep the measurement self-consistent we anchor the *factual* and the
*combo* to the stored calibration tensors, vary only the counterfactual
construction across the four rules, and recover the exact applied factor from
the stored raw channel 0 (avoiding an off-by-one in the window convention).
"""

import argparse
import json
import os
import sys

import numpy as np
import torch

os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "src/model")

from stwave_causal_v3 import STWaveCausalV3


device = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48
MAX_EVENTS = 5
D = 6          # NYC raw feature channels
N_ZONES = 265
FLOW = slice(0, 4)  # injection acts on the first 4 flow-like channels


def load_model(checkpoint):
    model = STWaveCausalV3(n_zones=N_ZONES, input_dim=2 * D, hidden_dim=64,
                           output_dim=D, ctx_channels=D, ctx_gate=True,
                           seq_len=SEQ, n_events=MAX_EVENTS).to(device)
    state = torch.load(checkpoint, map_location=device)
    if isinstance(state, dict) and "model" in state:
        state = state["model"]
    model.load_state_dict(state)
    model.eval()
    return model


def graphctx(modified, adj, z):
    raw = modified[:, z]
    ctx = np.einsum("snd,n->sd", modified, adj[z])
    return np.concatenate([raw, ctx], axis=-1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint",
                        default="data/nyc_taxi/processed/rerun_v3_seed42.pt")
    parser.add_argument("--pairs",
                        default="data/nyc_taxi/processed/"
                                "synthetic_pairs_v3_graphctx.npy")
    parser.add_argument("--output", default="direction2_misspec_bound.json")
    parser.add_argument("--n-eval", type=int, default=300)
    parser.add_argument("--seed", type=int, default=20260907)
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    rng = np.random.RandomState(args.seed)

    model = load_model(args.checkpoint)
    pairs = np.load(args.pairs, allow_pickle=True).item()["test"]
    feats_full = np.load("data/nyc_taxi/processed/node_features.npy",
                         mmap_mode="r").astype(np.float32)
    adj_raw = np.load("data/nyc_taxi/processed/adj.npy").astype(np.float32)
    adj = adj_raw / np.maximum(adj_raw.sum(axis=1, keepdims=True), 1e-6)

    idx = rng.choice(len(pairs), size=min(args.n_eval, len(pairs)),
                     replace=False)
    rows = []
    dispersion = []
    std_est = []
    std_true = []
    reconstruction_mae = []

    with torch.no_grad():
        for i in idx:
            s = pairs[i]
            z = int(s["zone"])
            t = int(s["t"])
            stu_fact = np.asarray(s["factual"], dtype=np.float32).reshape(
                SEQ, 2 * D)
            stu_cf = np.asarray(s["cf"], dtype=np.float32).reshape(SEQ, 2 * D)
            ice_true = float(s["ice_true"][0])
            if ice_true <= 0:
                continue

            # Recover the exact applied factor from stored raw channel 0.
            fact_last0 = float(stu_fact[SEQ - 1, 0])
            cf_last0 = float(stu_cf[SEQ - 1, 0])
            if fact_last0 <= 0 or cf_last0 <= 0:
                continue
            factor = cf_last0 / fact_last0
            if not (0.05 < factor < 0.95):
                continue

            # Rebuild full raw window exactly as the training generator did.
            t_start = max(0, t - SEQ)
            full = np.asarray(feats_full[t_start:t], dtype=np.float32)
            if full.shape[0] < SEQ:
                pad = np.zeros((SEQ - full.shape[0], N_ZONES, D),
                               dtype=np.float32)
                full = np.concatenate([pad, full], axis=0)
            rebuilt_fact = graphctx(full, adj, z).astype(np.float32)
            reconstruction_mae.append(
                float(np.abs(rebuilt_fact - stu_fact).mean()))

            factual = torch.from_numpy(stu_fact).unsqueeze(0).to(device)
            ids = torch.tensor([[z] * SEQ], dtype=torch.long).to(device)
            # Anchor the event to the stored combo (the exact event input the
            # head was calibrated on), batched to (1, ...).
            sc = s["combo"]
            combo_t = {
                "event_types": sc["event_types"].unsqueeze(0).to(device),
                "event_locs": sc["event_locs"].unsqueeze(0).to(device),
                "event_times": sc["event_times"].unsqueeze(0).to(device),
                "zone_states": sc["zone_states"].unsqueeze(0).to(device),
            }

            def estimate(cf_feats):
                cf_t = torch.from_numpy(
                    np.asarray(cf_feats, dtype=np.float32).reshape(SEQ, 2 * D)
                ).unsqueeze(0).to(device)
                out = model.causal_effect(
                    {"zone_ids": ids, "features": factual},
                    {"zone_ids": ids, "features": cf_t}, combo_t)
                return float(out[0, 0].cpu().numpy())

            # 1. Multiplicative (training rule): the stored counterfactual.
            est_mul = estimate(stu_cf)

            # 2. Additive offset of the same feature-0 effect.
            full_add = full.copy()
            full_add[:, z, 0] = full_add[:, z, 0] - ice_true
            est_add = estimate(graphctx(full_add, adj, z))

            # 3. Neighbour spillover.
            full_sp = full.copy()
            full_sp[:, z, FLOW] *= factor
            nb = np.where(adj[z] > 0.05)[0]
            for nbi in nb:
                if nbi != z:
                    full_sp[:, nbi, FLOW] *= factor
            est_sp = estimate(graphctx(full_sp, adj, z))

            # 4. Duration spread with the same feature-0 total effect.
            dur = 4
            full_du = full.copy()
            per = 1.0 - (1.0 - factor) / dur
            for j in range(dur):
                full_du[SEQ - 1 - j, z, FLOW] *= per
            est_du = estimate(graphctx(full_du, adj, z))

            ests = np.array([est_mul, est_add, est_sp, est_du])
            dispersion.append(float(ests.max() - ests.min()))
            std_est.append(est_mul)
            std_true.append(ice_true)
            rows.append({"zone": z, "t": t, "factor": factor,
                         "ice_true": ice_true,
                         "est": {"multiplicative": est_mul,
                                 "additive": est_add,
                                 "spillover": est_sp,
                                 "duration": est_du},
                         "dispersion": float(ests.max() - ests.min())})

    dispersion = np.array(dispersion)
    std_est = np.array(std_est)
    std_true = np.array(std_true)
    recon_mae = np.array(reconstruction_mae)
    calib_mae = float(np.abs(std_est - std_true).mean())
    calib_rel = float(calib_mae / max(std_true.mean(), 1e-9))

    out = {
        "protocol_name": "Counterfactual-definition sensitivity (delta_max)",
        "status": "complete",
        "n_eval": int(len(rows)),
        "rules": ["multiplicative", "additive", "spillover", "duration"],
        "reconstruction": {
            "graphctx_factual_mae": float(recon_mae.mean()),
            "comment": "L1 mismatch between the rebuilt graph-context factual "
                       "and the stored calibration tensor; small values "
                       "confirm the harness reproduces the feature "
                       "construction.",
        },
        "calibration": {
            "multiplicative_mae_vs_true": calib_mae,
            "multiplicative_relative_mae": calib_rel,
            "mean_true_effect": float(std_true.mean()),
            "comment": "calibration of the training (multiplicative) rule "
                       "using the stored counterfactual; should reproduce "
                       "the reported in-distribution self-consistency.",
        },
        "in_family_dispersion": {
            "mean": float(dispersion.mean()),
            "median": float(np.median(dispersion)),
            "p90": float(np.quantile(dispersion, 0.90)),
            "max": float(dispersion.max()),
            "relative_to_mean_true": float(dispersion.mean()
                                           / max(std_true.mean(), 1e-9)),
        },
        "bound": {
            "delta_max_empirical_lower_bound": float(
                np.quantile(dispersion, 0.90)),
            "delta_max_conservative": float(dispersion.max()),
            "delta_max_relative_p90": float(
                np.quantile(dispersion, 0.90)
                / max(std_true.mean(), 1e-9)),
            "interpretation": "in-family spread of the head estimate across "
                             "observable-equivalent counterfactual "
                             "constructions; a conservative empirical lower "
                             "bound on delta_max.",
        },
        "per_sample": rows,
    }
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps({k: v for k, v in out.items() if k != "per_sample"},
                     indent=2, default=str), flush=True)


if __name__ == "__main__":
    main()
