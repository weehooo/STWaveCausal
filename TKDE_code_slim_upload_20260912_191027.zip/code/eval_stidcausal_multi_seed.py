"""PEMS04 5-seed summary: STIDCausal vs STIDGraph, single + ensemble."""
import os
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.stats import wilcoxon

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from graph_dataset import GraphTrafficDataset
from stid_graph import STIDGraph
from stid_causal import STIDCausal

DATA = "data/pems04/processed"
device = "cuda" if torch.cuda.is_available() else "cpu"

SC_CKPTS = [
    DATA + "/stid_causal_pems04_best.pt",
    DATA + "/stid_causal_pems04_seed1.pt",
    DATA + "/stid_causal_pems04_seed2.pt",
    DATA + "/stid_causal_pems04_seed3.pt",
    DATA + "/stid_causal_pems04_seed4.pt",
]
STID_CKPTS = [
    DATA + "/stidgraph-pems04_best.pt",
    DATA + "/stidgraph-pems04_seed1_best.pt",
    DATA + "/stidgraph-pems04_seed2_best.pt",
    DATA + "/stidgraph-pems04_seed3_best.pt",
    DATA + "/stidgraph-pems04_seed4_best.pt",
]


def collate_graph(batch):
    return {
        "zone_ids": torch.stack([b["zone_ids"] for b in batch]),
        "features": torch.stack([b["features"] for b in batch]),
        "targets": torch.stack([b["targets"] for b in batch]),
        "adj": batch[0]["adj"],
    }


def run_preds(model, loader, use_causal):
    model.eval()
    ps, ts = [], []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) if isinstance(v, torch.Tensor) else v
                 for k, v in batch.items()}
            if use_causal:
                _, pred = model(f["features"], f["zone_ids"], f["adj"])
            else:
                pred = model(f["features"], f["zone_ids"], f["adj"])
            ps.append(pred.cpu().numpy())
            ts.append(f["targets"].cpu().numpy())
    return np.concatenate(ps, axis=0), np.concatenate(ts, axis=0)


def main():
    print("Device:", device)
    ds = GraphTrafficDataset(DATA, "val", 48)
    loader = torch.utils.data.DataLoader(ds, batch_size=16, shuffle=False,
                                         collate_fn=collate_graph)

    sc_all, st_all = [], []
    for ck in SC_CKPTS:
        m = STIDCausal(n_zones=307, input_dim=1, output_dim=1).to(device)
        m.load_state_dict(torch.load(ck, map_location=device))
        p, t = run_preds(m, loader, True)
        sc_all.append(p)
    for ck in STID_CKPTS:
        m = STIDGraph(n_zones=307, input_dim=1, hidden_dim=64, seq_len=48,
                      n_layers=2, n_days=7).to(device)
        m.load_state_dict(torch.load(ck, map_location=device))
        p, t = run_preds(m, loader, False)
        st_all.append(p)
    tgt = t

    sc_mae = [float(np.abs(p - tgt).mean()) for p in sc_all]
    st_mae = [float(np.abs(p - tgt).mean()) for p in st_all]
    print("STIDCausal per-seed:", ["%.4f" % x for x in sc_mae])
    print("STIDCausal mean %.4f std %.4f best %.4f" %
          (np.mean(sc_mae), np.std(sc_mae), np.min(sc_mae)))
    print("STIDGraph per-seed:", ["%.4f" % x for x in st_mae])
    print("STIDGraph mean %.4f std %.4f best %.4f" %
          (np.mean(st_mae), np.std(st_mae), np.min(st_mae)))

    sc_ens = np.mean(sc_all, axis=0)
    st_ens = np.mean(st_all, axis=0)
    print("STIDCausal ensemble MAE: %.4f" %
          np.abs(sc_ens - tgt).mean())
    print("STIDGraph ensemble MAE: %.4f" %
          np.abs(st_ens - tgt).mean())

    b3 = int(np.argmin(sc_mae))
    bs = int(np.argmin(st_mae))
    _, p1 = wilcoxon(np.abs(sc_all[b3] - tgt)[:, 0],
                     np.abs(st_all[bs] - tgt)[:, 0])
    _, p2 = wilcoxon(np.abs(sc_ens - tgt)[:, 0],
                     np.abs(st_ens - tgt)[:, 0])
    print("Wilcoxon STIDCausal-best vs STIDGraph-best p=%.4g" % p1)
    print("Wilcoxon STIDCausal-ens vs STIDGraph-ens p=%.4g" % p2)
    print("ALL DONE")


if __name__ == "__main__":
    main()
