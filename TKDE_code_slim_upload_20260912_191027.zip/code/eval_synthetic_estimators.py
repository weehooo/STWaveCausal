"""Compare V3 causal head with naive window-difference estimators on
synthetic pairs with known ground-truth effects (NYC)."""
import os
import sys
from pathlib import Path

import numpy as np
import torch

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, "src/model")

from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"
syn = np.load(
    "data/nyc_taxi/processed/synthetic_pairs_v3_graphctx.npy",
    allow_pickle=True).item()
test = syn["test"]


def synth_batch(samples, start, size):
    batch = samples[start:start + size]
    zones = torch.zeros(len(batch), 48, dtype=torch.long)
    ff = torch.zeros(len(batch), 48, 12)
    cf = torch.zeros(len(batch), 48, 12)
    ice = torch.zeros(len(batch), 6)
    et = torch.full((len(batch), 5), -1, dtype=torch.long)
    el = torch.zeros(len(batch), 5, 2)
    etm = torch.zeros(len(batch), 5)
    zs = torch.zeros(len(batch), 5, 12)
    for i, d in enumerate(batch):
        zones[i] = d["zone"]
        ff[i] = d["factual"]
        cf[i] = d["cf"]
        ice[i] = d["ice_true"]
        c = d["combo"]
        et[i] = c["event_types"]
        el[i] = c["event_locs"]
        etm[i] = c["event_times"]
        zs[i] = c["zone_states"]
    return {"zones": zones.to(device), "ff": ff.to(device), "cf": cf.to(device),
            "ice": ice.to(device), "et": et.to(device), "el": el.to(device),
            "etm": etm.to(device), "zs": zs.to(device)}


def main():
    model = STWaveCausalV3(n_zones=265, input_dim=12, output_dim=6,
                           ctx_channels=0).to(device)
    model.load_state_dict(torch.load(
        "data/nyc_taxi/processed/stwave_causal_v3_graphctx_nyc_best.pt",
        map_location=device))
    model.eval()
    print("Device:", device, "n_test:", len(test), flush=True)

    ests = []
    trues = []
    win_diff = []
    last_diff = []
    with torch.no_grad():
        for i in range(0, len(test), 64):
            b = synth_batch(test, i, 64)
            combo = {"event_types": b["et"], "event_locs": b["el"],
                     "event_times": b["etm"], "zone_states": b["zs"]}
            e = model.causal_effect(
                {"zone_ids": b["zones"], "features": b["ff"]},
                {"zone_ids": b["zones"], "features": b["cf"]}, combo)
            ests.append(e[:, 0].cpu().numpy())
            trues.append(b["ice"][:, 0].cpu().numpy())
            ff = b["ff"].cpu().numpy()
            cf = b["cf"].cpu().numpy()
            win_diff.append(np.abs(ff - cf)[..., 0].mean(axis=1))
            last_diff.append(np.abs(ff - cf)[:, -1, 0])
    est = np.concatenate(ests)
    true = np.concatenate(trues)
    wd = np.concatenate(win_diff)
    ld = np.concatenate(last_diff)

    rows = [("V3 CausalEffectHead", est),
            ("Window-difference (before-after)", wd),
            ("Last-step difference", ld)]
    print("%-32s %8s %10s %8s" % ("estimator", "corr", "med ratio", "MAE"))
    out = {}
    for name, x in rows:
        corr = float(np.corrcoef(x, true)[0, 1])
        ratio = float(np.median(x / (true + 1e-6)))
        mae = float(np.abs(x - true).mean())
        print("%-32s %8.4f %10.3f %8.3f" % (name, corr, ratio, mae))
        out[name] = {"corr": corr, "median_ratio": ratio, "mae": mae}
    with open("synthetic_estimator_comparison.json", "w",
              encoding="utf-8") as f:
        import json
        json.dump(out, f, indent=2)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
