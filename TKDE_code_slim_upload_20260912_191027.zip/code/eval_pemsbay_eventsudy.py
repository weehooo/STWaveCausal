"""Event-study / difference-in-differences audit on PEMS-BAY incidents.

This is a *model-free* quasi-experimental audit. For each documented incident
we take the affected sensor as the treated unit and a pool of clean (no
incident inside the event window), pre-trend-matched sensors as donors. We
estimate the event-time trajectory of the treatment effect as

    tau(k) = [Y_treated(k) - Y_donor(k)]
             - mean_{j in pre} [Y_treated(j) - Y_donor(j)],

for relative time k around the incident, where Y is the observed speed channel
(channel 0 of the processed tensor). This is a two-way-fixed / parallel-trend
estimator with a pre-period baseline correction. We additionally report

  * a pre-trend test (slope of the pre-period treated-minus-donor gap),
  * a pooled event-study curve averaged over all incidents,
  * a dose-response regression of the post effect on incident duration and
    severity, and
  * a sanity placebo: time-permuted / donor-only contrasts.

The audit is deliberately upstream of any model: it establishes whether
documented incidents causally shift the observed speed of the affected sensor
and by how much, which is the magnitude benchmark the main paper currently
only proxies via enrichment.
"""

import argparse
import hashlib
import json
import os
import sys
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats


BASE = Path(os.environ.get("PAPERS_BASE", Path(__file__).resolve().parent))
os.chdir(BASE)

EPOCH = datetime(2017, 1, 1)
WINDOW_MINUTES = 5
SEQ = 48
CF_OFFSET = 7 * 24 * 12
N_SENSORS = 325
TOTAL_WINDOWS = 52116
SPEED_CH = 0
HOLIDAYS = {"2017-01-02", "2017-01-16", "2017-02-20", "2017-05-29"}
PRE, POST = 6, 6          # relative-time window in 5-min steps each side
CONTAMINATION_BUFFER = 12  # 1 hour: also excluded from donor pool
IMPORTANT_TYPES = {
    "1183-Trfc Collision-Unkn Inj", "1182-Trfc Collision-No Inj",
    "1179-Trfc Collision-1141 Enrt", "1181-Trfc Collision-Minor Inj",
    "1125-Traffic Hazard", "20001-Hit and Run w/Injuries",
    "20002-Hit and Run No Injuries", "CFIRE-Car Fire",
    "FLOOD-Roadway Flooding", "1166-Defective Traffic Signals",
    "WW-Wrong Way Driver", "CLOSURE of a Road", "1184-Provide Traffic Control",
}


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_incidents(path):
    incidents = pd.read_csv(path)
    incidents["sensor_id"] = incidents["nearest_sensor_id"].astype(str)
    incidents = incidents[incidents["sensor_id"].isin(
        [str(v) for v in np.load("data/pems_bay/processed/sensor_ids.npy",
                                 allow_pickle=True)])].copy()
    incidents = incidents[incidents["type"].isin(IMPORTANT_TYPES)].copy()
    incidents["timestamp"] = pd.to_datetime(incidents["timestamp"])
    incidents = incidents[
        (incidents["timestamp"] >= EPOCH) &
        (incidents["timestamp"] < datetime(2017, 7, 1))].copy()
    incidents["start_idx"] = (
        (incidents["timestamp"] - EPOCH).dt.total_seconds() //
        (WINDOW_MINUTES * 60)).astype(int)
    duration = incidents["duration"].fillna(0).clip(lower=0)
    incidents["end_idx"] = (
        (incidents["timestamp"] + pd.to_timedelta(duration, unit="m")
         - EPOCH).dt.total_seconds() // (WINDOW_MINUTES * 60)).astype(int)
    events = []
    for row in incidents.itertuples(index=False):
        start, end = int(row.start_idx), int(row.end_idx)
        if start < CF_OFFSET + SEQ or end + SEQ >= TOTAL_WINDOWS:
            continue
        date = (EPOCH + timedelta(minutes=start * WINDOW_MINUTES)).date()
        if date.isoformat() in HOLIDAYS:
            continue
        events.append({
            "incident_id": str(row.id),
            "timestamp": str(row.timestamp),
            "start_idx": start,
            "end_idx": max(end, start),
            "duration_minutes": float(row.duration) if
            not np.isnan(row.duration) else 0.0,
            "type": str(row.type),
            "sensor_id": str(row.sensor_id),
            "date": date.isoformat(),
        })
    events.sort(key=lambda e: e["timestamp"])
    return events


def sensor_index(sensor_ids):
    return {sensor_id: idx for idx, sensor_id in enumerate(sensor_ids)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--incidents",
                        default="data/pems_bay/raw/kaggle_extract/"
                                "pems_bay_incidents.csv")
    parser.add_argument("--output", default="pemsbay_eventsudy_results.json")
    parser.add_argument("--n-donors", type=int, default=12)
    parser.add_argument("--min-duration", type=float, default=0.0)
    parser.add_argument("--limit-events", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260907)
    args = parser.parse_args()

    rng = np.random.RandomState(args.seed)
    sensor_ids = [str(v) for v in
                  np.load("data/pems_bay/processed/sensor_ids.npy",
                          allow_pickle=True)]
    idx = sensor_index(sensor_ids)
    feats = np.load("data/pems_bay/processed/node_features.npy",
                    mmap_mode="r")[:, :, SPEED_CH]  # (T, N) speed
    events = load_incidents(args.incidents)
    if args.min_duration > 0:
        events = [e for e in events if e["duration_minutes"] >= args.min_duration]
    if args.limit_events:
        events = events[:args.limit_events]

    # Incident-affected mask with a contamination buffer, for donor exclusion.
    affected = np.zeros((TOTAL_WINDOWS, N_SENSORS), dtype=bool)
    for e in events:
        lo = max(0, e["start_idx"] - CONTAMINATION_BUFFER)
        hi = min(TOTAL_WINDOWS, e["end_idx"] + CONTAMINATION_BUFFER + 1)
        affected[lo:hi, idx[e["sensor_id"]]] = True

    rel = np.arange(-PRE, POST + 1)  # event-time offsets
    N_DAYS = TOTAL_WINDOWS // 288
    minute_of_day = np.arange(TOTAL_WINDOWS) % 288
    day_of_window = np.arange(TOTAL_WINDOWS) // 288
    # Clean-day mask per sensor: a day is a valid control day for sensor s if
    # no incident (with buffer) on that sensor falls inside that calendar day.
    sensor_day_incident = np.zeros((N_SENSORS, N_DAYS), dtype=bool)
    for e in events:
        di = e["start_idx"] // 288
        s = idx[e["sensor_id"]]
        if 0 <= di < N_DAYS:
            sensor_day_incident[s, di] = True

    all_effects = []  # list of (rho, k)
    donor_effects = []
    pre_trends = []
    dose = []
    n_events_used = 0
    n_events_skipped = 0

    for e in events:
        s = idx[e["sensor_id"]]
        t0 = e["start_idx"]
        if t0 - PRE < 0 or t0 + POST >= TOTAL_WINDOWS:
            n_events_skipped += 1
            continue
        full_idx = t0 + rel

        treated = np.asarray(feats[full_idx][:, s], dtype=float)
        # Seasonality-aware counterfactual: same sensor, same clock time, clean
        # control days. This absorbs the dominant diurnal/weekly cycle that a
        # short pre-window cannot.
        clean_days = np.where(~sensor_day_incident[s])[0]
        cf = np.empty(len(rel), dtype=float)
        for j, t in enumerate(full_idx):
            mod = minute_of_day[t]
            cand_t = clean_days * 288 + mod
            cand_t = cand_t[(cand_t >= 0) & (cand_t < TOTAL_WINDOWS)]
            if cand_t.size < 10:
                cand_t = np.arange(mod, TOTAL_WINDOWS, 288)
            cf[j] = float(np.asarray(
                feats[cand_t][:, s], dtype=float).mean())

        # Donor pool: clean (not affected anywhere in the event window), and
        # with a valid pre-period.
        window_mask = (~affected[t0 - PRE - CONTAMINATION_BUFFER:
                                 t0 + POST + CONTAMINATION_BUFFER + 1, :]
                       .any(axis=0))
        donor_pool = np.where(window_mask)[0]
        donor_pool = donor_pool[donor_pool != s]
        if donor_pool.size < args.n_donors:
            n_events_skipped += 1
            continue

        # Pre-period donor features for similarity matching: level + trend.
        pre_treat = np.asarray(feats[t0 - PRE:t0, donor_pool], dtype=float)
        pre_level = pre_treat.mean(axis=0)
        # vectorized per-donor linear trend (slope) without np.polyfit(axis=)
        xr = np.arange(PRE, dtype=float)
        xc = xr - xr.mean()
        denom = float((xc ** 2).sum())
        pre_trend = ((pre_treat - pre_treat.mean(axis=0)).T @ xc) / denom
        feat_pool = np.stack([pre_level, pre_trend], axis=1)
        t_level = float(feats[t0 - PRE:t0, s].mean())
        txr = np.asarray(feats[t0 - PRE:t0, s], dtype=float)
        t_trend = float((txr - txr.mean()) @ xc / denom)
        feat_t = np.array([t_level, t_trend])
        # Standardize by pool spread for distance matching.
        spread = np.maximum(feat_pool.std(axis=0), 1e-6)
        dist = np.linalg.norm((feat_pool - feat_t) / spread, axis=1)
        order = np.argsort(dist)
        donors = donor_pool[order[:args.n_donors]]

        donor_curve = np.asarray(
            feats[full_idx][:, donors], dtype=float).mean(axis=1)

        # Primary effect: seasonality-aware, against the same-sensor clean-day
        # same-clock counterfactual, with a pre-period baseline correction.
        gap = treated - cf
        pre_gap = gap[:PRE]
        effect = gap - float(pre_gap.mean())
        # Cross-sectional robustness effect: against clean donor sensors.
        donor_gap = treated - donor_curve
        donor_effect = donor_gap - float(donor_gap[:PRE].mean())
        all_effects.append((e, effect))
        donor_effects.append((e, donor_effect))

        # Pre-trend test: regress pre-period gap on relative pre-time.
        slope, intercept, r, p, se = stats.linregress(rel[:PRE], pre_gap)
        pre_trends.append({"incident_id": e["incident_id"],
                           "sensor_id": e["sensor_id"],
                           "slope": float(slope), "p": float(p)})
        post_effect = float(effect[PRE:].mean())
        donor_post_effect = float(donor_effect[PRE:].mean())
        dose.append({"incident_id": e["incident_id"],
                     "sensor_id": e["sensor_id"],
                     "date": e["date"], "type": e["type"],
                     "duration_minutes": e["duration_minutes"],
                     "start_idx": e["start_idx"],
                     "post_effect": post_effect,
                     "donor_post_effect": donor_post_effect,
                     "peak_effect": float(abs(effect[PRE:]).max())})
        n_events_used += 1

    # Pooled event-study curve (mean effect per relative-time offset).
    pooled = np.zeros(len(rel), dtype=float)
    pooled_n = 0
    curves = []
    donor_curves = []
    for e, effect in all_effects:
        curves.append(effect)
        pooled += effect
        pooled_n += 1
    for e, donor_effect in donor_effects:
        donor_curves.append(donor_effect)
    if pooled_n:
        pooled /= pooled_n
    pooled_se = np.std(curves, axis=0) / np.sqrt(pooled_n) if pooled_n else \
        np.zeros(len(rel))
    pooled_donor = np.mean(donor_curves, axis=0) if donor_curves else \
        np.zeros(len(rel))
    pooled_donor_se = np.std(donor_curves, axis=0) / np.sqrt(len(donor_curves)) \
        if donor_curves else np.zeros(len(rel))
    pooled_donor_n = len(donor_curves)

    # Parallel-trends summary across events.
    pre_slopes = np.array([tr["slope"] for tr in pre_trends])
    pre_pvals = np.array([tr["p"] for tr in pre_trends])
    n_pre_significant = int((pre_pvals < 0.05).sum())
    # Pooled pre-period shape: residual trend after the fitted line.
    pr = stats.linregress(rel[:PRE], pooled[:PRE])

    # Dose-response: linear regression of post effect on duration and severity.
    dose_df = pd.DataFrame(dose)
    dose_reg = None
    if len(dose_df) >= 5:
        # severity proxy = 5*matched_type + duration, in the spirit of the
        # registry definition.
        dose_df["severity"] = (dose_df["duration_minutes"]
                               + 5.0 * dose_df["type"].apply(
                                   lambda t: int(t in {"1183-Trfc Collision-Unkn Inj",
                                                       "1182-Trfc Collision-No Inj",
                                                       "1179-Trfc Collision-1141 Enrt",
                                                       "1181-Trfc Collision-Minor Inj",
                                                       "20001-Hit and Run w/Injuries"})))
        x = dose_df[["duration_minutes", "severity"]].values.astype(float)
        y = dose_df["post_effect"].values.astype(float)
        X = np.column_stack([np.ones(len(x)), x])
        try:
            beta, *_ = np.linalg.lstsq(X, y, rcond=None)
            resid = y - X @ beta
            dof = max(len(x) - X.shape[1], 1)
            s2 = float(resid @ resid / dof)
            cov = s2 * np.linalg.pinv(X.T @ X)
            se = np.sqrt(np.maximum(np.diag(cov), 0.0))
            dose_reg = {"beta_duration": float(beta[1]),
                        "se_duration": float(se[1]),
                        "beta_severity": float(beta[2]),
                        "se_severity": float(se[2]),
                        "n": int(len(x)),
                        "r2": float(1 - resid.var() / y.var()) if y.var() > 0
                        else 0.0}
        except Exception as exc:  # pragma: no cover - defensive
            dose_reg = {"error": str(exc)}

    # Placebo: per-event effect at a time-permuted incident start (same sensor,
    # a random clean week), to sanity-check the null distribution.
    placebo_effects = []
    for e, effect in all_effects[:200]:
        s = idx[e["sensor_id"]]
        t0 = e["start_idx"]
        # pick a start that keeps the same window and is far from any incident
        candidates = np.arange(t0 - 4000, t0 + 4000, 288 * 7)
        candidates = candidates[(candidates - PRE >= 0) &
                                (candidates + POST < TOTAL_WINDOWS)]
        candidates = candidates[~affected[candidates, s]]
        if candidates.size == 0:
            continue
        t_p = int(rng.choice(candidates))
        full_p = t_p + rel
        pre_p = feats[t_p - PRE:t_p, s]
        pre_n = np.asarray(feats[t_p - PRE:t_p].astype(np.float32),
                           dtype=float).mean(axis=0)
        # nearest donors to this synthetic treated mean
        ddist = np.abs(np.nan_to_num(pre_n, nan=0.0) -
                       np.nan_to_num(np.mean(pre_p), nan=0.0))
        dpool = np.where(~affected[np.clip(full_p, 0, TOTAL_WINDOWS - 1), :]
                         .any(axis=0))[0]
        dpool = dpool[dpool != s]
        if dpool.size < 5:
            continue
        donors = dpool[np.argsort(ddist[dpool])[:args.n_donors]]
        t_pl = np.asarray(feats[full_p][:, s], dtype=float)
        d_pl = np.asarray(feats[full_p][:, donors], dtype=float).mean(axis=1)
        gap_p = t_pl - d_pl
        effect_p = gap_p - gap_p[:PRE].mean()
        placebo_effects.append(float(effect_p[PRE:].mean()))
    placebo_effects = np.array(placebo_effects)
    placebo = {"n": int(placebo_effects.size),
               "mean": float(placebo_effects.mean()) if placebo_effects.size
               else None,
               "std": float(placebo_effects.std()) if placebo_effects.size
               else None,
               "q05": float(np.quantile(placebo_effects, 0.05))
               if placebo_effects.size else None,
               "q95": float(np.quantile(placebo_effects, 0.95))
               if placebo_effects.size else None}

    # Good events = those whose 95% CI excludes zero post effect.
    good = []
    for e, effect in all_effects:
        post = effect[PRE:]
        ci = stats.t.interval(0.95, max(len(post) - 1, 1),
                              loc=post.mean(), scale=post.std(ddof=1)
                              / np.sqrt(len(post)) if post.std(ddof=1) > 0
                              else 0.0)
        if ci[0] > 0 or ci[1] < 0:
            good.append(e["incident_id"])

    out = {
        "protocol_name": "PEMS-BAY model-free event-study / DiD audit",
        "status": "complete",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "metadata": {
            "speed_channel": SPEED_CH,
            "window_minutes": WINDOW_MINUTES,
            "relative_time": {
                "pre_steps": PRE, "post_steps": POST,
                "labels": [int(k) for k in rel]},
            "n_donors": args.n_donors,
            "contamination_buffer": CONTAMINATION_BUFFER,
            "seed": args.seed,
            "input_sha256": sha256(args.incidents),
        },
        "configuration": {
            "events_read": len(events),
            "events_used": n_events_used,
            "events_skipped": n_events_skipped,
            "min_duration": args.min_duration,
        },
        "pooled_event_study": {
            "relative_time": [int(k) for k in rel],
            "mean_effect": [float(x) for x in pooled],
            "se": [float(x) for x in pooled_se],
            "n_events": pooled_n,
        },
        "pooled_donor_robustness": {
            "relative_time": [int(k) for k in rel],
            "mean_effect": [float(x) for x in pooled_donor],
            "se": [float(x) for x in pooled_donor_se],
            "n_events": pooled_donor_n,
        },
        "pre_trend": {
            "pooled_slope": float(pr.slope),
            "pooled_r": float(pr.rvalue),
            "pooled_p": float(pr.pvalue),
            "median_event_slope": float(np.median(pre_slopes))
            if pre_slopes.size else None,
            "n_events_pre_p_lt_0_05": n_pre_significant,
            "n_events": int(pre_slopes.size),
        },
        "dose_response": dose_reg,
        "placebo": placebo,
        "n_events_ci_excludes_zero_post_effect": len(good),
        "summary": {
            "mean_peak_post_effect": float(
                np.mean([np.abs(np.asarray(eff)[PRE:]).max()
                         for _, eff in all_effects])) if all_effects else None,
            "median_peak_post_effect": float(
                np.median([np.abs(np.asarray(eff)[PRE:]).max()
                           for _, eff in all_effects])) if all_effects else None,
            "mean_post_effect": float(
                np.mean([np.asarray(eff)[PRE:].mean()
                         for _, eff in all_effects])) if all_effects else None,
        },
        "per_event": [{"incident_id": e["incident_id"],
                       "sensor_id": e["sensor_id"], "date": e["date"],
                       "type": e["type"],
                       "duration_minutes": e["duration_minutes"],
                       "start_idx": e["start_idx"],
                       "curve": [float(x) for x in effect]}
                      for e, effect in all_effects],
    }
    Path(args.output).write_text(
        json.dumps(out, indent=2), encoding="utf-8")
    print(f"events read={len(events)} used={n_events_used} "
          f"skipped={n_events_skipped} -> {args.output}")


if __name__ == "__main__":
    main()
