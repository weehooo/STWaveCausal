"""External-documentation validation of real concurrent event pairs.

Treatment footprints come from public NOAA Storm Events records mapped to NYC
boroughs, not from post-hoc flow drops.  The primary estimands are ICE_A,
ICE_B, their joint effect JCE_AB, and the interaction residual
JCE_AB - ICE_A - ICE_B.
"""
import argparse
import json
import os
import sys
from datetime import datetime

import numpy as np
import torch

BASE = os.environ.get("PAPERS_BASE", os.path.dirname(os.path.abspath(__file__)))
os.chdir(BASE)
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from stwave_causal_v3 import STWaveCausalV3
from eval_events_new import SWPred, window_raw, window_v3

device = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48
CF_OFFSET = 7 * 7 * SEQ
START = datetime(2011, 1, 1)
N_ZONES = 265
TYPE_IDS = {
    "coastal flood": 0,
    "flash flood": 1,
    "flood": 2,
    "heavy rain": 3,
    "heavy snow": 4,
    "high wind": 5,
    "ice storm": 6,
    "strong wind": 7,
    "winter storm": 8,
    "winter weather": 9,
}


def time_index(timestamp):
    seconds = (datetime.fromisoformat(timestamp) - START).total_seconds()
    return int(round(seconds / 1800))


def zones_for_borough(registry_zones, borough):
    return sorted(int(v["zone_id"]) for v in registry_zones.values()
                  if v["borough"] == borough)


def active_zones(registry_zones, boroughs, baseline):
    zones = []
    for borough in boroughs:
        zones.extend(zones_for_borough(registry_zones, borough))
    zones = sorted(set(zones))
    # County-level records include some very low-activity pseudo-zones.
    return [z for z in zones if baseline[z] >= 5]


def make_combo(events, zones_union, t_state, adj):
    max_events = 5
    types = torch.full((len(zones_union), max_events), -1, dtype=torch.long)
    locs = torch.zeros(len(zones_union), max_events, 2)
    times = torch.zeros(len(zones_union), max_events)
    states = torch.zeros(len(zones_union), max_events, 12)
    for slot, event in enumerate(events[:max_events]):
        event_type = TYPE_IDS.get(event["category"].lower(), 0)
        start_idx = time_index(event["start_time"])
        end_idx = time_index(event["end_time"])
        types[:, slot] = event_type
        times[:, slot] = float(max(start_idx, 0))
        for row, zone in enumerate(zones_union):
            raw = np.asarray(feats[int(t_state), int(zone)])
            ctx = np.einsum("nd,n->d", np.asarray(feats[int(t_state)]),
                            adj[int(zone)])
            states[row, slot, :] = torch.FloatTensor(np.concatenate([raw, ctx]))
    return {
        "event_types": types.to(device),
        "event_locs": locs.to(device),
        "event_times": times.to(device),
        "zone_states": states.to(device),
    }


def sequences_for_zones(model_kind, zones, t_event, t_counterfactual):
    factual, counterfactual, ids = [], [], []
    for zone in zones:
        ids.append(torch.full((SEQ,), int(zone), dtype=torch.long))
        if model_kind == "v3":
            factual.append(torch.FloatTensor(window_v3(int(zone),
                                                        int(t_event))))
            counterfactual.append(torch.FloatTensor(window_v3(
                int(zone), int(t_counterfactual))))
        else:
            factual.append(torch.FloatTensor(window_raw(int(zone),
                                                         int(t_event))))
            counterfactual.append(torch.FloatTensor(window_raw(
                int(zone), int(t_counterfactual))))
    return {
        "zone_ids": torch.stack(ids).to(device),
        "features": torch.stack(factual).to(device),
    }, {
        "zone_ids": torch.stack(ids).to(device),
        "features": torch.stack(counterfactual).to(device),
    }


@torch.no_grad()
def model_effects(v3, pair, registry_zones, adj, t_event, t_cf):
    baseline = np.array([feats[t_cf:t_cf + SEQ, z, 0].mean()
                         for z in range(N_ZONES)])
    zones_a = active_zones(registry_zones, [pair["events"][0]["borough"]],
                           baseline)
    zones_b = active_zones(registry_zones, [pair["events"][1]["borough"]],
                           baseline)
    zones_union = sorted(set(zones_a) | set(zones_b))
    outputs = {}
    combos = {}
    events = pair["events"]
    for name, active in [
        ("ICE_A", [events[0]]),
        ("ICE_B", [events[1]]),
        ("JCE_AB", events),
    ]:
        factual, counterfactual = sequences_for_zones("v3", zones_union,
                                                      t_event, t_cf)
        combo = make_combo(active, zones_union, t_event, adj)
        effects = v3.causal_effect(factual, counterfactual, combo)
        outputs[name] = effects[:, 0].cpu().numpy()
        combos[name] = {"zones": zones_union, "raw_effects": outputs[name]}
    result = {
        "zones_a": zones_a,
        "zones_b": zones_b,
        "zones_union": zones_union,
        "ICE_A": float(outputs["ICE_A"].mean()),
        "ICE_B": float(outputs["ICE_B"].mean()),
        "JCE_AB": float(outputs["JCE_AB"].mean()),
        "interaction": float(outputs["JCE_AB"].mean() -
                             outputs["ICE_A"].mean() -
                             outputs["ICE_B"].mean()),
        "per_zone": {name: values.tolist() for name, values in outputs.items()},
    }
    del outputs, combos
    return result


@torch.no_grad()
def predonly_effect(po, pair, registry_zones, adj, t_event, t_cf):
    baseline = np.array([feats[t_cf:t_cf + SEQ, z, 0].mean()
                         for z in range(N_ZONES)])
    zones_union = active_zones(registry_zones,
                               [pair["events"][0]["borough"],
                                pair["events"][1]["borough"]], baseline)
    factual, counterfactual = sequences_for_zones("predonly", zones_union,
                                                  t_event, t_cf)
    diff = np.mean(np.abs(factual["features"].cpu().numpy() -
                          counterfactual["features"].cpu().numpy()),
                   axis=2)[:, 0]
    return {"zones_union": zones_union,
            "prediction_difference": float(diff.mean())}


def bootstrap_ci(values, n_boot=2000, seed=42):
    rng = np.random.RandomState(seed)
    values = np.asarray(values)
    means = [values[rng.randint(0, len(values), len(values))].mean()
             for _ in range(n_boot)]
    return [float(np.quantile(means, 0.025)),
            float(np.quantile(means, 0.975))]


def json_default(value):
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.floating):
        return float(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    raise TypeError(f"not JSON serializable: {type(value)}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", default="real_event_pairs_selected.json")
    ap.add_argument("--registry", default="real_event_registry.json")
    ap.add_argument("--n-placebo", type=int, default=60)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    with open(args.pairs, encoding="utf-8") as f:
        pairs = json.load(f)["pairs"]
    with open(args.registry, encoding="utf-8") as f:
        registry_zones = json.load(f)["zones"]

    feats = np.load("data/nyc_taxi/processed/node_features.npy", mmap_mode="r")
    labels = np.load("data/nyc_taxi/processed/labels.npy", mmap_mode="r")
    adj = np.load("data/nyc_taxi/processed/adj.npy").astype(np.float32)
    adj /= np.maximum(adj.sum(axis=1, keepdims=True), 1e-6)
    globals()["_adj"] = adj
    globals()["feats"] = feats

    v3 = STWaveCausalV3(n_zones=N_ZONES, input_dim=12, output_dim=6,
                        ctx_channels=6).to(device)
    v3.load_state_dict(torch.load(
        "data/nyc_taxi/processed/rerun_v3_seed42.pt", map_location=device))
    po = SWPred(N_ZONES, 6).to(device)
    po.load_state_dict(torch.load(
        "data/nyc_taxi/processed/stwave_predonly_50ep_seed1.pt",
        map_location=device))
    v3.eval()
    po.eval()

    real_windows = []
    results = []
    for pair in pairs:
        starts = [time_index(e["start_time"]) for e in pair["events"]]
        t_event = min(starts)
        t_cf = t_event - CF_OFFSET
        valid = t_cf >= SEQ and t_event + SEQ < feats.shape[0]
        if not valid:
            continue
        real_windows.extend(range(t_event - 14 * 48, t_event + 14 * 48))
        observed = model_effects(v3, pair, registry_zones, adj, t_event, t_cf)
        observed["predonly"] = predonly_effect(po, pair, registry_zones, adj,
                                                t_event, t_cf)
        observed["effect_cis"] = {
            key: bootstrap_ci(observed["per_zone"][key])
            for key in ["ICE_A", "ICE_B", "JCE_AB"]
        }

        original_date = datetime.fromordinal(
            START.toordinal() + t_event // 48).weekday()
        rng = np.random.RandomState(args.seed + pair["selection_rank"])
        candidates = []
        for t in range(CF_OFFSET + SEQ + 48,
                       feats.shape[0] - SEQ - 48):
            candidate_date = datetime.fromordinal(
                START.toordinal() + t // 48)
            if candidate_date.weekday() != original_date:
                continue
            if any(abs(t - x) < 14 * 48 for x in real_windows):
                continue
            candidates.append(t)
        if not candidates:
            raise RuntimeError(f"no placebo windows for {pair['pair_id']}")
        chosen_placebos = list(rng.choice(candidates,
                                          size=min(args.n_placebo,
                                                   len(candidates)),
                                          replace=False))
        placebo_joint, placebo_predonly, placebo_interaction = [], [], []
        for t in chosen_placebos:
            t_cf = t - CF_OFFSET
            effect = model_effects(v3, pair, registry_zones, adj, t, t_cf)
            pred = predonly_effect(po, pair, registry_zones, adj, t, t_cf)
            placebo_joint.append(effect["JCE_AB"])
            placebo_interaction.append(effect["interaction"])
            placebo_predonly.append(pred["prediction_difference"])

        def placebo_upper_p(observed_value, placebo_values):
            return float((np.sum(np.asarray(placebo_values) >=
                                 observed_value) + 1) /
                         (len(placebo_values) + 1))

        pair_result = {
            "pair_id": pair["pair_id"],
            "role": pair["role"],
            "spatial_relation": pair["spatial_relation"],
            "t_event_index": t_event,
            "counterfactual_index": t_cf,
            **{k: v for k, v in observed.items()
               if k not in ["per_zone", "effect_cis", "predonly"]},
            "effect_ci95": observed["effect_cis"],
            "predonly_prediction_difference": observed["predonly"]["prediction_difference"],
            "placebo": {
                "n": len(placebo_joint),
                "jce_mean": float(np.mean(placebo_joint)),
                "interaction_mean": float(np.mean(placebo_interaction)),
                "p_upper_jce": placebo_upper_p(observed["JCE_AB"],
                                                 placebo_joint),
                "p_upper_interaction": placebo_upper_p(
                    observed["interaction"], placebo_interaction),
                "p_upper_predonly": placebo_upper_p(
                    observed["predonly"]["prediction_difference"],
                    placebo_predonly),
            },
        }
        results.append(pair_result)
        print(json.dumps(pair_result, indent=2, default=json_default),
              flush=True)

    with open("real_event_validation_results.json", "w",
              encoding="utf-8") as f:
        json.dump({"results": results}, f, indent=2, default=json_default)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
