"""PEMS08 val MAE for 5 V3 seeds, 5 STIDGraph seeds, ensembles, and tests."""
import os
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.stats import wilcoxon

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from graphctx_dataset import GraphCtxCausalDataset
from graph_dataset import GraphTrafficDataset
from stid_graph import STIDGraph
from stwave_causal_v3 import STWaveCausalV3

DATA = "data/pems08/processed"
META = np.load("data/datasets/pems08_staeformer/data.npz")["data"][..., 1:3][:, 0]
device = "cuda" if torch.cuda.is_available() else "cpu"

V3_CKPTS = [
    DATA + "/stwave_causal_v3_graphctx_gate_pems08_best.pt",
    DATA + "/stwave_causal_v3_graphctx_gate_pems08_seed1.pt",
    DATA + "/stwave_causal_v3_graphctx_gate_pems08_seed2.pt",
    DATA + "/stwave_causal_v3_graphctx_gate_pems08_seed3.pt",
    DATA + "/stwave_causal_v3_graphctx_gate_pems08_seed4.pt",
]
STID_CKPTS = [
    DATA + "/stidgraph-pems08_best.pt",
    DATA + "/stidgraph-pems08_seed1_best.pt",
    DATA + "/stidgraph-pems08_seed2_best.pt",
    DATA + "/stidgraph-pems08_seed3_best.pt",
    DATA + "/stidgraph-pems08_seed4_best.pt",
]


def collate_pred(batch):
    f, _, _, _, _ = zip(*batch)
    def sd(d):
        return {k: torch.stack([x[k] for x in d]) for k in d[0].keys()}
    return sd(f)


def collate_graph(batch):
    return {
        "zone_ids": torch.stack([b["zone_ids"] for b in batch]),
        "features": torch.stack([b["features"] for b in batch]),
        "targets": torch.stack([b["targets"] for b in batch]),
        "adj": batch[0]["adj"],
    }


def v3_preds(ckpt):
    ds = GraphCtxCausalDataset(DATA, "val", 48, ctx_mode="mean", meta=META)
    loader = torch.utils.data.DataLoader(ds, batch_size=64, shuffle=False,
                                         collate_fn=collate_pred)
    model = STWaveCausalV3(n_zones=170, input_dim=4, output_dim=1,
                           ctx_channels=1).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    preds, tgts = [], []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) for k, v in batch.items()}
            _, pred = model(f["zone_ids"], f["features"])
            preds.append(pred.cpu().numpy())
            tgts.append(f["targets"].cpu().numpy())
    return np.concatenate(preds, axis=0), np.concatenate(tgts, axis=0)


def stid_preds(ckpt):
    ds = GraphTrafficDataset(DATA, "val", 48)
    loader = torch.utils.data.DataLoader(ds, batch_size=64, shuffle=False,
                                         collate_fn=collate_graph)
    model = STIDGraph(n_zones=170, input_dim=1, hidden_dim=64, seq_len=48,
                      n_layers=2, n_days=7).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    preds, tgts = [], []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) if isinstance(v, torch.Tensor) else v
                 for k, v in batch.items()}
            pred = model(f["features"], f["zone_ids"], f["adj"])
            preds.append(pred.cpu().numpy())
            tgts.append(f["targets"].cpu().numpy())
    return np.concatenate(preds, axis=0), np.concatenate(tgts, axis=0)


def main():
    print("Device:", device)
    v3_out = [v3_preds(p) for p in V3_CKPTS]
    stid_out = [stid_preds(p) for p in STID_CKPTS]
    v3_all = [x[0] for x in v3_out]
    stid_all = [x[0] for x in stid_out]
    v3_tgt = v3_out[0][1]
    stid_tgt = stid_out[0][1]

    v3_mae = [np.abs(p - v3_tgt).mean() for p in v3_all]
    stid_mae = [np.abs(p - stid_tgt).mean() for p in stid_all]
    print("V3 per-seed MAE:", ["%.3f" % x for x in v3_mae])
    print("V3 mean %.3f std %.3f best %.3f" %
          (np.mean(v3_mae), np.std(v3_mae), np.min(v3_mae)))
    print("STIDGraph per-seed MAE:", ["%.3f" % x for x in stid_mae])
    print("STIDGraph mean %.3f std %.3f best %.3f" %
          (np.mean(stid_mae), np.std(stid_mae), np.min(stid_mae)))

    v3_ens = np.mean(v3_all, axis=0)
    stid_ens = np.mean(stid_all, axis=0)
    e3 = np.abs(v3_ens - v3_tgt).mean()
    es = np.abs(stid_ens - stid_tgt).mean()
    print("V3 ensemble MAE: %.4f" % e3)
    print("STIDGraph ensemble MAE: %.4f" % es)

    err3 = np.abs(v3_ens - v3_tgt)[:, 0]
    errs = np.abs(stid_ens - stid_tgt)[:, 0]
    stat, p = wilcoxon(err3, errs)
    better = "V3" if e3 < es else "STIDGraph"
    print("Wilcoxon V3-ens vs STID-ens p=%.4g (%s better)" % (p, better))

    b3 = np.argmin(v3_mae)
    bs = np.argmin(stid_mae)
    stat, p = wilcoxon(np.abs(v3_all[b3] - v3_tgt)[:, 0],
                       np.abs(stid_all[bs] - stid_tgt)[:, 0])
    better = "V3" if v3_mae[b3] < stid_mae[bs] else "STIDGraph"
    print("Wilcoxon V3-best vs STID-best p=%.4g (%s better)" % (p, better))


if __name__ == "__main__":
    main()
