"""2x4 encoder comparison: STWaveCausal V3 vs STIDCausal on four datasets."""
import os
import sys

import numpy as np
import torch
from scipy.stats import wilcoxon

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from graph_dataset import GraphTrafficDataset
from graphctx_dataset import GraphCtxCausalDataset
from stid_causal import STIDCausal
from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"


def collate_ctx(batch):
    factual, _, _, _, _ = zip(*batch)
    return {k: torch.stack([x[k] for x in factual]) for k in factual[0].keys()}


def collate_graph(batch):
    return {
        "zone_ids": torch.stack([b["zone_ids"] for b in batch]),
        "features": torch.stack([b["features"] for b in batch]),
        "targets": torch.stack([b["targets"] for b in batch]),
        "adj": batch[0]["adj"],
    }


def eval_v3(data_dir, nz, ind, outd, ctxc, ckpt, ctx_mode="mean", meta=None):
    ds = GraphCtxCausalDataset(data_dir, "val", 48, ctx_mode=ctx_mode, meta=meta)
    loader = torch.utils.data.DataLoader(ds, batch_size=64, shuffle=False,
                                         collate_fn=collate_ctx, num_workers=0)
    model = STWaveCausalV3(n_zones=nz, input_dim=ind, output_dim=outd,
                           ctx_channels=ctxc).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    preds, tgts = [], []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) for k, v in batch.items()}
            _, pred = model(f["zone_ids"], f["features"])
            preds.append(pred.cpu().numpy())
            tgts.append(f["targets"].cpu().numpy())
    return np.concatenate(preds, axis=0), np.concatenate(tgts, axis=0)


def eval_stid(data_dir, nz, nd, ckpt):
    ds = GraphTrafficDataset(data_dir, "val", 48)
    loader = torch.utils.data.DataLoader(ds, batch_size=64, shuffle=False,
                                         collate_fn=collate_graph, num_workers=0)
    model = STIDCausal(n_zones=nz, input_dim=nd, output_dim=nd).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    preds, tgts = [], []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) if isinstance(v, torch.Tensor) else v
                 for k, v in batch.items()}
            _, pred = model(f["features"], f["zone_ids"], f["adj"])
            preds.append(pred.cpu().numpy())
            tgts.append(f["targets"].cpu().numpy())
    return np.concatenate(preds, axis=0), np.concatenate(tgts, axis=0)


def mae_per_sample(pred, tgt):
    return np.abs(pred - tgt).mean(axis=-1)


def report(name, p_v3, p_st, t):
    e_v3 = mae_per_sample(p_v3, t)
    e_st = mae_per_sample(p_st, t)
    e_ens = mae_per_sample(0.5 * (p_v3 + p_st), t)
    m_v3, m_st, m_ens = e_v3.mean(), e_st.mean(), e_ens.mean()
    print("== %s ==" % name)
    print("  STWaveCausal V3  val MAE %.4f" % m_v3)
    print("  STIDCausal       val MAE %.4f" % m_st)
    print("  Equal-weight ens val MAE %.4f" % m_ens)
    _, p1 = wilcoxon(e_v3, e_st)
    _, p2 = wilcoxon(e_v3, e_ens)
    print("  Wilcoxon V3 vs STID p=%.4g ; V3 vs ensemble p=%.4g" % (p1, p2))


def main():
    print("Device:", device)
    nyc = "data/nyc_taxi/processed"
    bay = "data/pems_bay/processed"
    p08 = "data/pems08/processed"
    p04 = "data/pems04/processed"
    meta08 = np.load("data/datasets/pems08_staeformer/data.npz")["data"][..., 1:3][:, 0]
    meta04 = np.load("data/datasets/pems04_staeformer/data.npz")["data"][..., 1:3][:, 0]

    v3_nyc, t_nyc = eval_v3(nyc, 265, 12, 6, 0,
                            nyc + "/stwave_causal_v3_graphctx_nyc_seed4.pt",
                            ctx_mode="mean")
    st_nyc, _ = eval_stid(nyc, 265, 6, nyc + "/stid_causal_nyc_best.pt")
    report("NYC Taxi", v3_nyc, st_nyc, t_nyc)

    v3_bay, t_bay = eval_v3(bay, 325, 16, 8, 0,
                            bay + "/stwave_causal_v3_graphctx_grad_pemsbay_seed4.pt",
                            ctx_mode="gradient")
    st_bay, _ = eval_stid(bay, 325, 8, bay + "/stid_causal_pemsbay_best.pt")
    report("PEMS-BAY", v3_bay, st_bay, t_bay)

    v3_p08, t_p08 = eval_v3(p08, 170, 4, 1, 1,
                            p08 + "/stwave_causal_v3_graphctx_gate_pems08_best.pt",
                            ctx_mode="mean", meta=meta08)
    st_p08, _ = eval_stid(p08, 170, 1, p08 + "/stid_causal_pems08_seed4.pt")
    report("PEMS08", v3_p08, st_p08, t_p08)

    v3_p04, t_p04 = eval_v3(p04, 307, 4, 1, 1,
                            p04 + "/stwave_causal_v3_graphctx_gate_pems04_seed2.pt",
                            ctx_mode="mean", meta=meta04)
    st_p04, _ = eval_stid(p04, 307, 1, p04 + "/stid_causal_pems04_seed2.pt")
    report("PEMS04", v3_p04, st_p04, t_p04)

    print("ALL DONE")


if __name__ == "__main__":
    main()
