"""Two-stage training for STIDCausal on full-node windows."""
import argparse
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, "src/model")
os.chdir(os.path.dirname(os.path.abspath(__file__)))

from graph_dataset import GraphTrafficDataset
from stid_causal import STIDCausal


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/pems04/processed")
    p.add_argument("--synthetic", default="synthetic_pairs_fullnode.npy")
    p.add_argument("--n-zones", type=int, default=307)
    p.add_argument("--feature-dim", type=int, default=1)
    p.add_argument("--epochs", type=int, default=130)
    p.add_argument("--pretrain-epochs", type=int, default=110)
    p.add_argument("--out", default="stid_causal_pems04_best.pt")
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--lambda1", type=float, default=0.3)
    p.add_argument("--lambda2", type=float, default=0.01)
    p.add_argument("--lambda3", type=float, default=0.3)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--max-batches", type=int, default=0)
    return p.parse_args()


SEQ = 48
MAX_EVENTS = 5


def collate_graph(batch):
    return {
        "zone_ids": torch.stack([b["zone_ids"] for b in batch]),
        "features": torch.stack([b["features"] for b in batch]),
        "targets": torch.stack([b["targets"] for b in batch]),
        "adj": batch[0]["adj"],
    }


def to_device(d, device):
    return {k: v.to(device) if isinstance(v, torch.Tensor) else v
            for k, v in d.items()}


def make_synth_batch(samples, start, batch_size, feature_dim, device):
    batch = samples[start:start + batch_size]
    factual = torch.zeros(len(batch), SEQ, 0 if len(batch) == 0 else 1)
    # Rebuild on first nonempty sample shape.
    first = samples[0]
    N = first["factual"].shape[1]
    factual = torch.zeros(len(batch), SEQ, N, feature_dim)
    cf = torch.zeros(len(batch), SEQ, N, feature_dim)
    ice = torch.zeros(len(batch), feature_dim)
    event_types = torch.full((len(batch), MAX_EVENTS), -1, dtype=torch.long)
    event_locs = torch.zeros(len(batch), MAX_EVENTS, 2)
    event_times = torch.zeros(len(batch), MAX_EVENTS)
    zone_states = torch.zeros(len(batch), MAX_EVENTS, feature_dim)
    zones = torch.zeros(len(batch), dtype=torch.long)
    for i, d in enumerate(batch):
        zones[i] = d["zone"]
        factual[i] = d["factual"]
        cf[i] = d["cf"]
        ice[i] = d["ice_true"]
        combo = d["combo"]
        event_types[i] = combo["event_types"]
        event_locs[i] = combo["event_locs"]
        event_times[i] = combo["event_times"]
        zone_states[i] = combo["zone_states"]
    return {
        "zone_ids": zones.to(device),
        "features": factual.to(device),
        "cf_features": cf.to(device),
        "targets": torch.zeros(len(batch), feature_dim, device=device),
        "ice_true": ice.to(device),
        "event_types": event_types.to(device),
        "event_locs": event_locs.to(device),
        "event_times": event_times.to(device),
        "zone_states": zone_states.to(device),
    }


def main():
    args = parse_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    print("Device:", device, flush=True)

    DATA = Path(args.data)
    synthetic = np.load(str(DATA / args.synthetic), allow_pickle=True).item()
    td = GraphTrafficDataset(str(DATA), "train", SEQ)
    vd = GraphTrafficDataset(str(DATA), "val", SEQ)
    tl = torch.utils.data.DataLoader(td, batch_size=args.batch_size,
                                     shuffle=True, collate_fn=collate_graph,
                                     num_workers=0, drop_last=True)
    vl = torch.utils.data.DataLoader(vd, batch_size=args.batch_size,
                                     shuffle=False, collate_fn=collate_graph,
                                     num_workers=0)

    model = STIDCausal(n_zones=args.n_zones, input_dim=args.feature_dim,
                       output_dim=args.feature_dim, hidden_dim=64).to(device)
    print("Params:", sum(p.numel() for p in model.parameters()), flush=True)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=args.epochs)

    best_mae = float("inf")
    best_state = None
    save_path = DATA / args.out

    for ep in range(args.epochs):
        model.train()
        t0 = time.time()
        totals = {"loss": 0.0, "pred": 0.0, "cs": 0.0, "cm": 0.0,
                  "div": 0.0, "causal": 0.0}
        acc = {k: torch.zeros((), device=device) for k in totals}
        n = 0
        full = ep >= args.pretrain_epochs
        for i, batch in enumerate(tl):
            f = to_device(batch, device)
            adj = f["adj"]
            if not full:
                _, pred = model(f["features"], f["zone_ids"], adj)
                L_pred = F.mse_loss(pred, f["targets"])
                loss = L_pred
                L_cs = L_cm = L_div = L_causal = torch.zeros((), device=device)
            else:
                s_i = (i * args.batch_size) % len(synthetic["train"])
                sb = make_synth_batch(synthetic["train"], s_i,
                                      args.batch_size, args.feature_dim,
                                      device)
                combo = {"event_types": sb["event_types"],
                         "event_locs": sb["event_locs"],
                         "event_times": sb["event_times"],
                         "zone_states": sb["zone_states"]}
                cl = model.contrastive_loss(
                    {"zone_ids": f["zone_ids"], "features": f["features"],
                     "targets": f["targets"]},
                    {"zone_ids": sb["zone_ids"], "features": sb["cf_features"]},
                    {"zone_ids": sb["zone_ids"], "features": sb["cf_features"]},
                    combo, adj)
                L_pred = cl["L_pred"]
                L_cs = cl["L_con_single"]
                L_cm = cl["L_con_multi"]
                L_div = cl["L_div"]
                ice_est = model.causal_effect(
                    {"zone_ids": sb["zone_ids"], "features": sb["features"]},
                    {"zone_ids": sb["zone_ids"], "features": sb["cf_features"]},
                    combo, adj)
                L_causal = F.mse_loss(ice_est, sb["ice_true"])
                loss = (L_pred + args.lambda1 * (L_cs + L_cm)
                        + args.lambda2 * L_div + args.lambda3 * L_causal)
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            bs = f["targets"].shape[0]
            acc["loss"] += loss.detach() * bs
            acc["pred"] += L_pred.detach() * bs
            acc["cs"] += L_cs.detach() * bs
            acc["cm"] += L_cm.detach() * bs
            acc["div"] += L_div.detach() * bs
            acc["causal"] += L_causal.detach() * bs
            n += bs
            if args.max_batches and i + 1 >= args.max_batches:
                break
        sched.step()
        m = {k: v.item() / max(1, n) for k, v in acc.items()}

        model.eval()
        tot, nn = 0.0, 0
        with torch.no_grad():
            for batch in vl:
                f = to_device(batch, device)
                _, pred = model(f["features"], f["zone_ids"], f["adj"])
                tot += F.l1_loss(pred, f["targets"], reduction="sum").item()
                nn += pred.shape[0]
        val_mae = tot / nn
        if val_mae < best_mae:
            best_mae = val_mae
            best_state = {k: v.cpu() for k, v in model.state_dict().items()}
            torch.save(best_state, str(save_path))
        if (ep + 1) % 5 == 0 or ep == 0:
            print("Ep %3d/%d %s loss=%.4f pred=%.4f cs=%.4f cm=%.4f "
                  "div=%.4f causal=%.4f valMAE=%.4f (%.1fs)" %
                  (ep + 1, args.epochs, "PRED" if not full else "FULL",
                   m["loss"], m["pred"], m["cs"], m["cm"], m["div"],
                   m["causal"], val_mae, time.time() - t0), flush=True)
    print("Best val MAE: %.4f" % best_mae, flush=True)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
