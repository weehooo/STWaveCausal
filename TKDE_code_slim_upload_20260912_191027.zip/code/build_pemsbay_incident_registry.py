"""Build a sensor-level concurrent incident registry for PEMS-BAY."""
import argparse
import hashlib
import json
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import pandas as pd


EPOCH = datetime(2017, 1, 1)
WINDOW_MINUTES = 5
CF_OFFSET_WINDOWS = 7 * 24 * 12
SEQ = 48
IMPORTANT_TYPES = {
    "1183-Trfc Collision-Unkn Inj",
    "1182-Trfc Collision-No Inj",
    "1179-Trfc Collision-1141 Enrt",
    "1181-Trfc Collision-Minor Inj",
    "1125-Traffic Hazard",
    "20001-Hit and Run w/Injuries",
    "20002-Hit and Run No Injuries",
    "CFIRE-Car Fire",
    "FLOOD-Roadway Flooding",
    "1166-Defective Traffic Signals",
    "WW-Wrong Way Driver",
    "CLOSURE of a Road",
    "1184-Provide Traffic Control",
}
HOLIDAYS = {"2017-01-02", "2017-01-16", "2017-02-20", "2017-05-29"}


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def haversine_km(lat1, lon1, lat2, lon2):
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
    dlat, dlon = lat2 - lat1, lon2 - lon1
    h = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * \
        np.sin(dlon / 2) ** 2
    return float(6371.0 * 2.0 * np.arcsin(np.sqrt(h)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--incidents",
                        default="data/pems_bay/raw/kaggle_extract/"
                                "pems_bay_incidents.csv")
    parser.add_argument("--locations",
                        default="data/pems_bay/raw/kaggle_extract/"
                                "sensor_locations.csv")
    parser.add_argument("--sensor-ids",
                        default="data/pems_bay/processed/sensor_ids.npy")
    parser.add_argument("--output", default="pemsbay_incident_registry.json")
    parser.add_argument("--max-pairs", type=int, default=100)
    parser.add_argument("--min-overlap-windows", type=int, default=1)
    args = parser.parse_args()

    incidents = pd.read_csv(args.incidents)
    locations = pd.read_csv(args.locations, header=None,
                            names=["sensor_id", "lat", "lon"])
    sensor_ids = [str(value) for value in
                  np.load(args.sensor_ids, allow_pickle=True)]
    location_map = {str(row.sensor_id): (float(row.lat), float(row.lon))
                    for row in locations.itertuples(index=False)}
    incidents["sensor_id"] = incidents["nearest_sensor_id"].astype(str)
    incidents = incidents[
        incidents["sensor_id"].isin(sensor_ids)].copy()
    incidents = incidents[incidents["type"].isin(IMPORTANT_TYPES)].copy()
    incidents["timestamp"] = pd.to_datetime(incidents["timestamp"])
    incidents = incidents[
        (incidents["timestamp"] >= EPOCH) &
        (incidents["timestamp"] < datetime(2017, 7, 1))].copy()
    incidents["start_idx"] = (
        (incidents["timestamp"] - EPOCH).dt.total_seconds() //
        (WINDOW_MINUTES * 60)).astype(int)
    duration_minutes = incidents["duration"].fillna(0).clip(lower=0)
    incidents["end_idx"] = (
        (incidents["timestamp"] + pd.to_timedelta(
            duration_minutes, unit="m") - EPOCH).dt.total_seconds() //
        (WINDOW_MINUTES * 60)).astype(int)

    events = []
    for row in incidents.itertuples(index=False):
        start = int(row.start_idx)
        end = int(row.end_idx)
        if start < CF_OFFSET_WINDOWS + SEQ or end + SEQ >= 52116:
            continue
        date = (EPOCH + timedelta(minutes=start * WINDOW_MINUTES)).date()
        if date.isoformat() in HOLIDAYS:
            continue
        lat, lon = location_map.get(row.sensor_id, (np.nan, np.nan))
        events.append({
            "incident_id": str(row.id),
            "timestamp": str(row.timestamp),
            "start_idx": start,
            "end_idx": max(end, start),
            "duration_minutes": float(row.duration),
            "type": str(row.type),
            "sensor_id": str(row.sensor_id),
            "lat": float(lat) if not np.isnan(lat) else None,
            "lon": float(lon) if not np.isnan(lon) else None,
            "dist_km": float(row.dist_km),
            "date": date.isoformat(),
        })
    events.sort(key=lambda event: event["timestamp"])

    by_day = defaultdict(list)
    for event in events:
        by_day[event["date"]].append(event)
    citywide = {day for day, day_events in by_day.items()
                if len({event["sensor_id"] for event in day_events}) >= 82}

    pairs = []
    for left_index, left in enumerate(events):
        for right in events[left_index + 1:]:
            if left["sensor_id"] == right["sensor_id"]:
                continue
            overlap = (min(left["end_idx"], right["end_idx"]) -
                       max(left["start_idx"], right["start_idx"]) + 1)
            if overlap < args.min_overlap_windows:
                continue
            if left["date"] in citywide or right["date"] in citywide:
                continue
            left_loc = location_map.get(left["sensor_id"])
            right_loc = location_map.get(right["sensor_id"])
            if left_loc is None or right_loc is None:
                continue
            distance = haversine_km(left_loc[0], left_loc[1],
                                   right_loc[0], right_loc[1])
            pairs.append({
                "pair_id": f"{left['incident_id']}__{right['incident_id']}",
                "date": left["date"],
                "overlap_windows": int(overlap),
                "distance_km": round(distance, 3),
                "spatial_relation": "adjacent" if distance <= 2 else "disjoint",
                "severity_score": float(left["duration_minutes"] +
                                        right["duration_minutes"] +
                                        5.0 * (left["type"] ==
                                                right["type"])),
                "events": [left, right],
            })
    pairs.sort(key=lambda pair: (-pair["severity_score"],
                                 pair["date"], pair["pair_id"]))
    selected, seen_days = [], set()
    for pair in pairs:
        if pair["date"] not in seen_days:
            selected.append(pair)
            seen_days.add(pair["date"])
        if len(selected) >= args.max_pairs:
            break

    output = {
        "protocol_name": "PEMS-BAY sensor-level concurrent incident audit",
        "status": "event_registry_only_no_model_outcomes",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "input_sha256": {
            args.incidents: sha256(args.incidents),
            args.locations: sha256(args.locations),
        },
        "summary": {
            "total_incidents_read": int(len(incidents)),
            "qualifying_events_after_exclusions": len(events),
            "citywide_days_excluded": len(citywide),
            "candidate_pairs": len(pairs),
            "unique_candidate_days": len({pair["date"] for pair in pairs}),
            "selected_pairs": len(selected),
            "relation_counts": {
                relation: sum(pair["spatial_relation"] == relation
                              for pair in selected)
                for relation in ["adjacent", "disjoint"]
            },
            "event_type_counts": dict(
                incidents["type"].value_counts().to_dict()),
        },
        "selected_pairs": selected,
    }
    Path(args.output).write_text(json.dumps(output, indent=2),
                                 encoding="utf-8")
    print(json.dumps(output["summary"], indent=2))


if __name__ == "__main__":
    main()
