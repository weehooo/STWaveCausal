"""Cross-fitted explicit-propensity-score matching with full balance audit."""
import argparse
import gc
import json
import os

import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler

DATASETS = ["nyc_taxi", "pems_bay", "pems08", "pems04"]


def column(values):
    return np.asarray(values).reshape(len(values), 1)


def csum(array):
    return np.cumsum(np.asarray(array, dtype=np.float32), axis=0)


def safe_index(array, times, zones):
    times = np.maximum(times, 0)
    return array[times, zones]


def build_features(features, neighbor, label_cum, times, zones):
    """All covariates are measured strictly before the indexed window."""
    lag_values = []
    for lag in [0, 1, 2, 3, 6, 12, 24, 48]:
        historical_t = np.maximum(times - lag, 0)
        lag_values.append(column(np.log1p(safe_index(
            features, historical_t, zones)[..., 0])))
    out = list(lag_values)
    # Short-horizon changes act as volatility/pre-trend controls.
    out.extend([lag_values[0] - lag_values[1],
                lag_values[0] - lag_values[4],
                lag_values[0] - lag_values[-1]])
    # Neighbor system state at the same pre-treatment lags.
    for lag in [0, 6]:
        historical_t = np.maximum(times - lag, 0)
        out.append(column(np.log1p(safe_index(neighbor, historical_t,
                                               zones)[..., 0])))
    # Calendar controls. Some processed datasets have explicit channels;
    # single-channel flow datasets derive them from the 30-minute index.
    current = safe_index(features, np.maximum(times, 0), zones)
    if current.shape[-1] >= 6:
        out.extend([column(current[..., 4]), column(current[..., 5])])
    else:
        hours = ((times * 30 / 60.0) % 24.0).reshape(-1, 1)
        weekdays = ((times // 48) % 7.0).reshape(-1, 1)
        out.extend([np.sin(2 * np.pi * hours / 24.0),
                    weekdays / 6.0])
    # Prior intervention exposure, excluding the current index.
    for horizon in [24, 48]:
        lo = np.maximum(times - horizon, 0)
        prior = label_cum[times, zones] - label_cum[lo, zones]
        out.append(np.log1p(prior).reshape(-1, 1))
    return np.concatenate(out, axis=1).astype(np.float32)


def smds(matrix, treated_mask):
    treated = matrix[treated_mask]
    control = matrix[~treated_mask]
    if len(treated) < 2 or len(control) < 2:
        return {"max": None, "mean": None, "passed": False}
    mt, mc = treated.mean(0), control.mean(0)
    vt, vc = treated.var(0), control.var(0)
    denominator = np.sqrt((vt + vc) / 2) + 1e-8
    values = np.abs(mt - mc) / denominator
    return {"values": values.tolist(), "max": float(values.max()),
            "mean": float(values.mean()),
            "passed": bool(np.all(values < 0.1))}


def greedy_match(propensity, treated_mask, zone, time, caliper_sd,
                 min_gap=3, max_gap=336):
    logit = np.log(np.clip(propensity, 1e-6, 1 - 1e-6) /
                   (1 - np.clip(propensity, 1e-6, 1 - 1e-6)))
    scale = np.std(logit) + 1e-8
    caliper = caliper_sd * scale
    treated_ids = np.where(treated_mask)[0]
    control_ids = np.where(~treated_mask)[0]
    control_zone = zone[control_ids]
    control_time = time[control_ids]
    used = np.zeros(len(control_ids), dtype=bool)
    matches = []
    edges = []
    for treated_id in treated_ids:
        candidates = control_ids[(control_zone == zone[treated_id]) &
                                  (np.abs(control_time - time[treated_id]) >=
                                   min_gap) &
                                  (np.abs(control_time - time[treated_id]) <=
                                   max_gap)]
        if not len(candidates):
            continue
        local_candidates = np.searchsorted(control_ids, candidates)
        available = local_candidates[~used[local_candidates]]
        if not len(available):
            continue
        distances = np.abs(logit[available] - logit[treated_id])
        best_local = int(available[np.argmin(distances)])
        distance = float(distances[np.argmin(distances)])
        if distance <= caliper:
            used[best_local] = True
            matches.append((int(treated_id), int(control_ids[best_local]),
                            distance))
            edges.append(distance)
    return matches, {"caliper_sd": caliper_sd, "pairs": len(matches),
                     "median_distance": float(np.median(edges)) if edges else None}


def process_dataset(name, args):
    path = os.path.join("data", name, "processed")
    raw_features = np.load(os.path.join(path, "node_features.npy"),
                           mmap_mode="r")
    features = np.asarray(raw_features, dtype=np.float32)
    if features.ndim == 2:
        features = features[..., None]
    labels = np.load(os.path.join(path, "labels.npy"))
    adj = np.load(os.path.join(path, "adj.npy")).astype(np.float32)
    adj /= np.maximum(adj.sum(axis=1, keepdims=True), 1e-6)
    print("%s building neighbor state" % name, flush=True)
    print("%s computing neighbor aggregate" % name, flush=True)
    neighbor = np.einsum("sm,tmd->tsd", adj, features,
                         optimize=True).astype(np.float32)
    raw_cum = csum(features)
    label_binary = (labels == 1).astype(np.int32)
    label_cum = np.cumsum(label_binary, axis=0, dtype=np.int32)

    treated_positions = np.argwhere(labels == 1)
    control_positions = np.argwhere(labels == 0)
    rng = np.random.RandomState(args.seed)
    if len(treated_positions) > args.max_treated:
        kept = rng.choice(len(treated_positions), args.max_treated,
                          replace=False)
        treated_positions = treated_positions[kept]
    if len(control_positions) > args.max_controls:
        kept = rng.choice(len(control_positions), args.max_controls,
                          replace=False)
        control_positions = control_positions[kept]
    positions = np.concatenate([treated_positions, control_positions])
    times = positions[:, 0].astype(int)
    zones = positions[:, 1].astype(int)
    # Drop earliest warmup windows.
    valid = times >= 48
    times, zones = times[valid], zones[valid]
    positions = positions[valid]
    treated_mask = labels[times, zones] == 1

    print("%s building %d feature rows" % (name, len(times)), flush=True)
    print("%s feature source shape %s" % (name, features.shape), flush=True)
    matrix = build_features(features, neighbor, label_cum, times, zones)
    core_matrix = matrix[:, :8]
    days = times // 48
    unique_days = np.unique(days)
    folds = {int(day): int(index % args.folds)
             for index, day in enumerate(unique_days)}
    fold_of_row = np.array([folds[int(day)] for day in days])

    oof_scores = {}
    for model_name in ["logistic", "boosting"]:
        scores = np.empty(len(times), dtype=float)
        for fold in range(args.folds):
            train = fold_of_row != fold
            test = fold_of_row == fold
            scaler = StandardScaler()
            x_train = scaler.fit_transform(matrix[train])
            y_train = treated_mask[train].astype(int)
            x_test = scaler.transform(matrix[test])
            if model_name == "logistic":
                model = LogisticRegression(C=0.2, class_weight="balanced",
                                           max_iter=1000)
            else:
                model = HistGradientBoostingClassifier(
                    max_iter=150, learning_rate=0.05,
                    class_weight="balanced", random_state=args.seed)
            # Keep fitting tractable on large NYC datasets.
            if len(x_train) > args.model_sample:
                indices = rng.choice(len(x_train), args.model_sample,
                                     replace=False)
                x_train, y_train = x_train[indices], y_train[indices]
            model.fit(x_train, y_train)
            scores[test] = model.predict_proba(x_test)[:, 1]
        auc = float(roc_auc_score(treated_mask, scores))
        oof_scores[model_name] = {"scores": scores, "auc": auc}
        print("%s %s OOF AUC %.4f" % (name, model_name, auc), flush=True)

    attempts = {}
    chosen = {}
    for model_name, score_info in oof_scores.items():
        before_smd = smds(core_matrix, treated_mask)
        for caliper in [0.1, 0.2, 0.3]:
            matches, info = greedy_match(score_info["scores"], treated_mask,
                                          zones, times, caliper)
            treated_rows = [pair[0] for pair in matches]
            control_rows = [pair[1] for pair in matches]
            if matches:
                combined_core = core_matrix[treated_rows + control_rows]
                combined_mask = np.concatenate([
                    np.ones(len(treated_rows), dtype=bool),
                    np.zeros(len(control_rows), dtype=bool)])
                after_core = smds(combined_core, combined_mask)
            else:
                after_core = {"max": None, "mean": None, "passed": False}
            key = f"{model_name}_caliper{caliper}"
            attempts[key] = {
                "model": model_name, "caliper_sd": caliper,
                "auc": score_info["auc"], "pairs": len(matches),
                "before_max_smd_core": before_smd["max"],
                "after_max_smd_core": after_core.get("max"),
                "passed": bool(after_core.get("passed")),
                "median_distance": info["median_distance"],
            }
            if model_name not in chosen and attempts[key]["passed"]:
                chosen[model_name] = {
                    **attempts[key],
                    "matches": matches,
                    "treated_rows": treated_rows,
                    "control_rows": control_rows,
                }
    outcomes = {}
    for model_name, item in chosen.items():
        treated_rows = item["treated_rows"]
        control_rows = item["control_rows"]
        treated_times = times[treated_rows]
        treated_zones = zones[treated_rows]
        control_times = times[control_rows]
        control_zones = zones[control_rows]
        treated_outcome = safe_index(features, treated_times,
                                      treated_zones)[..., 0]
        control_outcome = safe_index(features, control_times,
                                      control_zones)[..., 0]
        outcomes[model_name] = {
            "matched_att_feature0": float(np.mean(
                treated_outcome - control_outcome)),
            "treated_mean_flow": float(np.mean(treated_outcome)),
            "control_mean_flow": float(np.mean(control_outcome)),
        }

    result = {
        "seed": args.seed, "folds": args.folds,
        "n_treated_input": int(len(treated_positions)),
        "attempts": attempts, "chosen": {
            key: {k: v for k, v in item.items()
                  if k not in ["matches", "treated_rows", "control_rows"]}
            for key, item in chosen.items()},
        "outcomes": outcomes,
    }
    del features, neighbor, raw_cum, label_cum, matrix
    gc.collect()
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", nargs="+", default=DATASETS)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--max-treated", type=int, default=20000)
    ap.add_argument("--max-controls", type=int, default=120000)
    ap.add_argument("--model-sample", type=int, default=80000)
    args = ap.parse_args()

    rng = np.random.RandomState(args.seed)
    output = {"protocol": vars(args), "datasets": {}}
    for name in args.datasets:
        print("==", name, flush=True)
        output["datasets"][name] = process_dataset(name, args)
        with open("psm_fitted_closedloop_partial.json", "w",
                  encoding="utf-8") as f:
            json.dump(output, f, indent=2)
    with open("psm_fitted_closedloop_results.json", "w",
              encoding="utf-8") as f:
        json.dump(output, f, indent=2)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
