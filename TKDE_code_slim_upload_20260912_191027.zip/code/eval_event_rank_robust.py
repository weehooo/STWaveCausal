"""Stratified, clustered robustness checks for the multi-event rank test."""
import argparse
import json
import os
import sys
from datetime import datetime

import numpy as np
import torch

BASE = os.environ.get("PAPERS_BASE", os.path.dirname(os.path.abspath(__file__)))
os.chdir(BASE)
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from stwave_causal_v3 import STWaveCausalV3
from eval_events_new import SWPred, window_raw, window_v3

device = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48
CF_OFFSET = 7 * 7 * SEQ
START = datetime(2011, 1, 1)
EVENTS = [
    ("2012-10-29", "Hurricane Sandy"),
    ("2011-12-31", "New Year's Eve"),
    ("2013-02-08", "Winter Storm Nemo"),
    ("2011-10-29", "October nor'easter"),
    ("2012-11-07", "Post-Sandy nor'easter"),
    ("2013-03-07", "March nor'easter"),
    ("2011-08-28", "Hurricane Irene"),
]


def ace(model, causal, zone, t0, t_star):
    zid = torch.full((1, SEQ), int(zone), dtype=torch.long, device=device)
    window = window_v3(zone, t0) if causal else window_raw(zone, t0)
    counterfactual = window_v3(zone, t_star) if causal else window_raw(zone,
                                                                        t_star)
    ff = torch.FloatTensor(window).unsqueeze(0).to(device)
    cf = torch.FloatTensor(counterfactual).unsqueeze(0).to(device)
    with torch.no_grad():
        if causal:
            _, pf = model(zid, ff)
            _, pcf = model(zid, cf)
        else:
            pf = model(zid, ff)
            pcf = model(zid, cf)
    return float(np.mean(np.abs(pf[0].cpu().numpy() -
                                  pcf[0].cpu().numpy())))


def stratify(drop, eligible, n_bins=5):
    idx = np.where(eligible)[0]
    bins = np.full(drop.shape, -1, dtype=int)
    ordered = idx[np.argsort(drop[idx])]
    chunks = np.array_split(ordered, n_bins)
    for k, chunk in enumerate(chunks):
        bins[chunk] = k
    return bins


def rank_hits(values, eligible):
    ids = np.where(eligible)[0]
    threshold_id = ids[max(0, int(np.ceil(len(ids) * 0.05)) - 1)]
    threshold = np.sort(values[ids])[-max(1, int(np.ceil(len(ids) * 0.05)))]
    return set(ids[values[ids] >= threshold]), float(threshold)


def stratified_permutation(event, n_perm=10000, seed=42):
    """Permute affected labels inside drop strata, preserving the observed
    high-ACE set. This is an approximate randomization test for selection."""
    rng = np.random.RandomState(seed)
    eligible_ids = event["eligible_ids"]
    affected = np.asarray(event["affected_mask"])[eligible_ids].astype(int)
    high = np.asarray(event["high_ace_mask"])[eligible_ids].astype(int)
    strata = np.asarray(event["drop_strata"])[eligible_ids]
    observed = int(high[affected == 1].sum())
    counts = []
    strata_unique = np.unique(strata)
    masks_by_stratum = [(strata == s) for s in strata_unique]
    for _ in range(n_perm):
        permuted = affected.copy()
        for mask in masks_by_stratum:
            local = permuted[mask]
            permuted[mask] = rng.permutation(local)
        counts.append(int(high[permuted == 1].sum()))
    counts = np.array(counts)
    return {
        "observed_high_ace_affected": observed,
        "permuted_mean": float(counts.mean()),
        "permuted_p_upper": float((np.sum(counts >= observed) + 1) /
                                  (n_perm + 1)),
        "permuted_ci95": [float(np.quantile(counts, 0.025)),
                          float(np.quantile(counts, 0.975))],
    }


def clustered_bootstrap(events, n_boot=10000, seed=42):
    rng = np.random.RandomState(seed)
    rates = []
    for _ in range(n_boot):
        picks = rng.randint(0, len(events), len(events))
        hits = sum(events[i]["n_high_ace_affected"] for i in picks)
        total = sum(events[i]["n_eligible"] for i in picks)
        rates.append(hits / max(1, total))
    return {"hit_rate_ci95": [float(np.quantile(rates, 0.025)),
                              float(np.quantile(rates, 0.975))]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-perm", type=int, default=10000)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    feats = np.load("data/nyc_taxi/processed/node_features.npy", mmap_mode="r")
    adj = np.load("data/nyc_taxi/processed/adj.npy").astype(np.float32)
    adj /= np.maximum(adj.sum(axis=1, keepdims=True), 1e-6)
    globals()["_adj"] = adj
    v3 = STWaveCausalV3(n_zones=265, input_dim=12, output_dim=6,
                        ctx_channels=6).to(device)
    v3.load_state_dict(torch.load(
        "data/nyc_taxi/processed/rerun_v3_seed42.pt", map_location=device))
    po = SWPred(265, 6).to(device)
    po.load_state_dict(torch.load(
        "data/nyc_taxi/processed/stwave_predonly_50ep_seed1.pt",
        map_location=device))
    v3.eval()
    po.eval()

    rows = []
    for date_string, name in EVENTS:
        t0 = int((datetime.strptime(date_string, "%Y-%m-%d") -
                  START).total_seconds() / (30 * 60))
        t_star = t0 - CF_OFFSET
        if t_star <= SEQ or t0 + SEQ >= feats.shape[0]:
            continue
        baseline = np.array([feats[t_star:t_star + SEQ, z, 0].mean()
                             for z in range(265)])
        actual = np.array([feats[t0:t0 + SEQ, z, 0].mean()
                           for z in range(265)])
        drop = (baseline - actual) / np.maximum(baseline, 1e-6)
        eligible = baseline >= 5
        affected_mask = eligible & (drop > 0.4)
        if not affected_mask.any():
            continue
        ace_v3 = np.array([ace(v3, True, z, t0, t_star)
                           for z in range(265)])
        ace_po = np.array([ace(po, False, z, t0, t_star)
                           for z in range(265)])
        strata = stratify(drop, eligible)
        row = {"date": date_string, "event": name,
               "n_eligible": int(eligible.sum()),
               "n_affected": int(affected_mask.sum()),
               "eligible_ids": np.where(eligible)[0].tolist(),
               "affected_mask": affected_mask.tolist(),
               "high_ace_mask": np.zeros(265, dtype=bool).tolist(),
               "drop_strata": strata.tolist(),
               "mean_drop_affected": float(drop[affected_mask].mean())}
        for method, values in [("v3", ace_v3), ("predonly", ace_po)]:
            high, threshold = rank_hits(values, eligible)
            key = "high_ace_mask" if method == "v3" else \
                "high_ace_predonly_mask"
            row[key] = np.isin(np.arange(265), list(high)).tolist()
            if method == "v3":
                row["high_ace_mask"] = np.isin(np.arange(265),
                                               list(high)).tolist()
            row[method] = {
                "threshold": threshold,
                "n_high_ace_affected": int(sum(z in high for z in
                                                np.where(affected_mask)[0])),
                "hit_rate_affected": float(np.mean([z in high for z in
                                                     np.where(affected_mask)[0]])),
                "hit_rate_nonaffected": float(np.mean([z in high for z in
                                                        np.where(eligible & ~affected_mask)[0]])),
            }
        row["n_eligible"] = int(eligible.sum())
        row["n_high_ace_affected"] = row["v3"]["n_high_ace_affected"]
        # Keep only compact masks needed by permutation.
        row["high_ace_predonly_mask"] = row.pop("high_ace_predonly_mask")
        row["permutation"] = stratified_permutation(row, args.n_perm,
                                                    args.seed)
        rows.append(row)
        print("%-24s hits=%d/%d perm_p=%.4f" %
              (name, row["n_high_ace_affected"], row["n_affected"],
               row["permutation"]["permuted_p_upper"]), flush=True)

    summary = {
        "total_affected": sum(r["n_affected"] for r in rows),
        "total_high_ace_affected": sum(r["n_high_ace_affected"] for r in rows),
        "events": len(rows),
        "clustered_bootstrap_v3": clustered_bootstrap(rows, seed=args.seed),
    }
    pred_rows = []
    for r in rows:
        pred_rows.append({"event": r["event"],
                          "n_affected": r["n_affected"],
                          "n_high_ace_affected":
                              r["predonly"]["n_high_ace_affected"]})
    summary["predonly_placebo_enrichment"] = pred_rows
    with open("eval_event_rank_robust_results.json", "w",
              encoding="utf-8") as f:
        json.dump({"events": rows, "summary": summary}, f, indent=2)
    print(json.dumps(summary, indent=2), flush=True)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
