"""Controlled P/R sweep of the two-stage annotation over rule threshold tau."""
import json
import os
from pathlib import Path

import numpy as np

BASE = Path(r"F:\xuexi\codex\papers")
os.chdir(BASE)

FEAT = np.load("data/nyc_taxi/processed/node_features.npy").astype(np.float32)
LABELS = np.load("data/nyc_taxi/processed/labels.npy")
T, N, D = FEAT.shape
W = 48


def compute_baseline_stats(features):
    total_flow = features[:, :, 0] + features[:, :, 1]
    seg = np.arange(T) % W
    mean_p = np.zeros((W, N), dtype=np.float32)
    std_p = np.zeros((W, N), dtype=np.float32)
    for w in range(W):
        mask = seg == w
        vals = total_flow[mask]
        mean_p[w] = np.mean(vals, axis=0)
        std_p[w] = np.std(vals, axis=0) + 1e-8
    return mean_p, std_p


def rule_z(flow, z, t, mean_p, std_p):
    return (flow[z] - mean_p[t % W, z]) / std_p[t % W, z]


def hawkes_z(flow, z, t0, decay_hours=4.0, alpha=0.3, mu=0.1):
    beta = 1.0 / (decay_hours * 2)
    start = max(0, t0 - 12)
    f = flow[start:t0 + 1]
    intensity = np.zeros(len(f))
    intensity[0] = mu
    for i in range(1, len(f)):
        intensity[i] = intensity[i - 1] * np.exp(-beta)
        if i > 1:
            residual = abs(f[i - 1] - f[i - 2])
            if residual > 0.15 * (f[i - 2] + 1):
                intensity[i] += alpha * np.exp(-beta)
        intensity[i] += mu * (1 - np.exp(-beta))
    baseline = float(flow.mean())
    expected = intensity * baseline
    return np.abs(f - expected) / (expected + 1)


def main():
    mean_p, std_p = compute_baseline_stats(FEAT)
    bf = FEAT[:, :, 0] + FEAT[:, :, 1]
    cand = []
    for z in list(np.where(bf.mean(axis=0) > 15)[0])[:40]:
        n = 0
        for t0 in range(600, T - 200, 997):
            if LABELS[t0, z] == 0 and abs(rule_z(bf[:, z].copy(), z, t0,
                                                 mean_p, std_p)) < 1.5:
                cand.append((z, t0))
                n += 1
                if n >= 2:
                    break
    cand = cand[:120]
    print("candidates:", len(cand), flush=True)

    # flagged at a given tau: both rule |z|>tau and hawkes z>2.0
    taus = [0.8, 1.0, 1.2, 1.4, 1.6, 2.0, 2.5, 3.0]
    rows = []
    for f in (0.5, 0.1):
        for d in (1, 3):
            tp = np.zeros(len(taus))
            for (z, t0) in cand:
                pert = bf[:, z].copy()
                s = max(0, t0 - d + 1)
                e = t0 + 1
                pert[s:e] = f * pert[s:e]
                hz = hawkes_z(pert, z, t0)
                for i, tau in enumerate(taus):
                    if abs(rule_z(pert, z, t0, mean_p, std_p)) > tau and \
                       hz[-1] > 2.0:
                        tp[i] += 1
            # control false positives
            fp = np.zeros(len(taus))
            for (z, t0) in cand:
                bb = bf[:, z].copy()
                hz = hawkes_z(bb, z, t0)
                for i, tau in enumerate(taus):
                    if abs(rule_z(bb, z, t0, mean_p, std_p)) > tau and \
                       hz[-1] > 2.0:
                        fp[i] += 1
            n = len(cand)
            for i, tau in enumerate(taus):
                rec = tp[i] / n
                fpr = fp[i] / n
                prec = tp[i] / max(1, tp[i] + fp[i])
                rows.append({"factor": f, "dur": d, "tau": tau,
                             "recall": round(rec, 3),
                             "fpr": round(fpr, 3),
                             "precision": round(prec, 3)})
    print("factor dur tau recall fpr precision", flush=True)
    for r in rows:
        print(r["factor"], r["dur"], r["tau"], r["recall"], r["fpr"],
              r["precision"], flush=True)
    with open("eval_annotation_pr_results.json", "w",
              encoding="utf-8") as fo:
        json.dump(rows, fo, indent=2)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
