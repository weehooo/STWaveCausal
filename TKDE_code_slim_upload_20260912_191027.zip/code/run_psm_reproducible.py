"""P2: reproducible PSM pipeline (zdim standardization + per-dataset caliper)."""
import json
import sys
from pathlib import Path

import numpy as np

from src.preprocess.psm_matching import balance_check

BASE = Path(r"F:\xuexi\codex\papers")


def precompute_state(features, n_hist=3):
    T, N, D = features.shape
    state = np.zeros((T, N, D), dtype=np.float64)
    for t in range(T):
        lo = max(0, t - n_hist)
        hi = t + 1 if t < n_hist else t
        state[t] = features[lo:hi].mean(axis=0)
    return state


def psm_variant(state, labels, combo_map, caliper=0.1, time_buffer=3,
                use_labels=True, random_control=False, seed=42):
    T, N, D = state.shape
    rng = np.random.RandomState(seed)
    matches = []
    int_events = [(t, z) for t in range(T)
                  if combo_map[t] for z in combo_map[t]["events"]]
    max_samp = 30000
    if len(int_events) > max_samp:
        idx = rng.choice(len(int_events), max_samp, replace=False)
        int_events = [int_events[i] for i in idx]
    for (t, z) in int_events:
        t_start = max(0, t - 7 * 48)
        t_end = min(T, t + 7 * 48)
        if t_end - t_start <= 0:
            continue
        idxs = np.arange(t_start, t_end)
        mask = np.abs(idxs - t) >= time_buffer
        if use_labels:
            mask = mask & (labels[idxs, z] == 0)
        if not mask.any():
            continue
        cand = idxs[mask]
        if random_control:
            best = int(cand[0])
        else:
            d = np.linalg.norm(state[cand, z] - state[t, z], axis=1)
            keep = d < caliper
            if not keep.any():
                continue
            best = int(cand[keep][np.argmin(d[keep])])
        matches.append({"t": int(t), "t_star": best, "zone": int(z)})
    return matches


def summarize(matches, features):
    bal = balance_check(matches, features)
    smd = list(bal["smd"].values())
    return {"pairs": len(matches), "max_smd": float(max(smd)),
            "mean_smd": float(np.mean(smd)), "passed": bool(bal["passed"])}


def main():
    out = {}
    for name in ["nyc_taxi", "pems_bay", "pems08", "pems04"]:
        p = BASE / "data" / name / "processed"
        labels = np.load(str(p / "labels.npy"))
        features = np.load(str(p / "node_features.npy")).astype(np.float64)
        T, N, D = features.shape
        mu = features.mean(axis=(0, 1))
        sd = features.std(axis=(0, 1)) + 1e-8
        zf = (features - mu) / sd
        combo = {}
        for t in range(T):
            z = np.where(labels[t] == 1)[0]
            combo[t] = {"events": [int(x) for x in z]} if z.size else None
        state = precompute_state(zf)
        n_events = sum(len(v["events"]) for v in combo.values() if v)
        n_used = min(n_events, 30000)
        chosen = None
        for caliper in [0.5, 0.3, 0.1]:
            m = psm_variant(state, labels, combo, caliper=caliper)
            res = summarize(m, zf)
            if res["passed"]:
                chosen = {"caliper": caliper, "matches": m, "res": res}
                break
        if chosen is None:
            raise RuntimeError("no balanced caliper for %s" % name)
        res = chosen["res"]
        res["caliper"] = chosen["caliper"]
        res["events_used"] = n_used
        res["matching_rate"] = round(res["pairs"] / n_used, 4)
        out[name] = res
        print("%-8s cal=%.1f pairs=%d max_smd=%.3f rate=%.1f%%" % (
            name, res["caliper"], res["pairs"], res["max_smd"],
            res["matching_rate"] * 100), flush=True)
        np.save(str(p / "matched_pairs.npy"), np.array(chosen["matches"],
                                                      dtype=object))
        with open(str(p / "psm_stats.txt"), "w") as f:
            f.write("pairs=%d\ncaliper=%.1f\nmax_smd=%.4f\nmean_smd=%.4f\n"
                    % (res["pairs"], res["caliper"], res["max_smd"],
                       res["mean_smd"]))

    p = BASE / "data" / "nyc_taxi" / "processed"
    labels = np.load(str(p / "labels.npy"))
    features = np.load(str(p / "node_features.npy")).astype(np.float64)
    mu = features.mean(axis=(0, 1))
    sd = features.std(axis=(0, 1)) + 1e-8
    zf = (features - mu) / sd
    combo = {}
    for t in range(len(labels)):
        z = np.where(labels[t] == 1)[0]
        combo[t] = {"events": [int(x) for x in z]} if z.size else None
    state = precompute_state(zf)
    cal = out["nyc_taxi"]["caliper"]
    abl = {}
    for label, kw in [("annotated_psm", dict(use_labels=True)),
                      ("unannotated_psm", dict(use_labels=False)),
                      ("random_control", dict(use_labels=False,
                                              random_control=True))]:
        m = psm_variant(state, labels, combo, caliper=cal, **kw)
        r = summarize(m, zf)
        contam = sum(1 for x in m if labels[x["t_star"], x["zone"]] != 0)
        r["contaminated"] = contam
        r["contaminated_pct"] = round(contam / max(1, len(m)) * 100, 1)
        abl[label] = r
        print("NYC %-16s pairs=%d max_smd=%.3f contam=%.1f%%" % (
            label, r["pairs"], r["max_smd"], r["contaminated_pct"]),
            flush=True)
    out["nyc_control_pool_ablation"] = abl
    with open(BASE / "psm_reproducible_results.json", "w") as f:
        json.dump(out, f, indent=2)
    print("Saved psm_reproducible_results.json", flush=True)


if __name__ == "__main__":
    sys.exit(main())
