"""P1: realistic synthetic causal simulator with known ACE/JCE, spillover, confounding."""
import json
from pathlib import Path

import numpy as np

BASE = Path(r"F:\xuexi\codex\papers")


def simulate(seed=0, n_nodes=40, T=4000, p_base=0.2, p_amp=0.35,
             p_min=0.15, p_max=0.75):
    rng = np.random.RandomState(seed)
    adj = np.load(BASE / "data/nyc_taxi/processed/adj.npy")
    idx = rng.choice(adj.shape[0], size=n_nodes, replace=False)
    A = (adj[np.ix_(idx, idx)] > 0).astype(float)
    A = np.maximum(A, A.T)
    np.fill_diagonal(A, 0.0)
    N = A.shape[0]
    W = 48
    phase = rng.uniform(0, 2 * np.pi, N)
    base = 20 + 6 * np.sin(2 * np.pi * np.arange(T)[:, None] / W + phase)
    eps = rng.normal(0, 1.5, (T, N))
    ar = np.zeros_like(eps)
    for t in range(1, T):
        ar[t] = 0.6 * ar[t - 1] + eps[t]
    U = np.clip(
        0.5 + 0.3 * np.sin(2 * np.pi * np.arange(T)[:, None] / W + 0.5 * phase),
        0, 1) + 0.1 * rng.randn(T, N)
    p_treat = np.clip(p_base + p_amp * U, p_min, p_max)
    Tr = (rng.rand(T, N) < p_treat).astype(float)
    ACE = rng.uniform(2, 8, N) * (rng.rand(N) < 0.6)
    spill = 0.35 * ACE
    J = rng.uniform(-1.2, 1.2, (N, N))
    J = 0.5 * (J + J.T)
    np.fill_diagonal(J, 0.0)
    Y = np.zeros((T, N))
    for t in range(T - 1):
        spill_in = A @ (spill * Tr[t])
        inter = (J * Tr[t]) @ Tr[t]
        Y[t + 1] = (base[t] + ar[t] + ACE * Tr[t] + spill_in + inter
                    + rng.normal(0, 0.5, N))
    return {"Y": Y, "Tr": Tr, "A": A, "ACE": ACE, "spill": spill, "J": J,
            "U": U, "base": base}


def match(Tr, Y, rng, require_clean=True, caliper=0.6):
    T, N = Tr.shape
    logprev = np.log1p(Y[:-1])
    rows = []
    for t, v in np.argwhere(Tr[:-1] == 1):
        t = int(t)
        v = int(v)
        lo, hi = max(2, t - 40), min(T - 1, t + 40)
        idx = np.arange(lo, hi)
        mask = np.abs(idx - t) >= 4
        if require_clean:
            mask = mask & (Tr[idx, v] == 0)
        if not mask.any():
            continue
        cand = idx[mask]
        d = np.abs(logprev[cand, v] - logprev[t, v])
        j = int(np.argmin(d))
        if d[j] < caliper:
            rows.append((t, v, int(cand[j])))
    return rows


def ace_estimates(sim, rng):
    Tr, Y = sim["Tr"], sim["Y"]
    ann = match(Tr, Y, rng, require_clean=True)
    unann = match(Tr, Y, rng, require_clean=False)

    def est(rows):
        diffs = np.array([Y[t + 1, v] - Y[tt + 1, v] for (t, v, tt) in rows])
        return (float(diffs.mean()) if len(diffs) else None, len(diffs))

    a, na = est(ann)
    u, nu = est(unann)
    contam = int(sum(1 for (t, v, tt) in unann if Tr[tt, v] == 1))
    return {"annotated_ace": a, "annotated_pairs": na,
            "unannotated_ace": u, "unannotated_pairs": nu,
            "unannotated_contaminated_controls": contam}


def jce_recovery(sim, rng):
    Tr, Y, A = sim["Tr"], sim["Y"], sim["A"]
    T, N = Tr.shape
    logprev = np.log1p(Y[:-1])
    errors = []
    for t in range(2, T - 1):
        vs = np.where(Tr[t] == 1)[0]
        if len(vs) != 2:
            continue
        u, v = vs[0], vs[1]
        c = None
        best_d = float("inf")
        for tt in range(max(2, t - 40), min(T - 1, t + 40)):
            if abs(tt - t) < 4:
                continue
            if Tr[tt].sum() != 0 or Tr[tt + 1].sum() != 0:
                continue
            d = abs(np.log1p(Y[t - 1, u]) - np.log1p(Y[tt - 1, u]))
            if d < best_d:
                best_d = d
                c = tt
        if c is None:
            continue
        est_jce_u = Y[t + 1, u] - Y[c + 1, u]
        true_jce_u = (sim["ACE"][u] + sim["J"][u, v]
                      + (A[u, v] * sim["spill"][u] if A[u, v] else 0.0))
        errors.append(est_jce_u - true_jce_u)
    return {"n_dual": len(errors),
            "jce_mean_error": float(np.mean(errors)) if errors else None,
            "jce_mean_abs_error": float(np.mean(np.abs(errors))) if errors else None}


def bootstrap_coverage(sim, rng, n_boot=200):
    Tr, Y = sim["Tr"], sim["Y"]
    rows = match(Tr, Y, rng, require_clean=True)
    diffs = np.array([Y[t + 1, v] - Y[tt + 1, v] for (t, v, tt) in rows])
    rng2 = np.random.RandomState(99)
    boot = [np.mean(rng2.choice(diffs, len(diffs), replace=True))
            for _ in range(n_boot)]
    lo, hi = np.percentile(boot, 2.5), np.percentile(boot, 97.5)
    return {"ci": [float(lo), float(hi)]}


def main():
    results = {}
    for seed in range(5):
        sim = simulate(seed=seed)
        sim_sparse = simulate(seed=seed + 1000, p_base=0.03, p_amp=0.04,
                              p_min=0.01, p_max=0.2)
        rng = np.random.RandomState(seed)
        res = ace_estimates(sim, rng)
        res.update(jce_recovery(sim_sparse, rng))
        res.update(bootstrap_coverage(sim, rng))
        results[seed] = res
        print("seed", seed, res, flush=True)
    ann_ace = [results[s]["annotated_ace"] for s in results
               if results[s]["annotated_ace"] is not None]
    unann_ace = [results[s]["unannotated_ace"] for s in results
                 if results[s]["unannotated_ace"] is not None]
    summary = {
        "annotated_ace_mean": float(np.mean(ann_ace)),
        "unannotated_ace_mean": float(np.mean(unann_ace)),
        "jce_mean_abs_error_mean": float(np.mean([
            results[s]["jce_mean_abs_error"] for s in results
            if results[s]["jce_mean_abs_error"] is not None])),
        "jce_mean_error_mean": float(np.mean([
            results[s]["jce_mean_error"] for s in results
            if results[s]["jce_mean_error"] is not None])),
        "n_dual_mean": float(np.mean([
            results[s]["n_dual"] for s in results])),
        "annotated_pairs_mean": float(np.mean([
            results[s]["annotated_pairs"] for s in results])),
        "unannotated_pairs_mean": float(np.mean([
            results[s]["unannotated_pairs"] for s in results])),
        "unannotated_contaminated_fraction_mean": float(np.mean([
            results[s]["unannotated_contaminated_controls"]
            / max(1, results[s]["unannotated_pairs"]) for s in results])),
        "ci_examples": {str(s): results[s]["ci"] for s in results},
        "note": "Synthetic controller with known ACE/JCE, spatial spillover, "
                "confounded assignment, and multi-event interactions. "
                "Annotated PSM restricts controls to true treatment=0; "
                "unannotated admits treated controls (contamination). "
                "The JCE target includes own ACE + pairwise interaction + "
                "spillover from the partner node.",
    }
    with open(BASE / "simulate_causal_results.json", "w") as f:
        json.dump(summary, f, indent=2)
    print("Saved simulate_causal_results.json", flush=True)


if __name__ == "__main__":
    main()
