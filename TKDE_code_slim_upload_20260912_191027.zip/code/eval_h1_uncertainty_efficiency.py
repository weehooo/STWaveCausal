"""Conformal uncertainty and per-sample inference cost for the H1 family."""
import argparse
import json
import os
import sys
import time
from datetime import datetime, timezone

import numpy as np
import torch

BASE = os.environ.get("PAPERS_BASE", os.path.dirname(os.path.abspath(__file__)))
os.chdir(BASE)
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from eval_same_split import (collate_ctx, collate_graph, collate_pred,
                             loader_for, preds_stid, preds_v3)
from eval_h1_flow_baselines import CFGS, targets
from stwave_causal_v3 import STWaveCausalV3
from stid_causal import STIDCausal


def dataset_loaders(name, cfg, split):
    data_dir = os.path.join("data", name, "processed")
    npz = os.path.join("data", "datasets", f"{name}_staeformer", "data.npz")
    meta = np.load(npz)["data"][..., 1:3][:, 0] if os.path.exists(npz) else None
    from graphctx_dataset import GraphCtxCausalDataset
    from graph_dataset import GraphTrafficDataset
    from dataset import TrafficCausalDataset
    ctx_ds = GraphCtxCausalDataset(data_dir, split, 48,
                                   ctx_mode=cfg["ctx_mode"], meta=meta)
    graph_ds = GraphTrafficDataset(data_dir, split, 48)
    traffic_ds = TrafficCausalDataset(data_dir, split, 48)
    return (loader_for(ctx_ds, collate_ctx),
            loader_for(graph_ds, collate_graph),
            loader_for(traffic_ds, collate_pred))


def conformal_stats(pred, target, cal_scores, level=0.9):
    radius = float(np.quantile(cal_scores, level))
    covered = np.max(np.abs(pred - target), axis=1) <= radius
    picp = float(np.mean(covered))
    mpiw = float(2.0 * radius)
    return {"picp": picp, "mpiw": mpiw,
            "coverage_gap": picp - level, "radius": radius}


def efficiency(name, cfg, device):
    data_dir = os.path.join("data", name, "processed")
    v3 = STWaveCausalV3(n_zones=cfg["n_zones"], input_dim=cfg["input_dim"],
                        output_dim=cfg["output_dim"],
                        ctx_channels=cfg["ctx_channels"]).to(device)
    v3.load_state_dict(torch.load(
        f"{data_dir}/rerun_v3_seed42.pt", map_location=device))
    v3.eval()
    stid = STIDCausal(n_zones=cfg["n_zones"],
                      input_dim=cfg["feature_dim"],
                      output_dim=cfg["feature_dim"]).to(device)
    stid.load_state_dict(torch.load(
        f"{data_dir}/rerun_stid_seed42.pt", map_location=device))
    stid.eval()
    params = {
        "V3": sum(parameter.numel()
                  for parameter in v3.parameters()),
        "STID": sum(parameter.numel()
                    for parameter in stid.parameters()),
    }
    ctx_loader, graph_loader, _ = dataset_loaders(name, cfg, "test")
    samples = 0
    torch.cuda.reset_peak_memory_stats(device)
    start = time.perf_counter()
    with torch.no_grad():
        for batch in ctx_loader:
            data = {key: value.to(device) for key, value in batch.items()}
            _, _ = v3(data["zone_ids"], data["features"])
            samples += data["zone_ids"].shape[0]
    v3_ms = (time.perf_counter() - start) / samples * 1000.0
    stid_samples = 0
    start = time.perf_counter()
    with torch.no_grad():
        for batch in graph_loader:
            data = {key: (value.to(device)
                          if isinstance(value, torch.Tensor) else value)
                    for key, value in batch.items()}
            _ = stid(data["features"], data["zone_ids"], data["adj"])
            stid_samples += data["zone_ids"].shape[0]
    stid_ms = (time.perf_counter() - start) / stid_samples * 1000.0
    gpu_mb = torch.cuda.max_memory_allocated(device) / 1024.0 / 1024.0
    return {"params": params, "inference_ms_per_sample": {
        "V3": v3_ms, "STID": stid_ms},
        "peak_gpu_mb": float(gpu_mb)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--datasets", nargs="+", default=["pems08", "pems04"])
    parser.add_argument("--output", default="h1_uncertainty_efficiency.json")
    args = parser.parse_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    output = {"metadata": {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "device": device, "torch": torch.__version__}, "datasets": {}}
    for name in args.datasets:
        cfg = CFGS[name]
        data_dir = os.path.join("data", name, "processed")
        cal_ctx, cal_graph, cal_traffic = dataset_loaders(name, cfg, "val")
        test_ctx, test_graph, test_traffic = dataset_loaders(name, cfg, "test")
        cal_target = targets(cal_ctx)
        test_target = targets(test_ctx)
        rows = {}
        for seed in ["42", "1", "2"]:
            v3_cal = preds_v3(cfg["n_zones"], cfg["input_dim"],
                              cfg["output_dim"], cfg["ctx_channels"],
                              f"{data_dir}/rerun_v3_seed{seed}.pt",
                              cal_ctx)
            stid_cal = preds_stid(cfg["n_zones"], cfg["feature_dim"],
                                  f"{data_dir}/rerun_stid_seed{seed}.pt",
                                  cal_graph)
            ens_cal = 0.5 * (v3_cal + stid_cal)
            v3_test = preds_v3(cfg["n_zones"], cfg["input_dim"],
                               cfg["output_dim"], cfg["ctx_channels"],
                               f"{data_dir}/rerun_v3_seed{seed}.pt",
                               test_ctx)
            stid_test = preds_stid(cfg["n_zones"], cfg["feature_dim"],
                                   f"{data_dir}/rerun_stid_seed{seed}.pt",
                                   test_graph)
            ens_test = 0.5 * (v3_test + stid_test)
            cal_scores = np.max(np.abs(ens_cal - cal_target), axis=1)
            rows[seed] = {
                "ensemble_90": conformal_stats(ens_test, test_target,
                                                cal_scores),
                "v3_mae": float(np.abs(v3_test - test_target).mean()),
                "stid_mae": float(np.abs(stid_test - test_target).mean()),
                "ensemble_mae": float(np.abs(ens_test - test_target).mean()),
            }
        output["datasets"][CFGS[name]["display"]] = {
            "per_seed": rows,
            "ensemble_mean_picp": float(np.mean(
                [rows[seed]["ensemble_90"]["picp"] for seed in rows])),
            "ensemble_mean_mpiw": float(np.mean(
                [rows[seed]["ensemble_90"]["mpiw"] for seed in rows])),
            "ensemble_mean_mae": float(np.mean(
                [rows[seed]["ensemble_mae"] for seed in rows])),
            "efficiency": efficiency(name, cfg, device),
        }
    with open(args.output, "w", encoding="utf-8") as handle:
        json.dump(output, handle, indent=2)
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
