"""Plot the PEMS-BAY event-study / DiD audit curves."""

import json
import os
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


BASE = Path(os.environ.get("PAPERS_BASE", Path(__file__).resolve().parent))
os.chdir(BASE)


def main():
    with Path("pemsbay_eventsudy_results.json").open(encoding="utf-8") as fh:
        d = json.load(fh)
    rel = np.asarray(d["pooled_event_study"]["relative_time"], dtype=float)
    mean = np.asarray(d["pooled_event_study"]["mean_effect"], dtype=float)
    se = np.asarray(d["pooled_event_study"]["se"], dtype=float)
    donor = np.asarray(d["pooled_donor_robustness"]["mean_effect"], dtype=float)

    fig, ax = plt.subplots(figsize=(6.0, 3.1))
    ax.axhline(0.0, color="0.55", lw=0.8, ls="--")
    ax.fill_between(rel, mean - 1.96 * se, mean + 1.96 * se,
                    color="#4C72B0", alpha=0.18, label="95% CI (primary)")
    ax.plot(rel, mean, color="#4C72B0", marker="o", ms=3.5, lw=1.6,
            label="Primary (same-clock clean-day)")
    ax.plot(rel, donor, color="#DD8452", marker="s", ms=3.0, lw=1.4,
            ls="--", label="Donor robustness")
    ax.axvline(0.0, color="0.35", lw=0.9)
    ax.set_xlabel("Relative time to incident (5-min steps)")
    ax.set_ylabel("Speed anomaly (mph)")
    ax.set_title("PEMS-BAY incident event-study (8,576 events)")
    ax.legend(frameon=False, fontsize=7)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()
    fig.savefig("figures/pemsbay_eventsudy.png", dpi=250)
    print("wrote figures/pemsbay_eventsudy.png")


if __name__ == "__main__":
    main()
