"""Build synthetic multi-event pairs with graph-context input channels."""
import argparse
import os
import sys
from pathlib import Path

import numpy as np
import torch

os.chdir("F:/xuexi/codex/papers")


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/nyc_taxi/processed")
    p.add_argument("--n-zones", type=int, default=265)
    p.add_argument("--feature-dim", type=int, default=6)
    p.add_argument("--active-threshold", type=float, default=50.0)
    p.add_argument("--n-samples", type=int, default=20000)
    p.add_argument("--ctx-mode", choices=["mean", "gradient"], default="mean")
    p.add_argument("--meta-file", default=None,
                   help="official data.npz to take tod/dow channels from")
    return p.parse_args()


SEQ = 48
MAX_EVENTS = 5


def main():
    args = parse_args()
    data_dir = Path(args.data)
    feats = np.load(str(data_dir / "node_features.npy")).astype(np.float32)
    labels = np.load(str(data_dir / "labels.npy"))
    adj_raw = np.load(str(data_dir / "adj.npy")).astype(np.float32)
    adj = adj_raw / np.maximum(adj_raw.sum(axis=1, keepdims=True), 1e-6)
    meta = None
    if args.meta_file:
        raw_meta = np.load(args.meta_file)["data"][..., 1:3].astype(np.float32)
        assert np.allclose(raw_meta, raw_meta[:, 0:1], atol=1e-5), \
            "tod/dow are not global across nodes"
        meta = raw_meta[:, 0]
        print("Meta channels:", meta.shape, flush=True)
    D = args.feature_dim
    N = args.n_zones
    M = 0 if meta is None else meta.shape[1]
    print("Features:", feats.shape, flush=True)

    active = [z for z in range(N)
              if feats[:, z, 0].mean() > args.active_threshold
              and (feats[:, z, 0] == 0).mean() < 0.3]
    print("Active zones:", len(active), flush=True)

    candidates = []
    for z in active:
        cnt = 0
        for t in range(SEQ + 5, feats.shape[0] - 1):
            if labels[t, z] == 0:
                candidates.append((z, t))
                cnt += 1
                if cnt > 500:
                    break
    print("Candidate windows:", len(candidates), flush=True)

    def window(t):
        t_start = max(0, t - SEQ)
        w = feats[t_start:t]
        if len(w) < SEQ:
            pad = np.zeros((SEQ - len(w), N, D), dtype=w.dtype)
            w = np.concatenate([pad, w], axis=0)
        return w

    def state_ctx(t, z):
        ctx = np.einsum("nd,n->d", feats[t], adj[z])
        if args.ctx_mode == "gradient":
            ctx = ctx - feats[t, z]
        parts = [feats[t, z], ctx]
        if meta is not None:
            parts.append(meta[t])
        return np.concatenate(parts)

    def meta_window(t):
        if meta is None:
            return None
        t_start = max(0, t - SEQ)
        m = meta[t_start:t]
        if len(m) < SEQ:
            m = np.concatenate(
                [np.zeros((SEQ - len(m), m.shape[1]), dtype=m.dtype), m],
                axis=0)
        return m

    rng = np.random.RandomState(42)
    samples = []
    for _ in range(args.n_samples):
        z, t = candidates[rng.randint(len(candidates))]
        w = window(t)
        m_win = meta_window(t)
        y_f = feats[t, z]
        mode = rng.rand()
        if mode < 0.7:
            factor = 0.7
            et = torch.full((MAX_EVENTS,), -1, dtype=torch.long)
            et[0] = 1
            n_events = 1
        elif mode < 0.9:
            factor = 0.8
            et = torch.full((MAX_EVENTS,), -1, dtype=torch.long)
            et[0] = 2
            n_events = 1
        else:
            factor = 0.7 * 0.8
            et = torch.full((MAX_EVENTS,), -1, dtype=torch.long)
            et[0] = 1
            et[1] = 2
            n_events = 2

        modified = w.copy()
        modified[:, z, :min(4, D)] *= factor
        raw_f = w[:, z]
        ctx_f = np.einsum("snd,n->sd", w, adj[z])
        raw_cf = modified[:, z]
        ctx_cf = np.einsum("snd,n->sd", modified, adj[z])
        if args.ctx_mode == "gradient":
            ctx_f = ctx_f - raw_f
            ctx_cf = ctx_cf - raw_cf
        parts_f = [raw_f, ctx_f]
        parts_cf = [raw_cf, ctx_cf]
        if m_win is not None:
            parts_f.append(m_win)
            parts_cf.append(m_win)
        ice_true = np.abs(y_f - y_f * factor).astype(np.float32)

        combo = {
            "event_types": et,
            "event_locs": torch.zeros(MAX_EVENTS, 2),
            "event_times": torch.zeros(MAX_EVENTS),
            "zone_states": torch.zeros(MAX_EVENTS, D * 2 + M),
        }
        for i in range(n_events):
            combo["event_times"][i] = float(t)
            combo["zone_states"][i] = torch.FloatTensor(state_ctx(t, z))

        samples.append({
            "zone": z,
            "t": t,
            "factual": torch.FloatTensor(np.concatenate(parts_f, -1)),
            "cf": torch.FloatTensor(np.concatenate(parts_cf, -1)),
            "ice_true": torch.FloatTensor(ice_true),
            "combo": combo,
        })

    rng.shuffle(samples)
    n = len(samples)
    n_train = int(n * 0.8)
    n_val = int(n * 0.1)
    out = {
        "train": samples[:n_train],
        "val": samples[n_train:n_train + n_val],
        "test": samples[n_train + n_val:],
    }
    save = data_dir / "synthetic_pairs_v3_graphctx.npy"
    np.save(str(save), out, allow_pickle=True)
    print("Saved", save,
          "train/val/test =", len(out["train"]), len(out["val"]), len(out["test"]),
          flush=True)


if __name__ == "__main__":
    main()
