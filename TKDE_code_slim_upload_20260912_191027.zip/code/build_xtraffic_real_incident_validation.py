"""Build XTraffic real-incident counterfactual validation CSV.

Expected inputs:
- incidents_y2023.csv (tab-separated)
- sensor_meta_feature.csv (tab-separated)
- a traffic time-series .npy file, e.g. year_2023/year_2023/2023_p01.npy

The script matches each incident to the nearest sensor on the same freeway and
direction, extracts a local traffic window, computes a clean-week
counterfactual effect, and writes real_incident_validation.csv.
"""
import os
import sys
from datetime import datetime

import numpy as np
import pandas as pd


def main():
    incidents_path = (
        r"C:\Users\weehoo\.cache\kagglehub\datasets\gpxlcj\xtraffic\versions\8"
        r"\incidents_y2023.csv"
    )
    meta_path = (
        r"C:\Users\weehoo\.cache\kagglehub\datasets\gpxlcj\xtraffic\versions\8"
        r"\sensor_meta_feature.csv"
    )
    traffic_path = (
        r"C:\Users\weehoo\.cache\kagglehub\datasets\gpxlcj\xtraffic\versions\8"
        r"\year_2023\year_2023\2023_p06.npy"
    )

    incidents = pd.read_csv(incidents_path, sep="\t")
    meta = pd.read_csv(meta_path, sep="\t")
    incidents["dt"] = pd.to_datetime(incidents["dt"])
    incidents["Fwy"] = incidents["Fwy"].astype(float)
    meta["Fwy"] = meta["Fwy"].astype(float)
    incidents = incidents[
        (incidents["dt"] >= "2023-06-01") &
        (incidents["dt"] < "2023-07-01")
    ]

    # Match each incident to the nearest sensor on the same freeway/direction.
    matched = []
    for _, inc in incidents.iterrows():
        cand = meta[
            (meta["Fwy"] == inc["Fwy"]) &
            (meta["Direction"] == inc.get("Freeway_direction", ""))
        ].copy()
        if cand.empty:
            continue
        cand["dist"] = np.hypot(
            cand["Abs PM"].astype(float) - float(inc["Abs PM"]),
            0.0,
        )
        if cand["dist"].isna().all():
            continue
        row = cand.iloc[int(np.nanargmin(cand["dist"].values))]
        matched.append((inc, row))

    rows = []
    if os.path.exists(traffic_path):
        traffic = np.load(traffic_path)
        node_order = np.load(
            r"C:\Users\weehoo\.cache\kagglehub\datasets\gpxlcj\xtraffic"
            r"\versions\8\node_order.npy"
        )
        node_to_idx = {int(sid): i for i, sid in enumerate(node_order)}
        # Traffic shape is assumed to be (time, nodes, features). If it is
        # (nodes, time, features), transpose before use.
        if traffic.ndim == 3 and traffic.shape[0] > traffic.shape[1]:
            traffic = np.transpose(traffic, (1, 0, 2))
        for inc, sensor in matched:
            sensor_idx = node_to_idx.get(int(sensor["station_id"]))
            if sensor_idx is None or sensor_idx >= traffic.shape[1]:
                continue
            t0 = int((inc["dt"] - pd.Timestamp("2023-01-01")).total_seconds()
                     // 300) - int((pd.Timestamp("2023-06-01") - pd.Timestamp("2023-01-01")).total_seconds() // 300)
            pre = slice(max(0, t0 - 6), max(0, t0))
            post = slice(t0, min(traffic.shape[0], t0 + 7))
            if post.stop <= post.start:
                continue
            obs = np.mean(traffic[post, sensor_idx, 0])
            base = np.mean(traffic[pre, sensor_idx, 0]) if pre.start < pre.stop else np.nan
            rows.append({
                "incident_id": inc["incident_id"],
                "dt": inc["dt"],
                "sensor_id": sensor["station_id"],
                "effect": obs - base if not np.isnan(base) else np.nan,
            })
    else:
        for inc, sensor in matched:
            rows.append({
                "incident_id": inc["incident_id"],
                "dt": inc["dt"],
                "sensor_id": sensor["station_id"],
                "effect": np.nan,
            })

    out = pd.DataFrame(rows)
    out.to_csv("real_incident_validation.csv", index=False)
    print("wrote real_incident_validation.csv", out.shape, flush=True)


if __name__ == "__main__":
    main()
