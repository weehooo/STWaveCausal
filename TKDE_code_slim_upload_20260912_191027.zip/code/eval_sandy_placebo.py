"""Hurricane Sandy placebo test with the V3 model.

Compares the V3 prediction-difference ACE on Sandy windows against a placebo
distribution of ACE values from matched non-intervention windows in the same
zones. Reports per-zone and pooled z-scores.
"""
import os
import sys
from datetime import datetime, timedelta

import numpy as np
import torch
import torch.nn as nn

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, "src/model")

from stwave import STWaveBlock
from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"
print("Device:", device)

SEQ = 48
start = datetime(2011, 1, 1, 0, 0, 0)
sandy_t = int((datetime(2012, 10, 29, 0, 0, 0) - start).total_seconds() / (30 * 60))
print("Sandy t:", sandy_t)

feats = np.load("data/nyc_taxi/processed/node_features.npy", mmap_mode="r")
labels = np.load("data/nyc_taxi/processed/labels.npy", mmap_mode="r")

model = STWaveCausalV3(n_zones=265, input_dim=6).to(device)
model.load_state_dict(torch.load(
    "data/nyc_taxi/processed/stwave_causal_v3_full_best.pt", map_location=device))
model.eval()


class SWPred(nn.Module):
    def __init__(self, nz=265, nd=6):
        super().__init__()
        self.zone_embed = nn.Embedding(nz, 64)
        self.input_proj = nn.Linear(nd, 64)
        self.pos_embed = nn.Embedding(48, 64)
        self.blocks = nn.ModuleList([STWaveBlock(nz, 64) for _ in range(2)])
        self.pred_head = nn.Sequential(nn.Linear(64, 64), nn.ReLU(), nn.Linear(64, nd))

    def forward(self, zid, f):
        B, S, D = f.shape
        x = self.input_proj(f)
        pos = torch.arange(S, device=f.device).unsqueeze(0).expand(B, -1)
        x = (self.zone_embed(zid) + x + self.pos_embed(pos)).unsqueeze(1)
        for b in self.blocks:
            x = b(x)
        return self.pred_head(x[:, 0, -1, :])


predonly = SWPred().to(device)
predonly.load_state_dict(torch.load(
    "data/nyc_taxi/processed/stwave_predonly_50ep.pt", map_location=device))
predonly.eval()

CF_OFFSET = 7 * 7 * 48  # 7 weeks earlier in 30-minute windows


def window(zone, t):
    ts = max(0, t - SEQ)
    w = feats[ts:t, zone].copy()
    if len(w) < SEQ:
        w = np.concatenate([np.zeros((SEQ - len(w), 6)), w])
    return w


@torch.no_grad()
def ace_v3(zone, t, t_star):
    ff = torch.FloatTensor(window(zone, t)).unsqueeze(0).to(device)
    cf = torch.FloatTensor(window(zone, t_star)).unsqueeze(0).to(device)
    zid = torch.full((1, SEQ), zone, dtype=torch.long, device=device)
    _, pf = model(zid, ff)
    _, pcf = model(zid, cf)
    return float(np.mean(np.abs(pf[0].cpu().numpy() - pcf[0].cpu().numpy())))


@torch.no_grad()
def ace_predonly(zone, t, t_star):
    ff = torch.FloatTensor(window(zone, t)).unsqueeze(0).to(device)
    cf = torch.FloatTensor(window(zone, t_star)).unsqueeze(0).to(device)
    zid = torch.full((1, SEQ), zone, dtype=torch.long, device=device)
    pf = predonly(zid, ff)
    pcf = predonly(zid, cf)
    return float(np.mean(np.abs(pf[0].cpu().numpy() - pcf[0].cpu().numpy())))


def placebo_ace(zone, t):
    t_star = t - CF_OFFSET
    if t_star <= SEQ:
        return None
    return ace_v3(zone, t, t_star)


impacts = []
for zone in range(265):
    pre = feats[sandy_t - SEQ:sandy_t, zone, 0].mean()
    post = feats[sandy_t:sandy_t + SEQ, zone, 0].mean()
    if abs(post - pre) > 0.3:
        impacts.append((zone, float(abs(post - pre)), float(pre), float(post)))
impacts.sort(key=lambda x: x[1], reverse=True)
print("Impacted zones:", len(impacts))

rng = np.random.RandomState(42)
results = []
targets = list(dict.fromkeys(
    [z for z, _, _, _ in impacts[:20]] + [78, 185, 169]))
for zone in targets:
    t_star = sandy_t - CF_OFFSET
    if t_star <= SEQ:
        continue
    sandy_ace = ace_v3(zone, sandy_t, t_star)
    placebos = []
    for _ in range(200):
        t = int(rng.randint(SEQ + 1, feats.shape[0] - 1))
        if abs(t - sandy_t) < 1000 or labels[t, zone] != 0:
            continue
        v = placebo_ace(zone, t)
        if v is not None:
            placebos.append(v)
    if len(placebos) < 50:
        continue
    mu, sd = float(np.mean(placebos)), float(np.std(placebos))
    z = (sandy_ace - mu) / (sd + 1e-8)
    results.append((zone, sandy_ace, mu, sd, z, len(placebos)))
    print("Zone %3d: Sandy ACE=%.3f placebo mean=%.3f std=%.3f z=%.2f n=%d"
          % (zone, sandy_ace, mu, sd, z, len(placebos)))

if results:
    zone78 = next((r for r in results if r[0] == 78), None)
    if zone78:
        z78 = zone78[4]
        from scipy.stats import norm
        p78 = norm.sf(z78)
        print("\nZone 78: z=%.2f one-sided p=%.4f" % (z78, p78))
    pooled_sandy = [r[1] for r in results]
    print("Per-zone Sandy ACE mean: %.3f" % np.mean(pooled_sandy))
    zs = [r[4] for r in results]
    print("z-scores: mean=%.2f, median=%.2f, >1.96 count=%d/%d"
          % (np.mean(zs), np.median(zs), sum(z > 1.96 for z in zs), len(zs)))
    for zone in [78, 185, 169]:
        row = next((r for r in results if r[0] == zone), None)
        if row:
            from scipy.stats import norm
            pa = ace_predonly(zone, sandy_t, sandy_t - CF_OFFSET)
            print("Paper zone %d: PredOnly ACE=%.3f V3 ACE=%.3f ratio=%.2f "
                  "placebo mean=%.3f z=%.2f p=%.4f"
                  % (zone, pa, row[1], row[1] / (pa + 1e-8),
                     row[2], row[4], norm.sf(row[4])))
print("ALL DONE")
