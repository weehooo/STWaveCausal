# STWaveCausal

Code and experiments for the STWaveCausal paper (TKDE submission target):
identifiable multi-event counterfactual reasoning for spatio-temporal traffic
forecasting.

## Datasets

- `data/nyc_taxi/processed` - NYC taxi flow, 265 zones, 52,608 windows, D=6
- `data/pems_bay/processed` - PEMS-BAY speed, 325 sensors, 52,116 windows, D=8
- `data/pems08/processed` - PEMS08 flow, 170 sensors, 17,856 windows, D=1
- `data/pems04/processed` - PEMS04 flow, 307 sensors, 16,992 windows, D=1

Each processed directory contains `node_features.npy`, `labels.npy`,
`matched_pairs.npy`, `psm_stats.txt`, `adj.npy` (graph baselines), and
`synthetic_pairs_v3.npy` (known-effect benchmark).

PEMS08 raw data is the official STAEformer release:
`https://github.com/XDZhelheim/STAEformer` (data/PEMS08).

## Main training commands

```bash
# V3 full objective (NYC, 50 epochs)
python train_causal_v3_full.py \
  --data data/nyc_taxi/processed \
  --n-zones 265 --feature-dim 6 --epochs 50 \
  --out stwave_causal_v3_full_best.pt

# V3 two-stage (PEMS-BAY / PEMS08, 50 pred-only + 20 causal)
python train_causal_v3_full.py \
  --data data/pems_bay/processed \
  --synthetic data/pems_bay/processed/synthetic_pairs_v3_pems.npy \
  --n-zones 325 --feature-dim 8 --epochs 70 --pretrain-epochs 50 \
  --out stwave_causal_v3_full_pems_50p20_best.pt

# Baselines
python train_graph_baselines.py      # STIDGraph / STAEFormerGraph
python train_pems08_baselines.py     # STWave / CrossGNN / PredOnly / STIDGraph on PEMS08
python train_flow_baselines.py \
  --data data/pems04/processed --n-zones 307 --feature-dim 1 --epochs 50

# PEMS04 evaluation (val MAE + paired Wilcoxon)
python eval_pems04.py

# Official STAEformer baseline (PEMS08)
python train_staeformer_pems08.py
```

## Key checkpoints

- NYC V3: `data/nyc_taxi/processed/stwave_causal_v3_full_best.pt`
- PEMS-BAY V3 (50+20): `data/pems_bay/processed/stwave_causal_v3_full_pems_50p20_best.pt`
- Old L_pred-only checkpoint backed up as
  `data/nyc_taxi/processed/stwave_causal_v3_full_best_lpredonly_backup.pt`

## New experiments (2026-08-16)

### 12-step protocol (PEMS08, official STAEformer protocol)

```bash
# STWaveCausal V3 instance under the 5,000-window x 30-epoch budget
python train_pems08_12step.py --model v3 --epochs 30 --batch-size 16 \
  --max-windows 5000 --out data/pems08/processed/stwavecausal_v3_12step_best.pt
```

The `v3` model (`STWaveCausal12FG` in `src/model/models_12step.py`) uses the
STWave backbone with graph-context and per-zone gate, matching the 1-step
PEMS08 V3 instance.

### STIDCausal encoder comparison (2x4)

```bash
python run_stidcausal_encoders.py          # PEMS08/NYC/PEMS-BAY/PEMS08 seeds
python eval_stidcausal_pems08_multi_seed.py  # PEMS08 5-seed vs STIDGraph
python eval_encoder_2x4.py                   # 2x4 table + equal-weight ensemble
```

### Causal recovery calibration (STID instances)

```bash
# PEMS04 seed 42 (and seed 2), PEMS08 best seed
python calibrate_stidcausal_recovery.py --data data/pems04/processed \
  --n-zones 307 --feature-dim 1 --epochs 30 --lambda3 3.0 --lr 3e-4 \
  --batch-size 8 --init data/pems04/processed/stid_causal_pems04_best.pt \
  --out stid_causal_pems04_calib_l3.pt
```

### Real-event validation

```bash
python bootstrap_event_ace.py       # bootstrap 95% CI for event ACE
python eval_annotation_events.py    # annotation precision/recall on known events
```

## Annotation control-pool ablation and statistical checks (K2/K3)

```bash
python eval_psm_balance_pretty.py --data-dirs data/nyc_taxi data/pems_bay
python eval_annotation_pr.py        # precision/recall scan over the rule tau
python eval_annotation_local.py     # controlled local-perturbation sensitivity
python eval_test_wilcoxon.py        # paired Wilcoxon on held-out test splits
```

`eval_psm_balance_pretty.py` compares annotation-constrained PSM, covariate
PSM without the label constraint, and a random no-covariate control on the same
treated windows, reporting max/mean SMD and the share of ``non-clean'' controls
(Table `tab:control_pool`).

## Capability upgrades (2026-08-20)

```bash
python detect_calibrated.py      # learnable calibratable intervention detector
python plot_detect_pr.py         # precision/recall curve (AUC 0.984)
python simulate_causal.py        # synthetic ACE/JCE/spillover controller
python run_psm_reproducible.py   # zdim-standardized PSM + per-dataset caliper
```

`detect_calibrated.py` trains a small NumPy MLP on controlled ground-truth
perturbations and reports a selectable operating point (precision >= 0.90
implies recall 0.965). `simulate_causal.py` validates the control-purity
proposition: unannotated PSM admits 37.4% contaminated controls and attenuates
the ACE estimate by about one unit, while annotated PSM recovers the truth.
`run_psm_reproducible.py` standardizes features per dimension and selects the
largest per-dataset caliper in {0.5, 0.3, 0.1} that keeps max SMD below 0.1.

## 3-seed same-split refresh (2026-08-25)

```bash
python eval_same_split.py        # val/test same-split table + paired Wilcoxon
python eval_synth_new.py         # NYC graph-ctx synthetic recovery (0.99997)
python eval_causal_estimators.py # V3 vs before-after / DiD / SC on 50 zones
python eval_sandy_new.py         # Sandy per-zone placebo table (zones 78/185/169)
```

Precomputed outputs are collected under `code/results/`.

## Reproducibility

- Python 3.8, PyTorch 2.3.1, CUDA 12.1
- Single RTX 2060 SUPER, fixed seed 42
- Full joint loss:
  `L_pred + 0.3*(L_con^s + L_con^m) + 0.01*L_div + 0.3*L_causal`

Detailed status and remaining work: `SmartSteer_Status1.md`,
`SmartSteer_Status2.md`.
