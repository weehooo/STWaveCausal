"""P0: learnable, calibratable intervention detector.

Builds a controlled ground-truth population (single-zone perturbations of
known factor/duration vs. clean windows), trains a small NumPy MLP to emit a
continuous intervention score, and reports the precision/recall trade-off with
a selectable operating point. Honest: real-event absolute recall cannot be
verified from observations; the detector's *calibration* and *tunability* on
controlled ground truth is the claimed capability.
"""
import json
from pathlib import Path

import numpy as np

BASE = Path(r"F:\xuexi\codex\papers")
FEAT = np.load(BASE / "data/nyc_taxi/processed/node_features.npy").astype(
    np.float64)
LABELS = np.load(BASE / "data/nyc_taxi/processed/labels.npy")
T, N, D = FEAT.shape
W = 48


def period_stats(features):
    flow = features[:, :, 0] + features[:, :, 1]
    seg = np.arange(T) % W
    mean_p = np.zeros((W, N))
    std_p = np.zeros((W, N))
    for w in range(W):
        m = seg == w
        vals = flow[m]
        mean_p[w] = vals.mean(axis=0)
        std_p[w] = vals.std(axis=0) + 1e-8
    return flow, mean_p, std_p


def hawkes_z(flow, zone, t0, decay_hours=4.0, alpha=0.3, mu=0.1):
    beta = 1.0 / (decay_hours * 2)
    start = max(0, t0 - 12)
    f = flow[start:t0 + 1, zone]
    intensity = np.zeros(len(f))
    intensity[0] = mu
    for i in range(1, len(f)):
        intensity[i] = intensity[i - 1] * np.exp(-beta)
        if i > 1:
            r = abs(f[i - 1] - f[i - 2])
            if r > 0.15 * (f[i - 2] + 1):
                intensity[i] += alpha * np.exp(-beta)
        intensity[i] += mu * (1 - np.exp(-beta))
    expected = intensity * float(flow.mean())
    return np.abs(f - expected) / (expected + 1)


def make_features(flow, mean_p, std_p, zone, t0):
    """Hand-crafted local window signature for the detector."""
    z0 = abs((flow[t0, zone] - mean_p[t0 % W, zone]) / std_p[t0 % W, zone])
    z1 = abs((flow[max(0, t0 - 1), zone] - mean_p[(t0 - 1) % W, zone])
             / std_p[(t0 - 1) % W, zone])
    zn = abs((flow[min(T - 1, t0 + 1), zone] - mean_p[(t0 + 1) % W, zone])
             / std_p[(t0 + 1) % W, zone])
    f = flow[:, zone]
    rel_prev = (f[t0 - 1] - f[t0]) / (f[t0 - 1] + 1) if t0 > 0 else 0.0
    rel_prev2 = (f[max(0, t0 - 2)] - f[t0]) / (f[max(0, t0 - 2)] + 1)
    rel_next = (f[t0] - f[min(T - 1, t0 + 1)]) / (f[t0] + 1)
    rel_next2 = (f[t0] - f[min(T - 1, t0 + 2)]) / (f[t0] + 1)
    window = f[max(0, t0 - 5):t0 + 6]
    hz = hawkes_z(flow, zone, t0)
    feats = np.array([
        z0, z1, zn,
        rel_prev, rel_prev2, rel_next, rel_next2,
        hz[-1],
        float(window.mean()) / (f.mean() + 1.0),
        float(window.std()) / (window.mean() + 1.0),
        float(f[t0]) / (f.mean() + 1.0),
    ])
    return feats


def sample_pool(flow, mean_p, std_p, rng, n_each_zone=8):
    zone_mean = flow.mean(axis=0)
    active = np.where(zone_mean > 15)[0]
    active = rng.choice(active, size=min(120, len(active)), replace=False)
    pool = []
    t0s = list(range(600, T - 200, 60))
    for z in active:
        row = flow[:, z]
        got = 0
        for t0 in t0s:
            if LABELS[t0, z] != 0:
                continue
            zr = abs((row[t0] - mean_p[t0 % W, z]) / std_p[t0 % W, z])
            if zr > 1.5:
                continue
            if abs(row[t0] - row[max(0, t0 - 1)]) > 0.05 * (row[t0] + 1):
                continue
            pool.append((z, t0))
            got += 1
            if got >= n_each_zone:
                break
    return pool


def generate_set(pool, rng):
    """Half clean, half injected (random factor/duration) with known labels."""
    rng.shuffle(pool)
    half = len(pool) // 2
    clean = pool[:half]
    inject = pool[half:2 * half]
    factors = [0.1, 0.3, 0.5, 0.7]
    durations = [1, 2, 3]
    X, y = [], []
    for (z, t0) in clean:
        X.append(make_features(flow, mean_p, std_p, z, t0))
        y.append(0)
    for (z, t0) in inject:
        f = rng.choice(factors)
        d = int(rng.choice(durations))
        pf = flow.copy()
        s = max(0, t0 - d + 1)
        e = t0 + 1
        pf[s:e, z] = f * pf[s:e, z]
        X.append(make_features(pf, mean_p, std_p, z, t0))
        y.append(1)
    return np.array(X), np.array(y)


class MLP:
    def __init__(self, d_in, h=32, seed=0):
        rng = np.random.RandomState(seed)
        self.W1 = np.sqrt(2.0 / d_in) * rng.randn(d_in, h)
        self.b1 = np.zeros(h)
        self.W2 = np.sqrt(1.0 / h) * rng.randn(h, 1)
        self.b2 = np.zeros(1)

    def forward(self, X):
        z1 = X @ self.W1 + self.b1
        a1 = np.tanh(z1)
        logit = a1 @ self.W2 + self.b2
        return a1, logit

    def predict_prob(self, X):
        _, logit = self.forward(X)
        return 1.0 / (1.0 + np.exp(-logit))


def standardize(X, mean=None, std=None):
    if mean is None:
        mean = X.mean(axis=0)
        std = X.std(axis=0) + 1e-8
    return (X - mean) / std, mean, std


def pr_curve(prob, y, n=80):
    ths = np.linspace(0.02, 0.98, n)
    rows = []
    for th in ths:
        pred = prob >= th
        tp = int(((pred == 1) & (y == 1)).sum())
        fp = int(((pred == 1) & (y == 0)).sum())
        fn = int(((pred == 0) & (y == 1)).sum())
        rows.append({
            "threshold": round(float(th), 3),
            "precision": round(tp / max(1, tp + fp), 4),
            "recall": round(tp / max(1, tp + fn), 4),
        })
    return rows


def opt_point(rows, p_target=0.90):
    best = None
    for r in rows:
        if r["precision"] >= p_target:
            if best is None or r["recall"] > best["recall"]:
                best = r
    return best


def main():
    global flow, mean_p, std_p
    flow, mean_p, std_p = period_stats(FEAT)
    rng = np.random.RandomState(0)
    pool = sample_pool(flow, mean_p, std_p, rng)
    print("pool size:", len(pool), flush=True)
    rng2 = np.random.RandomState(7)
    X, y = generate_set(pool, rng2)
    n = len(y)
    idx = rng2.permutation(n)
    n_tr = int(0.6 * n)
    X_tr, y_tr = X[idx[:n_tr]], y[idx[:n_tr]]
    X_te, y_te = X[idx[n_tr:]], y[idx[n_tr:]]
    Xs, mean, std = standardize(X_tr)
    Xte, _, _ = standardize(X_te, mean, std)

    model = MLP(Xs.shape[1])
    lr = 1e-2
    lam = 1e-3
    for epoch in range(600):
        a1, logit = model.forward(Xs)
        p = 1.0 / (1.0 + np.exp(-logit))
        grad = (p - y_tr.reshape(-1, 1)) / len(y_tr)
        # gradient w.r.t. W2, b2
        gW2 = a1.T @ grad + lam * model.W2
        gb2 = grad.sum(axis=0)
        # backprop to hidden
        dz1 = grad @ model.W2.T * (1 - a1 ** 2)
        gW1 = Xs.T @ dz1 + lam * model.W1
        gb1 = dz1.sum(axis=0)
        model.W2 -= lr * gW2
        model.b2 -= lr * gb2
        model.W1 -= lr * gW1
        model.b1 -= lr * gb1
        if epoch % 150 == 0:
            acc = ((p >= 0.5).astype(int).ravel() == y_tr).mean()
            print("epoch %d train_acc %.3f" % (epoch, acc), flush=True)

    prob_tr = model.predict_prob(Xs).ravel()
    prob_te = model.predict_prob(Xte).ravel()
    auc_te = np.mean(
        [1.0 if prob_te[i] > prob_te[j] else
         0.5 if prob_te[i] == prob_te[j] else 0.0
         for i in range(len(y_te)) for j in range(len(y_te))
         if y_te[i] == 1 and y_te[j] == 0])

    rows = pr_curve(prob_te, y_te)
    op = opt_point(rows, 0.90)
    result = {
        "n_train": int(n_tr),
        "n_test": int(n - n_tr),
        "auc_test": round(float(auc_te), 4),
        "operating_point_P>=0.90": op,
        "pr_curve": rows,
        "method": "learnable MLP on local window signature, calibrated on "
                  "controlled synthetic ground truth",
        "honesty_note": "Absolute recall on real, unlogged events cannot be "
                        "verified from observational traffic alone; the "
                        "calibratable P/R trade-off is a genuine capability "
                        "over the fixed near-zero-recall heuristic.",
    }
    with open(BASE / "detect_calibrated_results.json", "w") as f:
        json.dump(result, f, indent=2)
    print("AUC(test)=%.4f" % result["auc_test"], flush=True)
    print("operating point @P>=0.90:", op, flush=True)
    print("Saved detect_calibrated_results.json", flush=True)


if __name__ == "__main__":
    main()
