"""Null placebo calibration: how often z>1.96 occurs on random dates."""
import os
import sys
from datetime import datetime, timedelta

import numpy as np
import torch

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, "src/model")

from stwave_causal_v3 import STWaveCausalV3
from scipy.stats import norm

device = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48
CF_OFFSET = 7 * 7 * 48
start = datetime(2011, 1, 1)
feats = np.load("data/nyc_taxi/processed/node_features.npy", mmap_mode="r")
labels = np.load("data/nyc_taxi/processed/labels.npy", mmap_mode="r")
model = STWaveCausalV3(n_zones=265, input_dim=6).to(device)
model.load_state_dict(torch.load(
    "data/nyc_taxi/processed/stwave_causal_v3_full_best.pt", map_location=device))
model.eval()

EXCLUDE = {
    datetime(2012, 10, 29),
    datetime(2011, 12, 31),
    datetime(2013, 2, 8),
    datetime(2011, 1, 26),
}


def window(zone, t):
    ts = max(0, t - SEQ)
    w = feats[ts:t, zone].copy()
    if len(w) < SEQ:
        w = np.concatenate([np.zeros((SEQ - len(w), 6)), w])
    return w


@torch.no_grad()
def ace(zone, t, t_star):
    zid = torch.full((1, SEQ), zone, dtype=torch.long, device=device)
    ff = torch.FloatTensor(window(zone, t)).unsqueeze(0).to(device)
    cf = torch.FloatTensor(window(zone, t_star)).unsqueeze(0).to(device)
    _, pf = model(zid, ff)
    _, pcf = model(zid, cf)
    return float(np.mean(np.abs(pf[0].cpu().numpy() - pcf[0].cpu().numpy())))


def date_z_scores(date):
    t0 = int((date - start).total_seconds() / (30 * 60))
    if t0 - CF_OFFSET <= SEQ or t0 + SEQ >= feats.shape[0]:
        return []
    impacts = []
    for zone in range(265):
        pre = feats[t0 - SEQ:t0, zone, 0].mean()
        post = feats[t0:t0 + SEQ, zone, 0].mean()
        if abs(post - pre) > 0.3:
            impacts.append((zone, float(abs(post - pre))))
    impacts.sort(key=lambda x: x[1], reverse=True)
    rng = np.random.RandomState(42)
    zs = []
    for zone, _ in impacts[:5]:
        ace_d = ace(zone, t0, t0 - CF_OFFSET)
        pb = []
        for _ in range(150):
            t = int(rng.randint(SEQ + 1, feats.shape[0] - 1))
            if abs(t - t0) < 1000 or labels[t, zone] != 0:
                continue
            ts2 = t - CF_OFFSET
            if ts2 > SEQ:
                pb.append(ace(zone, t, ts2))
        if len(pb) >= 30:
            zs.append((ace_d - np.mean(pb)) / (np.std(pb) + 1e-8))
    return zs


def main():
    rng = np.random.RandomState(7)
    dates = []
    while len(dates) < 15:
        d = start + timedelta(days=int(rng.randint(0, 1095)))
        if d in EXCLUDE or d.weekday() >= 5:
            continue
        dates.append(d)
    all_zs = []
    for d in dates:
        zs = date_z_scores(d)
        all_zs.extend(zs)
        print("%s n=%d max_z=%.2f n_sig=%d" %
              (d.strftime("%Y-%m-%d"), len(zs), max(zs) if zs else 0,
               sum(z > 1.96 for z in zs)), flush=True)
    all_zs = np.array(all_zs)
    frac = np.mean(all_zs > 1.96)
    print("NULL CALIBRATION: n_pairs=%d, z>1.96 fraction=%.3f (expected ~0.05)"
          % (len(all_zs), frac))


if __name__ == "__main__":
    main()
