"""Train and evaluate a frozen-backbone real-data magnitude head.

Uses the features produced by build_pemsbay_magnitude_features.py and a
chronological split: the last 20% of incidents are test, the preceding 20%
are validation, and the first 60% are training. A ridge head is selected on
validation MAE and evaluated on the held-out test incidents.
"""
import json

import numpy as np


def ridge_fit_predict(X, y, X_test, lam):
    X = np.column_stack([np.ones(len(X)), X])
    X_test = np.column_stack([np.ones(len(X_test)), X_test])
    A = X.T @ X + lam * np.eye(X.shape[1])
    w = np.linalg.solve(A, X.T @ y)
    return X_test @ w


def metrics(y_true, y_pred):
    ss_res = float(np.sum((y_true - y_pred) ** 2))
    ss_tot = float(np.sum((y_true - y_true.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    mae = float(np.mean(np.abs(y_true - y_pred)))
    bias = float(np.mean(y_pred - y_true))
    corr = float(np.corrcoef(y_true, y_pred)[0, 1])
    return {"r2": r2, "mae": mae, "bias": bias, "corr": corr}


def normalize(train, val, test):
    mean = train.mean(axis=0)
    std = train.std(axis=0) + 1e-8
    return ((train - mean) / std, (val - mean) / std,
            (test - mean) / std)


def main():
    data = np.load("pemsbay_magnitude_features.npz")
    X = data["X"].astype(np.float64)
    y = data["y"].astype(np.float64)
    starts = data["starts"]
    order = np.argsort(starts)
    X, y = X[order], y[order]

    n = len(y)
    train_end = int(n * 0.60)
    val_end = int(n * 0.80)
    train = np.arange(0, train_end)
    val = np.arange(train_end, val_end)
    test = np.arange(val_end, n)

    X_train, X_val, X_test = normalize(X[train], X[val], X[test])
    y_train, y_val, y_test = y[train], y[val], y[test]

    # Feature groups: prediction channels are features 128:144 in the raw
    # feature vector (h_f 64, h_cf 64, pred_f 8, pred_cf 8, covariates 4).
    groups = {
        "embeddings": np.arange(0, 128),
        "predictions": np.arange(128, 144),
        "covariates": np.arange(144, 148),
        "all": np.arange(X.shape[1]),
    }

    results = {}
    for name, cols in groups.items():
        Xt, Xv, Xs = X_train[:, cols], X_val[:, cols], X_test[:, cols]
        best = None
        for lam in [0.1, 1.0, 10.0, 100.0, 1000.0]:
            pred_val = ridge_fit_predict(Xt, y_train, Xv, lam)
            val_mae = float(np.mean(np.abs(y_val - pred_val)))
            if best is None or val_mae < best[0]:
                best = (val_mae, lam)
        _, lam = best
        pred_test = ridge_fit_predict(Xt, y_train, Xs, lam)
        results[name] = {"lambda": lam, "test": metrics(y_test, pred_test)}

    baseline_pred = np.full_like(y_test, float(y_train.mean()))
    results["baseline_mean"] = {"test": metrics(y_test, baseline_pred)}

    out = {
        "n_train": int(len(train)),
        "n_val": int(len(val)),
        "n_test": int(len(test)),
        "feature_groups": results,
    }
    with open("realdatamagnitude_head_results.json", "w",
              encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)
    print("Wrote realdatamagnitude_head_results.json", flush=True)


if __name__ == "__main__":
    main()
