"""Fair same-split evaluation: retrained family vs baselines on the
matched-pair validation split used during P3 training.

All three dataset classes share the same matched-pair sample construction and
the same 80/10/10 permutation, so ``split="val"`` gives the same sample set
for V3 (graph-ctx), STID/STIDGraph (graph), and TrafficCausal baselines.
"""
import gc
import json
import os
import sys

import numpy as np
import torch
import torch.nn as nn
from scipy.stats import wilcoxon

BASE = os.environ.get("PAPERS_BASE", os.path.dirname(os.path.abspath(__file__)))
os.chdir(BASE)
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")
SPLIT = os.environ.get("EVAL_SPLIT", "val")

from dataset import TrafficCausalDataset
from graph_dataset import GraphTrafficDataset
from graphctx_dataset import GraphCtxCausalDataset
from stid_causal import STIDCausal
from stwave_causal_v3 import STWaveCausalV3
from stwave import STWave, STWaveBlock
from crossgnn import CrossGNN
from stid_graph import STIDGraph

device = "cuda" if torch.cuda.is_available() else "cpu"


def collate_ctx(batch):
    factual, _, _, _, _ = zip(*batch)
    return {k: torch.stack([x[k] for x in factual]) for k in factual[0].keys()}


def collate_graph(batch):
    return {
        "zone_ids": torch.stack([b["zone_ids"] for b in batch]),
        "features": torch.stack([b["features"] for b in batch]),
        "targets": torch.stack([b["targets"] for b in batch]),
        "adj": batch[0]["adj"],
    }


def collate_pred(batch):
    factual, _, _, _, _ = zip(*batch)
    return {k: torch.stack([x[k] for x in factual]) for k in factual[0].keys()}


def loader_for(ds, collate_fn, batch=64):
    return torch.utils.data.DataLoader(ds, batch_size=batch, shuffle=False,
                                       collate_fn=collate_fn, num_workers=0)


class SWPred(nn.Module):
    def __init__(self, nz, nd, h=64, b=2):
        super().__init__()
        self.zone_embed = nn.Embedding(nz, h)
        self.input_proj = nn.Linear(nd, h)
        self.pos_embed = nn.Embedding(48, h)
        self.blocks = nn.ModuleList([STWaveBlock(nz, h) for _ in range(b)])
        self.pred_head = nn.Sequential(nn.Linear(h, h), nn.ReLU(),
                                       nn.Linear(h, nd))

    def forward(self, zid, feats):
        B, S, D = feats.shape
        x = self.input_proj(feats)
        pos = torch.arange(S, device=feats.device).unsqueeze(0).expand(B, -1)
        x = (self.zone_embed(zid) + x + self.pos_embed(pos)).unsqueeze(1)
        for blk in self.blocks:
            x = blk(x)
        return self.pred_head(x[:, 0, -1, :])


def preds_v3(nz, ind, outd, ctxc, ckpt, loader):
    model = STWaveCausalV3(n_zones=nz, input_dim=ind, output_dim=outd,
                           ctx_channels=ctxc).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    ps = []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) for k, v in batch.items()}
            _, pred = model(f["zone_ids"], f["features"])
            ps.append(pred.cpu().numpy())
    return np.concatenate(ps)


def preds_stid(nz, nd, ckpt, loader):
    model = STIDCausal(n_zones=nz, input_dim=nd, output_dim=nd).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    ps = []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) if isinstance(v, torch.Tensor) else v
                 for k, v in batch.items()}
            _, pred = model(f["features"], f["zone_ids"], f["adj"])
            ps.append(pred.cpu().numpy())
    return np.concatenate(ps)


def preds_stidgraph(nz, nd, ckpt, loader):
    model = STIDGraph(n_zones=nz, input_dim=nd, hidden_dim=64, seq_len=48,
                      n_layers=2, n_days=7).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    ps = []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) if isinstance(v, torch.Tensor) else v
                 for k, v in batch.items()}
            pred = model(f["features"], f["zone_ids"], f["adj"])
            ps.append(pred.cpu().numpy())
    return np.concatenate(ps)


def preds_predonly(nz, nd, ckpt, loader):
    model = SWPred(nz, nd).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    ps = []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) for k, v in batch.items()}
            ps.append(model(f["zone_ids"], f["features"]).cpu().numpy())
    return np.concatenate(ps)


def preds_features(ModelClass, nz, nd, ckpt, loader, **kw):
    model = ModelClass(n_zones=nz, input_dim=nd, **kw).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    ps = []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) for k, v in batch.items()}
            ps.append(model(f["features"]).cpu().numpy())
    return np.concatenate(ps)


def arr(pred, t):
    return np.abs(pred - t).mean(axis=-1)


CFGS = [
    ("nyc_taxi", "NYC Taxi", 265, 6, "mean", dict(ind=12, outd=6, ctxc=6),
     {"PredOnly": ["stwave_predonly_50ep_seed1.pt", "stwave_predonly_50ep_seed2.pt",
                   "stwave_predonly_50ep_seed3.pt"],
      "STWave": ["stwave_seed1_best.pt", "stwave_seed2_best.pt",
                 "stwave_seed3_best.pt"],
      "CrossGNN": ["crossgnn_seed1_best.pt", "crossgnn_seed2_best.pt",
                   "crossgnn_seed3_best.pt"],
      "STIDGraph": ["stidgraph-nyc_seed1_best.pt", "stidgraph-nyc_seed2_best.pt",
                    "stidgraph-nyc_seed3_best.pt"]}),
    ("pems_bay", "PEMS-BAY", 325, 8, "gradient", dict(ind=16, outd=8, ctxc=8),
     {"PredOnly": ["stwave_predonly_50ep_seed1.pt", "stwave_predonly_50ep_seed2.pt",
                   "stwave_predonly_50ep_seed3.pt"],
      "STWave": ["stwave_seed1_best.pt", "stwave_seed2_best.pt",
                 "stwave_seed3_best.pt"],
      "CrossGNN": ["crossgnn_seed1_best.pt", "crossgnn_seed2_best.pt",
                   "crossgnn_seed3_best.pt"],
      "STIDGraph": ["stidgraph-pems_bay_seed1_best.pt",
                    "stidgraph-pems_bay_seed2_best.pt",
                    "stidgraph-pems_bay_seed3_best.pt"]}),
    ("pems08", "PEMS08", 170, 1, "mean", dict(ind=4, outd=1, ctxc=1),
     {"PredOnly": ["stwave_predonly_50ep.pt"],
      "STWave": ["stwave_best.pt"],
      "CrossGNN": ["crossgnn_best.pt"],
      "STIDGraph": ["stidgraph-pems08_seed1_best.pt",
                    "stidgraph-pems08_seed2_best.pt",
                    "stidgraph-pems08_seed3_best.pt",
                    "stidgraph-pems08_seed4_best.pt"]}),
    ("pems04", "PEMS04", 307, 1, "mean", dict(ind=4, outd=1, ctxc=1),
     {"PredOnly": ["stwave_predonly_50ep.pt"],
      "STWave": ["stwave_best.pt"],
      "CrossGNN": ["crossgnn_best.pt"],
      "STIDGraph": ["stidgraph-pems04_seed1_best.pt",
                    "stidgraph-pems04_seed2_best.pt",
                    "stidgraph-pems04_seed3_best.pt",
                    "stidgraph-pems04_seed4_best.pt"]}),
]

FAMILY_SEEDS = ["42", "1", "2"]


def main():
    print("Device:", device, flush=True)
    meta08 = np.load("data/datasets/pems08_staeformer/data.npz")["data"][..., 1:3][:, 0]
    meta04 = np.load("data/datasets/pems04_staeformer/data.npz")["data"][..., 1:3][:, 0]
    out = {}
    for data_name, disp, nz, nd, ctx_mode, cfg, baselines in CFGS:
        data_dir = "data/%s/processed" % data_name
        print("==", disp, flush=True)
        meta = None
        if data_name == "pems08":
            meta = meta08
        elif data_name == "pems04":
            meta = meta04
        ctx_ds = GraphCtxCausalDataset(data_dir, SPLIT, 48,
                                       ctx_mode=ctx_mode, meta=meta)
        graph_ds = GraphTrafficDataset(data_dir, SPLIT, 48)
        traffic_ds = TrafficCausalDataset(data_dir, SPLIT, 48)
        ctx_l = loader_for(ctx_ds, collate_ctx)
        graph_l = loader_for(graph_ds, collate_graph)
        traffic_l = loader_for(traffic_ds, collate_pred)

        t = []
        with torch.no_grad():
            for batch in ctx_l:
                t.append(batch["targets"].numpy())
        t = np.concatenate(t)

        maes = {"V3": [], "STID": [], "Ens": []}
        for s in FAMILY_SEEDS:
            p_v3 = preds_v3(nz, cfg["ind"], cfg["outd"], cfg["ctxc"],
                            data_dir + "/rerun_v3_seed%s.pt" % s, ctx_l)
            p_st = preds_stid(nz, nd, data_dir + "/rerun_stid_seed%s.pt" % s,
                              graph_l)
            maes["V3"].append(float(arr(p_v3, t).mean()))
            maes["STID"].append(float(arr(p_st, t).mean()))
            maes["Ens"].append(float(arr(0.5 * (p_v3 + p_st), t).mean()))

        res = {"mean_mae": {}, "mae_by_seed": maes,
               "wilcoxon": {}, "seeds": FAMILY_SEEDS}
        for bname, files in baselines.items():
            res["mae_by_seed"][bname] = []
            for f in files:
                ckpt = data_dir + "/" + f
                if not os.path.exists(ckpt):
                    print("missing checkpoint:", ckpt, flush=True)
                    continue
                if bname == "PredOnly":
                    p = preds_predonly(nz, nd, ckpt, traffic_l)
                elif bname == "STIDGraph":
                    p = preds_stidgraph(nz, nd, ckpt, graph_l)
                elif bname == "STWave":
                    p = preds_features(STWave, nz, nd, ckpt, traffic_l,
                                       hidden_dim=64, n_blocks=2, seq_len=48)
                else:
                    p = preds_features(CrossGNN, nz, nd, ckpt, traffic_l,
                                       hidden_dim=64, n_blocks=2, n_heads=4,
                                       seq_len=48)
                res["mae_by_seed"][bname].append(float(arr(p, t).mean()))
                del p
            if res["mae_by_seed"][bname]:
                res["mean_mae"][bname] = float(
                    np.mean(res["mae_by_seed"][bname]))

        res["mean_mae"]["V3"] = float(np.mean(maes["V3"]))
        res["mean_mae"]["STID"] = float(np.mean(maes["STID"]))
        res["mean_mae"]["Ens"] = float(np.mean(maes["Ens"]))

        # Paired Wilcoxon across seeds (family vs baseline).
        fam_err = {"V3": [], "STID": [], "Ens": []}
        for s in FAMILY_SEEDS:
            pv = preds_v3(nz, cfg["ind"], cfg["outd"], cfg["ctxc"],
                          data_dir + "/rerun_v3_seed%s.pt" % s, ctx_l)
            ps = preds_stid(nz, nd, data_dir + "/rerun_stid_seed%s.pt" % s,
                            graph_l)
            fam_err["V3"].append(arr(pv, t))
            fam_err["STID"].append(arr(ps, t))
            fam_err["Ens"].append(arr(0.5 * (pv + ps), t))
            del pv, ps
        for bname in ["PredOnly", "STWave", "CrossGNN", "STIDGraph"]:
            files = baselines.get(bname, [])
            if not files:
                continue
            bs = []
            for fb in files:
                ckpt = data_dir + "/" + fb
                if not os.path.exists(ckpt):
                    continue
                if bname == "PredOnly":
                    p = preds_predonly(nz, nd, ckpt, traffic_l)
                elif bname == "STIDGraph":
                    p = preds_stidgraph(nz, nd, ckpt, graph_l)
                elif bname == "STWave":
                    p = preds_features(STWave, nz, nd, ckpt, traffic_l,
                                       hidden_dim=64, n_blocks=2,
                                       seq_len=48)
                else:
                    p = preds_features(CrossGNN, nz, nd, ckpt, traffic_l,
                                       hidden_dim=64, n_blocks=2,
                                       n_heads=4, seq_len=48)
                bs.append(arr(p, t))
                del p
            for fam in ["V3", "STID", "Ens"]:
                if len(bs) == len(fam_err[fam]):
                    xs = np.concatenate(fam_err[fam])
                    ys = np.concatenate(bs)
                elif len(bs) == 1:
                    xs = fam_err[fam][0]
                    ys = bs[0]
                else:
                    continue
                try:
                    res["wilcoxon"]["%s_vs_%s" % (fam, bname)] = float(
                        wilcoxon(xs, ys).pvalue)
                except Exception as e:
                    res["wilcoxon"]["%s_vs_%s" % (fam, bname)] = str(e)
        out[disp] = res
        print(json.dumps(res, indent=2), flush=True)
        del ctx_ds, graph_ds, traffic_ds, ctx_l, graph_l, traffic_l
        gc.collect()
        torch.cuda.empty_cache()

    with open("eval_same_split_%s_results.json" % SPLIT, "w",
              encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
