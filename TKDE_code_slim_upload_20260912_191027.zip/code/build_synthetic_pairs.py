﻿import sys, os, numpy as np
os.chdir('F:/xuexi/codex/papers')
sys.path.insert(0, 'src/model')
from pathlib import Path
import torch, torch.nn as nn, torch.nn.functional as F

# ============================================================
# Build synthetic counterfactual pairs with known ICE ground truth
# ============================================================
device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('Device:', device)

data_dir = 'data/nyc_taxi/processed'
n_zones = 265
feats = np.load(str(Path(data_dir) / 'node_features.npy'), mmap_mode='r').astype(np.float32)
labels = np.load(str(Path(data_dir) / 'labels.npy'), mmap_mode='r')
matches = np.load(str(Path(data_dir) / 'matched_pairs.npy'), allow_pickle=True)

seq_len = 48
feature_dim = 6
eff_a = 0.7  # -30% for event A
eff_b = 0.8  # -20% for event B

# Find active (non-sparse) zones
active = [z for z in range(n_zones) if feats[:, z, 0].mean() > 50 and (feats[:, z, 0] == 0).mean() < 0.3]
print(f'Active zones: {len(active)}')

# Build synthetic dataset: for each match, produce (factual, cf_single, ice_true, combo)
samples = []
max_events = 5

for m in matches:
    z = int(m['zone'])
    t = int(m['t'])
    t_star = int(m['t_star'])
    
    if t_star < seq_len + 2:
        continue
    if z not in active:
        continue
    
    # Factual: normal sequence ending at t (predict t)
    f_start = max(0, t - seq_len)
    factual = feats[f_start:t, z].copy()
    if len(factual) < seq_len:
        factual = np.concatenate([np.zeros((seq_len - len(factual), feature_dim)), factual])
    
    # Counterfactual (single): normal sequence ending at t_star
    cf_start = max(0, t_star - seq_len)
    cf = feats[cf_start:t_star, z].copy()
    if len(cf) < seq_len:
        cf = np.concatenate([np.zeros((seq_len - len(cf), feature_dim)), cf])
    
    # Ground truth ICE: difference between factual next-step and counterfactual next-step
    y_f = feats[t, z] if t < feats.shape[0] else factual[-1]
    y_cf = feats[t_star, z] if t_star < feats.shape[0] else cf[-1]
    
    ice_true = np.abs(y_f - y_cf).astype(np.float32)
    
    # Also inject synthetic effect to ensure ICE is non-trivial and known
    eff_factor = 0.7 if np.random.rand() > 0.5 else 0.8
    cf_injected = cf * eff_factor
    ice_true_inj = np.abs(y_f - feats[t_star, z] * eff_factor).astype(np.float32)
    
    # Choose: use either matched-pair ICE or injected ICE (mix for robustness)
    if np.random.rand() > 0.5:
        ice_target = ice_true
        cf_use = cf
    else:
        ice_target = ice_true_inj
        cf_use = cf_injected
    
    # Combo data
    combo = {
        'event_types': torch.full((max_events,), -1, dtype=torch.long),
        'event_locs': torch.zeros(max_events, 2),
        'event_times': torch.zeros(max_events),
        'zone_states': torch.zeros(max_events, feature_dim),
    }
    combo['event_types'][0] = 1
    combo['event_times'][0] = float(t)
    combo['zone_states'][0] = torch.FloatTensor(feats[t, z])
    
    samples.append({
        'zone': z,
        'factual': torch.FloatTensor(factual),
        'cf': torch.FloatTensor(cf_use),
        'ice_true': torch.FloatTensor(ice_target),
        'combo': combo,
    })

print(f'Total synthetic pairs: {len(samples)}')

# Shuffle
rng = np.random.RandomState(42)
rng.shuffle(samples)
n = len(samples)
n_train = int(n * 0.8)
n_val = int(n * 0.1)
train = samples[:n_train]
val = samples[n_train:n_train+n_val]
test = samples[n_train+n_val:]
print(f'Train: {len(train)}, Val: {len(val)}, Test: {len(test)}')

# Save to disk
out = {}
for split, data in [('train', train), ('val', val), ('test', test)]:
    arr = []
    for d in data:
        arr.append((d['zone'], d['factual'], d['cf'], d['ice_true']))
    out[split] = arr

np.save(str(Path(data_dir) / 'synthetic_pairs_v3.npy'), out, allow_pickle=True)
print('Saved synthetic_pairs_v3.npy')
print('ALL DONE')
