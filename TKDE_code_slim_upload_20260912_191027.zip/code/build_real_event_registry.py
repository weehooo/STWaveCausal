"""Build an auditable real-event registry from NOAA Storm Events and TLC zones."""
import argparse
import csv
import subprocess
import gzip
import json
import os
import re
import shutil
import urllib.request
import zipfile
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
import shapefile
from pyproj import Transformer

BASE = os.environ.get("PAPERS_BASE", os.path.dirname(os.path.abspath(__file__)))
os.chdir(BASE)

LIST_URL = "https://www.ncei.noaa.gov/pub/data/swdi/stormevents/csvfiles/"
DETAIL_RE = re.compile(
    r"(StormEvents_details-ftp_v1\.0_d(?:2011|2012|2013)_c\d+\.csv\.gz)")
ZONE_URL = "https://d37ci6vzurychx.cloudfront.net/misc/taxi_zones.zip"

COUNTY_TO_BOROUGH = {
    "bronx": "Bronx",
    "kings": "Brooklyn",
    "brooklyn": "Brooklyn",
    "new york": "Manhattan",
    "manhattan": "Manhattan",
    "queens": "Queens",
    "richmond": "Staten Island",
    "staten island": "Staten Island",
}

SEVERE_TYPES = {
    "coastal flood", "flash flood", "flood", "heavy rain", "heavy snow",
    "high wind", "ice storm", "sleet", "strong wind", "tornado",
    "thunderstorm wind", "winter storm", "winter weather", "blizzard",
}


def norm_text(value):
    return re.sub(r"\s+", " ", str(value)).strip()


def norm_key(value):
    return norm_text(value).lower()


def ensure_zones():
    raw_dir = Path("data/events/raw")
    final_dir = raw_dir / "taxi_zones"
    if (final_dir / "taxi_zones.shp").is_file():
        return final_dir
    raw_dir.mkdir(parents=True, exist_ok=True)
    zpath = raw_dir / "taxi_zones.zip"
    if not zpath.is_file():
        print("downloading TLC taxi zones", flush=True)
        urllib.request.urlretrieve(ZONE_URL, zpath)
    extract = raw_dir / "taxi_zones_extract"
    if extract.is_dir():
        shutil.rmtree(extract)
    with zipfile.ZipFile(zpath) as zf:
        zf.extractall(extract)
    shp_files = list(extract.rglob("taxi_zones.shp"))
    if not shp_files:
        raise FileNotFoundError("taxi_zones.shp not found")
    src = shp_files[0].parent
    final_dir.mkdir(parents=True, exist_ok=True)
    for item in src.iterdir():
        shutil.copy2(item, final_dir / item.name)
    shutil.rmtree(extract)
    return final_dir


def load_zone_mapping(zone_dir):
    reader = shapefile.Reader(str(zone_dir / "taxi_zones.dbf"))
    fields = [f[0] for f in reader.fields[1:]]
    transformer = Transformer.from_crs("EPSG:2263", "EPSG:4326",
                                       always_xy=True)
    zones = {}
    for idx in range(len(reader)):
        rec = dict(zip(fields, reader.record(idx)))
        keys = {k.lower(): k for k in rec}
        location_field = keys.get("locationid")
        borough_field = keys.get("borough")
        zone_field = keys.get("zone")
        if location_field is None or borough_field is None:
            continue
        zone_id = int(rec[location_field])
        borough = norm_text(rec[borough_field])
        shape = reader.shape(idx)
        xmin, ymin, xmax, ymax = shape.bbox
        lon, lat = transformer.transform((xmin + xmax) / 2,
                                         (ymin + ymax) / 2)
        zones[zone_id] = {
            "zone_id": zone_id,
            "borough": borough,
            "zone_name": norm_text(rec.get(zone_field, "")),
            "centroid_lat": float(lat),
            "centroid_lon": float(lon),
        }
    if not zones:
        raise RuntimeError("no TLC zones parsed")
    return zones


def storm_detail_urls(years):
    result = subprocess.run(
        ["curl", "-L", "--fail", "--max-time", "120", "-s",
         "-A", "Mozilla/5.0 (research workflow)", LIST_URL],
        check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    text = result.stdout.decode("utf-8", "replace")
    urls = []
    for match in sorted(set(DETAIL_RE.findall(text))):
        year = int(re.search(r"_d(\d{4})_", match).group(1))
        if year in years:
            urls.append(LIST_URL + match)
    return urls


def damage_to_usd(value):
    value = str(value or "").strip().upper()
    if not value or value in {"0", "0.00"}:
        return 0.0
    match = re.fullmatch(r"([0-9.]+)\s*([KMB])?", value)
    if not match:
        return 0.0
    factor = {"K": 1e3, "M": 1e6, "B": 1e9}.get(match.group(2), 1.0)
    try:
        return float(match.group(1)) * factor
    except ValueError:
        return 0.0


def load_noaa_events(years):
    frames = []
    raw_dir = Path("data/events/raw")
    raw_dir.mkdir(parents=True, exist_ok=True)
    for url in storm_detail_urls(years):
        name = url.rsplit("/", 1)[-1]
        path = raw_dir / name
        if not path.is_file() or path.stat().st_size == 0:
            print("download", name, flush=True)
            part = path.with_suffix(path.suffix + ".part")
            subprocess.run(
                ["curl", "-L", "--fail", "--max-time", "1800", "-s",
                 "-A", "Mozilla/5.0 (research workflow)", "-o", str(part),
                 url],
                check=True)
            part.replace(path)
        print("parse", name, flush=True)
        with gzip.open(path, "rt", encoding="utf-8", errors="replace") as f:
            frame = pd.read_csv(f, low_memory=False)
        frames.append(frame)
    frame = pd.concat(frames, ignore_index=True)
    frame = frame[frame["STATE"].astype(str).str.upper() == "NEW YORK"].copy()
    out = []
    for _, row in frame.iterrows():
        county = norm_key(row.get("CZ_NAME", ""))
        borough = COUNTY_TO_BOROUGH.get(county)
        if borough is None:
            continue
        try:
            start = pd.to_datetime(row["BEGIN_DATE_TIME"],
                                   format="%d-%b-%y %H:%M:%S")
            end = pd.to_datetime(row["END_DATE_TIME"],
                                 format="%d-%b-%y %H:%M:%S")
        except Exception:
            continue
        if pd.isna(start) or pd.isna(end):
            continue
        if end < start:
            start, end = end, start
        event_type = norm_text(row.get("EVENT_TYPE", ""))
        injuries = float(row.get("INJURIES_DIRECT", 0) or 0) + \
            float(row.get("INJURIES_INDIRECT", 0) or 0)
        deaths = float(row.get("DEATHS_DIRECT", 0) or 0) + \
            float(row.get("DEATHS_INDIRECT", 0) or 0)
        damage = damage_to_usd(row.get("DAMAGE_PROPERTY")) + \
            damage_to_usd(row.get("DAMAGE_CROPS"))
        magnitude = float(row.get("MAGNITUDE") or 0)
        severity = np.log1p(damage) + deaths * 12 + injuries * 6 + \
            min(abs(magnitude), 150) * 0.5 + \
            (3 if norm_key(event_type) in SEVERE_TYPES else 0)
        out.append({
            "event_id": "NOAA-" + str(int(row.get("EVENT_ID", len(out)))),
            "episode_id": str(row.get("EPISODE_ID", "")),
            "source": "NOAA/NCEI StormEvents",
            "source_url": LIST_URL,
            "category": norm_key(event_type),
            "start_time": start.isoformat(),
            "end_time": end.isoformat(),
            "borough": borough,
            "county": norm_text(row.get("CZ_NAME", "")),
            "narrative": norm_text(row.get("EVENT_NARRATIVE", "")),
            "injuries": injuries,
            "deaths": deaths,
            "damage_usd": damage,
            "magnitude": magnitude,
            "severity": float(severity),
            "confidence": "medium" if damage or injuries or deaths else "low",
        })
    return out


def haversine_km(a, b):
    lat1, lon1, lat2, lon2 = map(np.radians, [a[0], a[1], b[0], b[1]])
    dlat, dlon = lat2 - lat1, lon2 - lon1
    h = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * \
        np.sin(dlon / 2) ** 2
    return 2 * 6371.0 * np.arcsin(np.sqrt(h))


def select_pairs(events, zones, max_pairs=10):
    events = sorted(events, key=lambda x: x["start_time"])
    candidates = []
    for i, a in enumerate(events):
        za = [z for z in zones.values() if z["borough"] == a["borough"]]
        ca = np.mean([[z["centroid_lat"], z["centroid_lon"]]
                      for z in za], axis=0).tolist()
        for b in events[i + 1:]:
            if b["borough"] == a["borough"]:
                continue
            zb = [z for z in zones.values() if z["borough"] == b["borough"]]
            cb = np.mean([[z["centroid_lat"], z["centroid_lon"]]
                          for z in zb], axis=0).tolist()
            start = max(pd.Timestamp(a["start_time"]),
                        pd.Timestamp(b["start_time"]))
            end = min(pd.Timestamp(a["end_time"]),
                      pd.Timestamp(b["end_time"]))
            overlap_minutes = (end - start).total_seconds() / 60
            if overlap_minutes < 30:
                continue
            if norm_key(a["category"]) not in SEVERE_TYPES or \
                    norm_key(b["category"]) not in SEVERE_TYPES:
                continue
            distance = haversine_km(ca, cb)
            severity = a["severity"] + b["severity"]
            candidates.append({
                "pair_id": f"{a['event_id']}__{b['event_id']}",
                "events": [a, b],
                "overlap_minutes": overlap_minutes,
                "distance_km": round(distance, 2),
                "spatial_relation": "adjacent" if distance <= 15 else "disjoint",
                "severity_score": round(severity, 3),
            })
    candidates.sort(key=lambda x: (-x["severity_score"], -x["overlap_minutes"]))
    chosen = []
    seen_dates = set()
    seen_borough_pairs = set()
    for pair in candidates:
        date_key = pair["events"][0]["start_time"][:10]
        borough_pair = tuple(sorted(e["borough"] for e in pair["events"]))
        if date_key in seen_dates or borough_pair in seen_borough_pairs:
            continue
        chosen.append(pair)
        seen_dates.add(date_key)
        seen_borough_pairs.add(borough_pair)
        if len(chosen) >= max_pairs:
            break
    for rank, pair in enumerate(chosen, 1):
        pair["role"] = "primary" if rank <= 2 else "sensitivity"
        pair["selection_rank"] = rank
    return chosen


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--years", nargs="+", default=[2011, 2012, 2013], type=int)
    ap.add_argument("--max-pairs", type=int, default=10)
    args = ap.parse_args()

    zone_dir = ensure_zones()
    zones = load_zone_mapping(zone_dir)
    events = load_noaa_events(set(args.years))
    pairs = select_pairs(events, zones, args.max_pairs)
    os.makedirs("data/events", exist_ok=True)
    with open("real_event_registry.json", "w", encoding="utf-8") as f:
        json.dump({"zones": zones, "events": events}, f, indent=2)
    with open("real_event_pairs_selected.json", "w", encoding="utf-8") as f:
        json.dump({"selection_criteria": {
            "min_overlap_minutes": 30,
            "different_boroughs": True,
            "severe_types_only": True,
            "ordering": "severity then overlap",
        }, "pairs": pairs}, f, indent=2)
    print("registry events:", len(events))
    print("selected pairs:", len(pairs))
    for pair in pairs:
        print(pair["selection_rank"], pair["pair_id"], pair["role"],
              pair["overlap_minutes"], pair["distance_km"])


if __name__ == "__main__":
    main()
