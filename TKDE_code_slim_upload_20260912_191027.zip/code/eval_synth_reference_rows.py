"""Regenerate archived PredOnly/V2 rows on the raw synthetic benchmark."""
import argparse
import json
import os
import sys

import numpy as np
import torch

BASE = os.environ.get("PAPERS_BASE", os.path.dirname(os.path.abspath(__file__)))
os.chdir(BASE)
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from stwave_causal import STWaveCausal
from eval_same_split import SWPred

device = "cuda" if torch.cuda.is_available() else "cpu"


def batch(samples, start, stop):
    chunk = samples[start:stop]
    zones = torch.tensor([x["zone"] for x in chunk], dtype=torch.long)
    factual = torch.stack([x["factual"][..., :6] for x in chunk]).float()
    cf = torch.stack([x["cf"][..., :6] for x in chunk]).float()
    truth = torch.stack([x["ice_true"] for x in chunk]).float()
    return zones.to(device), factual.to(device), cf.to(device), truth.to(device)


@torch.no_grad()
def predict_difference(model, causal, samples, batch_size=64):
    estimates, truths = [], []
    for start in range(0, len(samples), batch_size):
        zid, ff, cf, true = batch(samples, start, min(len(samples),
                                                       start + batch_size))
        if not causal:
            zid = zid.unsqueeze(1).expand(-1, ff.shape[1])
        else:
            zid = zid.unsqueeze(1).expand(-1, ff.shape[1])
        if causal:
            _, pf = model(zid, ff)
            _, pcf = model(zid, cf)
        else:
            pf = model(zid, ff)
            pcf = model(zid, cf)
        estimates.append(torch.mean(torch.abs(pf - pcf),
                                    dim=1).cpu().numpy())
        truths.append(true[:, 0].cpu().numpy())
    return np.concatenate(estimates), np.concatenate(truths)


def metrics(estimates, truths):
    corr = float(np.corrcoef(estimates, truths)[0, 1])
    ratio = float(np.median(estimates / (truths + 1e-6)))
    mae = float(np.mean(np.abs(estimates - truths)))
    return {"corr": corr, "median_ratio": ratio, "mae": mae}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predonly", default="data/nyc_taxi/processed/"
                                           "stwave_predonly_50ep_seed1.pt")
    ap.add_argument("--v2", default="data/nyc_taxi/processed/"
                                     "stwave_causal_best_v2.pt")
    ap.add_argument("--synthetic", default="data/nyc_taxi/processed/"
                                            "synthetic_pairs_v3_graphctx.npy")
    args = ap.parse_args()
    data = np.load(args.synthetic, allow_pickle=True).item()["test"]
    out = {}

    predonly = SWPred(265, 6).to(device)
    predonly.load_state_dict(torch.load(args.predonly, map_location=device))
    predonly.eval()
    e, t = predict_difference(predonly, False, data)
    out["PredOnly"] = metrics(e, t)

    v2 = STWaveCausal(n_zones=265, input_dim=6, hidden_dim=64, n_blocks=2,
                      seq_len=48).to(device)
    v2.load_state_dict(torch.load(args.v2, map_location=device))
    v2.eval()
    e, t = predict_difference(v2, True, data)
    out["STWaveCausal_V2"] = metrics(e, t)

    with open("synthetic_reference_rows.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
