"""Incident-type stratified PEMS-BAY event-study summary."""
import json
from collections import defaultdict

import numpy as np
from scipy import stats


def main():
    study = json.load(open("pemsbay_eventsudy_results.json", encoding="utf-8"))
    groups = defaultdict(list)
    for row in study["per_event"]:
        post = float(np.mean(row["curve"][6:]))
        groups[row["type"]].append(post)

    rows = []
    for typ, values in groups.items():
        values = np.array(values)
        if len(values) < 10:
            continue
        ci = stats.t.interval(0.95, len(values) - 1,
                              loc=values.mean(),
                              scale=values.std(ddof=1) / np.sqrt(len(values))
                              if values.std(ddof=1) > 0 else 0.0)
        rows.append({
            "type": typ,
            "n": int(len(values)),
            "mean_post_effect": float(values.mean()),
            "ci_low": float(ci[0]),
            "ci_high": float(ci[1]),
        })
    rows.sort(key=lambda r: r["mean_post_effect"], reverse=True)
    out = {"types": rows}
    with open("pemsbay_type_stratified.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)


if __name__ == "__main__":
    main()
