"""Controlled local-perturbation sensitivity of the two-stage annotation."""
import json
import os
from pathlib import Path

import numpy as np

BASE = Path(r"F:\xuexi\codex\papers")
os.chdir(BASE)

FEAT = np.load("data/nyc_taxi/processed/node_features.npy").astype(np.float32)
LABELS = np.load("data/nyc_taxi/processed/labels.npy")
T, N, D = FEAT.shape
W = 48


def compute_baseline_stats(features):
    total_flow = features[:, :, 0] + features[:, :, 1]
    seg_idx = np.arange(T) % W
    mean_profile = np.zeros((W, N), dtype=np.float32)
    std_profile = np.zeros((W, N), dtype=np.float32)
    for w in range(W):
        mask = seg_idx == w
        vals = total_flow[mask]
        mean_profile[w] = np.mean(vals, axis=0)
        std_profile[w] = np.std(vals, axis=0) + 1e-8
    return mean_profile, std_profile


def rule_z(flow, z, t, mean_p, std_p):
    return (flow[z] - mean_p[t % W, z]) / std_p[t % W, z]


def hawkes_z(flow, z, t0, decay_hours=4.0, alpha=0.3, mu=0.1):
    beta = 1.0 / (decay_hours * 2)
    start = max(0, t0 - 12)
    f = flow[start:t0 + 1]
    intensity = np.zeros(len(f))
    intensity[0] = mu
    for i in range(1, len(f)):
        intensity[i] = intensity[i - 1] * np.exp(-beta)
        if i > 1:
            residual = abs(f[i - 1] - f[i - 2])
            if residual > 0.15 * (f[i - 2] + 1):
                intensity[i] += alpha * np.exp(-beta)
        intensity[i] += mu * (1 - np.exp(-beta))
    baseline = float(flow.mean())
    expected = intensity * baseline
    zval = np.abs(f - expected) / (expected + 1)
    return zval


def main():
    mean_p, std_p = compute_baseline_stats(FEAT)
    base_flow = FEAT[:, :, 0] + FEAT[:, :, 1]
    zone_mean = base_flow.mean(axis=0)
    active = np.where(zone_mean > 15)[0]
    rng = np.random.RandomState(42)
    active = rng.choice(active, size=min(40, len(active)), replace=False)
    t0s = list(range(600, T - 200, 137))
    candidates = []
    for z in active:
        base_z = base_flow[:, z]
        chosen = 0
        for t0 in t0s:
            if LABELS[t0, z] != 0:
                continue
            zr = rule_z(base_z, z, t0, mean_p, std_p)
            if abs(zr) > 1.5:
                continue
            if abs(base_z[t0] - base_z[max(0, t0 - 1)]) > 0.05 * (base_z[t0] + 1):
                continue
            candidates.append((z, t0))
            chosen += 1
            if chosen >= 4:
                break
    print("candidates:", len(candidates), flush=True)

    factors = [0.1, 0.3, 0.5, 0.7, 0.8]
    durations = [1, 2, 3]
    rng.shuffle(candidates)
    cand = candidates[:800]
    results = {"sensitivity": {}, "control_false_alarm": 0.0,
               "n_cand": len(cand)}
    tp_all = 0
    fp_control = 0
    for z, t0 in cand:
        base_z = base_flow[:, z].copy()
        # control false-alarm from the unperturbed window
        zr = rule_z(base_z, z, t0, mean_p, std_p)
        hz = hawkes_z(base_z, z, t0)
        if (abs(zr) > 2.0) and (hz[-1] > 2.0):
            fp_control += 1
        for f in factors:
            for d in durations:
                pert = base_z.copy()
                s = max(0, t0 - d + 1)
                e = t0 + 1
                pert[s:e] = f * pert[s:e]
                zr = rule_z(pert, z, t0, mean_p, std_p)
                hz = hawkes_z(pert, z, t0)
                flag = (abs(zr) > 2.0) and (hz[-1] > 2.0)
                key = "f%.2f_d%d" % (f, d)
                results["sensitivity"].setdefault(key, [0, 0])
                results["sensitivity"][key][1] += 1
                if flag:
                    results["sensitivity"][key][0] += 1
                    tp_all += 1
    results["control_false_alarm"] = fp_control / max(1, len(cand)) * 100
    print("control false-alarm %%: %.2f" % results["control_false_alarm"],
          flush=True)
    for key in sorted(results["sensitivity"]):
        hits, n = results["sensitivity"][key]
        print("%s -> sensitivity %.1f%% (%d/%d)" %
              (key, hits / max(1, n) * 100, hits, n), flush=True)
        results["sensitivity"][key] = round(hits / max(1, n) * 100, 2)
    with open("eval_annotation_local_results.json", "w",
              encoding="utf-8") as fout:
        json.dump(results, fout, indent=2)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
