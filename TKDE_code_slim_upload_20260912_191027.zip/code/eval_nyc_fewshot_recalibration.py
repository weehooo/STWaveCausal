"""Few-shot donor-free recalibration from PEMS-BAY to NYC.

The source magnitude head is trained on PEMS-BAY same-clock clean-day post
effects. For k NYC events with donor-matched DiD labels, an affine
recalibration is fitted; the remaining NYC events are used for evaluation.
Monte Carlo repeats estimate the distribution of transfer performance.
"""
import json
import os
import sys
from datetime import datetime

import numpy as np
import torch

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

import eval_causal_estimators as ec
from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"


def ridge_fit_predict(X, y, X_test, lam=1.0):
    X = np.column_stack([np.ones(len(X)), X])
    X_test = np.column_stack([np.ones(len(X_test)), X_test])
    A = X.T @ X + lam * np.eye(X.shape[1])
    w = np.linalg.solve(A, X.T @ y)
    return X_test @ w


def metrics(y_true, y_pred):
    ss_res = float(np.sum((y_true - y_pred) ** 2))
    ss_tot = float(np.sum((y_true - y_true.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    mae = float(np.mean(np.abs(y_true - y_pred)))
    bias = float(np.mean(y_pred - y_true))
    corr = float(np.corrcoef(y_true, y_pred)[0, 1])
    return {"r2": r2, "mae": mae, "bias": bias, "corr": corr}


def affine_fit_predict(s, t, y):
    A = np.column_stack([np.ones(len(s)), s])
    w, *_ = np.linalg.lstsq(A, y, rcond=None)
    return np.column_stack([np.ones(len(t)), t]) @ w


def build_nyc_features():
    model = STWaveCausalV3(
        n_zones=265, input_dim=12, output_dim=6, ctx_channels=6,
        ctx_gate=True,
    ).to(device)
    model.load_state_dict(torch.load(
        "data/nyc_taxi/processed/rerun_v3_seed42.pt", map_location=device))
    model.eval()

    comparison = json.load(
        open("causal_estimator_comparison.json", encoding="utf-8"))
    rows = comparison["rows"]
    event_dates = {name: datetime.strptime(date, "%Y-%m-%d")
                   for date, name in ec.EVENTS}
    feats, targets, metas = [], [], []
    with torch.no_grad():
        for r in rows:
            event = r["event"]
            if event not in event_dates:
                continue
            date = event_dates[event]
            t0 = int((date - ec.start).total_seconds() / 1800)
            t_cf = t0 - ec.CF_OFFSET
            zone = int(r["zone"])
            ff = torch.FloatTensor(
                ec.window_v3(zone, t0)).unsqueeze(0).to(device)
            cf = torch.FloatTensor(
                ec.window_v3(zone, t_cf)).unsqueeze(0).to(device)
            zid = torch.full((1, ec.SEQ), zone, dtype=torch.long,
                             device=device)
            h_f, pred_f = model(zid, ff)
            h_cf, pred_cf = model(zid, cf)
            cov = np.array([
                0.0,
                0.0,
                float((t0 % 48) / 48.0),
                float(((t0 // 48) % 7) / 7.0),
            ], dtype=np.float32)
            feat = np.concatenate([
                h_f[0].cpu().numpy(),
                h_cf[0].cpu().numpy(),
                cov,
            ])
            feats.append(feat)
            targets.append(float(r["did"]))
            metas.append({"event": event, "zone": zone})
    return np.stack(feats).astype(np.float64), np.array(targets), metas


def main():
    data = np.load("pemsbay_magnitude_features.npz")
    X_src = data["X"].astype(np.float64)
    y_src = data["y"].astype(np.float64)
    src_cols = list(range(128)) + list(range(144, 148))
    X_src = X_src[:, src_cols]
    mean = X_src.mean(axis=0)
    std = X_src.std(axis=0) + 1e-8
    X_src = (X_src - mean) / std

    X_tgt, y_tgt, metas = build_nyc_features()
    X_tgt = (X_tgt - mean) / std
    source_pred_tgt = ridge_fit_predict(X_src, y_src, X_tgt, lam=1.0)

    out = {
        "n_source": int(len(X_src)),
        "n_target": int(len(y_tgt)),
        "zero_shot": metrics(y_tgt, source_pred_tgt),
        "few_shot": {},
    }
    rng = np.random.RandomState(20260908)
    for k in [5, 10, 20, 40]:
        if k >= len(y_tgt):
            continue
        values = []
        for _ in range(200):
            cal_idx = rng.choice(len(y_tgt), k, replace=False)
            test_idx = np.array([i for i in range(len(y_tgt))
                                 if i not in cal_idx])
            pred = affine_fit_predict(source_pred_tgt[cal_idx],
                                      source_pred_tgt[test_idx],
                                      y_tgt[cal_idx])
            values.append(metrics(y_tgt[test_idx], pred))
        out["few_shot"][str(k)] = {
            "mae_mean": float(np.mean([v["mae"] for v in values])),
            "mae_std": float(np.std([v["mae"] for v in values])),
            "corr_mean": float(np.mean([v["corr"] for v in values])),
            "corr_std": float(np.std([v["corr"] for v in values])),
            "r2_mean": float(np.mean([v["r2"] for v in values])),
            "r2_std": float(np.std([v["r2"] for v in values])),
        }

    with open("nyc_fewshot_recalibration.json", "w",
              encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)
    print("Wrote nyc_fewshot_recalibration.json", flush=True)


if __name__ == "__main__":
    main()
