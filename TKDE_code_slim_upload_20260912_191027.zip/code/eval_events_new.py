"""Recompute RQ3 event ACE bootstrap CIs and rank test with the retrained
NYC V3 checkpoint on the shared (new) pipeline."""
import json
import os
import sys
from datetime import datetime

import numpy as np
import torch
import torch.nn as nn
from scipy.stats import binom, wilcoxon

BASE = os.environ.get("PAPERS_BASE", os.path.dirname(os.path.abspath(__file__)))
os.chdir(BASE)
sys.path.insert(0, "src/model")

from stwave import STWaveBlock
from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48
CF_OFFSET = 7 * 7 * SEQ
start = datetime(2011, 1, 1)
feats = np.load("data/nyc_taxi/processed/node_features.npy",
                mmap_mode="r")
_adj = np.load("data/nyc_taxi/processed/adj.npy").astype(np.float32)
_adj = _adj / np.maximum(_adj.sum(axis=1, keepdims=True), 1e-6)

EVENTS = [
    ("2012-10-29", "Hurricane Sandy"),
    ("2011-12-31", "New Year's Eve"),
    ("2013-02-08", "Winter Storm Nemo"),
    ("2011-10-29", "October nor'easter"),
    ("2012-11-07", "Post-Sandy nor'easter"),
    ("2013-03-07", "March nor'easter"),
    ("2011-08-28", "Hurricane Irene"),
]


class SWPred(nn.Module):
    def __init__(self, nz, nd, h=64, b=2):
        super().__init__()
        self.zone_embed = nn.Embedding(nz, h)
        self.input_proj = nn.Linear(nd, h)
        self.pos_embed = nn.Embedding(48, h)
        self.blocks = nn.ModuleList([STWaveBlock(nz, h) for _ in range(b)])
        self.pred_head = nn.Sequential(nn.Linear(h, h), nn.ReLU(),
                                       nn.Linear(h, nd))

    def forward(self, zid, feats):
        B, S, D = feats.shape
        x = self.input_proj(feats)
        pos = torch.arange(S, device=feats.device).unsqueeze(0).expand(B, -1)
        x = (self.zone_embed(zid) + x + self.pos_embed(pos)).unsqueeze(1)
        for blk in self.blocks:
            x = blk(x)
        return self.pred_head(x[:, 0, -1, :])


def window_v3(zone, t):
    ts = max(0, t - SEQ)
    w_all = feats[ts:t]
    if len(w_all) < SEQ:
        pad = np.zeros((SEQ - len(w_all), feats.shape[1], feats.shape[2]),
                       dtype=w_all.dtype)
        w_all = np.concatenate([pad, w_all], axis=0)
    raw = w_all[:, zone]
    ctx = np.einsum("snd,n->sd", w_all, _adj[zone])
    return np.concatenate([raw, ctx], axis=-1)


def window_raw(zone, t):
    ts = max(0, t - SEQ)
    w = feats[ts:t, zone].copy()
    if len(w) < SEQ:
        w = np.concatenate([np.zeros((SEQ - len(w), 6)), w])
    return w


@torch.no_grad()
def ace(model, zone, t, t_star, causal=True):
    zid = torch.full((1, SEQ), zone, dtype=torch.long, device=device)
    if causal:
        ff = torch.FloatTensor(window_v3(zone, t)).unsqueeze(0).to(device)
        cf = torch.FloatTensor(window_v3(zone, t_star)).unsqueeze(0).to(device)
        _, pf = model(zid, ff)
        _, pcf = model(zid, cf)
    else:
        ff = torch.FloatTensor(window_raw(zone, t)).unsqueeze(0).to(device)
        cf = torch.FloatTensor(window_raw(zone, t_star)).unsqueeze(0).to(device)
        pf = model(zid, ff)
        pcf = model(zid, cf)
    return float(np.mean(np.abs(pf[0].cpu().numpy() - pcf[0].cpu().numpy())))


def bootstrap_ci(values, n_boot=5000, seed=42):
    rng = np.random.RandomState(seed)
    v = np.asarray(values, dtype=np.float64)
    means = rng.choice(v, size=(n_boot, len(v)), replace=True).mean(axis=1)
    return float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))


def main():
    v3 = STWaveCausalV3(n_zones=265, input_dim=12, output_dim=6,
                        ctx_channels=6, ctx_gate=True).to(device)
    v3.load_state_dict(torch.load(
        "data/nyc_taxi/processed/rerun_v3_seed42.pt", map_location=device))
    po = SWPred(265, 6).to(device)
    po.load_state_dict(torch.load(
        "data/nyc_taxi/processed/stwave_predonly_50ep_seed1.pt",
        map_location=device))
    v3.eval()
    po.eval()
    print("Device:", device, flush=True)

    boot = []
    rank_total_affected = 0
    rank_hits = 0
    event_with_hit = 0
    out = []
    for dstr, name in EVENTS:
        date = datetime.strptime(dstr, "%Y-%m-%d")
        t0 = int((date - start).total_seconds() / (30 * 60))
        t_star = t0 - CF_OFFSET
        if t_star - SEQ < 0 or t0 + SEQ >= feats.shape[0]:
            print("skip", name, "out of range", flush=True)
            continue
        zones = list(range(feats.shape[1]))
        baseline = np.array([feats[t_star:t_star + SEQ, z, 0].mean()
                             for z in zones])
        event_flow = np.array([feats[t0:t0 + SEQ, z, 0].mean()
                               for z in zones])
        drop = (baseline - event_flow) / np.maximum(baseline, 1e-6)
        affected = [z for z in zones if baseline[z] >= 5 and drop[z] > 0.4]
        ace_all = np.array([ace(v3, z, t0, t_star) for z in zones])
        hit = 0
        if affected:
            ace_v3 = np.array([ace(v3, z, t0, t_star) for z in affected])
            ace_po = np.array([ace(po, z, t0, t_star, causal=False)
                               for z in affected])
            lo3, hi3 = bootstrap_ci(ace_v3)
            lo0, hi0 = bootstrap_ci(ace_po)
            boot.append({"date": dstr, "event": name,
                         "n_affected": len(affected),
                         "mean_ace_v3": float(ace_v3.mean()),
                         "ci95_v3": [lo3, hi3],
                         "mean_ace_predonly": float(ace_po.mean()),
                         "ci95_predonly": [lo0, hi0]})
            top5 = int(np.ceil(len(zones) * 0.05))
            thr = np.sort(ace_all)[-top5]
            hit = int(sum(ace_v3 >= thr))
            rank_total_affected += len(affected)
            rank_hits += hit
            if hit > 0:
                event_with_hit += 1
            print("%-24s n=%3d V3=%.2f [%.2f, %.2f] PredOnly=%.2f "
                  "[%.2f, %.2f] hits=%d" %
                  (name, len(affected), ace_v3.mean(), lo3, hi3,
                   ace_po.mean(), lo0, hi0, hit), flush=True)
        else:
            print("%-24s no affected zones" % name, flush=True)
        out.append({"date": dstr, "event": name, "n_affected": len(affected),
                    "top5_hit": hit})

    zone_p = float(binom.sf(rank_hits - 1, rank_total_affected, 0.05))
    res = {
        "bootstrap": boot,
        "rank": {
            "n_events_used": len(out),
            "affected_per_event": out,
            "total_affected": rank_total_affected,
            "hits_top5": rank_hits,
            "events_with_hit": event_with_hit,
            "binom_p": zone_p,
        },
    }
    with open("eval_events_new.json", "w", encoding="utf-8") as f:
        json.dump(res, f, indent=2)
    print(json.dumps(res, indent=2), flush=True)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
