"""Recompute the Hurricane Sandy per-zone table with the retrained V3."""
import json
import os
import sys
from datetime import datetime

import numpy as np
import torch
import torch.nn as nn

BASE = os.environ.get("PAPERS_BASE", os.path.dirname(os.path.abspath(__file__)))
os.chdir(BASE)
sys.path.insert(0, "src/model")

from stwave import STWaveBlock
from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48
CF_OFFSET = 7 * 7 * SEQ
start = datetime(2011, 1, 1)
feats = np.load("data/nyc_taxi/processed/node_features.npy", mmap_mode="r")
_adj = np.load("data/nyc_taxi/processed/adj.npy").astype(np.float32)
_adj = _adj / np.maximum(_adj.sum(axis=1, keepdims=True), 1e-6)
ZONES = [78, 185, 169]


class SWPred(nn.Module):
    def __init__(self, nz, nd, h=64, b=2):
        super().__init__()
        self.zone_embed = nn.Embedding(nz, h)
        self.input_proj = nn.Linear(nd, h)
        self.pos_embed = nn.Embedding(48, h)
        self.blocks = nn.ModuleList([STWaveBlock(nz, h) for _ in range(b)])
        self.pred_head = nn.Sequential(nn.Linear(h, h), nn.ReLU(),
                                       nn.Linear(h, nd))

    def forward(self, zid, feats):
        B, S, D = feats.shape
        x = self.input_proj(feats)
        pos = torch.arange(S, device=feats.device).unsqueeze(0).expand(B, -1)
        x = (self.zone_embed(zid) + x + self.pos_embed(pos)).unsqueeze(1)
        for blk in self.blocks:
            x = blk(x)
        return self.pred_head(x[:, 0, -1, :])


def window_v3(zone, t):
    ts = max(0, t - SEQ)
    w_all = feats[ts:t]
    if len(w_all) < SEQ:
        pad = np.zeros((SEQ - len(w_all), feats.shape[1], feats.shape[2]),
                       dtype=w_all.dtype)
        w_all = np.concatenate([pad, w_all], axis=0)
    raw = w_all[:, zone]
    ctx = np.einsum("snd,n->sd", w_all, _adj[zone])
    return np.concatenate([raw, ctx], axis=-1)


def window_raw(zone, t):
    ts = max(0, t - SEQ)
    w = feats[ts:t, zone].copy()
    if len(w) < SEQ:
        w = np.concatenate([np.zeros((SEQ - len(w), 6)), w])
    return w


@torch.no_grad()
def ace(model, zone, t, t_star, causal=True):
    zid = torch.full((1, SEQ), zone, dtype=torch.long, device=device)
    if causal:
        ff = torch.FloatTensor(window_v3(zone, t)).unsqueeze(0).to(device)
        cf = torch.FloatTensor(window_v3(zone, t_star)).unsqueeze(0).to(device)
        _, pf = model(zid, ff)
        _, pcf = model(zid, cf)
    else:
        ff = torch.FloatTensor(window_raw(zone, t)).unsqueeze(0).to(device)
        cf = torch.FloatTensor(window_raw(zone, t_star)).unsqueeze(0).to(device)
        pf = model(zid, ff)
        pcf = model(zid, cf)
    return float(np.mean(np.abs(pf[0].cpu().numpy() - pcf[0].cpu().numpy())))


def main():
    v3 = STWaveCausalV3(n_zones=265, input_dim=12, output_dim=6,
                        ctx_channels=6, ctx_gate=True).to(device)
    v3.load_state_dict(torch.load(
        "data/nyc_taxi/processed/rerun_v3_seed42.pt", map_location=device))
    po = SWPred(265, 6).to(device)
    po.load_state_dict(torch.load(
        "data/nyc_taxi/processed/stwave_predonly_50ep_seed1.pt",
        map_location=device))
    v3.eval()
    po.eval()

    date = datetime(2012, 10, 29)
    t0 = int((date - start).total_seconds() / (30 * 60))
    t_star = t0 - CF_OFFSET
    rng = np.random.RandomState(42)
    safe = np.arange(CF_OFFSET + SEQ + 1,
                     feats.shape[0] - SEQ - CF_OFFSET - 1)
    safe = safe[safe != t0]
    picks = rng.choice(safe, size=200, replace=False)

    rows = []
    for z in ZONES:
        normal = float(np.median(feats[t0 - 96:t0, z, 0]))
        sandy = float(np.median(feats[t0:t0 + SEQ, z, 0]))
        a3 = ace(v3, z, t0, t_star)
        ap = ace(po, z, t0, t_star, causal=False)
        ph = np.array([ace(v3, z, int(tt), int(tt) - CF_OFFSET)
                       for tt in picks])
        zscore = float((a3 - ph.mean()) / (ph.std() + 1e-9))
        rows.append({"zone": z, "normal": normal, "sandy": sandy,
                     "ace_v3": a3, "ace_predonly": ap,
                     "ratio": a3 / (ap + 1e-9), "z": zscore,
                     "n_placebo_gt": int((ph >= a3).sum()), "n_placebo": 200})
        print(rows[-1], flush=True)

    baseline = np.array([feats[t_star:t_star + SEQ, z, 0].mean()
                         for z in range(265)])
    event_flow = np.array([feats[t0:t0 + SEQ, z, 0].mean()
                           for z in range(265)])
    drop = (baseline - event_flow) / np.maximum(baseline, 1e-6)
    affected = [z for z in range(265)
                if baseline[z] >= 5 and drop[z] > 0.4]
    a3_all = np.array([ace(v3, z, t0, t_star) for z in affected])
    ap_all = np.array([ace(po, z, t0, t_star, causal=False)
                       for z in affected])
    print("n_affected", len(affected), "v3_mean", a3_all.mean(),
          "po_mean", ap_all.mean(), flush=True)
    res = {"rows": rows, "affected": len(affected),
           "all_mean_v3": float(a3_all.mean()),
           "all_mean_predonly": float(ap_all.mean())}
    with open("eval_sandy_new.json", "w", encoding="utf-8") as f:
        json.dump(res, f, indent=2)
    print(json.dumps(res, indent=2), flush=True)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
