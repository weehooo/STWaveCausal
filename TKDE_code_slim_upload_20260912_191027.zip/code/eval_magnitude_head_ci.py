"""Bootstrap confidence intervals for the real-data magnitude head."""
import json

import numpy as np


def ridge_fit_predict(X, y, X_test, lam):
    X = np.column_stack([np.ones(len(X)), X])
    X_test = np.column_stack([np.ones(len(X_test)), X_test])
    A = X.T @ X + lam * np.eye(X.shape[1])
    w = np.linalg.solve(A, X.T @ y)
    return X_test @ w


def main():
    data = np.load("pemsbay_magnitude_features.npz")
    X = data["X"].astype(np.float64)
    y = data["y"].astype(np.float64)
    starts = data["starts"]
    order = np.argsort(starts)
    X, y = X[order], y[order]

    n = len(y)
    train_end = int(n * 0.60)
    val_end = int(n * 0.80)
    train = np.arange(0, train_end)
    val = np.arange(train_end, val_end)
    test = np.arange(val_end, n)

    mean = X[train].mean(axis=0)
    std = X[train].std(axis=0) + 1e-8
    X_train = (X[train] - mean) / std
    X_val = (X[val] - mean) / std
    X_test = (X[test] - mean) / std
    y_train, y_val, y_test = y[train], y[val], y[test]

    best = None
    for lam in [0.1, 1.0, 10.0, 100.0, 1000.0]:
        pred_val = ridge_fit_predict(X_train, y_train, X_val, lam)
        val_mae = float(np.mean(np.abs(y_val - pred_val)))
        if best is None or val_mae < best[0]:
            best = (val_mae, lam)
    _, lam = best
    pred_test = ridge_fit_predict(X_train, y_train, X_test, lam)

    rng = np.random.RandomState(20260908)
    mae_boot = []
    corr_boot = []
    bias_boot = []
    for _ in range(2000):
        idx = rng.choice(len(y_test), len(y_test), replace=True)
        mae_boot.append(float(np.mean(np.abs(y_test[idx] - pred_test[idx]))))
        if np.std(pred_test[idx]) > 0 and np.std(y_test[idx]) > 0:
            corr_boot.append(float(np.corrcoef(y_test[idx],
                                               pred_test[idx])[0, 1]))
        bias_boot.append(float(np.mean(pred_test[idx] - y_test[idx])))

    def ci(vals):
        return [float(np.percentile(vals, 2.5)),
                float(np.percentile(vals, 97.5))]

    out = {
        "lambda": lam,
        "n_test": int(len(y_test)),
        "mae": float(np.mean(np.abs(y_test - pred_test))),
        "mae_ci": ci(mae_boot),
        "corr": float(np.corrcoef(y_test, pred_test)[0, 1]),
        "corr_ci": ci(corr_boot),
        "bias": float(np.mean(pred_test - y_test)),
        "bias_ci": ci(bias_boot),
    }
    with open("magnitude_head_ci.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)


if __name__ == "__main__":
    main()
