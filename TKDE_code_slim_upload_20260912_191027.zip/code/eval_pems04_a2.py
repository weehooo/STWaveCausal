"""Evaluate the A2 PEMS04 checkpoint (hidden 128, 90+20) vs STIDGraph best."""
import os
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.stats import wilcoxon

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from graphctx_dataset import GraphCtxCausalDataset
from graph_dataset import GraphTrafficDataset
from stid_graph import STIDGraph
from stwave_causal_v3 import STWaveCausalV3

DATA = "data/pems04/processed"
META = np.load("data/datasets/pems04_staeformer/data.npz")["data"][..., 1:3][:, 0]
device = "cuda" if torch.cuda.is_available() else "cpu"

A2_CKPT = DATA + "/stwave_causal_v3_pems04_h128_90p20_best.pt"
STID_BEST = DATA + "/stidgraph-pems04_seed2_best.pt"


def collate_pred(batch):
    f, _, _, _, _ = zip(*batch)
    def sd(d):
        return {k: torch.stack([x[k] for x in d]) for k in d[0].keys()}
    return sd(f)


def collate_graph(batch):
    return {
        "zone_ids": torch.stack([b["zone_ids"] for b in batch]),
        "features": torch.stack([b["features"] for b in batch]),
        "targets": torch.stack([b["targets"] for b in batch]),
        "adj": batch[0]["adj"],
    }


def v3_preds(ckpt, hidden=128):
    ds = GraphCtxCausalDataset(DATA, "val", 48, ctx_mode="mean", meta=META)
    loader = torch.utils.data.DataLoader(ds, batch_size=64, shuffle=False,
                                         collate_fn=collate_pred)
    model = STWaveCausalV3(n_zones=307, input_dim=4, output_dim=1,
                           hidden_dim=hidden, ctx_channels=1).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    preds, tgts = [], []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) for k, v in batch.items()}
            _, pred = model(f["zone_ids"], f["features"])
            preds.append(pred.cpu().numpy())
            tgts.append(f["targets"].cpu().numpy())
    return np.concatenate(preds, axis=0), np.concatenate(tgts, axis=0)


def stid_preds(ckpt):
    ds = GraphTrafficDataset(DATA, "val", 48)
    loader = torch.utils.data.DataLoader(ds, batch_size=64, shuffle=False,
                                         collate_fn=collate_graph)
    model = STIDGraph(n_zones=307, input_dim=1, hidden_dim=64, seq_len=48,
                      n_layers=2, n_days=7).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    preds, tgts = [], []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) if isinstance(v, torch.Tensor) else v
                 for k, v in batch.items()}
            pred = model(f["features"], f["zone_ids"], f["adj"])
            preds.append(pred.cpu().numpy())
            tgts.append(f["targets"].cpu().numpy())
    return np.concatenate(preds, axis=0), np.concatenate(tgts, axis=0)


def main():
    print("Device:", device)
    pa, ta = v3_preds(A2_CKPT)
    ps, ts = stid_preds(STID_BEST)
    mae_a2 = float(np.abs(pa - ta).mean())
    mae_s = float(np.abs(ps - ts).mean())
    print("A2 (h128, 90+20) val MAE: %.4f" % mae_a2)
    print("STIDGraph best val MAE: %.4f" % mae_s)
    _, p = wilcoxon(np.abs(pa - ta)[:, 0], np.abs(ps - ts)[:, 0])
    print("Wilcoxon A2 vs STIDGraph p=%.4g" % p)
    print("ALL DONE")


if __name__ == "__main__":
    main()
