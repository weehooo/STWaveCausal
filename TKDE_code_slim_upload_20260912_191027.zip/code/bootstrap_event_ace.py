"""Bootstrap 95% CIs for real-event V3/PredOnly ACE (NYC affected zones)."""
import json
import os
import sys
from datetime import datetime

import numpy as np
import torch
import torch.nn as nn

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, "src/model")

from stwave import STWaveBlock
from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48
CF_OFFSET = 7 * 7 * SEQ
start = datetime(2011, 1, 1)
feats = np.load("data/nyc_taxi/processed/node_features.npy",
                mmap_mode="r")
_adj = np.load("data/nyc_taxi/processed/adj.npy").astype(np.float32)
_adj = _adj / np.maximum(_adj.sum(axis=1, keepdims=True), 1e-6)

EVENTS = [
    ("2012-10-29", "Hurricane Sandy"),
    ("2011-12-31", "New Year's Eve"),
    ("2013-02-08", "Winter Storm Nemo"),
    ("2011-10-29", "October nor'easter"),
    ("2012-11-07", "Post-Sandy nor'easter"),
    ("2011-08-28", "Hurricane Irene"),
]


class SWPred(nn.Module):
    def __init__(self, nz, nd, h=64, b=2):
        super().__init__()
        self.zone_embed = nn.Embedding(nz, h)
        self.input_proj = nn.Linear(nd, h)
        self.pos_embed = nn.Embedding(48, h)
        self.blocks = nn.ModuleList([STWaveBlock(nz, h) for _ in range(b)])
        self.pred_head = nn.Sequential(nn.Linear(h, h), nn.ReLU(),
                                       nn.Linear(h, nd))

    def forward(self, zid, feats):
        B, S, D = feats.shape
        x = self.input_proj(feats)
        pos = torch.arange(S, device=feats.device).unsqueeze(0).expand(B, -1)
        x = (self.zone_embed(zid) + x + self.pos_embed(pos)).unsqueeze(1)
        for blk in self.blocks:
            x = blk(x)
        return self.pred_head(x[:, 0, -1, :])


def window_raw(zone, t):
    ts = max(0, t - SEQ)
    w = feats[ts:t, zone].copy()
    if len(w) < SEQ:
        w = np.concatenate([np.zeros((SEQ - len(w), 6)), w])
    return w


def window_v3(zone, t):
    ts = max(0, t - SEQ)
    w_all = feats[ts:t]
    if len(w_all) < SEQ:
        pad = np.zeros((SEQ - len(w_all), feats.shape[1], feats.shape[2]),
                       dtype=w_all.dtype)
        w_all = np.concatenate([pad, w_all], axis=0)
    raw = w_all[:, zone]
    ctx = np.einsum("snd,n->sd", w_all, _adj[zone])
    return np.concatenate([raw, ctx], axis=-1)


@torch.no_grad()
def ace(model, zone, t, t_star):
    zid = torch.full((1, SEQ), zone, dtype=torch.long, device=device)
    if hasattr(model, "causal_head"):
        ff = torch.FloatTensor(window_v3(zone, t)).unsqueeze(0).to(device)
        cf = torch.FloatTensor(window_v3(zone, t_star)).unsqueeze(0).to(device)
        _, pf = model(zid, ff)
        _, pcf = model(zid, cf)
    else:
        ff = torch.FloatTensor(window_raw(zone, t)).unsqueeze(0).to(device)
        cf = torch.FloatTensor(window_raw(zone, t_star)).unsqueeze(0).to(device)
        pf = model(zid, ff)
        pcf = model(zid, cf)
    return float(np.mean(np.abs(pf[0].cpu().numpy() -
                                pcf[0].cpu().numpy())))


def bootstrap_ci(values, n_boot=5000, seed=42):
    rng = np.random.RandomState(seed)
    v = np.asarray(values, dtype=np.float64)
    means = np.empty(n_boot)
    for b in range(n_boot):
        idx = rng.randint(0, len(v), size=len(v))
        means[b] = v[idx].mean()
    return float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))


def main():
    v3 = STWaveCausalV3(n_zones=265, input_dim=12, output_dim=6,
                        ctx_channels=0).to(device)
    v3.load_state_dict(torch.load(
        "data/nyc_taxi/processed/stwave_causal_v3_graphctx_nyc_best.pt",
        map_location=device))
    po = SWPred(265, 6).to(device)
    po.load_state_dict(torch.load(
        "data/nyc_taxi/processed/stwave_predonly_50ep.pt",
        map_location=device))
    v3.eval()
    po.eval()
    print("Device:", device, flush=True)

    out = []
    for dstr, name in EVENTS:
        date = datetime.strptime(dstr, "%Y-%m-%d")
        t0 = int((date - start).total_seconds() / (30 * 60))
        t_star = t0 - CF_OFFSET
        if t_star - SEQ < 0 or t0 + SEQ >= feats.shape[0]:
            print("skip", name, "out of range", flush=True)
            continue
        zones = list(range(feats.shape[1]))
        baseline = np.array([feats[t_star:t_star + SEQ, z, 0].mean()
                             for z in zones])
        event_flow = np.array([feats[t0:t0 + SEQ, z, 0].mean()
                               for z in zones])
        drop = (baseline - event_flow) / np.maximum(baseline, 1e-6)
        affected = [z for z in zones
                    if baseline[z] >= 5 and drop[z] > 0.4]
        if not affected:
            print("no affected zones:", name, flush=True)
            continue
        ace_v3 = np.array([ace(v3, z, t0, t_star) for z in affected])
        ace_po = np.array([ace(po, z, t0, t_star) for z in affected])
        lo3, hi3 = bootstrap_ci(ace_v3)
        lo0, hi0 = bootstrap_ci(ace_po)
        row = {
            "date": dstr, "event": name, "n_affected": len(affected),
            "mean_ace_v3": float(ace_v3.mean()),
            "ci95_v3": [lo3, hi3],
            "mean_ace_predonly": float(ace_po.mean()),
            "ci95_predonly": [lo0, hi0],
        }
        out.append(row)
        print("%-22s n=%2d V3=%.2f [%.2f, %.2f] PredOnly=%.2f [%.2f, %.2f]" %
              (name, len(affected), row["mean_ace_v3"], lo3, hi3,
               row["mean_ace_predonly"], lo0, hi0), flush=True)

    with open("event_ace_bootstrap.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
