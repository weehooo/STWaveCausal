"""Test-set paired Wilcoxon: V3/STID/ensemble vs baselines (P0-1)."""
import gc
import json
import os
import sys

import numpy as np
import torch
import torch.nn as nn
from scipy.stats import wilcoxon

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")
try:
    sys.stdout.reconfigure(line_buffering=True)
except Exception:
    pass

from dataset import TrafficCausalDataset
from graph_dataset import GraphTrafficDataset
from graphctx_dataset import GraphCtxCausalDataset
from stid_causal import STIDCausal
from stwave_causal_v3 import STWaveCausalV3
from stwave import STWave, STWaveBlock
from crossgnn import CrossGNN
from stid_graph import STIDGraph

device = "cuda" if torch.cuda.is_available() else "cpu"


def collate_ctx(batch):
    factual, _, _, _, _ = zip(*batch)
    return {k: torch.stack([x[k] for x in factual]) for k in factual[0].keys()}


def collate_graph(batch):
    return {
        "zone_ids": torch.stack([b["zone_ids"] for b in batch]),
        "features": torch.stack([b["features"] for b in batch]),
        "targets": torch.stack([b["targets"] for b in batch]),
        "adj": batch[0]["adj"],
    }


def collate_pred(batch):
    factual, _, _, _, _ = zip(*batch)
    return {k: torch.stack([x[k] for x in factual]) for k in factual[0].keys()}


def loader_for(ds, collate_fn, batch=64):
    return torch.utils.data.DataLoader(ds, batch_size=batch, shuffle=False,
                                       collate_fn=collate_fn, num_workers=0)


class SWPred(nn.Module):
    def __init__(self, nz, nd, h=64, b=2):
        super().__init__()
        self.zone_embed = nn.Embedding(nz, h)
        self.input_proj = nn.Linear(nd, h)
        self.pos_embed = nn.Embedding(48, h)
        self.blocks = nn.ModuleList([STWaveBlock(nz, h) for _ in range(b)])
        self.pred_head = nn.Sequential(nn.Linear(h, h), nn.ReLU(),
                                       nn.Linear(h, nd))

    def forward(self, zid, feats):
        B, S, D = feats.shape
        x = self.input_proj(feats)
        pos = torch.arange(S, device=feats.device).unsqueeze(0).expand(B, -1)
        x = (self.zone_embed(zid) + x + self.pos_embed(pos)).unsqueeze(1)
        for blk in self.blocks:
            x = blk(x)
        return self.pred_head(x[:, 0, -1, :])


def preds_v3(nz, ind, outd, ctxc, ckpt, loader):
    model = STWaveCausalV3(n_zones=nz, input_dim=ind, output_dim=outd,
                           ctx_channels=ctxc).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    ps = []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) for k, v in batch.items()}
            _, pred = model(f["zone_ids"], f["features"])
            ps.append(pred.cpu().numpy())
    return np.concatenate(ps)


def preds_stid(nz, nd, ckpt, loader):
    model = STIDCausal(n_zones=nz, input_dim=nd, output_dim=nd).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    ps = []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) if isinstance(v, torch.Tensor) else v
                 for k, v in batch.items()}
            _, pred = model(f["features"], f["zone_ids"], f["adj"])
            ps.append(pred.cpu().numpy())
    return np.concatenate(ps)


def preds_stidgraph(nz, nd, ckpt, loader):
    model = STIDGraph(n_zones=nz, input_dim=nd, hidden_dim=64, seq_len=48,
                      n_layers=2, n_days=7).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    ps = []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) if isinstance(v, torch.Tensor) else v
                 for k, v in batch.items()}
            pred = model(f["features"], f["zone_ids"], f["adj"])
            ps.append(pred.cpu().numpy())
    return np.concatenate(ps)


def preds_predonly(nz, nd, ckpt, loader):
    model = SWPred(nz, nd).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    ps = []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) for k, v in batch.items()}
            ps.append(model(f["zone_ids"], f["features"]).cpu().numpy())
    return np.concatenate(ps)


def preds_features(ModelClass, nz, nd, ckpt, loader, **kw):
    model = ModelClass(n_zones=nz, input_dim=nd, **kw).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    ps = []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) for k, v in batch.items()}
            ps.append(model(f["features"]).cpu().numpy())
    return np.concatenate(ps)


def arr(pred, t):
    return np.abs(pred - t).mean(axis=-1)


def main():
    print("Device:", device, flush=True)
    meta08 = np.load("data/datasets/pems08_staeformer/data.npz")["data"][..., 1:3][:, 0]
    meta04 = np.load("data/datasets/pems04_staeformer/data.npz")["data"][..., 1:3][:, 0]
    cfgs = [
        ("NYC Taxi", "data/nyc_taxi/processed", 265, 6,
         dict(ctx_mode="mean", ind=12, outd=6, ctxc=0,
              v3="stwave_causal_v3_graphctx_nyc_seed4.pt",
              stid="stid_causal_nyc_best.pt",
              stg="stidgraph-nyc_best.pt")),
        ("PEMS-BAY", "data/pems_bay/processed", 325, 8,
         dict(ctx_mode="gradient", ind=16, outd=8, ctxc=0,
              v3="stwave_causal_v3_graphctx_grad_pemsbay_seed4.pt",
              stid="stid_causal_pemsbay_best.pt",
              stg="stidgraph-pems_best.pt")),
        ("PEMS08", "data/pems08/processed", 170, 1,
         dict(ctx_mode="mean", ind=4, outd=1, ctxc=1, meta=meta08,
              v3="stwave_causal_v3_graphctx_gate_pems08_best.pt",
              stid="stid_causal_pems08_seed4.pt",
              stg="stidgraph-pems08_seed4_best.pt")),
        ("PEMS04", "data/pems04/processed", 307, 1,
         dict(ctx_mode="mean", ind=4, outd=1, ctxc=1, meta=meta04,
              v3="stwave_causal_v3_graphctx_gate_pems04_seed2.pt",
              stid="stid_causal_pems04_seed2.pt",
              stg="stidgraph-pems04_seed2_best.pt")),
    ]
    out = {}
    for name, data_dir, nz, nd, cfg in cfgs:
        print("==", name, flush=True)
        ctx_ds = GraphCtxCausalDataset(data_dir, "test", 48,
                                       ctx_mode=cfg["ctx_mode"],
                                       meta=cfg.get("meta"))
        graph_ds = GraphTrafficDataset(data_dir, "test", 48)
        traffic_ds = TrafficCausalDataset(data_dir, "test", 48)
        ctx_l = loader_for(ctx_ds, collate_ctx)
        graph_l = loader_for(graph_ds, collate_graph)
        traffic_l = loader_for(traffic_ds, collate_pred)

        p_v3 = preds_v3(nz, cfg["ind"], cfg["outd"], cfg["ctxc"],
                        data_dir + "/" + cfg["v3"], ctx_l)
        p_st = preds_stid(nz, nd, data_dir + "/" + cfg["stid"], graph_l)
        p_sg = preds_stidgraph(nz, nd, data_dir + "/" + cfg["stg"], graph_l)
        p_po = preds_predonly(nz, nd, data_dir + "/stwave_predonly_50ep.pt",
                              traffic_l)
        p_sw = preds_features(STWave, nz, nd, data_dir + "/stwave_best.pt",
                              traffic_l, hidden_dim=64, n_blocks=2, seq_len=48)
        p_cg = preds_features(CrossGNN, nz, nd, data_dir + "/crossgnn_best.pt",
                              traffic_l, hidden_dim=64, n_blocks=2, n_heads=4,
                              seq_len=48)
        # targets from ctx loader (same sample order)
        t_ctx = []
        with torch.no_grad():
            for batch in ctx_l:
                t_ctx.append(batch["targets"].numpy())
        t = np.concatenate(t_ctx)

        e3 = arr(p_v3, t)
        es = arr(p_st, t)
        ee = arr(0.5 * (p_v3 + p_st), t)
        bas = {"PredOnly": arr(p_po, t), "STWave": arr(p_sw, t),
               "CrossGNN": arr(p_cg, t), "STIDGraph": arr(p_sg, t)}

        def wil(x, y):
            if len(x) != len(y):
                return None
            try:
                return float(wilcoxon(x, y).pvalue)
            except Exception:
                return None

        res = {"V3_mae": float(e3.mean()), "STID_mae": float(es.mean()),
               "Ens_mae": float(ee.mean())}
        for bname, eb in bas.items():
            res["V3_vs_" + bname] = wil(e3, eb)
            res["Ens_vs_" + bname] = wil(ee, eb)
        res["STID_vs_STIDGraph"] = wil(es, bas["STIDGraph"])
        out[name] = res
        print(res, flush=True)
        del ctx_ds, graph_ds, traffic_ds, ctx_l, graph_l, traffic_l
        gc.collect()
        torch.cuda.empty_cache()
    with open("eval_test_wilcoxon_results.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
