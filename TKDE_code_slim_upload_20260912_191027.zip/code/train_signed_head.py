"""Train a dedicated signed causal-effect head on frozen V3 embeddings.

The existing V3 CausalEffectHead is constrained to non-negative magnitudes.
This script augments the synthetic graph-context pairs by swapping factual and
counterfactual windows to produce negative-effect examples, then fits a small
signed MLP head over the frozen STWaveCausalV3 representations.
"""
import json
import os
import sys

import numpy as np
import torch
import torch.nn as nn

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, "src/model")

from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"
syn = np.load(
    "data/nyc_taxi/processed/synthetic_pairs_v3_graphctx.npy",
    allow_pickle=True,
).item()


class SignedEffectHead(nn.Module):
    def __init__(self, hidden_dim=64, output_dim=6):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(hidden_dim * 3, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim),
        )

    def forward(self, h_f, h_cf, combo_emb):
        return self.net(torch.cat([h_f, h_cf, combo_emb], dim=-1))


def make_tensors(samples, start, size):
    batch = samples[start:start + size]
    zones = torch.zeros(len(batch), 48, dtype=torch.long)
    ff = torch.zeros(len(batch), 48, 12)
    cf = torch.zeros(len(batch), 48, 12)
    ice = torch.zeros(len(batch), 6)
    et = torch.full((len(batch), 5), -1, dtype=torch.long)
    el = torch.zeros(len(batch), 5, 2)
    etm = torch.zeros(len(batch), 5)
    zs = torch.zeros(len(batch), 5, 12)
    for i, d in enumerate(batch):
        zones[i] = d["zone"]
        ff[i] = d["factual"]
        cf[i] = d["cf"]
        ice[i] = d["ice_true"]
        c = d["combo"]
        et[i] = c["event_types"]
        el[i] = c["event_locs"]
        etm[i] = c["event_times"]
        zs[i] = c["zone_states"]
    return zones, ff, cf, ice, et, el, etm, zs


def encode_batch(model, zones, ff, cf, et, el, etm, zs):
    zones = zones.to(device)
    ff = ff.to(device)
    cf = cf.to(device)
    et = et.to(device)
    el = el.to(device)
    etm = etm.to(device)
    zs = zs.to(device)
    with torch.no_grad():
        h_f = model.encode(zones, ff)
        h_cf = model.encode(zones, cf)
        combo = {"event_types": et, "event_locs": el,
                 "event_times": etm, "zone_states": zs}
        combo_emb, _, _ = model.causal_learner(
            combo["event_types"], combo["event_locs"],
            combo["event_times"], combo["zone_states"])
    return h_f, h_cf, combo_emb


def evaluate(model, head, samples, swap=False):
    model.eval()
    head.eval()
    ests, trues = [], []
    with torch.no_grad():
        for i in range(0, len(samples), 64):
            zones, ff, cf, ice, et, el, etm, zs = make_tensors(
                samples, i, 64)
            if swap:
                ff, cf = cf, ff
            h_f, h_cf, combo = encode_batch(model, zones, ff, cf, et, el, etm, zs)
            pred = head(h_f, h_cf, combo)
            ests.append(pred[:, 0].cpu().numpy())
            if swap:
                trues.append((-ice[:, 0]).cpu().numpy())
            else:
                trues.append(ice[:, 0].cpu().numpy())
    est = np.concatenate(ests)
    true = np.concatenate(trues)
    corr = float(np.corrcoef(est, true)[0, 1])
    ratio = float(np.median(est / (true + 1e-6)))
    mae = float(np.abs(est - true).mean())
    return {"corr": corr, "median_ratio": ratio, "mae": mae}, est, true


def main():
    model = STWaveCausalV3(
        n_zones=265, input_dim=12, output_dim=6, ctx_channels=0
    ).to(device)
    model.load_state_dict(torch.load(
        "data/nyc_taxi/processed/stwave_causal_v3_graphctx_nyc_best.pt",
        map_location=device))
    model.eval()
    for p in model.parameters():
        p.requires_grad_(False)

    head = SignedEffectHead().to(device)
    opt = torch.optim.Adam(head.parameters(), lr=1e-3)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=20)
    train = syn["train"]

    for ep in range(20):
        head.train()
        model.eval()
        order = np.random.permutation(len(train))
        total = 0.0
        n = 0
        for start in range(0, len(order), 64):
            idx = order[start:start + 64]
            batch = [train[j] for j in idx]
            zones, ff, cf, ice, et, el, etm, zs = make_tensors(
                batch, 0, len(batch))
            h_f, h_cf, combo = encode_batch(
                model, zones, ff, cf, et, el, etm, zs)
            h_f2, h_cf2, combo2 = encode_batch(
                model, zones, cf, ff, et, el, etm, zs)
            y_pos = ice.to(device)
            y_neg = -ice.to(device)
            pred_pos = head(h_f, h_cf, combo)
            pred_neg = head(h_f2, h_cf2, combo2)
            loss = nn.functional.mse_loss(pred_pos, y_pos) + \
                nn.functional.mse_loss(pred_neg, y_neg)
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(head.parameters(), 5.0)
            opt.step()
            total += loss.item()
            n += 1
        sched.step()
        if ep == 0 or (ep + 1) % 5 == 0:
            pos, _, _ = evaluate(model, head, syn["test"], swap=False)
            neg, _, _ = evaluate(model, head, syn["test"], swap=True)
            print("Ep %02d loss=%.4f pos=%.3f neg=%.3f" %
                  (ep + 1, total / max(n, 1), pos["mae"], neg["mae"]),
                  flush=True)

    pos, pos_est, pos_true = evaluate(model, head, syn["test"], swap=False)
    neg, neg_est, neg_true = evaluate(model, head, syn["test"], swap=True)
    all_est = np.concatenate([pos_est, neg_est])
    all_true = np.concatenate([pos_true, neg_true])
    all_metrics = {
        "corr": float(np.corrcoef(all_est, all_true)[0, 1]),
        "median_ratio": float(np.median(all_est / (all_true + 1e-6))),
        "mae": float(np.abs(all_est - all_true).mean()),
    }
    out = {
        "positive": pos,
        "negative": neg,
        "combined": all_metrics,
    }
    torch.save(head.state_dict(), "signed_effect_head.pt")
    with open("signed_head_results.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print("POS", pos, flush=True)
    print("NEG", neg, flush=True)
    print("COMBINED", all_metrics, flush=True)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
