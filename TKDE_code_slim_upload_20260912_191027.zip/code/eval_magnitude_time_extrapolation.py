"""Time-extrapolation check for the real-data magnitude head.

Train on PEMS-BAY incidents through the end of May and evaluate on June
incidents, which are never seen during training. This directly tests whether
the magnitude signal is stable over calendar time.
"""
import json

import numpy as np


def ridge_fit_predict(X, y, X_test, lam):
    X = np.column_stack([np.ones(len(X)), X])
    X_test = np.column_stack([np.ones(len(X_test)), X_test])
    A = X.T @ X + lam * np.eye(X.shape[1])
    w = np.linalg.solve(A, X.T @ y)
    return X_test @ w


def metrics(y_true, y_pred):
    ss_res = float(np.sum((y_true - y_pred) ** 2))
    ss_tot = float(np.sum((y_true - y_true.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    mae = float(np.mean(np.abs(y_true - y_pred)))
    bias = float(np.mean(y_pred - y_true))
    corr = float(np.corrcoef(y_true, y_pred)[0, 1])
    return {"r2": r2, "mae": mae, "bias": bias, "corr": corr}


def main():
    data = np.load("pemsbay_magnitude_features.npz")
    X = data["X"].astype(np.float64)
    y = data["y"].astype(np.float64)
    starts = data["starts"]
    order = np.argsort(starts)
    X, y, starts = X[order], y[order], starts[order]

    june_start = 151 * 288
    train = starts < june_start
    test = starts >= june_start
    if test.sum() < 20 or train.sum() < 20:
        raise RuntimeError("Insufficient time-extrapolation split")

    X_train, y_train = X[train], y[train]
    X_test, y_test = X[test], y[test]
    mean = X_train.mean(axis=0)
    std = X_train.std(axis=0) + 1e-8
    X_train = (X_train - mean) / std
    X_test = (X_test - mean) / std

    best = None
    for lam in [0.1, 1.0, 10.0, 100.0, 1000.0]:
        # Use an inner chronological validation fold inside the training set.
        cut = int(len(X_train) * 0.8)
        pred_val = ridge_fit_predict(X_train[:cut], y_train[:cut],
                                     X_train[cut:], lam)
        val_mae = float(np.mean(np.abs(y_train[cut:] - pred_val)))
        if best is None or val_mae < best[0]:
            best = (val_mae, lam)
    _, lam = best
    pred_test = ridge_fit_predict(X_train, y_train, X_test, lam)
    baseline = np.full_like(y_test, float(y_train.mean()))

    out = {
        "n_train": int(train.sum()),
        "n_test": int(test.sum()),
        "test_start_idx": int(starts[test].min()),
        "lambda": lam,
        "baseline_mean": metrics(y_test, baseline),
        "magnitude_head": metrics(y_test, pred_test),
    }
    with open("magnitude_time_extrapolation.json", "w",
              encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)
    print("Wrote magnitude_time_extrapolation.json", flush=True)


if __name__ == "__main__":
    main()
