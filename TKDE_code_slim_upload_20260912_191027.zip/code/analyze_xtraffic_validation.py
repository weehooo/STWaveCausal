"""Summarize the XTraffic real-incident counterfactual validation CSV."""
import json

import numpy as np
import pandas as pd


def main():
    val = pd.read_csv("real_incident_validation.csv")
    incidents = pd.read_csv(
        r"C:\Users\weehoo\.cache\kagglehub\datasets\gpxlcj\xtraffic"
        r"\versions\8\incidents_y2023.csv",
        sep="\t",
    )
    incidents["dt"] = pd.to_datetime(incidents["dt"])
    val["dt"] = pd.to_datetime(val["dt"])
    merged = val.merge(
        incidents[["incident_id", "DESCRIPTION", "duration", "Type"]],
        on="incident_id",
        how="left",
    )

    valid = merged.dropna(subset=["effect"])
    by_type = (
        valid.groupby("DESCRIPTION")["effect"]
        .agg(["count", "mean", "std"])
        .sort_values("count", ascending=False)
        .head(12)
        .reset_index()
    )
    duration_corr = float(
        valid[["effect", "duration"]].corr().iloc[0, 1]
    )

    out = {
        "n_rows": int(len(val)),
        "n_valid_effects": int(len(valid)),
        "effect_mean": float(valid["effect"].mean()),
        "effect_std": float(valid["effect"].std()),
        "effect_median": float(valid["effect"].median()),
        "duration_corr": duration_corr,
        "by_type": by_type.to_dict(orient="records"),
    }
    with open("xtraffic_validation_summary.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)


if __name__ == "__main__":
    main()
