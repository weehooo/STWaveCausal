"""Closure test for a doubly robust effect estimator on a synthetic controller.

The simulator generates a panel with known treatment probabilities, no
interference, and known per-node ACE. We fit outcome models for treated and
untreated states, then evaluate the augmented inverse-propensity weighted
(AIPW) estimator against the true average causal effect. We also compare the
oracle propensity to a fitted logistic propensity.
"""
import json
from pathlib import Path

import numpy as np

BASE = Path("F:/xuexi/codex/papers")


def add_intercept(X):
    return np.column_stack([np.ones(len(X)), X])


def linear_fit_predict(X, y, X_test):
    beta, *_ = np.linalg.lstsq(add_intercept(X), y, rcond=None)
    return add_intercept(X_test) @ beta


def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))


def logistic_fit_predict(X, y, X_test, iters=3000, lr=0.1, l2=1e-4):
    mean = X.mean(axis=0)
    std = X.std(axis=0) + 1e-8
    X = (X - mean) / std
    X_test = (X_test - mean) / std
    X_aug = add_intercept(X)
    X_test_aug = add_intercept(X_test)
    w = np.zeros(X_aug.shape[1])
    for _ in range(iters):
        grad = X_aug.T @ (sigmoid(X_aug @ w) - y) / len(y) + l2 * w
        w -= lr * grad
    return sigmoid(X_test_aug @ w)


def simulate_no_interference(seed, n_nodes=40, T=4000, p_base=0.2,
                             p_amp=0.35, p_min=0.15, p_max=0.75):
    rng = np.random.RandomState(seed)
    N = n_nodes
    W = 48
    phase = rng.uniform(0, 2 * np.pi, N)
    base = 20 + 6 * np.sin(2 * np.pi * np.arange(T)[:, None] / W + phase)
    eps = rng.normal(0, 1.5, (T, N))
    ar = np.zeros_like(eps)
    for t in range(1, T):
        ar[t] = 0.6 * ar[t - 1] + eps[t]
    U = np.clip(
        0.5 + 0.3 * np.sin(2 * np.pi * np.arange(T)[:, None] / W +
                           0.5 * phase), 0, 1) + 0.1 * rng.randn(T, N)
    propensity = np.clip(p_base + p_amp * U, p_min, p_max)
    Tr = (rng.rand(T, N) < propensity).astype(float)
    ACE = rng.uniform(2, 8, N) * (rng.rand(N) < 0.6)
    Y = np.zeros((T, N))
    for t in range(T - 1):
        Y[t + 1] = base[t] + ar[t] + ACE * Tr[t] + rng.normal(0, 0.5, N)
    return {"Y": Y, "Tr": Tr, "propensity": propensity, "ACE": ACE,
            "base": base, "ar": ar, "U": U}


def aipw(Y_next, Tr, propensity, mu0, mu1):
    p = np.clip(propensity, 1e-6, 1 - 1e-6)
    return np.mean(mu1 - mu0 +
                   Tr * (Y_next - mu1) / p -
                   (1 - Tr) * (Y_next - mu0) / (1 - p))


def run_seed(seed):
    sim = simulate_no_interference(seed)
    Y, Tr, propensity = sim["Y"], sim["Tr"], sim["propensity"]
    T, N = Y.shape
    rows = []
    for t in range(1, T):
        x = np.column_stack([
            sim["base"][t - 1],
            sim["ar"][t - 1],
            sim["U"][t - 1],
        ])
        rows.append(x)
    X = np.concatenate(rows, axis=0).astype(float)
    y = Y[1:].reshape(-1)
    tr = Tr[:-1].reshape(-1)

    mu1 = linear_fit_predict(X[tr == 1], y[tr == 1], X)
    mu0 = linear_fit_predict(X[tr == 0], y[tr == 0], X)
    p = propensity[:-1].reshape(-1)
    p_oracle = np.clip(p, 1e-6, 1 - 1e-6)

    # Fitted propensity model using the same pre-treatment covariates.
    p_fitted = np.clip(logistic_fit_predict(X, tr, X), 1e-6, 1 - 1e-6)

    true_ace = np.mean(sim["ACE"])
    return {
        "true_ace": float(true_ace),
        "aipw_oracle": float(aipw(y, tr, p_oracle, mu0, mu1)),
        "aipw_fitted": float(aipw(y, tr, p_fitted, mu0, mu1)),
        "naive_regression": float(np.mean(mu1[tr == 1] - mu0[tr == 1])),
    }


def main():
    rows = [run_seed(s) for s in range(5)]
    for r in rows:
        print(r, flush=True)
    summary = {
        "true_ace_mean": float(np.mean([r["true_ace"] for r in rows])),
        "aipw_oracle_mean": float(np.mean([r["aipw_oracle"] for r in rows])),
        "aipw_fitted_mean": float(np.mean([r["aipw_fitted"] for r in rows])),
        "naive_regression_mean": float(
            np.mean([r["naive_regression"] for r in rows])),
        "oracle_bias": float(np.mean([abs(r["aipw_oracle"] - r["true_ace"])
                                      for r in rows])),
        "fitted_bias": float(np.mean([abs(r["aipw_fitted"] - r["true_ace"])
                                      for r in rows])),
        "naive_bias": float(np.mean([abs(r["naive_regression"] - r["true_ace"])
                                     for r in rows])),
    }
    with open("doubly_robust_synthetic_results.json", "w",
              encoding="utf-8") as f:
        json.dump({"per_seed": rows, "summary": summary}, f, indent=2)
    print("SUMMARY", summary, flush=True)
    print("Wrote doubly_robust_synthetic_results.json", flush=True)


if __name__ == "__main__":
    main()
