"""Evaluate an audit-aware abstention rule on PEMS-BAY incidents."""
import json

import numpy as np
from scipy import stats


def main():
    study = json.load(open("pemsbay_eventsudy_results.json", encoding="utf-8"))
    rows = study["per_event"]
    post_effects = []
    retained = []
    abstained = []
    for r in rows:
        curve = np.array(r["curve"][6:])
        post = float(curve.mean())
        se = float(curve.std(ddof=1) / np.sqrt(len(curve))) if curve.std(ddof=1) > 0 else 0.0
        ci = stats.t.interval(0.95, max(len(curve) - 1, 1),
                              loc=post, scale=se)
        post_effects.append(post)
        if ci[0] > 0 or ci[1] < 0:
            retained.append(post)
        else:
            abstained.append(post)
    out = {
        "n_events": int(len(post_effects)),
        "n_retained": int(len(retained)),
        "n_abstained": int(len(abstained)),
        "retained_mean_abs_effect": float(np.mean(np.abs(retained)))
        if retained else None,
        "abstained_mean_abs_effect": float(np.mean(np.abs(abstained)))
        if abstained else None,
        "retention_rate": float(len(retained) / max(1, len(post_effects))),
    }
    with open("audit_abstention.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)


if __name__ == "__main__":
    main()
