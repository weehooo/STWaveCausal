"""Regenerate the two experiment figures used in paper_tkde."""
import os
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, "src/model")

from dataset import TrafficCausalDataset
from stwave_causal_v3 import STWaveCausalV3, collate_v3

device = "cuda" if torch.cuda.is_available() else "cpu"
DATA = Path("data/nyc_taxi/processed")
OUT = Path("paper_tkde/figures")


def synthetic_batch(samples, start, size, feature_dim, ice_dim=6):
    batch = samples[start:start + size]
    zones = torch.zeros(len(batch), 48, dtype=torch.long)
    ff = torch.zeros(len(batch), 48, feature_dim)
    cf = torch.zeros(len(batch), 48, feature_dim)
    ice = torch.zeros(len(batch), ice_dim)
    et = torch.full((len(batch), 5), -1, dtype=torch.long)
    el = torch.zeros(len(batch), 5, 2)
    etm = torch.zeros(len(batch), 5)
    zs = torch.zeros(len(batch), 5, feature_dim)
    for i, d in enumerate(batch):
        zones[i] = d["zone"]
        ff[i] = d["factual"]
        cf[i] = d["cf"]
        ice[i] = d["ice_true"]
        c = d["combo"]
        et[i] = c["event_types"]
        el[i] = c["event_locs"]
        etm[i] = c["event_times"]
        zs[i] = c["zone_states"]
    return {
        "zones": zones.to(device),
        "ff": ff.to(device),
        "cf": cf.to(device),
        "ice": ice.to(device),
        "et": et.to(device),
        "el": el.to(device),
        "etm": etm.to(device),
        "zs": zs.to(device),
    }


@torch.no_grad()
def collect_recovery(model, samples, feature_dim, ice_dim=6):
    ests, trues = [], []
    for i in range(0, len(samples), 64):
        b = synthetic_batch(samples, i, 64, feature_dim, ice_dim)
        combo = {
            "event_types": b["et"],
            "event_locs": b["el"],
            "event_times": b["etm"],
            "zone_states": b["zs"],
        }
        e = model.causal_effect(
            {"zone_ids": b["zones"], "features": b["ff"]},
            {"zone_ids": b["zones"], "features": b["cf"]},
            combo)
        ests.append(e[:, 0].cpu().numpy())
        trues.append(b["ice"][:, 0].cpu().numpy())
    return np.concatenate(ests), np.concatenate(trues)


def plot_synthetic_recovery():
    model = STWaveCausalV3(n_zones=265, input_dim=12, output_dim=6,
                           ctx_channels=0).to(device)
    model.load_state_dict(torch.load(
        str(DATA / "stwave_causal_v3_graphctx_nyc_seed4.pt"),
        map_location=device))
    model.eval()
    synthetic = np.load(str(DATA / "synthetic_pairs_v3_graphctx.npy"),
                        allow_pickle=True).item()
    est, true = collect_recovery(model, synthetic["test"], 12, 6)
    corr = np.corrcoef(est, true)[0, 1]
    ratio = np.median(est / (true + 1e-6))
    mae = np.abs(est - true).mean()

    plt.figure(figsize=(4.4, 4.0))
    plt.scatter(true, est, s=6, alpha=0.35, c="#1f6feb", edgecolors="none")
    lim = [0, max(true.max(), est.max()) * 1.05]
    plt.plot(lim, lim, "--", color="#333333", linewidth=1.2, label="Identity")
    plt.xlabel("True ICE (feature 0)")
    plt.ylabel("Estimated ICE")
    plt.title("STWaveCausal V3 recovery (NYC test)")
    plt.text(0.04, 0.96,
             "rho={:.4f}\nratio={:.3f}\nMAE(f0)={:.3f}".format(
                 corr, ratio, mae),
             transform=plt.gca().transAxes, va="top",
             bbox=dict(boxstyle="round,pad=0.35", fc="white", ec="#bbbbbb"))
    plt.xlim(lim)
    plt.ylim(lim)
    plt.tight_layout()
    plt.savefig(OUT / "synthetic_recovery.png", dpi=200)
    plt.close()
    print("synthetic_recovery.png: rho={:.4f} ratio={:.3f} mae={:.3f}".format(
        corr, ratio, mae))


def plot_ablation():
    variants = ["Full V3 (graph ctx)", "V3 w/o graph ctx", "PredOnly"]
    maes = [6.140, 6.664, 6.405]
    colors = ["#1f6feb", "#ff9f1c", "#8d6e63"]
    plt.figure(figsize=(4.4, 3.6))
    bars = plt.bar(variants, maes, color=colors, width=0.62)
    for bar, v in zip(bars, maes):
        plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.02,
                 "{:.3f}".format(v), ha="center", fontsize=9)
    plt.ylabel("Val MAE (NYC Taxi)")
    plt.ylim(6.0, 7.0)
    plt.tight_layout()
    plt.savefig(OUT / "ablation_nyc.png", dpi=200)
    plt.close()
    print("ablation_nyc.png written")


if __name__ == "__main__":
    plot_synthetic_recovery()
    plot_ablation()
