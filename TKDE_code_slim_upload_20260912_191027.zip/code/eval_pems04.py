"""Evaluate STWaveCausal V3 and baselines on PEMS04 (val MAE + paired tests)."""
import os
import sys

import numpy as np
import torch
import torch.nn as nn
from scipy.stats import wilcoxon

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from dataset import TrafficCausalDataset
from graph_dataset import GraphTrafficDataset
from graphctx_dataset import GraphCtxCausalDataset
from stwave import STWave, STWaveBlock
from crossgnn import CrossGNN
from stid_graph import STIDGraph
from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"
print("Device:", device)


class SWPred(nn.Module):
    def __init__(self, nz, nd, h=64, b=2):
        super().__init__()
        self.zone_embed = nn.Embedding(nz, h)
        self.input_proj = nn.Linear(nd, h)
        self.pos_embed = nn.Embedding(48, h)
        self.blocks = nn.ModuleList([STWaveBlock(nz, h) for _ in range(b)])
        self.pred_head = nn.Sequential(nn.Linear(h, h), nn.ReLU(), nn.Linear(h, nd))

    def forward(self, zid, feats):
        B, S, D = feats.shape
        x = self.input_proj(feats)
        pos = torch.arange(S, device=feats.device).unsqueeze(0).expand(B, -1)
        x = (self.zone_embed(zid) + x + self.pos_embed(pos)).unsqueeze(1)
        for blk in self.blocks:
            x = blk(x)
        return self.pred_head(x[:, 0, -1, :])


def collate_pred(batch):
    f, _, _, _, _ = zip(*batch)
    def sd(d):
        return {k: torch.stack([x[k] for x in d]) for k in d[0].keys()}
    return sd(f)


def collate_graph(batch):
    return {
        "zone_ids": torch.stack([b["zone_ids"] for b in batch]),
        "features": torch.stack([b["features"] for b in batch]),
        "targets": torch.stack([b["targets"] for b in batch]),
        "adj": batch[0]["adj"],
    }


def eval_v3(data_dir, nz, ind, outd, ctxc, ckpt, ctx_mode="mean", meta=None):
    ds = GraphCtxCausalDataset(data_dir, "val", 48, ctx_mode=ctx_mode, meta=meta)
    loader = torch.utils.data.DataLoader(ds, batch_size=64, shuffle=False,
                                         collate_fn=collate_pred, num_workers=0)
    model = STWaveCausalV3(n_zones=nz, input_dim=ind, output_dim=outd,
                           ctx_channels=ctxc).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    errs = []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) for k, v in batch.items()}
            _, pred = model(f["zone_ids"], f["features"])
            errs.append((pred - f["targets"]).abs().mean(dim=-1).cpu().numpy())
    return np.concatenate(errs)


def eval_predonly(data_dir, nz, nd, ckpt):
    ds = TrafficCausalDataset(data_dir, "val", 48)
    loader = torch.utils.data.DataLoader(ds, batch_size=64, shuffle=False,
                                         collate_fn=collate_pred, num_workers=0)
    model = SWPred(nz, nd).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    errs = []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) for k, v in batch.items()}
            pred = model(f["zone_ids"], f["features"])
            errs.append((pred - f["targets"]).abs().mean(dim=-1).cpu().numpy())
    return np.concatenate(errs)


def eval_features_only(ModelClass, data_dir, nz, nd, ckpt, **kw):
    ds = TrafficCausalDataset(data_dir, "val", 48)
    loader = torch.utils.data.DataLoader(ds, batch_size=64, shuffle=False,
                                         collate_fn=collate_pred, num_workers=0)
    model = ModelClass(n_zones=nz, input_dim=nd, **kw).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    errs = []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) for k, v in batch.items()}
            pred = model(f["features"])
            errs.append((pred - f["targets"]).abs().mean(dim=-1).cpu().numpy())
    return np.concatenate(errs)


def eval_stidgraph(data_dir, nz, nd, ckpt):
    ds = GraphTrafficDataset(data_dir, "val", 48)
    loader = torch.utils.data.DataLoader(ds, batch_size=64, shuffle=False,
                                         collate_fn=collate_graph, num_workers=0)
    model = STIDGraph(n_zones=nz, input_dim=nd, hidden_dim=64, seq_len=48,
                      n_layers=2, n_days=7).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    errs = []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) if isinstance(v, torch.Tensor) else v
                 for k, v in batch.items()}
            pred = model(f["features"], f["zone_ids"], f["adj"])
            errs.append((pred - f["targets"]).abs().mean(dim=-1).cpu().numpy())
    return np.concatenate(errs)


def main():
    p04 = "data/pems04/processed"
    meta04 = np.load("data/datasets/pems04_staeformer/data.npz")["data"][..., 1:3][:, 0]

    v3 = eval_v3(p04, 307, 4, 1, 1,
                 p04 + "/stwave_causal_v3_graphctx_gate_pems04_best.pt",
                 ctx_mode="mean", meta=meta04)
    baselines = {
        "PredOnly": eval_predonly(p04, 307, 1, p04 + "/stwave_predonly_50ep.pt"),
        "STWave": eval_features_only(STWave, p04, 307, 1, p04 + "/stwave_best.pt",
                                     hidden_dim=64, n_blocks=2, seq_len=48),
        "CrossGNN": eval_features_only(CrossGNN, p04, 307, 1, p04 + "/crossgnn_best.pt",
                                       hidden_dim=64, n_blocks=2, n_heads=4, seq_len=48),
        "STIDGraph": eval_stidgraph(p04, 307, 1, p04 + "/stidgraph-pems04_best.pt"),
    }

    print("\n== PEMS04 (n=%d) ==" % len(v3))
    print("  V3 mean %.4f" % v3.mean())
    for bname, errs in baselines.items():
        if len(errs) != len(v3):
            print("  %s: length mismatch %d vs %d" % (bname, len(errs), len(v3)))
            continue
        stat, p = wilcoxon(v3, errs)
        better = "V3 better" if v3.mean() < errs.mean() else "baseline better"
        stars = "***" if p < 0.001 else ("**" if p < 0.01 else ("*" if p < 0.05 else "ns"))
        print("  %-12s mean=%.4f  V3 vs %s p=%.4g %s %s"
              % (bname, errs.mean(), bname, p, stars, better))


if __name__ == "__main__":
    main()
