"""Train the graph-aware STWaveCausal V3 with the full joint objective."""
import argparse
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from graph_causal_dataset import GraphTrafficCausalDataset, collate_graph_causal
from stwave_causal_graph import GraphSTWaveCausalV3


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/nyc_taxi/processed")
    p.add_argument("--n-zones", type=int, default=265)
    p.add_argument("--feature-dim", type=int, default=6)
    p.add_argument("--epochs", type=int, default=50)
    p.add_argument("--pretrain-epochs", type=int, default=0)
    p.add_argument("--out", default="stwave_causal_v3_graph_nyc_best.pt")
    p.add_argument("--lambda1", type=float, default=0.3)
    p.add_argument("--lambda2", type=float, default=0.01)
    p.add_argument("--lambda3", type=float, default=0.3)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--max-batches", type=int, default=0)
    return p.parse_args()


SEQ = 48


def build_synth_meta(synthetic):
    meta = []
    for d in synthetic["train"]:
        et = d["combo"]["event_types"]
        if et[0] == 1 and et[1] == -1:
            factor = 0.7
        elif et[0] == 2:
            factor = 0.8
        else:
            factor = 0.7 * 0.8
        meta.append({
            "zone": int(d["zone"]),
            "t": int(d["t"]),
            "factor": factor,
            "combo": d["combo"],
        })
    return meta


def make_synth_batch(meta, start, bs, feats, seq, feature_dim, device):
    batch = meta[start:start + bs]
    B = len(batch)
    N = feats.shape[1]
    factual = torch.zeros(B, seq, N, feature_dim)
    cf = torch.zeros(B, seq, N, feature_dim)
    zones = torch.zeros(B, dtype=torch.long)
    ice = torch.zeros(B, feature_dim)
    et = torch.full((B, 5), -1, dtype=torch.long)
    el = torch.zeros(B, 5, 2)
    etm = torch.zeros(B, 5)
    zs = torch.zeros(B, 5, feature_dim)
    for i, d in enumerate(batch):
        z = d["zone"]
        t = d["t"]
        t_start = max(0, t - seq)
        w = feats[t_start:t]
        if len(w) < seq:
            pad = np.zeros((seq - len(w), N, feature_dim), dtype=w.dtype)
            w = np.concatenate([pad, w], axis=0)
        factual[i] = torch.FloatTensor(w)
        c = w.copy()
        c[:, z, :min(4, feature_dim)] *= d["factor"]
        cf[i] = torch.FloatTensor(c)
        zones[i] = z
        ice[i] = torch.FloatTensor(
            np.abs(feats[t, z] - feats[t, z] * d["factor"]))
        et[i] = d["combo"]["event_types"]
        el[i] = d["combo"]["event_locs"]
        etm[i] = d["combo"]["event_times"]
        zs[i] = d["combo"]["zone_states"]
    return {
        "features": factual.to(device),
        "cf_features": cf.to(device),
        "zone_ids": zones.to(device),
        "ice_true": ice.to(device),
        "event_types": et.to(device),
        "event_locs": el.to(device),
        "event_times": etm.to(device),
        "zone_states": zs.to(device),
    }


def train_epoch(model, opt, loader, synth_meta, feats, adj, args, device, epoch):
    model.train()
    totals = {"loss": 0.0, "pred": 0.0, "cs": 0.0, "cm": 0.0,
              "div": 0.0, "causal": 0.0}
    n = 0
    full = epoch >= args.pretrain_epochs
    for i, batch in enumerate(loader):
        factual, cf_single, cf_multi, combo, zones = batch
        factual = {k: v.to(device) for k, v in factual.items()}
        cf_single = {k: v.to(device) for k, v in cf_single.items()}
        cf_multi = {k: v.to(device) for k, v in cf_multi.items()}
        combo = {k: v.to(device) for k, v in combo.items()}
        zones = zones.to(device)

        if not full:
            _, pred = model(factual["features"], adj, zones)
            L_pred = F.mse_loss(pred, factual["targets"])
            loss = L_pred
            L_cs = L_cm = L_div = L_causal = torch.zeros((), device=device)
        else:
            _, pred = model(factual["features"], adj, zones)
            L_pred = F.mse_loss(pred, factual["targets"])
            cl = model.contrastive_loss(
                factual, cf_single, cf_multi, combo, adj, zones)
            L_cs = cl["L_con_single"]
            L_cm = cl["L_con_multi"]
            L_div = cl["L_div"]
            s_i = (i * args.batch_size) % len(synth_meta)
            sb = make_synth_batch(
                synth_meta, s_i, args.batch_size, feats, SEQ,
                args.feature_dim, device)
            ice_est = model.causal_effect(
                {"features": sb["features"]},
                {"features": sb["cf_features"]},
                {"event_types": sb["event_types"],
                 "event_locs": sb["event_locs"],
                 "event_times": sb["event_times"],
                 "zone_states": sb["zone_states"]},
                adj, sb["zone_ids"])
            L_causal = F.mse_loss(ice_est, sb["ice_true"])
            loss = (L_pred + args.lambda1 * (L_cs + L_cm)
                    + args.lambda2 * L_div + args.lambda3 * L_causal)

        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        bs = factual["targets"].shape[0]
        totals["loss"] += loss.item() * bs
        totals["pred"] += L_pred.item() * bs
        totals["cs"] += L_cs.item() * bs
        totals["cm"] += L_cm.item() * bs
        totals["div"] += L_div.item() * bs
        totals["causal"] += L_causal.item() * bs
        n += bs
        if args.max_batches and i + 1 >= args.max_batches:
            break
    return {k: v / max(1, n) for k, v in totals.items()}


@torch.no_grad()
def evaluate_real(model, loader, adj, device):
    model.eval()
    tot, n = 0.0, 0
    for batch in loader:
        factual, _, _, _, zones = batch
        factual = {k: v.to(device) for k, v in factual.items()}
        zones = zones.to(device)
        _, pred = model(factual["features"], adj, zones)
        tot += F.l1_loss(pred, factual["targets"], reduction="sum").item()
        n += pred.shape[0]
    return tot / n


@torch.no_grad()
def evaluate_synth(model, meta, feats, adj, args, device, batch_size=64):
    model.eval()
    ests, trues = [], []
    for i in range(0, len(meta), batch_size):
        sb = make_synth_batch(meta, i, batch_size, feats, SEQ,
                              args.feature_dim, device)
        ice_est = model.causal_effect(
            {"features": sb["features"]},
            {"features": sb["cf_features"]},
            {"event_types": sb["event_types"],
             "event_locs": sb["event_locs"],
             "event_times": sb["event_times"],
             "zone_states": sb["zone_states"]},
            adj, sb["zone_ids"])
        ests.append(ice_est[:, 0].cpu().numpy())
        trues.append(sb["ice_true"][:, 0].cpu().numpy())
    est = np.concatenate(ests)
    true = np.concatenate(trues)
    corr = np.corrcoef(est, true)[0, 1]
    ratio = np.median(est / (true + 1e-6))
    mae = np.abs(est - true).mean()
    return corr, float(ratio), float(mae)


def main():
    args = parse_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Device:", device, flush=True)
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    td = GraphTrafficCausalDataset(args.data, "train", SEQ)
    vd = GraphTrafficCausalDataset(args.data, "val", SEQ)
    adj = torch.FloatTensor(td.adj).to(device)
    tl = torch.utils.data.DataLoader(
        td, batch_size=args.batch_size, shuffle=True,
        collate_fn=collate_graph_causal, num_workers=0)
    vl = torch.utils.data.DataLoader(
        vd, batch_size=args.batch_size, shuffle=False,
        collate_fn=collate_graph_causal, num_workers=0)

    synth = np.load(str(Path(args.data) / "synthetic_pairs_v3.npy"),
                    allow_pickle=True).item()
    synth_meta = build_synth_meta(synth)
    synth_val = build_synth_meta({"train": synth["val"]})
    synth_test = build_synth_meta({"train": synth["test"]})
    feats = td.features

    model = GraphSTWaveCausalV3(
        n_zones=args.n_zones, input_dim=args.feature_dim).to(device)
    print("Params:", sum(p.numel() for p in model.parameters()), flush=True)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=args.epochs)
    best_mae = float("inf")
    best_state = None
    save_path = Path(args.data) / args.out

    for ep in range(args.epochs):
        t0 = time.time()
        m = train_epoch(model, opt, tl, synth_meta, feats, adj,
                        args, device, ep)
        sched.step()
        val_mae = evaluate_real(model, vl, adj, device)
        c, r, me = evaluate_synth(model, synth_val, feats, adj, args, device)
        if (ep + 1) % 5 == 0 or ep == 0:
            stage = "PRED" if ep < args.pretrain_epochs else "FULL"
            print("Ep %2d/%d [%s] loss=%.3f pred=%.3f cs=%.3f cm=%.3f "
                  "div=%.3f causal=%.3f valMAE=%.3f synCorr=%.4f "
                  "synRatio=%.3f synMAE=%.3f (%.1fs)" %
                  (ep + 1, args.epochs, stage, m["loss"], m["pred"],
                   m["cs"], m["cm"], m["div"], m["causal"], val_mae,
                   c, r, me, time.time() - t0), flush=True)
        if val_mae < best_mae:
            best_mae = val_mae
            best_state = {k: v.cpu() for k, v in model.state_dict().items()}
            torch.save(best_state, str(save_path))
            print("  * best val MAE %.4f saved" % best_mae, flush=True)

    print("Best val MAE:", best_mae, flush=True)
    if best_state is not None:
        model.load_state_dict(best_state)
    c, r, me = evaluate_synth(model, synth_test, feats, adj, args, device)
    print("FINAL synthetic test: corr=%.4f ratio=%.3f mae=%.3f" %
          (c, r, me), flush=True)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
