"""Build synthetic multi-event pairs on full-node windows (for STIDCausal)."""
import argparse
import os
import sys
from pathlib import Path

import numpy as np
import torch

os.chdir("F:/xuexi/codex/papers")


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/pems04/processed")
    p.add_argument("--n-zones", type=int, default=307)
    p.add_argument("--feature-dim", type=int, default=1)
    p.add_argument("--active-threshold", type=float, default=10.0)
    p.add_argument("--n-samples", type=int, default=20000)
    p.add_argument("--out", default="synthetic_pairs_fullnode.npy")
    return p.parse_args()


SEQ = 48
MAX_EVENTS = 5


def main():
    args = parse_args()
    data_dir = Path(args.data)
    feats = np.load(str(data_dir / "node_features.npy")).astype(np.float32)
    labels = np.load(str(data_dir / "labels.npy"))
    D = args.feature_dim
    N = args.n_zones
    print("Features:", feats.shape, flush=True)

    active = [z for z in range(N)
              if feats[:, z, 0].mean() > args.active_threshold
              and (feats[:, z, 0] == 0).mean() < 0.3]
    print("Active zones:", len(active), flush=True)

    candidates = []
    for z in active:
        cnt = 0
        for t in range(SEQ + 5, feats.shape[0] - 1):
            if labels[t, z] == 0:
                candidates.append((z, t))
                cnt += 1
                if cnt > 500:
                    break
    print("Candidate windows:", len(candidates), flush=True)

    def window(t):
        t_start = max(0, t - SEQ)
        w = feats[t_start:t]
        if len(w) < SEQ:
            pad = np.zeros((SEQ - len(w), N, D), dtype=w.dtype)
            w = np.concatenate([pad, w], axis=0)
        return w

    rng = np.random.RandomState(42)
    samples = []
    for _ in range(args.n_samples):
        z, t = candidates[rng.randint(len(candidates))]
        w = window(t)
        y_f = feats[t, z, 0]
        mode = rng.rand()
        if mode < 0.7:
            factor = 0.7
            et = torch.full((MAX_EVENTS,), -1, dtype=torch.long)
            et[0] = 1
            n_events = 1
        elif mode < 0.9:
            factor = 0.8
            et = torch.full((MAX_EVENTS,), -1, dtype=torch.long)
            et[0] = 2
            n_events = 1
        else:
            factor = 0.7 * 0.8
            et = torch.full((MAX_EVENTS,), -1, dtype=torch.long)
            et[0] = 1
            et[1] = 2
            n_events = 2

        modified = w.copy()
        modified[:, z, :min(4, D)] *= factor
        ice_true = np.abs(y_f - y_f * factor).astype(np.float32)

        combo = {
            "event_types": et,
            "event_locs": torch.zeros(MAX_EVENTS, 2),
            "event_times": torch.zeros(MAX_EVENTS),
            "zone_states": torch.zeros(MAX_EVENTS, D),
        }
        for i in range(n_events):
            combo["event_times"][i] = float(t)
            combo["zone_states"][i, 0] = float(feats[t, z, 0])

        samples.append({
            "zone": z,
            "t": t,
            "factual": torch.FloatTensor(w),
            "cf": torch.FloatTensor(modified),
            "ice_true": torch.tensor(ice_true, dtype=torch.float32),
            "combo": combo,
        })

    rng.shuffle(samples)
    n = len(samples)
    n_train = int(n * 0.8)
    n_val = int(n * 0.1)
    out = {
        "train": samples[:n_train],
        "val": samples[n_train:n_train + n_val],
        "test": samples[n_train + n_val:],
    }
    save = data_dir / args.out
    np.save(str(save), out, allow_pickle=True)
    print("Saved", save,
          "train/val/test =", len(out["train"]), len(out["val"]),
          len(out["test"]), flush=True)


if __name__ == "__main__":
    main()
