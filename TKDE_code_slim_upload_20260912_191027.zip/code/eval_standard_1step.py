"""Evaluate existing standard 60/20/20 single-step checkpoints.

This is an evaluation-only companion to train_standard_1step.py. It loads the
checkpoints produced under the same protocol and recomputes test RMSE/MAE/MAPE
for all available methods without retraining.
"""
import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.abspath("."))
sys.path.insert(0, "src/model")

from train_standard_1step import load_1step, build_model, mae_rmse_mape


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", choices=["pems08", "pems04"], required=True)
    p.add_argument("--seq-len", type=int, default=12)
    p.add_argument("--max-windows", type=int, default=4000)
    p.add_argument("--hidden", type=int, default=64)
    p.add_argument(
        "--models",
        default="v3,stwave,predonly,stidgraph,crossgnn",
    )
    p.add_argument("--out", default=None)
    p.add_argument("--save-dir", default="data/%s/processed")
    return p.parse_args()


def forward_model(name, model, xb, adj_t):
    if name == "stidgraph":
        return model(xb, adj_t).permute(0, 2, 1, 3)
    return model(xb).permute(0, 2, 1, 3)


def main():
    args = parse_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Device:", device, flush=True)
    torch.backends.cudnn.benchmark = True

    data_dir = "data/datasets/%s_staeformer" % args.dataset
    (x_train, y_train), (x_val, y_val), (x_test, y_test), scaler = load_1step(
        data_dir, args.seq_len, args.max_windows)
    n_zones = x_train.shape[2]
    adj = np.load("data/%s/processed/adj.npy" % args.dataset).astype(np.float32)
    adj_t = torch.FloatTensor(
        adj / np.maximum(adj.sum(axis=1, keepdims=True), 1e-6)).to(device)

    loader = torch.utils.data.DataLoader(
        torch.utils.data.TensorDataset(x_test, y_test),
        batch_size=64,
        shuffle=False,
    )

    results = {}
    for name in [m.strip() for m in args.models.split(",")]:
        ckpt = Path(args.save_dir % args.dataset) / (
            "stand1step_%s_best.pt" % name)
        if not ckpt.exists():
            print("Missing checkpoint", ckpt, flush=True)
            continue
        model = build_model(name, n_zones, args.seq_len, args.hidden,
                            adj, device)
        model.load_state_dict(torch.load(str(ckpt), map_location=device))
        model.eval()
        ys, ps = [], []
        with torch.no_grad():
            for xb, yb in loader:
                xb, yb = xb.to(device), yb.to(device)
                pred = forward_model(name, model, xb, adj_t).squeeze(1)
                ys.append(yb.cpu().numpy())
                ps.append(scaler.inverse_transform(pred).cpu().numpy())
        y_true = np.concatenate(ys).reshape(-1, n_zones)
        y_pred = np.concatenate(ps).reshape(-1, n_zones)
        rmse, mae, mape = mae_rmse_mape(y_true, y_pred)
        results[name] = {"rmse": rmse, "mae": mae, "mape": mape}
        print("%s RMSE=%.4f MAE=%.4f MAPE=%.4f" % (name, rmse, mae, mape),
              flush=True)
        del model
        torch.cuda.empty_cache()

    out_path = args.out or ("standard_1step_%s.json" % args.dataset)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(
            {
                "dataset": args.dataset,
                "protocol": "standard 60/20/20, lookback=%d, horizon=1" %
                args.seq_len,
                "results": results,
            },
            f,
            indent=2,
        )
    print("Wrote", out_path, flush=True)


if __name__ == "__main__":
    main()
