"""PEMS04 V3 5-seed stats, ensemble, recovery, and paired tests."""
import os
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from scipy.stats import wilcoxon

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from graphctx_dataset import GraphCtxCausalDataset
from graph_dataset import GraphTrafficDataset
from stid_graph import STIDGraph
from stwave_causal_v3 import STWaveCausalV3

DATA = "data/pems04/processed"
META = np.load("data/datasets/pems04_staeformer/data.npz")["data"][..., 1:3][:, 0]
device = "cuda" if torch.cuda.is_available() else "cpu"

V3_CKPTS = [
    DATA + "/stwave_causal_v3_graphctx_gate_pems04_best.pt",
    DATA + "/stwave_causal_v3_graphctx_gate_pems04_seed1.pt",
    DATA + "/stwave_causal_v3_graphctx_gate_pems04_seed2.pt",
    DATA + "/stwave_causal_v3_graphctx_gate_pems04_seed3.pt",
    DATA + "/stwave_causal_v3_graphctx_gate_pems04_seed4.pt",
]
STID_CKPTS = [
    DATA + "/stidgraph-pems04_best.pt",
    DATA + "/stidgraph-pems04_seed1_best.pt",
    DATA + "/stidgraph-pems04_seed2_best.pt",
    DATA + "/stidgraph-pems04_seed3_best.pt",
    DATA + "/stidgraph-pems04_seed4_best.pt",
]


def collate_pred(batch):
    f, _, _, _, _ = zip(*batch)
    def sd(d):
        return {k: torch.stack([x[k] for x in d]) for k in d[0].keys()}
    return sd(f)


def collate_graph(batch):
    return {
        "zone_ids": torch.stack([b["zone_ids"] for b in batch]),
        "features": torch.stack([b["features"] for b in batch]),
        "targets": torch.stack([b["targets"] for b in batch]),
        "adj": batch[0]["adj"],
    }


def v3_preds(ckpt):
    ds = GraphCtxCausalDataset(DATA, "val", 48, ctx_mode="mean", meta=META)
    loader = torch.utils.data.DataLoader(ds, batch_size=64, shuffle=False,
                                         collate_fn=collate_pred)
    model = STWaveCausalV3(n_zones=307, input_dim=4, output_dim=1,
                           ctx_channels=1).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    preds, tgts = [], []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) for k, v in batch.items()}
            _, pred = model(f["zone_ids"], f["features"])
            preds.append(pred.cpu().numpy())
            tgts.append(f["targets"].cpu().numpy())
    return np.concatenate(preds, axis=0), np.concatenate(tgts, axis=0)


def stid_preds(ckpt):
    ds = GraphTrafficDataset(DATA, "val", 48)
    loader = torch.utils.data.DataLoader(ds, batch_size=64, shuffle=False,
                                         collate_fn=collate_graph)
    model = STIDGraph(n_zones=307, input_dim=1, hidden_dim=64, seq_len=48,
                      n_layers=2, n_days=7).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    preds, tgts = [], []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) if isinstance(v, torch.Tensor) else v
                 for k, v in batch.items()}
            pred = model(f["features"], f["zone_ids"], f["adj"])
            preds.append(pred.cpu().numpy())
            tgts.append(f["targets"].cpu().numpy())
    return np.concatenate(preds, axis=0), np.concatenate(tgts, axis=0)


def synth_batch(samples, start, size, feature_dim=4, output_dim=1):
    batch = samples[start:start + size]
    zones = torch.zeros(len(batch), 48, dtype=torch.long)
    ff = torch.zeros(len(batch), 48, feature_dim)
    cf = torch.zeros(len(batch), 48, feature_dim)
    ice = torch.zeros(len(batch), output_dim)
    et = torch.full((len(batch), 5), -1, dtype=torch.long)
    el = torch.zeros(len(batch), 5, 2)
    etm = torch.zeros(len(batch), 5)
    zs = torch.zeros(len(batch), 5, feature_dim)
    for i, d in enumerate(batch):
        zones[i] = d["zone"]
        ff[i] = d["factual"]
        cf[i] = d["cf"]
        ice[i] = d["ice_true"]
        c = d["combo"]
        et[i] = c["event_types"]
        el[i] = c["event_locs"]
        etm[i] = c["event_times"]
        zs[i] = c["zone_states"]
    return {"zones": zones.to(device), "ff": ff.to(device), "cf": cf.to(device),
            "ice": ice.to(device), "et": et.to(device), "el": el.to(device),
            "etm": etm.to(device), "zs": zs.to(device)}


def v3_recovery(ckpt, samples):
    model = STWaveCausalV3(n_zones=307, input_dim=4, output_dim=1,
                           ctx_channels=1).to(device)
    model.load_state_dict(torch.load(ckpt, map_location=device))
    model.eval()
    ests, trues = [], []
    with torch.no_grad():
        for i in range(0, len(samples), 64):
            b = synth_batch(samples, i, 64)
            combo = {"event_types": b["et"], "event_locs": b["el"],
                     "event_times": b["etm"], "zone_states": b["zs"]}
            e = model.causal_effect(
                {"zone_ids": b["zones"], "features": b["ff"]},
                {"zone_ids": b["zones"], "features": b["cf"]}, combo)
            ests.append(e[:, 0].cpu().numpy())
            trues.append(b["ice"][:, 0].cpu().numpy())
    est = np.concatenate(ests)
    true = np.concatenate(trues)
    corr = np.corrcoef(est, true)[0, 1]
    ratio = float(np.median(est / (true + 1e-6)))
    mae = float(np.abs(est - true).mean())
    return corr, ratio, mae


def report(name, maes, ens_mae):
    a = np.array(maes)
    print("%s per-seed: %s" % (name, ["%.3f" % x for x in maes]))
    print("%s mean %.3f std %.3f best %.3f" %
          (name, a.mean(), a.std(), a.min()))
    print("%s ensemble MAE: %.4f" % (name, ens_mae))


def main():
    print("Device:", device)
    v3_out = [v3_preds(p) for p in V3_CKPTS]
    stid_out = [stid_preds(p) for p in STID_CKPTS]
    v3_all = [x[0] for x in v3_out]
    stid_all = [x[0] for x in stid_out]
    v3_tgt = v3_out[0][1]
    stid_tgt = stid_out[0][1]

    v3_mae = [float(np.abs(p - v3_tgt).mean()) for p in v3_all]
    stid_mae = [float(np.abs(p - stid_tgt).mean()) for p in stid_all]
    v3_ens = np.mean(v3_all, axis=0)
    stid_ens = np.mean(stid_all, axis=0)
    report("V3", v3_mae, float(np.abs(v3_ens - v3_tgt).mean()))
    report("STIDGraph", stid_mae, float(np.abs(stid_ens - stid_tgt).mean()))

    best3 = np.argmin(v3_mae)
    bests = np.argmin(stid_mae)
    for label, e3, es in [
        ("best", np.abs(v3_all[best3] - v3_tgt)[:, 0],
         np.abs(stid_all[bests] - stid_tgt)[:, 0]),
        ("ensemble", np.abs(v3_ens - v3_tgt)[:, 0],
         np.abs(stid_ens - stid_tgt)[:, 0]),
    ]:
        _, p = wilcoxon(e3, es)
        better = "V3" if e3.mean() < es.mean() else "STIDGraph"
        print("Wilcoxon V3-%s vs STIDGraph-%s p=%.4g (%s better, %.3f vs %.3f)"
              % (label, label, p, better, e3.mean(), es.mean()))

    syn = np.load(str(Path(DATA) / "synthetic_pairs_v3_graphctx.npy"),
                  allow_pickle=True).item()
    c, r, m = v3_recovery(V3_CKPTS[best3], syn["test"])
    print("V3 best recovery: corr=%.4f ratio=%.3f mae=%.3f" % (c, r, m))
    print("ALL DONE")


if __name__ == "__main__":
    main()
