﻿import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class TemporalConvBlock(nn.Module):
    """Temporal convolution with gating applied per node."""
    def __init__(self, hidden_dim=64, kernel_size=3):
        super().__init__()
        self.conv = nn.Conv2d(hidden_dim, hidden_dim * 2, (1, kernel_size),
                              padding=(0, kernel_size // 2))
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, x):
        # x: (B, N, T, H)
        B, N, T, H = x.shape
        x_perm = x.permute(0, 3, 1, 2)  # (B, H, N, T)
        gated = self.conv(x_perm)
        a, b = gated.chunk(2, dim=1)
        h = a * torch.sigmoid(b)         # (B, H, N, T)
        h = h.permute(0, 2, 3, 1)        # (B, N, T, H)
        return self.norm(h + x)


class GCNLayer(nn.Module):
    """Graph convolution layer over nodes using a precomputed adjacency."""
    def __init__(self, hidden_dim=64):
        super().__init__()
        self.linear = nn.Linear(hidden_dim, hidden_dim)
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, x, adj):
        # x: (B, N, T, H), adj: (N, N)
        B, N, T, H = x.shape
        # Graph conv per time step.
        x_g = torch.einsum('bnti,nj->bjti', x, adj)  # (B, N, T, H)
        out = self.linear(x_g)
        return self.norm(out + x)


class STIDGraph(nn.Module):
    """Graph-aware STID baseline.

    Uses the observed full-node sequence, temporal gated conv, graph convolution
    over the precomputed adjacency, and spatial/temporal identity embeddings.
    Closer to the original STID idea while enabling true spatial aggregation.
    """
    def __init__(self, n_zones=265, input_dim=6, hidden_dim=64, seq_len=48,
                 n_layers=2, n_days=7):
        super().__init__()
        self.n_zones = n_zones
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.seq_len = seq_len
        self.n_layers = n_layers
        self.n_days = n_days

        self.spatial_embed = nn.Embedding(n_zones, hidden_dim)
        self.temporal_embed = nn.Embedding(seq_len + 1, hidden_dim)
        self.week_embed = nn.Embedding(n_days, hidden_dim)

        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.tcn = nn.ModuleList([TemporalConvBlock(hidden_dim) for _ in range(n_layers)])
        self.gcn = nn.ModuleList([GCNLayer(hidden_dim) for _ in range(n_layers)])

        self.mlp = nn.Sequential(
            nn.Linear(hidden_dim * 5, hidden_dim * 2),
            nn.ReLU(),
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim),
        )

    def forward(self, features, zone_ids, adj):
        """features: (B, T, N, D), zone_ids: (B,), adj: (N,N)."""
        B, T, N, D = features.shape
        device = features.device

        x = self.input_proj(features)   # (B, T, N, H)
        x = x.permute(0, 2, 1, 3)       # (B, N, T, H)
        for tcn, gcn in zip(self.tcn, self.gcn):
            x = tcn(x)                  # (B, N, T, H)
            x = gcn(x, adj)             # (B, N, T, H)

        # Focus on target zone.
        if zone_ids.dim() == 2:
            zone_ids = zone_ids[:, -1]
        target = x[torch.arange(B, device=device), zone_ids]   # (B, T, H)

        spatial = self.spatial_embed(zone_ids)                     # (B, H)
        tod = self.temporal_embed(torch.full((B,), self.seq_len, dtype=torch.long, device=device))
        weekly = self.week_embed(torch.zeros(B, dtype=torch.long, device=device))

        h_last = target[:, -1, :]
        h_mean = target.mean(dim=1)
        pooled = torch.stack([h_last, h_mean], dim=1).reshape(B, -1)  # (B, 2H)

        inp = torch.cat([spatial, tod, weekly, pooled], dim=-1)  # (B, 4H)
        pred = self.mlp(inp)
        return pred

