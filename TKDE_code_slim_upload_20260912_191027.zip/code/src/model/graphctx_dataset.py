"""Per-zone causal dataset with graph-context input channels.

Each sample's features are concatenated with a precomputed neighbor-aggregated
context (adjacency-weighted average of neighbor features). This gives the
per-zone V3 model spatial context at the original training cost.
"""
import numpy as np
import torch
from torch.utils.data import Dataset
from pathlib import Path


class GraphCtxCausalDataset(Dataset):
    def __init__(self, data_dir="data/nyc_taxi/processed", split="train",
                 seq_len=48, ctx_mode="mean", meta=None):
        self.data_dir = Path(data_dir)
        self.seq_len = seq_len
        self.ctx_mode = ctx_mode
        self.meta = meta  # optional (T, M) time features
        self.meta_dim = 0 if meta is None else meta.shape[1]
        print("Loading graph-context dataset...")
        self.features = np.load(str(self.data_dir / "node_features.npy"))
        self.labels = np.load(str(self.data_dir / "labels.npy"))
        self.matches = np.load(str(self.data_dir / "matched_pairs.npy"),
                               allow_pickle=True)
        adj = np.load(str(self.data_dir / "adj.npy")).astype(np.float32)
        self.adj = adj / np.maximum(adj.sum(axis=1, keepdims=True), 1e-6)
        self.T, self.N, self.D = self.features.shape
        print("  Features: (%d, %d, %d)" % (self.T, self.N, self.D))
        print("  Matches: %d pairs" % len(self.matches))

        self.samples = []
        for m in self.matches.tolist():
            if isinstance(m, dict):
                self.samples.append({
                    "zone": m["zone"],
                    "t_factual": m["t"],
                    "t_counter": m["t_star"],
                    "is_multi": False,
                })
        multi_windows = []
        for t in range(self.T):
            int_zones = np.where(self.labels[t] == 1)[0]
            if len(int_zones) > 1:
                multi_windows.append((t, int_zones))
        for t, zones in multi_windows[:len(self.matches)]:
            self.samples.append({
                "zone": int(zones[0]),
                "t_factual": t,
                "t_counter": None,
                "is_multi": True,
                "multi_zones": [int(z) for z in zones],
            })
        np.random.seed(42)
        n = len(self.samples)
        idx = np.random.permutation(n)
        n_train = int(n * 0.8)
        n_val = int(n * 0.1)
        if split == "train":
            self.samples = [self.samples[i] for i in idx[:n_train]]
        elif split == "val":
            self.samples = [self.samples[i] for i in idx[n_train:n_train + n_val]]
        else:
            self.samples = [self.samples[i] for i in idx[n_train + n_val:]]
        print("  Split '%s': %d samples" % (split, len(self.samples)))

    def __len__(self):
        return len(self.samples)

    def _aug_window(self, t, zone):
        t_start = max(0, t - self.seq_len)
        w_all = self.features[t_start:t]
        if len(w_all) < self.seq_len:
            pad = np.zeros((self.seq_len - len(w_all), self.N, self.D),
                           dtype=w_all.dtype)
            w_all = np.concatenate([pad, w_all], axis=0)
        raw = w_all[:, zone]                                      # (S, D)
        ctx = np.einsum("snd,n->sd", w_all, self.adj[zone])       # (S, D)
        if self.ctx_mode == "gradient":
            ctx = ctx - raw
        parts = [raw, ctx]
        if self.meta is not None:
            m = self.meta[t_start:t]
            if len(m) < self.seq_len:
                m = np.concatenate(
                    [np.zeros((self.seq_len - len(m), m.shape[1]),
                              dtype=m.dtype), m], axis=0)
            parts.append(m)
        return np.concatenate(parts, axis=-1).astype(np.float32)

    def _state_ctx(self, t, zone):
        raw = self.features[t, zone]
        ctx = np.einsum("nd,n->d", self.features[t], self.adj[zone])
        if self.ctx_mode == "gradient":
            ctx = ctx - raw
        parts = [raw, ctx]
        if self.meta is not None:
            parts.append(self.meta[t])
        return np.concatenate(parts).astype(np.float32)

    def __getitem__(self, idx):
        s = self.samples[idx]
        zone = int(s["zone"])
        t = int(s["t_factual"])
        factual = {
            "zone_ids": torch.full((self.seq_len,), zone, dtype=torch.long),
            "features": torch.FloatTensor(self._aug_window(t, zone)),
            "targets": torch.FloatTensor(self.features[t, zone]),
        }
        t_c = s["t_counter"]
        cf_features = (self._aug_window(t, zone) if t_c is None
                       else self._aug_window(int(t_c), zone))
        cf_single = {
            "zone_ids": torch.full((self.seq_len,), zone, dtype=torch.long),
            "features": torch.FloatTensor(cf_features),
        }
        cf_multi = {
            "zone_ids": torch.full((self.seq_len,), zone, dtype=torch.long),
            "features": torch.FloatTensor(cf_features),
        }
        max_events = 5
        event_types = torch.full((max_events,), -1, dtype=torch.long)
        event_locs = torch.zeros(max_events, 2)
        event_times = torch.zeros(max_events)
        zone_states = torch.zeros(max_events, self.D * 2 + self.meta_dim)
        if s.get("is_multi") and "multi_zones" in s:
            for i, z in enumerate(s["multi_zones"][:max_events]):
                event_types[i] = 1
                event_times[i] = float(t)
                zone_states[i] = torch.FloatTensor(self._state_ctx(t, int(z)))
        combo = {
            "event_types": event_types,
            "event_locs": event_locs,
            "event_times": event_times,
            "zone_states": zone_states,
        }
        label = torch.tensor(zone, dtype=torch.long)
        return factual, cf_single, cf_multi, combo, label
