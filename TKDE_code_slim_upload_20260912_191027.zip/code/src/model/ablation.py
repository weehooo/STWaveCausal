
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
from pathlib import Path
from src.model.causal_structure import CausalStructureLearner


# ============================================================
# Ablation A: No CausalStructure (mean pooling instead)
# ============================================================
class TrafficCausal_NoCausalStruct(nn.Module):
    def __init__(self, n_zones=265, input_dim=6, hidden_dim=64, n_layers=5):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.zone_embed = nn.Embedding(n_zones, hidden_dim)
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.tconvs = nn.ModuleList()
        self.skips = nn.ModuleList()
        for i in range(n_layers):
            d = 2**i
            self.tconvs.append(nn.Conv1d(hidden_dim, hidden_dim, 3, padding=d, dilation=d))
            self.skips.append(nn.Linear(hidden_dim, hidden_dim))
        self.pred_head = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.ReLU(), nn.Linear(hidden_dim, input_dim))
        self.logit_scale = nn.Parameter(torch.ones([]) * np.log(1 / 0.07))

    def _temporal_forward(self, features):
        B, S, D = features.shape
        x = self.input_proj(features).permute(0, 2, 1)
        skip_out = 0
        for conv, sk in zip(self.tconvs, self.skips):
            res = x
            x = F.gelu(conv(x))
            if x.shape[-1] == res.shape[-1]:
                x = x + res[:, :, -x.shape[-1]:]
            skip_out = skip_out + sk(x.permute(0, 2, 1))
        return torch.relu(skip_out)

    def forward(self, zone_ids, features, return_emb=True):
        h = self._temporal_forward(features)
        h = h + self.zone_embed(zone_ids)
        pred = self.pred_head(h[:, -1, :])
        if return_emb: return h, pred
        return pred

    def compute_loss(self, factual, cf_single, cf_multi, combo_data, labels_zone):
        h_f, pred_f = self.forward(factual['zone_ids'], factual['features'], return_emb=True)
        L_pred = F.mse_loss(pred_f, factual['targets'])
        h_cs, _ = self.forward(cf_single['zone_ids'], cf_single['features'], return_emb=True)
        E = h_f[:, -1, :].detach() if combo_data.get('intervention_emb') is None else combo_data['intervention_emb']
        logits = self.logit_scale.exp() * torch.matmul(E, h_f[:, -1, :].T)
        labels = torch.arange(logits.shape[0], device=logits.device)
        L_cs = F.cross_entropy(logits, labels)
        # Mean pooling for multi-event
        zs = combo_data['zone_states']
        vm = (combo_data['event_types'] >= 0).float().unsqueeze(-1)
        se = self.input_proj(zs)
        ce = (se * vm).sum(dim=1) / (vm.sum(dim=1) + 1e-8)
        logits_m = self.logit_scale.exp() * torch.matmul(ce, h_f[:, -1, :].T)
        L_cm = F.cross_entropy(logits_m, labels)
        L_div = torch.clamp(F.mse_loss(F.normalize(h_f[:, -1, :], dim=-1), F.normalize(h_cs[:, -1, :], dim=-1)) - 0.3, min=0.0)
        loss = 1.0*L_pred + 0.5*L_cs + 0.5*L_cm + 0.1*L_div
        return loss, {'loss':loss.item(),'L_pred':L_pred.item(),'L_cs':L_cs.item(),'L_cm':L_cm.item(),'L_div':L_div.item()}


# ============================================================
# Ablation B: No MultiEvent
# ============================================================
class TrafficCausal_NoMultiEvent(nn.Module):
    def __init__(self, n_zones=265, input_dim=6, hidden_dim=64, n_layers=5):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.zone_embed = nn.Embedding(n_zones, hidden_dim)
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.tconvs = nn.ModuleList()
        self.skips = nn.ModuleList()
        for i in range(n_layers):
            d = 2**i
            self.tconvs.append(nn.Conv1d(hidden_dim, hidden_dim, 3, padding=d, dilation=d))
            self.skips.append(nn.Linear(hidden_dim, hidden_dim))
        self.pred_head = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.ReLU(), nn.Linear(hidden_dim, input_dim))
        self.causal_learner = CausalStructureLearner(event_type_dim=16, hidden_dim=hidden_dim, device='cpu')
        self.logit_scale = nn.Parameter(torch.ones([]) * np.log(1 / 0.07))

    def _temporal_forward(self, features):
        B, S, D = features.shape
        x = self.input_proj(features).permute(0, 2, 1)
        skip_out = 0
        for conv, sk in zip(self.tconvs, self.skips):
            res = x
            x = F.gelu(conv(x))
            if x.shape[-1] == res.shape[-1]:
                x = x + res[:, :, -x.shape[-1]:]
            skip_out = skip_out + sk(x.permute(0, 2, 1))
        return torch.relu(skip_out)

    def forward(self, zone_ids, features, return_emb=True):
        h = self._temporal_forward(features)
        h = h + self.zone_embed(zone_ids)
        pred = self.pred_head(h[:, -1, :])
        if return_emb: return h, pred
        return pred

    def compute_loss(self, factual, cf_single, cf_multi, combo_data, labels_zone):
        h_f, pred_f = self.forward(factual['zone_ids'], factual['features'], return_emb=True)
        L_pred = F.mse_loss(pred_f, factual['targets'])
        h_cs, _ = self.forward(cf_single['zone_ids'], cf_single['features'], return_emb=True)
        E = h_f[:, -1, :].detach() if combo_data.get('intervention_emb') is None else combo_data['intervention_emb']
        logits = self.logit_scale.exp() * torch.matmul(E, h_f[:, -1, :].T)
        labels = torch.arange(logits.shape[0], device=logits.device)
        L_cs = F.cross_entropy(logits, labels)
        # No multi-event loss
        L_div = torch.clamp(F.mse_loss(F.normalize(h_f[:, -1, :], dim=-1), F.normalize(h_cs[:, -1, :], dim=-1)) - 0.3, min=0.0)
        loss = 1.0*L_pred + 0.5*L_cs + 0.1*L_div
        return loss, {'loss':loss.item(),'L_pred':L_pred.item(),'L_cs':L_cs.item(),'L_cm':0.0,'L_div':L_div.item()}


# ============================================================
# Ablation C: No DivReg
# ============================================================
class TrafficCausal_NoDivReg(nn.Module):
    def __init__(self, n_zones=265, input_dim=6, hidden_dim=64, n_layers=5):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.zone_embed = nn.Embedding(n_zones, hidden_dim)
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.tconvs = nn.ModuleList()
        self.skips = nn.ModuleList()
        for i in range(n_layers):
            d = 2**i
            self.tconvs.append(nn.Conv1d(hidden_dim, hidden_dim, 3, padding=d, dilation=d))
            self.skips.append(nn.Linear(hidden_dim, hidden_dim))
        self.pred_head = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.ReLU(), nn.Linear(hidden_dim, input_dim))
        self.causal_learner = CausalStructureLearner(event_type_dim=16, hidden_dim=hidden_dim, device='cpu')
        self.logit_scale = nn.Parameter(torch.ones([]) * np.log(1 / 0.07))

    def _temporal_forward(self, features):
        B, S, D = features.shape
        x = self.input_proj(features).permute(0, 2, 1)
        skip_out = 0
        for conv, sk in zip(self.tconvs, self.skips):
            res = x
            x = F.gelu(conv(x))
            if x.shape[-1] == res.shape[-1]:
                x = x + res[:, :, -x.shape[-1]:]
            skip_out = skip_out + sk(x.permute(0, 2, 1))
        return torch.relu(skip_out)

    def forward(self, zone_ids, features, return_emb=True):
        h = self._temporal_forward(features)
        h = h + self.zone_embed(zone_ids)
        pred = self.pred_head(h[:, -1, :])
        if return_emb: return h, pred
        return pred

    def compute_loss(self, factual, cf_single, cf_multi, combo_data, labels_zone):
        h_f, pred_f = self.forward(factual['zone_ids'], factual['features'], return_emb=True)
        L_pred = F.mse_loss(pred_f, factual['targets'])
        h_cs, _ = self.forward(cf_single['zone_ids'], cf_single['features'], return_emb=True)
        E = h_f[:, -1, :].detach() if combo_data.get('intervention_emb') is None else combo_data['intervention_emb']
        logits = self.logit_scale.exp() * torch.matmul(E, h_f[:, -1, :].T)
        labels = torch.arange(logits.shape[0], device=logits.device)
        L_cs = F.cross_entropy(logits, labels)
        # Multi-event with causal learner
        h_cm, _ = self.forward(cf_multi['zone_ids'], cf_multi['features'], return_emb=True)
        ce, _, _ = self.causal_learner(combo_data['event_types'], combo_data['event_locs'], combo_data['event_times'], combo_data['zone_states'])
        logits_m = self.logit_scale.exp() * torch.matmul(ce, h_f[:, -1, :].T)
        L_cm = F.cross_entropy(logits_m, labels)
        # No L_div
        loss = 1.0*L_pred + 0.5*L_cs + 0.5*L_cm
        return loss, {'loss':loss.item(),'L_pred':L_pred.item(),'L_cs':L_cs.item(),'L_cm':L_cm.item(),'L_div':0.0}


# ============================================================
# Ablation D: PredOnly (no causal losses)
# ============================================================
class TrafficCausal_PredOnly(nn.Module):
    def __init__(self, n_zones=265, input_dim=6, hidden_dim=64, n_layers=5):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.zone_embed = nn.Embedding(n_zones, hidden_dim)
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.tconvs = nn.ModuleList()
        self.skips = nn.ModuleList()
        for i in range(n_layers):
            d = 2**i
            self.tconvs.append(nn.Conv1d(hidden_dim, hidden_dim, 3, padding=d, dilation=d))
            self.skips.append(nn.Linear(hidden_dim, hidden_dim))
        self.pred_head = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.ReLU(), nn.Linear(hidden_dim, input_dim))

    def forward(self, zone_ids, features):
        B, S, D = features.shape
        x = self.input_proj(features).permute(0, 2, 1)
        skip_out = 0
        for conv, sk in zip(self.tconvs, self.skips):
            res = x
            x = F.gelu(conv(x))
            if x.shape[-1] == res.shape[-1]:
                x = x + res[:, :, -x.shape[-1]:]
            skip_out = skip_out + sk(x.permute(0, 2, 1))
        h = torch.relu(skip_out)
        h = h + self.zone_embed(zone_ids)
        return self.pred_head(h[:, -1, :])


# ============================================================
# Training
# ============================================================
from src.model.dataset import TrafficCausalDataset

def collate_fn(batch):
    factual, cf_single, cf_multi, combo, labels = zip(*batch)
    def sd(d):
        return {k: torch.stack([x[k] for x in d]) for k in d[0].keys()}
    return (sd(factual), sd(cf_single), sd(cf_multi),
            {k: torch.stack([c[k] for c in combo]) for k in combo[0].keys()},
            torch.stack(labels))


def train_abl(ModelClass, data_dir, device, epochs, name, has_causal=True, save_path=None):
    print("\\n[Ablation {}] Training...".format(name))
    train_ds = TrafficCausalDataset(data_dir, 'train', 48)
    val_ds = TrafficCausalDataset(data_dir, 'val', 48)
    tl = torch.utils.data.DataLoader(train_ds, batch_size=32, shuffle=True, collate_fn=collate_fn)
    vl = torch.utils.data.DataLoader(val_ds, batch_size=32, shuffle=False, collate_fn=collate_fn)
    model = ModelClass().to(device)
    print('  Params:', sum(p.numel() for p in model.parameters()))
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    best = float('inf')
    best_state = None
    for ep in range(epochs):
        model.train()
        tr_loss = 0.0
        for batch in tl:
            factual, cf_single, cf_multi, combo, labels = batch
            factual = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in factual.items()}
            cf_single = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in cf_single.items()}
            cf_multi = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in cf_multi.items()}
            combo = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in combo.items()}
            labels = labels.to(device)
            if has_causal:
                loss, _ = model.compute_loss(factual, cf_single, cf_multi, combo, labels)
            else:
                pred = model(factual['zone_ids'], factual['features'])
                loss = F.mse_loss(pred, factual['targets'])
            opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); opt.step()
            tr_loss += loss.item()
        sched.step()
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for batch in vl:
                factual, cf_single, cf_multi, combo, labels = batch
                factual = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in factual.items()}
                cf_single = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in cf_single.items()}
                cf_multi = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in cf_multi.items()}
                combo = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in combo.items()}
                labels = labels.to(device)
                if has_causal:
                    loss, _ = model.compute_loss(factual, cf_single, cf_multi, combo, labels)
                else:
                    pred = model(factual['zone_ids'], factual['features'])
                    loss = F.mse_loss(pred, factual['targets'])
                val_loss += loss.item()
        tr_loss /= len(tl); val_loss /= len(vl)
        if (ep+1) % 5 == 0 or ep == 0:
            print('  Ep {}/{}: tr={:.4f} val={:.4f}'.format(ep+1, epochs, tr_loss, val_loss))
        if val_loss < best:
            best = val_loss
            best_state = {k: v.cpu() for k, v in model.state_dict().items()}
    print('  [{}] Best val loss: {:.4f}'.format(name, best))
    if best_state is not None and save_path:
        torch.save(best_state, save_path)
        print('  Saved to', save_path)
    return best


if __name__ == '__main__':
    data_dir = 'data/nyc_taxi/processed'
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print('Device:', device)
    print('=' * 60)
    r = {}
    r['TrafficCausal (Full)'] = 27.66
    print("\\n[TrafficCausal (Full)] Reference: 27.66")
    v = train_abl(TrafficCausal_NoCausalStruct, data_dir, device, 30, 'No CausalStructure', save_path=str(Path(data_dir) / 'abl_nocs.pt'))
    r['No CausalStructure'] = v
    v = train_abl(TrafficCausal_NoMultiEvent, data_dir, device, 30, 'No MultiEvent', save_path=str(Path(data_dir) / 'abl_nome.pt'))
    r['No MultiEvent'] = v
    v = train_abl(TrafficCausal_NoDivReg, data_dir, device, 30, 'No DivReg', save_path=str(Path(data_dir) / 'abl_nodr.pt'))
    r['No DivReg'] = v
    v = train_abl(TrafficCausal_PredOnly, data_dir, device, 30, 'PredOnly', has_causal=False, save_path=str(Path(data_dir) / 'abl_predonly.pt'))
    r['PredOnly'] = v
    print('\\n' + '=' * 60)
    print('Ablation Summary')
    print('=' * 60)
    for k, v in sorted(r.items(), key=lambda x: x[1]):
        print('  {:30s}: val_loss={:.4f}'.format(k, v))
