import numpy as np
import torch
import argparse
import time
from pathlib import Path
from dataset import TrafficCausalDataset
from traffic_causal_model import TrafficTransformer, TrafficCausalPipeline

def collate_fn(batch):
    factual, cf_single, cf_multi, combo, labels = zip(*batch)
    def sd(d):
        return {k: torch.stack([x[k] for x in d]) for k in d[0].keys()}
    return (sd(factual), sd(cf_single), sd(cf_multi),
            {k: torch.stack([c[k] for c in combo]) for k in combo[0].keys()},
            torch.stack(labels))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="data/nyc_taxi/processed")
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=0.001)
    parser.add_argument("--seq-len", type=int, default=48)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    print("Device:", args.device)
    train_ds = TrafficCausalDataset(args.data_dir, "train", args.seq_len)
    val_ds = TrafficCausalDataset(args.data_dir, "val", args.seq_len)
    train_loader = torch.utils.data.DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, collate_fn=collate_fn)
    val_loader = torch.utils.data.DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, collate_fn=collate_fn)
    model = TrafficTransformer(n_zones=265, input_dim=6, hidden_dim=64, n_layers=2, n_heads=4, max_seq_len=args.seq_len)
    pipeline = TrafficCausalPipeline(model, args.lr, args.device)
    print("Params:", sum(p.numel() for p in model.parameters()))
    best_loss, pc = float("inf"), 0
    for epoch in range(args.epochs):
        t0 = time.time()
        train_loss, m = pipeline.train_epoch(train_loader)
        val_loss = pipeline.evaluate(val_loader)
        dt = time.time() - t0
        lpred = m.get("L_pred", 0)
        lcs = m.get("L_con_single", 0)
        lcm = m.get("L_con_multi", 0)
        ld = m.get("L_div", 0)
        print("Ep %d/%d | tr=%.4f val=%.4f | Lp=%.4f Lcs=%.4f Lcm=%.4f Ld=%.4f | %.1fs" 
              % (epoch+1, args.epochs, train_loss, val_loss, lpred, lcs, lcm, ld, dt))
        if val_loss < best_loss:
            best_loss = val_loss
            pc = 0
            torch.save(model.state_dict(), str(Path(args.data_dir) / "model_best.pt"))
            print("  ^ saved")
        else:
            pc += 1
            if pc >= 10:
                print("Early stop")
                break
    print("Best val:", best_loss)

if __name__ == "__main__":
    main()
