﻿import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class STID(nn.Module):
    """Spatial-Temporal Identity model for traffic prediction.

    Simplified implementation inspired by STID (AAAI 2023).
    Uses separate spatial identity, time-of-day/day-of-week identity embeddings
    combined with the observed feature sequence, then maps through an MLP.
    """
    def __init__(self, n_zones=265, input_dim=6, hidden_dim=64, seq_len=48,
                 n_days=7):
        super().__init__()
        self.n_zones = n_zones
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.seq_len = seq_len
        self.n_days = n_days

        self.spatial_embed = nn.Embedding(n_zones, hidden_dim)
        self.temporal_embed = nn.Embedding(seq_len + 1, hidden_dim)
        self.week_embed = nn.Embedding(n_days, hidden_dim)

        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.temporal_conv = nn.Conv1d(hidden_dim, hidden_dim * 2, kernel_size=3,
                                       padding=1)
        self.norm = nn.LayerNorm(hidden_dim)

        self.mlp = nn.Sequential(
            nn.Linear(hidden_dim * 5, hidden_dim * 2),
            nn.ReLU(),
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim),
        )

    def forward(self, zone_ids, features):
        """Forward prediction.

        zone_ids: (B,) or (B, T) zone index tensor
        features: (B, T, D) observed feature sequence
        """
        B, T, D = features.shape
        device = features.device

        if zone_ids.dim() == 2:
            zone_ids = zone_ids[:, -1]

        spatial = self.spatial_embed(zone_ids)      # (B, H)
        weekly = self.week_embed(torch.zeros(B, dtype=torch.long, device=device))
        tod = self.temporal_embed(torch.full((B,), self.seq_len, dtype=torch.long, device=device))

        x = self.input_proj(features)              # (B, T, H)
        x = x.transpose(1, 2)                      # (B, H, T)
        gated = self.temporal_conv(x)              # (B, 2H, T)
        a, b = gated.chunk(2, dim=1)
        h_seq = a * torch.sigmoid(b)               # (B, H, T)

        h_last = h_seq[:, :, -1]                   # (B, H)
        h_mean = h_seq.mean(dim=2)                 # (B, H)
        pooled = torch.stack([h_last, h_mean], dim=1)  # (B, 2, H)
        pooled = self.norm(pooled).reshape(B, -1)  # (B, 2H)

        inp = torch.cat([spatial, tod, weekly, pooled], dim=-1)  # (B, 5H)
        pred = self.mlp(inp)
        return pred
