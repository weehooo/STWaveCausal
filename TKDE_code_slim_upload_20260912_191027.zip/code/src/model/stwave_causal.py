# -*- coding: utf-8 -*-
"""
STWaveCausal: STWave backbone + CausalStructureLearner + contrastive losses.

Architecture:
- Backbone: STWave's wavelet decomposition + temporal/spatial gating
- Causal: CausalStructureLearner for multi-event interaction modeling
- Loss: L_pred + L_con_single + L_con_multi + L_div (same as TrafficCausal)

Key difference from TrafficCausal (Transformer):
- Transformer backbone -> STWave backbone (wavelet + temporal gate + spatial gate)
- STWave is the strongest baseline across all three datasets
"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from pathlib import Path
from src.model.causal_structure import CausalStructureLearner
from src.model.stwave import WaveletTransform, TemporalGate, SpatialGate


class STWaveCausalBlock(nn.Module):
    """STWave block adapted for per-zone processing."""
    def __init__(self, hidden_dim=64):
        super().__init__()
        self.wavelet = WaveletTransform(hidden_dim)
        self.temp_gate_low = TemporalGate(hidden_dim)
        self.temp_gate_high = TemporalGate(hidden_dim)
        self.fusion = nn.Linear(hidden_dim * 2, hidden_dim)
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, x):
        """x: (B, N, T, C) batch, zones=1, time, channels"""
        B, N, T, C = x.shape
        x_flat = x.reshape(B * N, C, T)
        low, high = self.wavelet(x_flat)
        low = F.interpolate(low, size=T, mode="linear", align_corners=False)
        high = F.interpolate(high, size=T, mode="linear", align_corners=False)
        low_gated = self.temp_gate_low(low)
        high_gated = self.temp_gate_high(high)
        fused = self.fusion(torch.cat([low_gated, high_gated], dim=1).transpose(1, 2))
        fused = fused.reshape(B, N, T, C)
        return self.norm(x + fused)


class STWaveCausal(nn.Module):
    """
    STWaveCausal: Wavelet-based spatio-temporal backbone + causal learning.
    """
    def __init__(self, n_zones=265, input_dim=6, hidden_dim=64, n_blocks=2, seq_len=48):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.input_dim = input_dim
        self.n_zones = n_zones

        # Zone embedding
        self.zone_embed = nn.Embedding(n_zones, hidden_dim)
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.pos_embed = nn.Embedding(seq_len, hidden_dim)

        # STWave blocks
        self.blocks = nn.ModuleList([
            STWaveCausalBlock(hidden_dim) for _ in range(n_blocks)
        ])

        # Prediction head
        self.pred_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim),
        )

        # Causal structure learner
        self.causal_learner = CausalStructureLearner(
            event_type_dim=16, hidden_dim=hidden_dim, device="cpu", state_dim=input_dim)

        # Contrastive temperature
        self.logit_scale = nn.Parameter(torch.ones([]) * np.log(1 / 0.07))

    def forward(self, zone_ids, features, return_emb=True):
        """
        Args:
            zone_ids: (batch, seq_len) long, zone IDs
            features: (batch, seq_len, input_dim) node features
            return_emb: if True, return full embeddings
        Returns:
            h: (batch, seq_len, hidden_dim) embeddings
            pred: (batch, input_dim) next-step prediction
        """
        B, S, D = features.shape

        # Embeddings
        z_emb = self.zone_embed(zone_ids)
        f_emb = self.input_proj(features)
        positions = torch.arange(S, device=features.device).unsqueeze(0).expand(B, -1)
        p_emb = self.pos_embed(positions)

        x = z_emb + f_emb + p_emb  # (B, S, C)

        # Reshape to (B, N=1, T, C) for STWave blocks
        x = x.unsqueeze(1)  # (B, 1, S, C)

        # STWave blocks
        for block in self.blocks:
            x = block(x)

        h = x[:, 0, :, :]  # (B, S, C)

        # Predict
        pred = self.pred_head(h[:, -1, :])

        return h, pred

    def compute_loss(self, factual, cf_single, cf_multi, combo_data, labels_zone):
        """Joint loss: L_pred + L_con_single + L_con_multi + L_div."""
        B = factual["features"].shape[0]

        # Sub-stage 1: Standard prediction
        h_factual, pred_factual = self.forward(
            factual["zone_ids"], factual["features"], return_emb=True)
        L_pred = F.mse_loss(pred_factual, factual["targets"])

        # Sub-stage 2: Single-event contrastive
        h_counter_single, _ = self.forward(
            cf_single["zone_ids"], cf_single["features"], return_emb=True)

        if combo_data.get("intervention_emb") is not None:
            E_intervention = combo_data["intervention_emb"]
        else:
            E_intervention = h_factual[:, -1, :].detach()

        logits = self.logit_scale.exp() * torch.matmul(
            E_intervention, h_factual[:, -1, :].T)
        labels = torch.arange(logits.shape[0], device=logits.device)
        L_con_single = F.cross_entropy(logits, labels)

        # Sub-stage 3: Multi-event joint contrastive
        h_counter_multi, _ = self.forward(
            cf_multi["zone_ids"], cf_multi["features"], return_emb=True)

        combo_emb, _, _ = self.causal_learner(
            combo_data["event_types"], combo_data["event_locs"],
            combo_data["event_times"], combo_data["zone_states"])
        combo_emb_last = combo_emb  # (B, C)

        # Normalize
        h_fn = F.normalize(h_factual[:, -1, :], dim=-1)
        h_csn = F.normalize(h_counter_single[:, -1, :], dim=-1)
        h_cmn = F.normalize(h_counter_multi[:, -1, :], dim=-1)
        cn = F.normalize(combo_emb_last, dim=-1)

        pos_sim = (cn * h_fn).sum(dim=-1)
        neg_sim_s = (cn * h_csn).sum(dim=-1)
        neg_sim_m = (cn * h_cmn).sum(dim=-1)

        logits_multi = torch.stack([pos_sim, neg_sim_s, neg_sim_m], dim=-1)
        L_con_multi = F.cross_entropy(
            logits_multi / 0.07,
            torch.zeros(B, dtype=torch.long, device=logits_multi.device))

        # Sub-stage 4: Diversity regularization
        margin = 0.3
        L_div = F.relu(margin - torch.norm(
            h_factual[:, -1, :] - h_counter_multi[:, -1, :], dim=-1)).mean()

        # Joint loss
        loss = 1.0 * L_pred + 0.5 * (L_con_single + L_con_multi) + 0.1 * L_div

        return loss, {
            "loss": loss.item(),
            "L_pred": L_pred.item(),
            "L_con_single": L_con_single.item(),
            "L_con_multi": L_con_multi.item(),
            "L_div": L_div.item(),
        }


def collate_fn(batch):
    factual, cf_single, cf_multi, combo, labels = zip(*batch)
    def sd(d):
        return {k: torch.stack([x[k] for x in d]) for k in d[0].keys()}
    return (sd(factual), sd(cf_single), sd(cf_multi),
            {k: torch.stack([c[k] for c in combo]) for k in combo[0].keys()},
            torch.stack(labels))


def train_stwave_causal(data_dir, device, epochs=50, n_zones=265, input_dim=6):
    """Train the STWaveCausal model."""
    print("\n[STWaveCausal] Training...")
    from src.model.dataset import TrafficCausalDataset

    train_ds = TrafficCausalDataset(data_dir, "train", 48)
    val_ds = TrafficCausalDataset(data_dir, "val", 48)

    train_loader = torch.utils.data.DataLoader(
        train_ds, batch_size=32, shuffle=True, collate_fn=collate_fn)
    val_loader = torch.utils.data.DataLoader(
        val_ds, batch_size=32, shuffle=False, collate_fn=collate_fn)

    model = STWaveCausal(n_zones=n_zones, input_dim=input_dim,
                         hidden_dim=64, n_blocks=2, seq_len=48).to(device)
    n_params = sum(p.numel() for p in model.parameters())
    print("  Params:", n_params)

    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    best_loss = float("inf")
    best_state = None

    for epoch in range(epochs):
        model.train()
        train_loss = 0.0
        metrics = {}

        for batch in train_loader:
            factual, cf_single, cf_multi, combo, labels = batch
            factual = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in factual.items()}
            cf_single = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in cf_single.items()}
            cf_multi = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in cf_multi.items()}
            combo = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in combo.items()}
            labels = labels.to(device)

            loss, loss_dict = model.compute_loss(factual, cf_single, cf_multi, combo, labels)

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

            train_loss += loss.item()
            for k, v in loss_dict.items():
                metrics[k] = metrics.get(k, 0) + v

        scheduler.step()

        # Validation
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for batch in val_loader:
                factual, cf_single, cf_multi, combo, labels = batch
                factual = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in factual.items()}
                cf_single = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in cf_single.items()}
                cf_multi = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in cf_multi.items()}
                combo = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in combo.items()}
                labels = labels.to(device)

                loss, _ = model.compute_loss(factual, cf_single, cf_multi, combo, labels)
                val_loss += loss.item()

        train_loss /= len(train_loader)
        val_loss /= len(val_loader)
        for k in metrics:
            metrics[k] /= len(train_loader)

        if (epoch + 1) % 5 == 0 or epoch == 0:
            lp = metrics.get("L_pred", 0)
            lcs = metrics.get("L_con_single", 0)
            lcm = metrics.get("L_con_multi", 0)
            ld = metrics.get("L_div", 0)
            print("  Ep %d/%d: tr=%.4f val=%.4f | Lp=%.4f Lcs=%.4f Lcm=%.4f Ld=%.4f" % (
                epoch + 1, epochs, train_loss, val_loss, lp, lcs, lcm, ld))

        if val_loss < best_loss:
            best_loss = val_loss
            best_state = {k: v.cpu() for k, v in model.state_dict().items()}
            print("    * best so far (%.4f)" % best_loss)

    print("  [STWaveCausal] Best val loss: %.4f" % best_loss)
    if best_state is not None:
        save_path = Path(data_dir) / "stwave_causal_best.pt"
        torch.save(best_state, str(save_path))
        print("  Saved to", save_path)

    return best_loss


if __name__ == "__main__":
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Device:", device)
    
    for ds_name, data_dir, n_zones, input_dim in [
        ("NYC Taxi", "data/nyc_taxi/processed", 265, 6),
        ("METR-LA", "data/metr_la/processed", 207, 8),
        ("PEMS-BAY", "data/pems_bay/processed", 325, 8),
    ]:
        print("\n" + "#" * 60)
        print("#", ds_name)
        print("#" * 60)
        best_val = train_stwave_causal(data_dir, device, epochs=50,
                                       n_zones=n_zones, input_dim=input_dim)
    
    print("\nALL DONE")
