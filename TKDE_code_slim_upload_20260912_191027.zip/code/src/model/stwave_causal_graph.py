"""Graph-aware STWaveCausal V3.

Adds precomputed-adjacency graph convolution to the V3 backbone so the model
can spatially aggregate like STIDGraph while keeping the causal head,
contrastive objective, and multi-event structure learner.
"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from pathlib import Path

from stwave import STWaveBlock
from stid_graph import GCNLayer
from causal_structure import CausalStructureLearner


class GraphSTWaveBackbone(nn.Module):
    def __init__(self, n_zones=265, input_dim=6, hidden_dim=64, n_blocks=2,
                 seq_len=48):
        super().__init__()
        self.n_zones = n_zones
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.pos_embed = nn.Embedding(seq_len, hidden_dim)
        self.blocks = nn.ModuleList(
            [STWaveBlock(n_zones, hidden_dim) for _ in range(n_blocks)])
        self.gcn = GCNLayer(hidden_dim)
        self.pred_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim),
        )

    def forward(self, features, adj):
        """features: (B, T, N, D), adj: (N, N) -> h (B,N,C), pred (B,N,D)."""
        B, T, N, D = features.shape
        x = self.input_proj(features)
        pos = torch.arange(T, device=features.device)
        x = x + self.pos_embed(pos).view(1, T, 1, -1)
        x = x.permute(0, 2, 1, 3)                      # (B,N,T,C)
        for block in self.blocks:
            x = block(x)
        x = self.gcn(x, adj)                           # graph aggregation
        h = x[:, :, -1, :]                             # (B,N,C)
        pred = self.pred_head(h)                       # (B,N,D)
        return h, pred


class GraphCausalEffectHead(nn.Module):
    def __init__(self, hidden_dim=64, input_dim=6, n_events=5):
        super().__init__()
        self.head = nn.Sequential(
            nn.Linear(hidden_dim * 3, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim),
            nn.Softplus(),
        )

    def forward(self, h_f, h_cf, combo_emb):
        x = torch.cat([h_f, h_cf, combo_emb], dim=-1)
        return self.head(x)


class GraphSTWaveCausalV3(nn.Module):
    def __init__(self, n_zones=265, input_dim=6, hidden_dim=64, n_blocks=2,
                 seq_len=48, n_events=5):
        super().__init__()
        self.n_zones = n_zones
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.backbone = GraphSTWaveBackbone(
            n_zones, input_dim, hidden_dim, n_blocks, seq_len)
        self.causal_learner = CausalStructureLearner(
            event_type_dim=16, hidden_dim=hidden_dim, device="cpu",
            state_dim=input_dim)
        self.causal_head = GraphCausalEffectHead(hidden_dim, input_dim, n_events)
        self.logit_scale = nn.Parameter(torch.ones([]) * np.log(1 / 0.07))

    def encode(self, features, adj):
        return self.backbone(features, adj)[0]

    def forward(self, features, adj, zone_ids):
        h, pred_all = self.backbone(features, adj)
        idx = torch.arange(features.shape[0], device=features.device)
        pred = pred_all[idx, zone_ids]
        h_target = h[idx, zone_ids]
        return h_target, pred

    def causal_effect(self, factual, cf_single, combo_data, adj, zone_ids):
        h_f = self.encode(factual["features"], adj)
        h_cf = self.encode(cf_single["features"], adj)
        combo_emb, _, _ = self.causal_learner(
            combo_data["event_types"], combo_data["event_locs"],
            combo_data["event_times"], combo_data["zone_states"])
        ice_all = self.causal_head(h_f, h_cf, combo_emb)
        idx = torch.arange(
            factual["features"].shape[0], device=factual["features"].device)
        return ice_all[idx, zone_ids]

    def contrastive_loss(self, factual, cf_single, cf_multi, combo_data,
                         adj, zone_ids):
        B = factual["features"].shape[0]
        dev = factual["features"].device
        h_f = self.encode(factual["features"], adj)
        h_cs = self.encode(cf_single["features"], adj)
        h_cm = self.encode(cf_multi["features"], adj)
        idx = torch.arange(B, device=dev)
        hf = h_f[idx, zone_ids]
        hcs = h_cs[idx, zone_ids]
        hcm = h_cm[idx, zone_ids]
        hf_n = F.normalize(hf, dim=-1)
        logits = self.logit_scale.exp() * torch.matmul(hf_n.detach(), hf_n.T)
        L_con_single = F.cross_entropy(
            logits, torch.arange(B, device=dev))
        combo_emb, _, _ = self.causal_learner(
            combo_data["event_types"], combo_data["event_locs"],
            combo_data["event_times"], combo_data["zone_states"])
        cn = F.normalize(combo_emb, dim=-1)
        pos_sim = (cn * hf_n).sum(dim=-1)
        neg_sim_s = (cn * F.normalize(hcs, dim=-1)).sum(dim=-1)
        neg_sim_m = (cn * F.normalize(hcm, dim=-1)).sum(dim=-1)
        logits_m = torch.stack([pos_sim, neg_sim_s, neg_sim_m], dim=-1)
        L_con_multi = F.cross_entropy(
            logits_m / 0.07, torch.zeros(B, dtype=torch.long, device=dev))
        L_div = torch.norm(hf - hcm, dim=-1).mean()
        return {
            "L_con_single": L_con_single,
            "L_con_multi": L_con_multi,
            "L_div": L_div,
        }
