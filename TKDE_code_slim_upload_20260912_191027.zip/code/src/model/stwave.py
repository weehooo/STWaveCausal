
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import math

class WaveletTransform(nn.Module):
    """Learnable 1D wavelet decomposition using DWT."""
    def __init__(self, hidden_dim=64):
        super().__init__()
        # Low-pass and high-pass filters (Haar wavelet approximation)
        self.register_buffer('lo_a', torch.tensor([0.5, 0.5]).view(1, 1, -1))  # low
        self.register_buffer('hi_a', torch.tensor([0.5, -0.5]).view(1, 1, -1)) # high
        self.low_proj = nn.Linear(hidden_dim, hidden_dim)
        self.high_proj = nn.Linear(hidden_dim, hidden_dim)
        
    def forward(self, x):
        """x: (B, C, T) input signal"""
        # Wavelet decomposition
        low = F.conv1d(x, self.lo_a.expand(x.size(1), -1, -1), groups=x.size(1), padding=1)
        high = F.conv1d(x, self.hi_a.expand(x.size(1), -1, -1), groups=x.size(1), padding=1)
        # Downsample
        low = low[:, :, ::2]
        high = high[:, :, ::2]
        # Project
        low = self.low_proj(low.transpose(1, 2)).transpose(1, 2)
        high = self.high_proj(high.transpose(1, 2)).transpose(1, 2)
        return low, high


class TemporalGate(nn.Module):
    """Temporal gating mechanism for STWave."""
    def __init__(self, hidden_dim=64, kernel_size=3):
        super().__init__()
        self.conv = nn.Conv1d(hidden_dim, hidden_dim * 2, kernel_size, padding=kernel_size//2)
        self.sigmoid = nn.Sigmoid()
        
    def forward(self, x):
        """x: (B, C, T)"""
        gates = self.conv(x)
        gated = gates.chunk(2, dim=1)
        return gated[0] * self.sigmoid(gated[1])


class SpatialGate(nn.Module):
    """Spatial gating mechanism using graph structure."""
    def __init__(self, n_zones=265, hidden_dim=64):
        super().__init__()
        self.n_zones = n_zones
        # Learnable spatial adjacency
        self.spatial_weight = nn.Parameter(torch.randn(n_zones, n_zones) * 0.1)
        self.node_proj = nn.Linear(hidden_dim, hidden_dim)
        self.gate_proj = nn.Linear(hidden_dim, hidden_dim)
        self.sigmoid = nn.Sigmoid()
        
    def forward(self, x):
        """x: (B, N, T, C) batch, zones, time, channels"""
        B, N, T, C = x.shape
        # Spatial aggregation
        adj = F.softmax(self.spatial_weight, dim=1)  # (N, N)
        x_t = x.permute(0, 2, 1, 3)  # (B, T, N, C)
        # Graph convolution
        x_conv = torch.einsum('btnc,nm->btmc', x_t, adj)  # (B, T, N, C)
        x_conv = x_conv.permute(0, 2, 1, 3)  # (B, N, T, C)
        # Gate
        gate = self.sigmoid(self.gate_proj(x))
        return gate * self.node_proj(x_conv) + (1 - gate) * x


class STWaveBlock(nn.Module):
    """STWave building block: Wavelet + Temporal Gate + Spatial Gate."""
    def __init__(self, n_zones=265, hidden_dim=64):
        super().__init__()
        self.wavelet = WaveletTransform(hidden_dim)
        self.temp_gate_low = TemporalGate(hidden_dim)
        self.temp_gate_high = TemporalGate(hidden_dim)
        self.spatial_gate = SpatialGate(n_zones, hidden_dim)
        self.fusion = nn.Linear(hidden_dim * 2, hidden_dim)
        self.norm1 = nn.LayerNorm(hidden_dim)
        self.norm2 = nn.LayerNorm(hidden_dim)
        
    def forward(self, x):
        """x: (B, N, T, C)"""
        B, N, T, C = x.shape
        # Reshape for 1D conv: (B*N, C, T)
        x_flat = x.reshape(B * N, C, T)
        
        # Wavelet decomposition
        low, high = self.wavelet(x_flat)  # both: (B*N, C, T/2)
        
        # Upsample to original length
        low = F.interpolate(low, size=T, mode='linear', align_corners=False)
        high = F.interpolate(high, size=T, mode='linear', align_corners=False)
        
        # Temporal gates
        low_gated = self.temp_gate_low(low)
        high_gated = self.temp_gate_high(high)
        
        # Fusion
        fused = self.fusion(torch.cat([low_gated, high_gated], dim=1).transpose(1, 2))
        fused = fused.reshape(B, N, T, C)
        
        # Residual + norm
        x = x + fused
        x = self.norm1(x)
        
        # Spatial gate
        x_spatial = self.spatial_gate(x)
        x = x + x_spatial
        x = self.norm2(x)
        
        return x


class STWave(nn.Module):
    """
    STWave: When Spatio-Temporal Meet Wavelets (AAAI 2023).
    
    Simplified implementation for traffic flow prediction.
    Key ideas:
    - Wavelet decomposition to separate trend (low-freq) and detail (high-freq)
    - Temporal gate to model time dependencies per frequency
    - Spatial gate for spatial aggregation
    """
    def __init__(self, n_zones=265, input_dim=6, hidden_dim=64, n_blocks=2, seq_len=48):
        super().__init__()
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.pos_embed = nn.Embedding(seq_len, hidden_dim)
        
        self.blocks = nn.ModuleList([
            STWaveBlock(n_zones, hidden_dim) for _ in range(n_blocks)
        ])
        
        self.pred_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim),
        )
        
    def forward(self, features):
        """
        Args:
            features: (batch, seq_len, input_dim)  [NOTE: same interface as baselines]
                      internally we treat each batch as one zone
        Returns:
            pred: (batch, input_dim) next-step prediction
        """
        B, S, D = features.shape
        
        # Project to hidden dim
        x = self.input_proj(features)  # (B, S, C)
        
        # Add position encoding
        pos = torch.arange(S, device=features.device).unsqueeze(0).expand(B, -1)
        p_emb = self.pos_embed(pos)
        x = x + p_emb
        
        # Reshape to (B, N=1, T, C) for STWave blocks
        x = x.unsqueeze(1)  # (B, 1, S, C)
        
        # STWave blocks
        for block in self.blocks:
            x = block(x)
        
        # Predict next step from last time
        pred = self.pred_head(x[:, 0, -1, :])
        
        return pred
