﻿import numpy as np
import torch
from torch.utils.data import Dataset
from pathlib import Path


class GraphTrafficDataset(Dataset):
    """Dataset for graph-aware baselines.

    Unlike TrafficCausalDataset, each sample returns the full node feature
    history for a look-back window, plus the target zone id and target values.
    This lets graph baselines perform genuine spatial aggregation over the
    precomputed adjacency matrix.
    """
    def __init__(self, data_dir="data/nyc_taxi/processed", split="train",
                 seq_len=48, device='cpu'):
        self.data_dir = Path(data_dir)
        self.seq_len = seq_len
        self.device = device

        print("Loading graph dataset...")
        self.features = np.load(str(self.data_dir / "node_features.npy"))
        self.labels = np.load(str(self.data_dir / "labels.npy"))
        self.matches = np.load(str(self.data_dir / "matched_pairs.npy"),
                               allow_pickle=True)
        self.adj = np.load(str(self.data_dir / "adj.npy"))

        self.T, self.N, self.D = self.features.shape
        print("  Features: (%d, %d, %d)" % (self.T, self.N, self.D))
        print("  Adj: %s, matches: %d" % (str(self.adj.shape), len(self.matches)))

        # Same sample construction and split as TrafficCausalDataset.
        self.samples = []
        for m in self.matches.tolist():
            if isinstance(m, dict):
                self.samples.append({
                    'zone': int(m['zone']),
                    't': int(m['t']),
                    't_counter': int(m.get('t_star', m['t'])),
                })
        multi_windows = []
        for t in range(self.T):
            int_zones = np.where(self.labels[t] == 1)[0]
            if len(int_zones) > 1:
                multi_windows.append((t, int_zones))
        for t, zones in multi_windows[:len(self.matches)]:
            self.samples.append({
                'zone': int(zones[0]),
                't': t,
                't_counter': t,
            })

        np.random.seed(42)
        n = len(self.samples)
        idx = np.random.permutation(n)
        n_train = int(n * 0.8)
        n_val = int(n * 0.1)
        if split == 'train':
            self.samples = [self.samples[i] for i in idx[:n_train]]
        elif split == 'val':
            self.samples = [self.samples[i] for i in idx[n_train:n_train + n_val]]
        else:
            self.samples = [self.samples[i] for i in idx[n_train + n_val:]]
        print("  Split '%s': %d samples" % (split, len(self.samples)))

    def __len__(self):
        return len(self.samples)

    def _full_window(self, t):
        t_start = max(0, t - self.seq_len)
        w = self.features[t_start:t]  # (S', N, D)
        pad_len = self.seq_len - len(w)
        if pad_len > 0:
            pad = np.zeros((pad_len, self.N, self.D), dtype=w.dtype)
            w = np.concatenate([pad, w], axis=0)
        return w

    def __getitem__(self, idx):
        s = self.samples[idx]
        zone = s['zone']
        t = s['t']
        features_all = self._full_window(t)          # (seq_len, N, D)
        targets = torch.FloatTensor(self.features[t, zone])  # (D,)
        zone_ids = torch.tensor(zone, dtype=torch.long)
        adj = torch.FloatTensor(self.adj)            # (N, N)
        return {
            'zone_ids': zone_ids,
            'features': torch.FloatTensor(features_all),  # (seq_len, N, D)
            'targets': targets,
            'adj': adj,
        }
