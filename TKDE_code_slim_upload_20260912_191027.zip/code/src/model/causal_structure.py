import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class CausalStructureLearner(nn.Module):
    """
    Algorithm 3 (upgraded): Causal Structure Learning for intervention combos.
    
    For a set of K events happening in the same time window:
    1. Compute partial correlations to infer undirected graph skeleton
    2. Orient edges using temporal order + intervention heuristics
    3. Encode each event with parent/child message passing
    
    Outputs:
        - adj_matrix: KxK directed adjacency matrix (DAG)
        - combo_embedding: aggregated embedding for all events in the combo
        - event_embeddings: per-event embeddings with causal context
    """
    
    def __init__(self, event_type_dim=16, location_dim=16, hidden_dim=64, 
                 corr_threshold=0.1, device='cpu', state_dim=6):
        super().__init__()
        self.corr_threshold = corr_threshold
        self.device = device
        self.hidden_dim = hidden_dim
        
        # Event type embeddings (signal_adjust, traffic_restriction, accident, etc.)
        self.type_embed = nn.Embedding(10, event_type_dim)  # 10 event types
        self.loc_proj = nn.Linear(2, location_dim)  # (latitude, longitude) -> loc_emb
        
        # MLP for state features
        self.state_mlp = nn.Sequential(
            nn.Linear(state_dim, 16),
            nn.ReLU(),
            nn.Linear(16, 16),
        )
        
        # Message passing for causal graph
        self.parent_agg = nn.Linear(event_type_dim + location_dim + 16, hidden_dim)
        self.child_agg = nn.Linear(event_type_dim + location_dim + 16, hidden_dim)
        self.self_mlp = nn.Linear(event_type_dim + location_dim + 16, hidden_dim)
        self.combo_agg = nn.Linear(hidden_dim * 3, hidden_dim)
        
        # Edge predictor (for DAG learning via gradient-based method)
        self.edge_predictor = nn.Linear(event_type_dim + location_dim + 16, 1)
    
    def _partial_corr(self, states, n_events):
        """"Compute partial correlation matrix from state features."""
        # states: (n_events, state_dim)
        if n_events < 2:
            return torch.ones((1, 1))
        corr = torch.corrcoef(states)
        # Simple approximation of partial corr via inverse covariance
        try:
            prec = torch.linalg.inv(corr + torch.eye(n_events, device=corr.device) * 1e-4)
            pcorr = -prec / torch.sqrt(torch.diag(prec).unsqueeze(0) * torch.diag(prec).unsqueeze(1) + 1e-8)
        except:
            pcorr = corr
        return pcorr
    
    def _orient_edges(self, adj_undirected, times, n_events):
        """Orient undirected edges using temporal ordering."""
        # adj_undirected: (n_events, n_events) symmetric
        directed = torch.zeros_like(adj_undirected)
        for i in range(n_events):
            for j in range(n_events):
                if i == j: continue
                if adj_undirected[i, j] > self.corr_threshold:
                    # times[i] < times[j] -> i -> j
                    if times[i] < times[j]:
                        directed[i, j] = 1.0
                    elif times[j] < times[i]:
                        directed[j, i] = 1.0
                    else:
                        # Same time -> both directions (undirected in output)
                        directed[i, j] = 1.0
                        directed[j, i] = 1.0
        return directed
    
    def forward(self, event_types, event_locs, event_times, zone_states):
        """
        Args:
            event_types: (batch, max_events) long tensor, event type IDs
            event_locs:  (batch, max_events, 2) float, (lat, lon) normalized
            event_times: (batch, max_events) float, time indices
            zone_states: (batch, max_events, 6) float, state vectors for each zone
        
        Returns:
            combo_emb:  (batch, hidden_dim)
            event_embs: (batch, max_events, hidden_dim)
            adj_matrix: (batch, max_events, max_events) 
        """
        batch_size, max_events = event_types.shape[:2]
        device = event_types.device
        
        # Embeddings
        types_safe = event_types.clamp(min=0)  # -1 -> 0
        t_emb = self.type_embed(types_safe)  # (B, M, 16)
        l_emb = self.loc_proj(event_locs)     # (B, M, 16)
        s_emb = self.state_mlp(zone_states)    # (B, M, 16)
        
        all_emb = torch.cat([t_emb, l_emb, s_emb], dim=-1)  # (B, M, 48)
        
        # Per-sample causal structure
        combo_embs = []
        event_embs_list = []
        adj_list = []
        
        for b in range(batch_size):
            n_events = max(1, (event_types[b] >= 0).sum().item())
            if n_events < 1:
                # No events: zero embedding
                combo_embs.append(torch.zeros(self.hidden_dim, device=device))
                event_embs_list.append(torch.zeros(
                    max_events, self.hidden_dim, device=device))
                adj_list.append(torch.zeros(max_events, max_events, device=device))
                continue
            
            # Get valid events only
            valid = all_emb[b, :n_events]  # (n_events, 48)
            
            # Step 1: Compute partial correlations
            pcorr = self._partial_corr(zone_states[b, :n_events], n_events)
            
            # Step 2: Orient edges
            if n_events > 0:
                times = event_times[b, :n_events]
                directed = self._orient_edges(pcorr, times, n_events)
            else:
                directed = torch.zeros((1, 1), device=device)
            
            # Step 3: Message passing along causal graph
            parent_count = directed.sum(dim=1)  # incoming edges
            child_count = directed.sum(dim=0)   # outgoing edges
            
            event_embs = []
            for i in range(n_events):
                # Parent aggregation (incoming messages)
                if parent_count[i] > 0:
                    parents = (directed[:, i] > 0).float()
                    parent_msg = (valid * parents.unsqueeze(1)).sum(dim=0) / parent_count[i]
                else:
                    parent_msg = torch.zeros(48, device=device)
                
                # Child aggregation (outgoing messages)
                if child_count[i] > 0:
                    children = (directed[i, :] > 0).float()
                    child_msg = (valid * children.unsqueeze(1)).sum(dim=0) / child_count[i]
                else:
                    child_msg = torch.zeros(48, device=device)
                
                e = self.self_mlp(valid[i]) + self.parent_agg(parent_msg) + self.child_agg(child_msg)
                event_embs.append(e)
            
            event_embs_t = torch.stack(event_embs)  # (n_events, 64)
            
            # Aggregate combo embedding
            combo_emb = self.combo_agg(torch.cat([
                event_embs_t.mean(dim=0),
                event_embs_t.max(dim=0)[0],
                event_embs_t.min(dim=0)[0],
            ]))
            
            # Pad back to max_events
            padded = torch.zeros(max_events, self.hidden_dim, device=device)
            padded[:n_events] = event_embs_t
            adj_padded = torch.zeros(max_events, max_events, device=device)
            adj_padded[:n_events, :n_events] = directed
            
            combo_embs.append(combo_emb)
            event_embs_list.append(padded)
            adj_list.append(adj_padded)
        
        return torch.stack(combo_embs), torch.stack(event_embs_list), torch.stack(adj_list)
