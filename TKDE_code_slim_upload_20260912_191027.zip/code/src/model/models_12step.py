"""12-step, full-graph variants of the paper's predictor family.

Used for the protocol-fair comparison against the official 12-step
STAEformer on PEMS08. Inputs are full-graph windows (B, T, N, D); outputs
are per-node 12-step flow predictions (B, N, out_steps, 1).
"""
import torch
import torch.nn as nn

from stwave import STWaveBlock
from crossgnn import CrossGNNBlock
from stid_graph import TemporalConvBlock, GCNLayer


class STWave12FG(nn.Module):
    def __init__(self, n_zones=170, input_dim=3, hidden_dim=64, n_blocks=2,
                 seq_len=12, out_steps=12):
        super().__init__()
        self.out_steps = out_steps
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.pos_embed = nn.Embedding(seq_len, hidden_dim)
        self.blocks = nn.ModuleList(
            [STWaveBlock(n_zones, hidden_dim) for _ in range(n_blocks)])
        self.pred_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, out_steps),
        )

    def forward(self, features):
        B, T, N, D = features.shape
        x = self.input_proj(features)
        pos = torch.arange(T, device=features.device)
        x = x + self.pos_embed(pos).view(1, T, 1, -1)
        x = x.permute(0, 2, 1, 3)
        for block in self.blocks:
            x = block(x)
        pred = self.pred_head(x[:, :, -1, :])
        return pred.view(B, N, self.out_steps, 1)


class CrossGNN12FG(nn.Module):
    def __init__(self, n_zones=170, input_dim=3, hidden_dim=64, n_blocks=2,
                 n_heads=4, seq_len=12, out_steps=12):
        super().__init__()
        self.out_steps = out_steps
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.pos_embed = nn.Embedding(seq_len, hidden_dim)
        self.blocks = nn.ModuleList(
            [CrossGNNBlock(hidden_dim, n_heads) for _ in range(n_blocks)])
        self.pred_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, out_steps),
        )

    def forward(self, features):
        B, T, N, D = features.shape
        x = self.input_proj(features)
        pos = torch.arange(T, device=features.device)
        x = x + self.pos_embed(pos).view(1, T, 1, -1)
        x = x.permute(0, 2, 1, 3)
        for block in self.blocks:
            x = block(x)
        pred = self.pred_head(x[:, :, -1, :])
        return pred.view(B, N, self.out_steps, 1)


class SWPred12FG(nn.Module):
    """PredOnly (STWave + zone embedding) with a 12-step head."""
    def __init__(self, n_zones=170, input_dim=3, hidden_dim=64, n_blocks=2,
                 seq_len=12, out_steps=12):
        super().__init__()
        self.out_steps = out_steps
        self.zone_embed = nn.Embedding(n_zones, hidden_dim)
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.pos_embed = nn.Embedding(seq_len, hidden_dim)
        self.blocks = nn.ModuleList(
            [STWaveBlock(n_zones, hidden_dim) for _ in range(n_blocks)])
        self.pred_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, out_steps),
        )

    def forward(self, features):
        B, T, N, D = features.shape
        zid = torch.arange(N, device=features.device)
        x = self.input_proj(features)
        pos = torch.arange(T, device=features.device)
        x = x + self.pos_embed(pos).view(1, T, 1, -1)
        x = x + self.zone_embed(zid).view(1, 1, N, -1)
        x = x.permute(0, 2, 1, 3)
        for block in self.blocks:
            x = block(x)
        pred = self.pred_head(x[:, :, -1, :])
        return pred.view(B, N, self.out_steps, 1)


class STWaveCausal12FG(nn.Module):
    """V3-style predictor under the 12-step protocol.

    Uses the same graph-context + per-zone gate as the 1-step PEMS08 V3
    instance: per-zone features are [flow, neighbor-mean flow, tod, dow]
    with a learnable gate on the context channel.
    """
    def __init__(self, n_zones=170, input_dim=4, hidden_dim=64, n_blocks=2,
                 seq_len=12, out_steps=12, adj=None):
        super().__init__()
        self.out_steps = out_steps
        self.zone_embed = nn.Embedding(n_zones, hidden_dim)
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.pos_embed = nn.Embedding(seq_len, hidden_dim)
        self.blocks = nn.ModuleList(
            [STWaveBlock(n_zones, hidden_dim) for _ in range(n_blocks)])
        self.pred_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, out_steps),
        )
        self.ctx_gate = nn.Embedding(n_zones, 1)
        nn.init.zeros_(self.ctx_gate.weight)
        if adj is not None:
            adj = torch.FloatTensor(adj)
            adj = adj / adj.sum(dim=1, keepdim=True).clamp(min=1e-6)
            self.register_buffer("adj", adj)
        else:
            self.register_buffer("adj", None)

    def forward(self, features):
        B, T, N, D = features.shape
        raw = features[..., :1].squeeze(-1)             # (B, T, N)
        ctx = torch.einsum("btn,nm->btm", raw, self.adj)
        zid = torch.arange(N, device=features.device)
        gate = torch.sigmoid(self.ctx_gate(zid)).view(1, 1, N)
        ctx = ctx * gate
        f = torch.cat([raw.unsqueeze(-1), ctx.unsqueeze(-1),
                       features[..., 1:3]], dim=-1)     # (B, T, N, 4)
        x = self.input_proj(f)
        pos = torch.arange(T, device=features.device)
        x = x + self.pos_embed(pos).view(1, T, 1, -1)
        x = x + self.zone_embed(zid).view(1, 1, N, -1)
        x = x.permute(0, 2, 1, 3)
        for block in self.blocks:
            x = block(x)
        pred = self.pred_head(x[:, :, -1, :])
        return pred.view(B, N, self.out_steps, 1)


class STIDGraph12(nn.Module):
    """STIDGraph with per-node 12-step output (all nodes predicted)."""
    def __init__(self, n_zones=170, input_dim=3, hidden_dim=64, seq_len=12,
                 n_layers=2, n_days=7, out_steps=12):
        super().__init__()
        self.n_zones = n_zones
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.seq_len = seq_len
        self.out_steps = out_steps
        self.spatial_embed = nn.Embedding(n_zones, hidden_dim)
        self.temporal_embed = nn.Embedding(seq_len + 1, hidden_dim)
        self.week_embed = nn.Embedding(n_days, hidden_dim)
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.tcn = nn.ModuleList(
            [TemporalConvBlock(hidden_dim) for _ in range(n_layers)])
        self.gcn = nn.ModuleList(
            [GCNLayer(hidden_dim) for _ in range(n_layers)])
        self.mlp = nn.Sequential(
            nn.Linear(hidden_dim * 5, hidden_dim * 2),
            nn.ReLU(),
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, out_steps),
        )

    def forward(self, features, adj):
        B, T, N, D = features.shape
        x = self.input_proj(features)
        x = x.permute(0, 2, 1, 3)
        for tcn, gcn in zip(self.tcn, self.gcn):
            x = tcn(x)
            x = gcn(x, adj)
        nodes = torch.arange(N, device=features.device)
        spatial = self.spatial_embed(nodes).unsqueeze(0).expand(B, -1, -1)
        tod = self.temporal_embed(
            torch.full((B,), self.seq_len, dtype=torch.long,
                       device=features.device)).unsqueeze(1).expand(B, N, -1)
        weekly = self.week_embed(
            torch.zeros(B, dtype=torch.long, device=features.device)
        ).unsqueeze(1).expand(B, N, -1)
        pooled = torch.cat([x[:, :, -1, :], x.mean(dim=2)], dim=-1)
        inp = torch.cat([spatial, tod, weekly, pooled], dim=-1)
        pred = self.mlp(inp)
        return pred.view(B, N, self.out_steps, 1)
