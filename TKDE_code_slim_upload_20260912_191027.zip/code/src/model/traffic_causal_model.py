
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
from pathlib import Path
from src.model.causal_structure import CausalStructureLearner


class TrafficTransformer(nn.Module):
    """
    TrafficCausal Main Model.
    
    Architecture:
        - 2-layer Transformer encoder (MHSA + FFN + LayerNorm)
        - Learned zone embeddings + temporal positional encoding
        - MLP prediction head
        - CausalStructureLearner for multi-event interaction
        - Joint loss: L_pred + L_con_single + L_con_multi + L_div
    """
    def __init__(self, n_zones=265, input_dim=6, hidden_dim=64, n_layers=2, 
                 n_heads=4, dropout=0.1, max_seq_len=1000, event_type_dim=16):
        super().__init__()
        self.hidden_dim = hidden_dim
        
        self.zone_embed = nn.Embedding(n_zones, hidden_dim)
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.pos_embed = nn.Embedding(max_seq_len, hidden_dim)
        
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim, nhead=n_heads, dim_feedforward=hidden_dim * 4,
            dropout=dropout, batch_first=True, activation='gelu')
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        
        self.pred_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, input_dim))
        
        self.causal_learner = CausalStructureLearner(
            event_type_dim=event_type_dim, hidden_dim=hidden_dim, device='cpu', state_dim=input_dim)
        
        self.logit_scale = nn.Parameter(torch.ones([]) * np.log(1 / 0.07))
    
    def forward(self, zone_ids, features, return_emb=False):
        B, S, D = features.shape
        z_emb = self.zone_embed(zone_ids)
        f_emb = self.input_proj(features)
        positions = torch.arange(S, device=features.device).unsqueeze(0).expand(B, -1)
        p_emb = self.pos_embed(positions)
        x = z_emb + f_emb + p_emb
        h = self.transformer(x)
        pred = self.pred_head(h[:, -1, :])
        if return_emb:
            return h, pred
        return pred
    
    def compute_loss(self, factual, cf_single, cf_multi, combo_data, labels_zone):
        B = factual['features'].shape[0]
        
        h_factual, pred_factual = self.forward(
            factual['zone_ids'], factual['features'], return_emb=True)
        L_pred = F.mse_loss(pred_factual, factual['targets'])
        
        h_counter_single, _ = self.forward(
            cf_single['zone_ids'], cf_single['features'], return_emb=True)
        h_counter_multi, _ = self.forward(
            cf_multi['zone_ids'], cf_multi['features'], return_emb=True)
        
        # Use combo_emb from CausalStructureLearner as intervention embedding
        combo_emb, _, _ = self.causal_learner(
            combo_data['event_types'], combo_data['event_locs'],
            combo_data['event_times'], combo_data['zone_states'])
        
        # --- Single-event contrastive loss ---
        h_factual_norm = F.normalize(h_factual[:, -1, :], dim=-1)
        h_counter_norm = F.normalize(h_counter_single[:, -1, :], dim=-1)
        combo_norm = F.normalize(combo_emb, dim=-1)
        
        pos_sim = (combo_norm * h_factual_norm).sum(dim=-1)
        neg_sim = (combo_norm * h_counter_norm).sum(dim=-1)
        
        con_logits = self.logit_scale.exp() * torch.stack([pos_sim, neg_sim], dim=-1)
        con_labels = torch.zeros(B, dtype=torch.long, device=con_logits.device)
        L_con_single = F.cross_entropy(con_logits, con_labels)
        
        # --- Multi-event contrastive loss ---
        h_counter_multi_norm = F.normalize(h_counter_multi[:, -1, :], dim=-1)
        pos_sim_multi = (combo_norm * h_factual_norm).sum(dim=-1)
        neg_sim_multi = (combo_norm * h_counter_multi_norm).sum(dim=-1)
        
        multi_logits = self.logit_scale.exp() * torch.stack([pos_sim_multi, neg_sim_multi], dim=-1)
        L_con_multi = F.cross_entropy(multi_logits, con_labels)
        
        # --- Diversity regularization ---
        L_div = F.mse_loss(h_factual_norm, h_counter_norm)
        L_div = torch.clamp(L_div - 0.3, min=0.0)
        
        loss = 1.0 * L_pred + 0.5 * L_con_single + 0.5 * L_con_multi + 0.1 * L_div
        
        return loss, {
            'loss': loss.item(), 'L_pred': L_pred.item(),
            'L_con_single': L_con_single.item(), 'L_con_multi': L_con_multi.item(),
            'L_div': L_div.item(),
        }


class TrafficCausalPipeline:
    def __init__(self, model, lr=1e-3, device='cuda'):
        self.model = model.to(device)
        self.device = device
        self.optimizer = torch.optim.Adam(model.parameters(), lr=lr)
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer, T_max=50)
    
    def train_epoch(self, dataloader):
        self.model.train()
        total_loss = 0
        metrics = {}
        for batch in dataloader:
            factual, cf_single, cf_multi, combo, labels = batch
            factual = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in factual.items()}
            cf_single = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in cf_single.items()}
            cf_multi = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in cf_multi.items()}
            combo = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in combo.items()}
            labels = labels.to(self.device)
            loss, loss_dict = self.model.compute_loss(
                factual, cf_single, cf_multi, combo, labels)
            self.optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            self.optimizer.step()
            total_loss += loss.item()
            for k, v in loss_dict.items():
                metrics[k] = metrics.get(k, 0) + v
        self.scheduler.step()
        n = len(dataloader)
        return total_loss / n, {k: v / n for k, v in metrics.items()}
    
    def evaluate(self, dataloader):
        self.model.eval()
        total_loss = 0
        with torch.no_grad():
            for batch in dataloader:
                factual, cf_single, cf_multi, combo, labels = batch
                factual = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in factual.items()}
                cf_single = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in cf_single.items()}
                cf_multi = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in cf_multi.items()}
                combo = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in combo.items()}
                labels = labels.to(self.device)
                loss, _ = self.model.compute_loss(
                    factual, cf_single, cf_multi, combo, labels)
                total_loss += loss.item()
        return total_loss / len(dataloader)
    
    @torch.no_grad()
    def predict_counterfactual(self, factual_data, counterfactual_data):
        self.model.eval()
        for k in factual_data:
            if isinstance(factual_data[k], torch.Tensor):
                factual_data[k] = factual_data[k].to(self.device)
        for k in counterfactual_data:
            if isinstance(counterfactual_data[k], torch.Tensor):
                counterfactual_data[k] = counterfactual_data[k].to(self.device)
        _, pred_factual = self.model.forward(
            factual_data['zone_ids'], factual_data['features'], return_emb=False)
        h_counter, pred_counter = self.model.forward(
            counterfactual_data['zone_ids'], counterfactual_data['features'], return_emb=True)
        ace = F.mse_loss(pred_factual, pred_counter).item()
        return {
            'pred_factual': pred_factual.cpu(),
            'pred_counter': pred_counter.cpu(),
            'ace': ace,
        }


def collate_fn(batch):
    factual, cf_single, cf_multi, combo, labels = zip(*batch)
    def sd(d):
        return {k: torch.stack([x[k] for x in d]) for k in d[0].keys()}
    return (sd(factual), sd(cf_single), sd(cf_multi),
            {k: torch.stack([c[k] for c in combo]) for k in combo[0].keys()},
            torch.stack(labels))
