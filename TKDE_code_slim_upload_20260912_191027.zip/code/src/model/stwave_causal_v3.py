﻿"""
STWaveCausalV3: STWave backbone + explicit Causal Effect Head (supervised ICE/JCE regression).

Key change vs V1/V2:
- Add a dedicated CausalEffectHead that takes factual/counterfactual embeddings
  and directly regresses the per-feature causal effect vector.
- Train with synthetic injection pairs where ground-truth ICE/JCE is known:
  ICE_true = |Y_f(t+1) - Y_cf(t+1)| on flow features.
- Preserves prediction loss + contrastive losses, but the causal head provides
  a direct, testable causal effect estimate for TKDE experiments.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from pathlib import Path
from src.model.causal_structure import CausalStructureLearner
from src.model.stwave import WaveletTransform, TemporalGate, SpatialGate


class STWaveCausalBlockV3(nn.Module):
    def __init__(self, hidden_dim=64):
        super().__init__()
        self.wavelet = WaveletTransform(hidden_dim)
        self.temp_gate_low = TemporalGate(hidden_dim)
        self.temp_gate_high = TemporalGate(hidden_dim)
        self.fusion = nn.Linear(hidden_dim * 2, hidden_dim)
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, x):
        B, N, T, C = x.shape
        x_flat = x.reshape(B * N, C, T)
        low, high = self.wavelet(x_flat)
        low = F.interpolate(low, size=T, mode="linear", align_corners=False)
        high = F.interpolate(high, size=T, mode="linear", align_corners=False)
        low_gated = self.temp_gate_low(low)
        high_gated = self.temp_gate_high(high)
        fused = self.fusion(torch.cat([low_gated, high_gated], dim=1).transpose(1, 2))
        fused = fused.reshape(B, N, T, C)
        return self.norm(x + fused)


class CausalEffectHead(nn.Module):
    """Direct regression head for causal effects (ICE/JCE).

    Input: concat(h_factual_last, h_counterfactual_last, combo_emb)
    Output: per-feature effect vector E in R^D (>=0).
    """
    def __init__(self, hidden_dim=64, input_dim=6, n_events=5):
        super().__init__()
        self.head = nn.Sequential(
            nn.Linear(hidden_dim * 3, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim),
            nn.Softplus(),  # non-negative effect magnitudes
        )

    def forward(self, h_f, h_cf, combo_emb):
        # h_f, h_cf: (B, C)
        # combo_emb: (B, C) or already a small event vector
        x = torch.cat([h_f, h_cf, combo_emb], dim=-1)
        return self.head(x)


class STWaveCausalV3(nn.Module):
    def __init__(self, n_zones=265, input_dim=6, hidden_dim=64, n_blocks=2,
                 seq_len=48, n_events=5, output_dim=None, ctx_channels=0,
                 ctx_gate=True):
        super().__init__()
        self.n_zones = n_zones
        self.input_dim = input_dim
        self.output_dim = output_dim if output_dim is not None else input_dim
        self.ctx_channels = ctx_channels
        self.hidden_dim = hidden_dim
        self.seq_len = seq_len

        if ctx_channels > 0 and ctx_gate:
            self.ctx_gate = nn.Embedding(n_zones, 1)
            nn.init.zeros_(self.ctx_gate.weight)

        # Backbone embeddings
        self.zone_embed = nn.Embedding(n_zones, hidden_dim)
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.pos_embed = nn.Embedding(seq_len, hidden_dim)
        self.blocks = nn.ModuleList([
            STWaveCausalBlockV3(hidden_dim) for _ in range(n_blocks)
        ])

        # Prediction head
        self.pred_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, self.output_dim),
        )

        # Causal structure learner for combo embeddings
        self.causal_learner = CausalStructureLearner(
            event_type_dim=16, hidden_dim=hidden_dim, device="cpu", state_dim=input_dim)

        # Explicit causal effect head (new in V3)
        self.causal_head = CausalEffectHead(
            hidden_dim, self.output_dim, n_events)

        self.logit_scale = nn.Parameter(torch.ones([]) * np.log(1 / 0.07))

    def encode(self, zone_ids, features):
        """Encode input sequence to final embedding h (B, C)."""
        B, S, D = features.shape
        if self.ctx_channels > 0 and hasattr(self, "ctx_gate"):
            features = features.clone()
            raw_end = self.output_dim
            gate = torch.sigmoid(self.ctx_gate(zone_ids))
            features[:, :, raw_end:raw_end + self.ctx_channels] *= gate
        z_emb = self.zone_embed(zone_ids)
        f_emb = self.input_proj(features)
        positions = torch.arange(S, device=features.device).unsqueeze(0).expand(B, -1)
        p_emb = self.pos_embed(positions)
        x = z_emb + f_emb + p_emb
        x = x.unsqueeze(1)  # (B, 1, S, C)
        for block in self.blocks:
            x = block(x)
        h = x[:, 0, :, :]  # (B, S, C)
        return h[:, -1, :]  # (B, C)

    def forward(self, zone_ids, features):
        h = self.encode(zone_ids, features)
        pred = self.pred_head(h)
        return h, pred

    def contrastive_loss(self, factual, cf_single, cf_multi, combo_data,
                         div_mode="pull", margin=0.3):
        """Multi-event joint contrastive objective from the paper.

        Returns L_pred, L_con_single, L_con_multi and L_div.  L_div uses pull
        mode (factual/counterfactual embeddings pulled together) by default.
        """
        B = factual["features"].shape[0]
        h_factual, pred_factual = self.forward(
            factual["zone_ids"], factual["features"])
        L_pred = F.mse_loss(pred_factual, factual["targets"])

        h_counter_single, _ = self.forward(
            cf_single["zone_ids"], cf_single["features"])
        h_factual_n = F.normalize(h_factual, dim=-1)
        if combo_data.get("intervention_emb") is not None:
            E_intervention = combo_data["intervention_emb"]
        else:
            E_intervention = h_factual_n.detach()
        logits = self.logit_scale.exp() * torch.matmul(
            E_intervention, h_factual_n.T)
        L_con_single = F.cross_entropy(
            logits, torch.arange(logits.shape[0], device=logits.device))

        h_counter_multi, _ = self.forward(
            cf_multi["zone_ids"], cf_multi["features"])
        combo_emb, _, _ = self.causal_learner(
            combo_data["event_types"], combo_data["event_locs"],
            combo_data["event_times"], combo_data["zone_states"])

        h_fn = F.normalize(h_factual, dim=-1)
        h_csn = F.normalize(h_counter_single, dim=-1)
        h_cmn = F.normalize(h_counter_multi, dim=-1)
        cn = F.normalize(combo_emb, dim=-1)
        pos_sim = (cn * h_fn).sum(dim=-1)
        neg_sim_s = (cn * h_csn).sum(dim=-1)
        neg_sim_m = (cn * h_cmn).sum(dim=-1)
        logits_multi = torch.stack([pos_sim, neg_sim_s, neg_sim_m], dim=-1)
        L_con_multi = F.cross_entropy(
            logits_multi / 0.07,
            torch.zeros(B, dtype=torch.long, device=logits_multi.device))

        h_f_last = h_factual
        h_cm_last = h_counter_multi
        if div_mode == "pull":
            L_div = torch.norm(h_f_last - h_cm_last, dim=-1).mean()
        else:
            L_div = F.relu(margin - torch.norm(
                h_f_last - h_cm_last, dim=-1)).mean()

        return {
            "L_pred": L_pred,
            "L_con_single": L_con_single,
            "L_con_multi": L_con_multi,
            "L_div": L_div,
        }

    def causal_effect(self, factual, cf_single, combo_data=None, cf_multi=None):
        """Estimate ICE (and optionally JCE) given factual/counterfactual sequences.

        Args:
            factual: {'zone_ids': (B,S) long, 'features': (B,S,D)}
            cf_single: {'zone_ids': (B,S) long, 'features': (B,S,D)}
            combo_data: optional dict with event metadata.
        Returns:
            ice_est: (B, D) per-feature causal effect magnitude
        """
        h_f = self.encode(factual["zone_ids"], factual["features"])
        h_cf = self.encode(cf_single["zone_ids"], cf_single["features"])

        if combo_data is not None:
            combo_emb, _, _ = self.causal_learner(
                combo_data["event_types"], combo_data["event_locs"],
                combo_data["event_times"], combo_data["zone_states"])
        else:
            combo_emb = torch.zeros_like(h_f)

        ice_est = self.causal_head(h_f, h_cf, combo_emb)
        return ice_est


def collate_v3(batch):
    """Collate for V3: factual, cf_single, cf_multi, combo, true_causal_effect."""
    factual, cf_single, cf_multi, combo, labels = zip(*batch)
    def sd(d):
        return {k: torch.stack([x[k] for x in d]) for k in d[0].keys()}
    return (sd(factual), sd(cf_single), sd(cf_multi),
            {k: torch.stack([c[k] for c in combo]) for k in combo[0].keys()},
            torch.stack(labels))

