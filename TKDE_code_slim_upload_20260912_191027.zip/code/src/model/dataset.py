import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from pathlib import Path


class TrafficCausalDataset(Dataset):
    """
    Dataset that serves factual/counterfactual pairs for training.
    
    Each sample: zone, time window, its factual flow, its counterfactual flow,
    intervention combo information.
    """
    
    def __init__(self, data_dir="data/nyc_taxi/processed", split="train",
                 seq_len=48, device='cpu'):
        self.data_dir = Path(data_dir)
        self.seq_len = seq_len
        self.device = device
        
        print("Loading dataset...")
        self.features = np.load(str(self.data_dir / "node_features.npy"))
        self.labels = np.load(str(self.data_dir / "labels.npy"))
        self.matches = np.load(str(self.data_dir / "matched_pairs.npy"),
                                allow_pickle=True)
        
        self.T, self.N, self.D = self.features.shape
        print("  Features: (%d, %d, %d)" % (self.T, self.N, self.D))
        print("  Matches: %d pairs" % len(self.matches))
        
        # Build sample list from matches
        self.samples = []
        for m in self.matches.tolist():
            if isinstance(m, dict):
                self.samples.append({
                    'zone': m['zone'],
                    't_factual': m['t'],
                    't_counter': m['t_star'],
                    'is_multi': False,  # single-event default
                })
        
        # Add multi-event samples
        multi_windows = []
        for t in range(self.T):
            int_zones = np.where(self.labels[t] == 1)[0]
            if len(int_zones) > 1:
                multi_windows.append((t, int_zones))
        
        for t, zones in multi_windows[:len(self.matches)]:
            self.samples.append({
                'zone': int(zones[0]),
                't_factual': t,
                't_counter': None,
                'is_multi': True,
                'multi_zones': [int(z) for z in zones],
            })
        
        print("  Total samples:", len(self.samples))
        
        # Split
        np.random.seed(42)
        n = len(self.samples)
        idx = np.random.permutation(n)
        n_train = int(n * 0.8)
        n_val = int(n * 0.1)
        if split == 'train':
            self.samples = [self.samples[i] for i in idx[:n_train]]
        elif split == 'val':
            self.samples = [self.samples[i] for i in idx[n_train:n_train+n_val]]
        else:
            self.samples = [self.samples[i] for i in idx[n_train+n_val:]]
        print("  Split '%s': %d samples" % (split, len(self.samples)))
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        s = self.samples[idx]
        zone = s['zone']
        t = s['t_factual']
        
        # ─── Factual sequence ───
        t_start = max(0, t - self.seq_len)
        factual_features = self.features[t_start:t, zone]
        if len(factual_features) < self.seq_len:
            pad = np.zeros((self.seq_len - len(factual_features), self.D))
            factual_features = np.concatenate([pad, factual_features])
        
        factual = {
            'zone_ids': torch.full((self.seq_len,), zone, dtype=torch.long),
            'features': torch.FloatTensor(factual_features),
            'targets': torch.FloatTensor(self.features[t, zone]),
        }
        
        # ─── Counterfactual (single-event) ───
        t_c = s['t_counter']
        if t_c is not None:
            t_c_start = max(0, t_c - self.seq_len)
            cf_features = self.features[t_c_start:t_c, zone]
            if len(cf_features) < self.seq_len:
                pad = np.zeros((self.seq_len - len(cf_features), self.D))
                cf_features = np.concatenate([pad, cf_features])
        else:
            cf_features = factual_features
        
        cf_single = {
            'zone_ids': torch.full((self.seq_len,), zone, dtype=torch.long),
            'features': torch.FloatTensor(cf_features),
        }
        
        # ─── Counterfactual (multi-event) ───
        cf_multi = {
            'zone_ids': torch.full((self.seq_len,), zone, dtype=torch.long),
            'features': torch.FloatTensor(cf_features),
        }
        
        # ─── Combo data ───
        max_events = 5
        if s['is_multi'] and 'multi_zones' in s:
            n_events = len(s['multi_zones'])
            event_types = torch.full((max_events,), -1, dtype=torch.long)
            event_locs = torch.zeros(max_events, 2)
            event_times = torch.zeros(max_events)
            zone_states = torch.zeros(max_events, self.D)
            
            for i, z in enumerate(s['multi_zones'][:max_events]):
                event_types[i] = 1  # default event type
                event_times[i] = float(t)
                zone_states[i] = torch.FloatTensor(self.features[t, z])
        else:
            event_types = torch.full((max_events,), -1, dtype=torch.long)
            event_locs = torch.zeros(max_events, 2)
            event_times = torch.zeros(max_events)
            zone_states = torch.zeros(max_events, self.D)
        
        combo = {
            'event_types': event_types,
            'event_locs': event_locs,
            'event_times': event_times,
            'zone_states': zone_states,
        }
        
        label = torch.tensor(zone, dtype=torch.long)
        
        return factual, cf_single, cf_multi, combo, label
