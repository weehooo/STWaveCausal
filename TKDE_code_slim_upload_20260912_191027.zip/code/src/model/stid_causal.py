"""STIDCausal: STIDGraph encoder + explicit causal effect head.

Keeps the graph-aware STID backbone (full-node windows + GCN) and adds the
causal structure learner, contrastive objective, and supervised causal head
from STWaveCausal, so the causal machinery is backbone-agnostic.
"""
import os
import sys

import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from src.model.causal_structure import CausalStructureLearner
from src.model.stid_graph import STIDGraph


class CausalEffectHead(nn.Module):
    """Regress per-feature effect magnitudes from factual/cf embeddings."""
    def __init__(self, in_dim, out_dim, hidden=128):
        super().__init__()
        self.head = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.ReLU(),
            nn.Linear(hidden, hidden),
            nn.ReLU(),
            nn.Linear(hidden, out_dim),
            nn.Softplus(),
        )

    def forward(self, h_f, h_cf, combo_emb):
        return self.head(torch.cat([h_f, h_cf, combo_emb], dim=-1))


class STIDCausal(nn.Module):
    def __init__(self, n_zones=170, input_dim=1, hidden_dim=64, seq_len=48,
                 n_layers=2, n_days=7, output_dim=None, n_events=5):
        super().__init__()
        self.n_zones = n_zones
        self.input_dim = input_dim
        self.output_dim = output_dim if output_dim is not None else input_dim
        self.hidden_dim = hidden_dim
        self.seq_len = seq_len
        self.enc_h = hidden_dim * 5

        self.backbone = STIDGraph(
            n_zones=n_zones, input_dim=input_dim, hidden_dim=hidden_dim,
            seq_len=seq_len, n_layers=n_layers, n_days=n_days)
        self.causal_learner = CausalStructureLearner(
            event_type_dim=16, hidden_dim=hidden_dim, device="cpu",
            state_dim=input_dim)
        self.causal_head = CausalEffectHead(
            in_dim=hidden_dim * 3, out_dim=self.output_dim)
        self.combo_proj = nn.Linear(hidden_dim, self.enc_h)
        self.logit_scale = nn.Parameter(torch.ones([]) * torch.log(torch.tensor(1 / 0.07)))

    def encode(self, features, zone_ids, adj):
        """features: (B, T, N, D), zone_ids: (B,), adj: (N, N)
        -> (h, target_last, pred)."""
        B, T, N, D = features.shape
        device = features.device
        x = self.backbone.input_proj(features)
        x = x.permute(0, 2, 1, 3)
        for tcn, gcn in zip(self.backbone.tcn, self.backbone.gcn):
            x = tcn(x)
            x = gcn(x, adj)
        if zone_ids.dim() == 2:
            zone_ids = zone_ids[:, -1]
        target = x[torch.arange(B, device=device), zone_ids]
        spatial = self.backbone.spatial_embed(zone_ids)
        tod = self.backbone.temporal_embed(torch.full(
            (B,), self.seq_len, dtype=torch.long, device=device))
        weekly = self.backbone.week_embed(
            torch.zeros(B, dtype=torch.long, device=device))
        h_last = target[:, -1, :]
        h_mean = target.mean(dim=1)
        pooled = torch.stack([h_last, h_mean], dim=1).reshape(B, -1)
        h = torch.cat([spatial, tod, weekly, pooled], dim=-1)
        pred = self.backbone.mlp(h)
        return h, target[:, -1, :], pred

    def forward(self, features, zone_ids, adj):
        h, _, pred = self.encode(features, zone_ids, adj)
        return h, pred

    def contrastive_loss(self, factual, cf_single, cf_multi, combo_data, adj):
        B = factual["features"].shape[0]
        h_factual, _, pred_factual = self.encode(
            factual["features"], factual["zone_ids"], adj)
        L_pred = F.mse_loss(pred_factual, factual["targets"])

        h_counter_single, _, _ = self.encode(
            cf_single["features"], cf_single["zone_ids"], adj)
        h_factual_n = F.normalize(h_factual, dim=-1)
        logits = self.logit_scale.exp() * torch.matmul(
            h_factual_n, h_factual_n.T)
        L_con_single = F.cross_entropy(
            logits, torch.arange(logits.shape[0], device=logits.device))

        h_counter_multi, _, _ = self.encode(
            cf_multi["features"], cf_multi["zone_ids"], adj)
        combo_emb, _, _ = self.causal_learner(
            combo_data["event_types"], combo_data["event_locs"],
            combo_data["event_times"], combo_data["zone_states"])

        h_fn = F.normalize(h_factual, dim=-1)
        h_csn = F.normalize(h_counter_single, dim=-1)
        h_cmn = F.normalize(h_counter_multi, dim=-1)
        cn = F.normalize(self.combo_proj(combo_emb), dim=-1)
        pos_sim = (cn * h_fn).sum(dim=-1)
        neg_sim_s = (cn * h_csn).sum(dim=-1)
        neg_sim_m = (cn * h_cmn).sum(dim=-1)
        logits_multi = torch.stack([pos_sim, neg_sim_s, neg_sim_m], dim=-1)
        L_con_multi = F.cross_entropy(
            logits_multi / 0.07,
            torch.zeros(B, dtype=torch.long, device=logits_multi.device))
        L_div = torch.norm(h_factual - h_counter_multi, dim=-1).mean()
        return {"L_pred": L_pred, "L_con_single": L_con_single,
                "L_con_multi": L_con_multi, "L_div": L_div}

    def causal_effect(self, factual, cf_single, combo_data, adj):
        _, t_f, _ = self.encode(factual["features"], factual["zone_ids"], adj)
        _, t_cf, _ = self.encode(cf_single["features"], cf_single["zone_ids"], adj)
        if combo_data is not None:
            combo_emb, _, _ = self.causal_learner(
                combo_data["event_types"], combo_data["event_locs"],
                combo_data["event_times"], combo_data["zone_states"])
        else:
            combo_emb = torch.zeros_like(t_f)
        return self.causal_head(t_f, t_cf, combo_emb)
