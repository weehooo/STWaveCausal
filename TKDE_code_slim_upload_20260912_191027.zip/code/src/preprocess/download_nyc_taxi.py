"""
NYC Taxi Trip Data Downloader
=============================
Download yellow taxi trip records from NYC TLC website.

Data source: https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page
Format: Parquet (columnar, fast to read with pandas)
Coverage: 2011-01 ~ 2013-12 (36 months, covers Hurricane Sandy 2012-10)
Total size: ~6-8 GB

Usage:
    python download_nyc_taxi.py                   # full range (36 months)
    python download_nyc_taxi.py --year 2012        # single year
    python download_nyc_taxi.py --start 2012-10 --end 2012-11  # custom range
"""

import urllib.request
import os
import sys
import time
import argparse
from pathlib import Path

BASE_URL = "https://d37ci6vzurychx.cloudfront.net/trip-data"

def get_output_dir():
    """Locate the data/nyc_taxi/raw directory relative to this script."""
    script_dir = Path(__file__).resolve().parent
    repo_root = script_dir.parent.parent
    output_dir = repo_root / "data" / "nyc_taxi" / "raw"
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir

def download_file(url, output_path, retries=3):
    """Download a single file with retry logic."""
    if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
        file_size = os.path.getsize(output_path) / (1024 * 1024)
        return True, file_size
    
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=600) as resp:
                total = int(resp.headers.get("Content-Length", 0))
                temp_path = output_path + ".part"
                downloaded = 0
                start_time = time.time()
                
                with open(temp_path, "wb") as f:
                    while True:
                        chunk = resp.read(8192)
                        if not chunk:
                            break
                        f.write(chunk)
                        downloaded += len(chunk)
                
                os.replace(temp_path, output_path)
                elapsed = time.time() - start_time
                file_size = os.path.getsize(output_path) / (1024 * 1024)
                speed = file_size / elapsed if elapsed > 0 else 0
                return True, file_size, speed
                
        except Exception as e:
            if attempt < retries - 1:
                wait = 5 * (attempt + 1)
                time.sleep(wait)
                continue
            return False, str(e)
    
    return False, "max retries"

def main():
    parser = argparse.ArgumentParser(description="Download NYC Taxi trip data")
    parser.add_argument("--start", default="2011-01", help="Start month YYYY-MM")
    parser.add_argument("--end", default="2013-12", help="End month YYYY-MM")
    parser.add_argument("--dry-run", action="store_true", help="Only list files to download")
    args = parser.parse_args()
    
    start_year, start_month = map(int, args.start.split("-"))
    end_year, end_month = map(int, args.end.split("-"))
    
    output_dir = get_output_dir()
    
    # Build month list
    months = []
    y, m = start_year, start_month
    while (y, m) <= (end_year, end_month):
        months.append((y, m))
        m += 1
        if m > 12:
            m = 1
            y += 1
    
    print(f"Target: {len(months)} months ({args.start} ~ {args.end})")
    print(f"Output: {output_dir}")
    
    if args.dry_run:
        for y, m in months:
            filename = f"yellow_tripdata_{y}-{m:02d}.parquet"
            url = f"{BASE_URL}/{filename}"
            exists = os.path.exists(os.path.join(output_dir, filename))
            status = "EXISTS" if exists else "WILL DOWNLOAD"
            print(f"  {filename}  {status}")
        return
    
    results = {"ok": 0, "skip": 0, "fail": 0}
    
    for y, m in months:
        filename = f"yellow_tripdata_{y}-{m:02d}.parquet"
        url = f"{BASE_URL}/{filename}"
        output_path = os.path.join(output_dir, filename)
        
        if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
            file_size = os.path.getsize(output_path) / (1024 * 1024)
            print(f"[{y}-{m:02d}] SKIP ({file_size:.0f} MB)")
            results["skip"] += 1
            continue
        
        print(f"[{y}-{m:02d}] Downloading... ", end="", flush=True)
        ok, *info = download_file(url, output_path)
        
        if ok:
            file_size, speed = info
            print(f"{file_size:.0f} MB ({speed:.1f} MB/s)")
            results["ok"] += 1
        else:
            print(f"FAILED ({info[0]})")
            results["fail"] += 1
        
        time.sleep(0.5)
    
    print(f"\nDone: {results['ok']} downloaded, {results['skip']} skipped, {results['fail']} failed")
    
    # Verify Hurricane Sandy month
    sandy_path = os.path.join(output_dir, "yellow_tripdata_2012-10.parquet")
    sandy_ok = os.path.exists(sandy_path) and os.path.getsize(sandy_path) > 0
    print(f"Hurricane Sandy (2012-10): {'OK' if sandy_ok else 'NOT FOUND, need to download separately'}")

if __name__ == "__main__":
    main()
