"""Build the PEMS08 processed directory used by the paper pipeline.

Raw source: official STAEformer repository data/PEMS08/data.npz
(traffic flow + time-of-day + day-of-week). We keep only flow, run the
two-stage intervention annotation, PSM matching, correlation-based adjacency,
and the synthetic multi-event benchmark used for causal effect recovery.
"""
import os
import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(__file__))
from psm_matching import (
    encode_combos,
    psm_matching,
    balance_check,
    rosenbaum_sensitivity,
)

RAW = Path("data/datasets/pems08_staeformer")
OUT = Path("data/pems08/processed")
SEQ_LEN = 48
FEATURE_DIM = 1
MAX_EVENTS = 5


def rule_stage(flow, threshold=2.0):
    """Per-window z-score rule on flow."""
    T, N = flow.shape
    W = SEQ_LEN
    seg_idx = np.arange(T) % W
    mean_profile = np.zeros((W, N), dtype=np.float32)
    std_profile = np.zeros((W, N), dtype=np.float32)
    for w in range(W):
        mask = seg_idx == w
        vals = flow[mask]
        mean_profile[w] = vals.mean(axis=0)
        std_profile[w] = vals.std(axis=0) + 1e-8
    z_scores = np.zeros((T, N), dtype=np.float32)
    for w in range(W):
        mask = seg_idx == w
        z_scores[mask] = (flow[mask] - mean_profile[w]) / std_profile[w]
    return (np.abs(z_scores) > threshold).astype(np.int8)


def hawkes_stage(flow, decay_hours=4.0):
    """Hawkes-style double-consensus check on flow."""
    T, N = flow.shape
    alpha = 0.3
    beta = 1.0 / (decay_hours * 2)
    mu = 0.1
    labels = np.full((T, N), -1, dtype=np.int8)
    for n in range(N):
        total = flow[:, n]
        intensity = np.zeros(T)
        intensity[0] = mu
        for t in range(1, T):
            intensity[t] = intensity[t - 1] * np.exp(-beta)
            if t > 1:
                residual = abs(total[t - 1] - total[t - 2])
                if residual > 0.15 * (total[t - 2] + 1):
                    intensity[t] += alpha * np.exp(-beta)
            intensity[t] += mu * (1 - np.exp(-beta))
        expected = intensity * float(total.mean())
        z = np.abs(total - expected) / (expected + 1)
        labels[:, n] = np.where(z > 2.0, 1, np.where(z < 0.5, 0, -1))
    return labels


def combine_labels(rule, hawkes):
    final = np.full_like(rule, -1, dtype=np.int8)
    final[(rule == 1) & (hawkes == 1)] = 1
    final[(rule == 0) & (hawkes == 0)] = 0
    return final


def build_adjacency(flow, top_k=10, corr_threshold=0.5):
    """Row-normalized correlation-based adjacency."""
    T, N = flow.shape
    mu = flow.mean(axis=0)
    sd = flow.std(axis=0) + 1e-8
    z = (flow - mu) / sd
    corr = (z.T @ z) / T
    np.fill_diagonal(corr, 0.0)
    adj = np.zeros((N, N), dtype=np.float32)
    for i in range(N):
        row = corr[i].copy()
        valid = np.argsort(-np.abs(row))[:top_k]
        for j in valid:
            if abs(row[j]) >= corr_threshold:
                adj[i, j] = 1.0
    adj = (adj + adj.T) > 0
    adj = adj.astype(np.float32)
    row_sum = adj.sum(axis=1, keepdims=True)
    adj = adj / np.maximum(row_sum, 1.0)
    return adj


def inject_effect(x, factor):
    x = x.copy()
    for d in range(FEATURE_DIM):
        x[:, d] = x[:, d] * factor
    return x


def extract_window(feats, z, t):
    f_start = max(0, t - SEQ_LEN)
    x = feats[f_start:t, z].copy()
    if len(x) < SEQ_LEN:
        x = np.concatenate([np.zeros((SEQ_LEN - len(x), FEATURE_DIM)), x])
    return x


def build_synthetic_pairs(feats, labels, out_path):
    active = [z for z in range(feats.shape[1])
              if feats[:, z, 0].mean() > 30
              and (feats[:, z, 0] == 0).mean() < 0.3]
    print("Active zones:", len(active))
    candidate_windows = []
    for z in active:
        cnt = 0
        for t in range(SEQ_LEN + 5, feats.shape[0] - 1):
            if labels[t, z] == 0:
                candidate_windows.append((z, t))
                cnt += 1
                if cnt > 500:
                    break
    print("Candidate windows:", len(candidate_windows))
    rng = np.random.RandomState(42)
    samples = []
    for _ in range(20000):
        z, t = candidate_windows[rng.randint(len(candidate_windows))]
        factual = extract_window(feats, z, t)
        y_f = feats[t, z]
        mode = rng.rand()
        if mode < 0.7:
            eff = 0.7
            cf = inject_effect(factual, eff)
            ice_true = np.abs(y_f - feats[t, z] * eff).astype(np.float32)
            event_types = torch.full((MAX_EVENTS,), -1, dtype=torch.long)
            event_types[0] = 1
            n_events = 1
        elif mode < 0.9:
            eff = 0.8
            cf = inject_effect(factual, eff)
            ice_true = np.abs(y_f - feats[t, z] * eff).astype(np.float32)
            event_types = torch.full((MAX_EVENTS,), -1, dtype=torch.long)
            event_types[0] = 2
            n_events = 1
        else:
            eff = 0.7 * 0.8
            cf = inject_effect(factual, eff)
            ice_true = np.abs(y_f - feats[t, z] * eff).astype(np.float32)
            event_types = torch.full((MAX_EVENTS,), -1, dtype=torch.long)
            event_types[0] = 1
            event_types[1] = 2
            n_events = 2
        combo = {
            "event_types": event_types,
            "event_locs": torch.zeros(MAX_EVENTS, 2),
            "event_times": torch.zeros(MAX_EVENTS),
            "zone_states": torch.zeros(MAX_EVENTS, FEATURE_DIM),
        }
        for i in range(n_events):
            combo["event_times"][i] = float(t)
            combo["zone_states"][i] = torch.FloatTensor(feats[t, z])
        samples.append({
            "zone": z,
            "t": t,
            "factual": torch.FloatTensor(factual),
            "cf": torch.FloatTensor(cf),
            "ice_true": torch.FloatTensor(ice_true),
            "combo": combo,
        })
    rng.shuffle(samples)
    n = len(samples)
    n_train = int(n * 0.8)
    n_val = int(n * 0.1)
    out = {
        "train": samples[:n_train],
        "val": samples[n_train:n_train + n_val],
        "test": samples[n_train + n_val:],
    }
    np.save(str(out_path), out, allow_pickle=True)
    print("Saved", out_path, "train/val/test =",
          len(out["train"]), len(out["val"]), len(out["test"]))


def main():
    import torch

    OUT.mkdir(parents=True, exist_ok=True)
    raw = np.load(str(RAW / "data.npz"))["data"].astype(np.float32)
    flow = raw[..., 0]
    feats = flow[..., None]
    T, N, D = feats.shape
    np.save(str(OUT / "node_features.npy"), feats)
    print("node_features:", feats.shape, "flow mean/max:",
          float(flow.mean()), float(flow.max()))

    print("Stage 1: rule annotation...")
    rule = rule_stage(flow)
    print("Rule interventions:", int(rule.sum()))
    print("Stage 2: hawkes annotation...")
    hawkes = hawkes_stage(flow)
    labels = combine_labels(rule, hawkes)
    np.save(str(OUT / "labels.npy"), labels)
    n_int = int((labels == 1).sum())
    n_resp = int((labels == 0).sum())
    n_unc = int((labels == -1).sum())
    total = labels.size
    with open(str(OUT / "label_stats.txt"), "w") as f:
        f.write("T=%d N=%d pairs=%d\n" % (T, N, T * N))
        f.write("INTERVENTION: %d (%.2f%%)\n" % (n_int, n_int / total * 100))
        f.write("RESPONSE: %d (%.2f%%)\n" % (n_resp, n_resp / total * 100))
        f.write("UNCERTAIN: %d (%.2f%%)\n" % (n_unc, n_unc / total * 100))
    print("labels:", n_int, n_resp, n_unc)

    print("PSM matching...")
    combo_map = encode_combos(labels)
    matches = psm_matching(feats, labels, combo_map, caliper=10.0, time_buffer=3)
    np.save(str(OUT / "matched_pairs.npy"), matches)
    bal = balance_check(matches, feats)
    sens = rosenbaum_sensitivity(matches)
    print("SMD:", bal["smd"], "passed:", bal["passed"])
    print("Rosenbaum:", sens)
    with open(str(OUT / "psm_stats.txt"), "w") as f:
        f.write("Pairs: %d\n%s\n%s\n" % (len(matches), bal, sens))

    print("Adjacency...")
    adj = build_adjacency(flow)
    np.save(str(OUT / "adj.npy"), adj)
    print("adj shape:", adj.shape, "row sums:", adj.sum(1)[:5])

    print("Synthetic pairs...")
    build_synthetic_pairs(feats, labels, OUT / "synthetic_pairs_v3.npy")

    with open(str(OUT / "info.txt"), "w") as f:
        f.write("dataset: PEMS08 (STAEformer official split source)\n")
        f.write("n_sensors: %d\n" % N)
        f.write("n_windows: %d\n" % T)
        f.write("n_features: %d\n" % D)
        f.write("window_minutes: 5\n")
        f.write("time_span_days: %.1f\n" % (T * 5 / 1440))
        f.write("matched_pairs: %d\n" % len(matches))
    print("ALL DONE")


if __name__ == "__main__":
    main()
