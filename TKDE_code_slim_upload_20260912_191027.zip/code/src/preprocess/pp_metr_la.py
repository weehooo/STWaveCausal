# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "F:/xuexi/codex/papers/py_deps")
import numpy as np
from scipy.ndimage import median_filter, uniform_filter1d
from scipy.stats import wilcoxon
import warnings, time, h5py, pickle as pkl, argparse
from pathlib import Path
warnings.filterwarnings("ignore")


def clean_data(values):
    speed = values.copy()
    missing = (speed == 0)
    print("  Missing (zero) rate: %.2f%%" % (missing.sum() / speed.size * 100))
    sensor_means = np.mean(speed, axis=0)
    sensor_means[sensor_means == 0] = np.nanmean(sensor_means)
    for i in range(speed.shape[1]):
        speed[missing[:, i], i] = sensor_means[i]
    return speed, missing


def build_features(speed, missing):
    T, N = speed.shape
    print("  Building features: %d x %d x 8..." % (T, N))
    rolling_mean = np.zeros_like(speed)
    for i in range(N):
        rolling_mean[:, i] = uniform_filter1d(speed[:, i], size=12, mode="reflect")
    features = np.zeros((T, N, 8), dtype=np.float32)
    features[:, :, 0] = speed.astype(np.float32)
    features[:, :, 1] = np.roll(speed, 12, axis=0).astype(np.float32)
    features[:12, :, 1] = speed[:12]
    features[:, :, 2] = features[:, :, 0] - features[:, :, 1]
    features[:, :, 3] = rolling_mean.astype(np.float32)
    minutes = np.arange(T) * 5
    hours = (minutes / 60.0) % 24.0
    days = minutes / (24 * 60.0) % 7.0
    features[:, :, 4] = np.sin(2 * np.pi * hours / 24.0)[:, None]
    features[:, :, 5] = np.cos(2 * np.pi * hours / 24.0)[:, None]
    features[:, :, 6] = np.sin(2 * np.pi * days / 7.0)[:, None]
    features[:, :, 7] = np.cos(2 * np.pi * days / 7.0)[:, None]
    features[missing] = 0.0
    return features


def rule_stage(speed, missing, threshold=2.0):
    T, N = speed.shape
    rolling_med = np.zeros_like(speed)
    rolling_std = np.zeros_like(speed)
    for i in range(N):
        rolling_med[:, i] = median_filter(speed[:, i], size=12)
        residual = speed[:, i] - rolling_med[:, i]
        rolling_std[:, i] = np.sqrt(uniform_filter1d(residual**2, size=12, mode="reflect"))
    rolling_std = np.clip(rolling_std, 1.0, None)
    z_scores = (speed - rolling_med) / rolling_std
    labels = np.full((T, N), -1, dtype=np.int8)
    labels[z_scores < -threshold] = 1
    labels[z_scores > -threshold / 2] = 0
    n_int = int((labels == 1).sum())
    n_resp = int((labels == 0).sum())
    print("  Rule: INTERVENTION=%d (%.2f%%), RESPONSE=%d (%.2f%%)" % (n_int, n_int/(T*N)*100, n_resp, n_resp/(T*N)*100))
    return labels, z_scores


def hawkes_stage(speed, missing):
    T, N = speed.shape
    labels = np.full((T, N), -1, dtype=np.int8)
    speed_diff = np.diff(speed, axis=0, prepend=speed[:1])
    speed_std = np.std(speed_diff, axis=0)
    is_drop = speed_diff < -speed_std
    for i in range(N):
        drop_mask = is_drop[:, i]
        in_burst = False
        burst_len = 0
        burst_start = 0
        mean_speed_i = float(np.mean(speed[:, i]))
        for t in range(T):
            if drop_mask[t]:
                if not in_burst:
                    burst_start = t
                    in_burst = True
                    burst_len = 1
                else:
                    burst_len += 1
            else:
                if in_burst and burst_len >= 3:
                    for bt in range(burst_start, t):
                        if speed[bt, i] < mean_speed_i:
                            labels[bt, i] = 1
                in_burst = False
                burst_len = 0
        labels[~drop_mask, i] = 0
    n_int = int((labels == 1).sum())
    n_resp = int((labels == 0).sum())
    print("  Hawkes: INTERVENTION=%d (%.2f%%), RESPONSE=%d (%.2f%%)" % (n_int, n_int/(T*N)*100, n_resp, n_resp/(T*N)*100))
    return labels


def combine_labels(rule_labels, hawkes_labels):
    final = np.full_like(rule_labels, -1, dtype=np.int8)
    final[(rule_labels == 1) & (hawkes_labels == 1)] = 1
    final[(rule_labels == 0) & (hawkes_labels == 0)] = 0
    n_int = int((final == 1).sum())
    n_resp = int((final == 0).sum())
    n_unc = int((final == -1).sum())
    total = final.size
    print("  Combined: INTERVENTION=%d (%.2f%%), RESPONSE=%d (%.2f%%), UNCERTAIN=%d (%.2f%%)" % (n_int, n_int/total*100, n_resp, n_resp/total*100, n_unc, n_unc/total*100))
    return final


def extract_state(features, t, zone, n_hist=6):
    t_start = max(0, t - n_hist + 1)
    return features[t_start:t+1, zone].mean(axis=0)


def psm_matching(features, labels, caliper=0.5, time_buffer=6):
    T, N = features.shape[:2]
    int_events = [(t, z) for t in range(T) for z in range(N) if labels[t, z] == 1]
    resp_set = {(t, z) for t in range(T) for z in range(N) if labels[t, z] == 0}
    print("  Total intervention events: %d" % len(int_events))
    max_samp = 20000
    if len(int_events) > max_samp:
        rng = np.random.RandomState(42)
        idx = rng.choice(len(int_events), max_samp, replace=False)
        int_events = [int_events[i] for i in idx]
        print("  Sampled %d events" % max_samp)
    matches = []
    for i, (t, z) in enumerate(int_events):
        if (i + 1) % 5000 == 0:
            print("    matched %d/%d" % (i+1, len(int_events)))
        v_t = extract_state(features, t, z)
        best_dist = float("inf")
        best_tt = None
        t_win = 288
        t_start = max(0, t - t_win)
        t_end = min(T, t + t_win)
        for tt in range(t_start, t_end):
            if abs(tt - t) < time_buffer:
                continue
            if (tt, z) not in resp_set:
                continue
            v_c = extract_state(features, tt, z)
            d = float(np.linalg.norm(v_t - v_c))
            if d < best_dist and d < caliper:
                best_dist = d
                best_tt = tt
        if best_tt is not None:
            matches.append({"t": int(t), "t_star": int(best_tt), "zone": int(z), "feature_dist": best_dist})
    print("  Matched: %d pairs" % len(matches))
    return matches


def balance_check(matches, features):
    if len(matches) == 0:
        return {"smd": {}, "passed": False}
    treated, control = [], []
    for m in matches:
        treated.append(extract_state(features, m["t"], m["zone"]))
        control.append(extract_state(features, m["t_star"], m["zone"]))
    t_arr = np.array(treated)
    c_arr = np.array(control)
    smd = {}
    for i in range(t_arr.shape[1]):
        mt, mc = float(t_arr[:, i].mean()), float(c_arr[:, i].mean())
        vt, vc = float(t_arr[:, i].var()), float(c_arr[:, i].var())
        s = np.sqrt((vt + vc) / 2) + 1e-8
        smd["feat_" + str(i)] = abs(mt - mc) / s
    passed = all(v < 0.1 for v in smd.values())
    return {"smd": smd, "passed": passed}


def rosenbaum_sensitivity(matches):
    if len(matches) < 10:
        return {"gamma_max": None, "note": "too few matches"}
    diffs = np.array([m["feature_dist"] for m in matches if not np.isnan(m["feature_dist"])])
    if len(diffs) < 10:
        return {"gamma_max": None, "note": "too few valid diffs"}
    diffs = diffs - diffs.mean()
    if np.all(np.abs(diffs) < 1e-10):
        return {"gamma_max": 1.0, "note": "all diffs near zero"}
    diffs_filt = diffs[np.abs(diffs) > 1e-10]
    if len(diffs_filt) < 5:
        return {"gamma_max": None, "note": "too few non-zero diffs"}
    _, p0 = wilcoxon(diffs_filt, alternative="two-sided")
    gamma = 1.0
    while gamma < 3.0:
        adj = diffs_filt * gamma
        _, p_g = wilcoxon(adj, alternative="two-sided")
        if p_g > 0.05:
            break
        gamma += 0.2
    return {"gamma_max": round(gamma, 1), "p_baseline": float(p0)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-dir", default="data/datasets/annnnguyen/metr-la-dataset/versions/4")
    parser.add_argument("--out-dir", default="data/metr_la/processed")
    parser.add_argument("--rule-threshold", type=float, default=2.0)
    parser.add_argument("--caliper", type=float, default=0.5)
    parser.add_argument("--time-buffer", type=int, default=6)
    args = parser.parse_args()

    raw_dir = Path(args.raw_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    t0 = time.time()
    print("=" * 60)
    print("Step 0: Loading METR-LA data...")
    h5_path = raw_dir / "METR-LA.h5"
    pkl_path = raw_dir / "adj_METR-LA.pkl"
    f = h5py.File(str(h5_path), "r")
    values = f["df"]["block0_values"][:].astype(np.float64)
    sensor_ids = f["df"]["axis0"][:].astype(str)
    timestamps = f["df"]["axis1"][:]
    f.close()
    with open(str(pkl_path), "rb") as f2:
        adj_data = pkl.load(f2, encoding="latin1")
    adj = adj_data[2].astype(np.float32)
    T, N = values.shape
    print("  Shape: (%d, %d), Time: %.1f days" % (T, N, T * 5 / 60 / 24))
    print("  Adj density: %.2f%%" % ((adj > 0).sum() / adj.size * 100))

    print()
    print("Step 1: Cleaning data...")
    speed_clean, missing = clean_data(values)

    print()
    print("Step 2: Building node features...")
    features = build_features(speed_clean, missing)

    print()
    print("Step 3: Two-stage intervention annotation...")
    labels_rule, z_scores = rule_stage(speed_clean, missing, args.rule_threshold)
    labels_hawkes = hawkes_stage(speed_clean, missing)
    labels_final = combine_labels(labels_rule, labels_hawkes)

    np.save(str(out_dir / "node_features.npy"), features)
    np.save(str(out_dir / "labels.npy"), labels_final)
    np.save(str(out_dir / "adj.npy"), adj)
    np.save(str(out_dir / "sensor_ids.npy"), sensor_ids)

    n_int = int((labels_final == 1).sum())
    n_resp = int((labels_final == 0).sum())
    n_unc = int((labels_final == -1).sum())
    with open(str(out_dir / "label_stats.txt"), "w") as ff:
        ff.write("T=%d N=%d pairs=%d\n" % (features.shape[0], features.shape[1], features.shape[0] * features.shape[1]))
        ff.write("INTERVENTION: %d (%.2f%%)\n" % (n_int, n_int / (n_int + n_resp + n_unc) * 100))
        ff.write("RESPONSE: %d (%.2f%%)\n" % (n_resp, n_resp / (n_int + n_resp + n_unc) * 100))
        ff.write("UNCERTAIN: %d (%.2f%%)\n" % (n_unc, n_unc / (n_int + n_resp + n_unc) * 100))

    print()
    print("Step 4: PSM Matching...")
    matches = psm_matching(features, labels_final, args.caliper, args.time_buffer)
    np.save(str(out_dir / "matched_pairs.npy"), matches)

    print()
    print("  Balance check (SMD)...")
    bal = balance_check(matches, features)
    smd_vals = list(bal["smd"].values())
    if smd_vals:
        print("    SMD: max=%.4f mean=%.4f passed=%s" % (max(smd_vals), float(np.mean(smd_vals)), str(bal["passed"])))

    print()
    print("  Rosenbaum sensitivity...")
    sens = rosenbaum_sensitivity(matches)
    if sens.get("gamma_max"):
        print("    Gamma >= %s to overturn" % str(sens["gamma_max"]))

    with open(str(out_dir / "psm_stats.txt"), "w") as ff:
        ff.write("Pairs: %d\n" % len(matches))
        ff.write(str(bal) + "\n")
        ff.write(str(sens) + "\n")

    elapsed = time.time() - t0
    print()
    print("Done in %.1fs" % elapsed)
    print("  Output: %s" % str(out_dir))
