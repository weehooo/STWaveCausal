﻿"""
TrafficCausal - Data Preprocessing Pipeline
============================================
Step 1: Load raw Parquet files, build traffic flow matrices per time window.
Step 2: Construct node features per time window.
Step 3: Save processed data as numpy arrays for downstream training.

Input:  data/nyc_taxi/raw/yellow_tripdata_YYYY-MM.parquet  (36 files)
Output: data/nyc_taxi/processed/
          - flow_matrices.npz        (T x N x N sparse flow matrix)
          - node_features.npy        (T x N x d feature matrix)
          - timestamps.npy           (T, start time of each window)
          - zone_ids.npy             (N, zone IDs in the graph)
"""

import os
import sys
import time
import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from scipy.sparse import csr_matrix, save_npz, vstack
from collections import defaultdict


# === Constants ===
N_ZONES = 265  # NYC Taxi Zone system has 265 zones
ZONE_IDS = list(range(1, N_ZONES + 1))
TIME_WINDOW_MINUTES = 30  # 30 minutes per time window
WINDOWS_PER_DAY = 48      # 24h * 60min / 30min


def load_monthly_data(filepath: str) -> pd.DataFrame:
    """Load one month of Parquet data, return pickup_datetime + PULocationID + DOLocationID."""
    df = pq.read_table(filepath, columns=[
        "tpep_pickup_datetime", "PULocationID", "DOLocationID"
    ]).to_pandas()
    
    # Filter valid zones (1-265, NYC Taxi Zone system)
    mask = (
        df["PULocationID"].between(1, 265) & 
        df["DOLocationID"].between(1, 265)
    )
    df = df[mask].copy()
    
    # Convert to datetime
    df["pickup_ts"] = pd.to_datetime(df["tpep_pickup_datetime"], utc=True)
    
    return df[["pickup_ts", "PULocationID", "DOLocationID"]]


def assign_time_window(df: pd.DataFrame, start_date: pd.Timestamp) -> pd.DataFrame:
    """Assign each trip to a 30-minute time window index (0-based)."""
    minutes_since_start = (df["pickup_ts"] - start_date).dt.total_seconds() / 60.0
    df["window_idx"] = (minutes_since_start / TIME_WINDOW_MINUTES).astype(int)
    return df


def build_flow_matrix(df: pd.DataFrame, n_windows: int) -> np.ndarray:
    """
    Build T x N x N flow matrix.
    flow[t, i, j] = number of trips from zone i to zone j in window t.
    Returns dense array (may be large), switch to sparse if memory becomes an issue.
    """
    print(f"  Building flow matrix: {n_windows} windows x {N_ZONES} zones...")
    
    # Use 1D index for (window, from, to) to build coo matrix, then reshape
    # This avoids triple-loop Python iteration
    from scipy.sparse import coo_matrix
    
    row = df["window_idx"].values
    col_from = df["PULocationID"].values - 1  # 0-indexed
    col_to = df["DOLocationID"].values - 1    # 0-indexed
    
    # 1D index for coo: w * N*N + f * N + t
    idx_1d = row * (N_ZONES * N_ZONES) + col_from * N_ZONES + col_to
    data = np.ones(len(df), dtype=np.float32)
    
    coo = coo_matrix(
        (data, (np.zeros_like(idx_1d), idx_1d)),
        shape=(1, n_windows * N_ZONES * N_ZONES)
    )
    
    # Sum duplicates and reshape
    flow_flat = coo.toarray().flatten()
    flow = flow_flat.reshape(n_windows, N_ZONES, N_ZONES)
    
    print(f"  Flow matrix shape: {flow.shape}, "
          f"non-zero: {np.count_nonzero(flow):,}, "
          f"sparsity: {np.count_nonzero(flow) / flow.size * 100:.4f}%")
    
    return flow.astype(np.float32)


def build_node_features(flow: np.ndarray) -> np.ndarray:
    """
    Build T x N x d node feature matrix.
    Features per zone per window:
      0: total_outflow   (sum of flows from this zone to all others)
      1: total_inflow     (sum of flows from all others to this zone)
      2: out_degree       (number of distinct destination zones)
      3: in_degree        (number of distinct source zones)
      4: hour_of_day      (sin-cos encoding -> 2 features: 4,5)
      5: day_of_week      (0=Monday, ..., 6=Sunday)
    
    Returns: (T, N, 6) array
    """
    T, N, _ = flow.shape
    print(f"  Building node features: {T} windows x {N} zones x 6 dims...")
    
    features = np.zeros((T, N, 6), dtype=np.float32)
    
    for t in range(T):
        mat = flow[t]
        features[t, :, 0] = mat.sum(axis=1)           # total_outflow
        features[t, :, 1] = mat.sum(axis=0)           # total_inflow
        features[t, :, 2] = (mat > 0).sum(axis=1)     # out_degree
        features[t, :, 3] = (mat > 0).sum(axis=0)     # in_degree
    
    # Hour of day (sin-cos, 2 dims: 4, 5)
    minutes = np.arange(T) * TIME_WINDOW_MINUTES
    hours = (minutes / 60.0) % 24.0
    features[:, :, 4] = np.sin(2 * np.pi * hours / 24.0)[:, None]
    # features[:, :, 5] is day_of_week — set later with timestamp info
    
    return features.astype(np.float32)


def process_one_month(filepath: str, start_date: pd.Timestamp, 
                      n_windows_offset: int) -> tuple:
    """Process a single month's data."""
    month_str = Path(filepath).stem.replace("yellow_tripdata_", "")
    print(f"\n[{month_str}] Loading {filepath}...")
    
    df = load_monthly_data(filepath)
    print(f"  Loaded {len(df):,} trips")
    
    df = assign_time_window(df, start_date)
    
    # Only keep windows within this month's range
    minutes_in_month = (pd.Timestamp(month_str[:4] + "-" + month_str[5:7] + "-01").to_period("M").end_time - 
                        pd.Timestamp(month_str[:4] + "-" + month_str[5:7] + "-01")).total_seconds() / 60.0
    max_windows = int(minutes_in_month / TIME_WINDOW_MINUTES) + 48  # buffer for daylight saving, etc.
    
    df = df[df["window_idx"] < n_windows_offset + max_windows]
    df = df[df["window_idx"] >= n_windows_offset]
    df["window_idx"] -= n_windows_offset
    
    n_local_windows = int(df["window_idx"].max()) + 1 if len(df) > 0 else 0
    print(f"  Time windows in this month: {n_local_windows}")
    
    flow = build_flow_matrix(df, n_local_windows)
    
    return df, flow, n_local_windows


def main():
    parser = argparse.ArgumentParser(description="Preprocess NYC Taxi data")
    parser.add_argument("--data-dir", default="data/nyc_taxi")
    parser.add_argument("--start", default="2011-01", help="Start month")
    parser.add_argument("--end", default="2013-12", help="End month")
    parser.add_argument("--time-window", type=int, default=30, help="Minutes per window")
    args = parser.parse_args()
    
    raw_dir = Path(args.data_dir) / "raw"
    out_dir = Path(args.data_dir) / "processed"
    out_dir.mkdir(parents=True, exist_ok=True)
    
    global TIME_WINDOW_MINUTES, WINDOWS_PER_DAY
    TIME_WINDOW_MINUTES = args.time_window
    WINDOWS_PER_DAY = 24 * 60 // TIME_WINDOW_MINUTES
    
    # Determine start timestamp
    start_year, start_month = int(args.start.split("-")[0]), int(args.start.split("-")[1])
    start_date = pd.Timestamp(f"{args.start}-01", tz="UTC")
    
    # Collect all files
    all_files = sorted(raw_dir.glob("yellow_tripdata_*.parquet"))
    target_files = []
    for f in all_files:
        f_year = int(f.stem.split("_")[2].split("-")[0])
        f_month = int(f.stem.split("_")[2].split("-")[1])
        y_start, m_start = int(args.start.split("-")[0]), int(args.start.split("-")[1])
        y_end, m_end = int(args.end.split("-")[0]), int(args.end.split("-")[1])
        if (y_start, m_start) <= (f_year, f_month) <= (y_end, m_end):
            target_files.append(f)
    
    print(f"Processing {len(target_files)} months from {args.start} to {args.end}")
    print(f"Time window: {TIME_WINDOW_MINUTES} min, {WINDOWS_PER_DAY} windows/day")
    
    all_flow_chunks = []
    all_features_chunks = []
    window_offset = 0
    total_windows = 0
    
    for i, filepath in enumerate(target_files):
        _, flow, n_wins = process_one_month(str(filepath), start_date, window_offset)
        window_offset += n_wins
        all_flow_chunks.append(flow)
        total_windows += n_wins
    
    # Concatenate all months
    print(f"\nConcatenating {len(all_flow_chunks)} chunks...")
    flow_all = np.concatenate(all_flow_chunks, axis=0)
    print(f"Final flow matrix: {flow_all.shape}")
    
    # Build node features
    features_all = build_node_features(flow_all)
    
    # Add day_of_week feature
    for t in range(total_windows):
        minutes = t * TIME_WINDOW_MINUTES
        ts = start_date + pd.Timedelta(minutes=minutes)
        features_all[t, :, 5] = ts.dayofweek
    
    # Save
    out_path = out_dir / "flow_matrices.npz"
    print(f"\nSaving to {out_path}...")
    np.savez_compressed(out_path, flow=flow_all)
    
    feat_path = out_dir / "node_features.npy"
    print(f"Saving to {feat_path}...")
    np.save(feat_path, features_all)
    
    info = {
        "n_zones": N_ZONES,
        "n_windows": total_windows,
        "time_window_minutes": TIME_WINDOW_MINUTES,
        "n_features": features_all.shape[-1],
        "start_date": str(start_date),
        "flow_shape": list(flow_all.shape),
        "feature_shape": list(features_all.shape),
        "total_trips": int(flow_all.sum()),
        "sparsity_pct": round(np.count_nonzero(flow_all) / flow_all.size * 100, 4)
    }
    
    info_path = out_dir / "info.txt"
    with open(info_path, "w") as f:
        for k, v in info.items():
            f.write(f"{k}: {v}\n")
    
    print(f"\nDone! Processed data saved to {out_dir}")
    print(f"  Flow matrix:     {flow_all.shape} ({info['sparsity_pct']}% non-zero)")
    print(f"  Node features:   {features_all.shape}")
    print(f"  Total trips:     {info['total_trips']:,}")
    print(f"  Time range:      {args.start} ~ {args.end}")


if __name__ == "__main__":
    main()
