import numpy as np
from pathlib import Path
import argparse

def compute_baseline_stats(features):
    T, N = features.shape[0], features.shape[1]
    W = 48
    total_flow = features[:, :, 0] + features[:, :, 1]
    seg_idx = np.arange(T) % W
    mean_profile = np.zeros((W, N), dtype=np.float32)
    std_profile = np.zeros((W, N), dtype=np.float32)
    for w in range(W):
        mask = (seg_idx == w)
        vals = total_flow[mask]
        mean_profile[w] = np.mean(vals, axis=0)
        std_profile[w] = np.std(vals, axis=0) + 1e-8
    return mean_profile, std_profile

def rule_stage(features, mean_profile, std_profile, threshold=2.0):
    T, N = features.shape[0], features.shape[1]
    total_flow = features[:, :, 0] + features[:, :, 1]
    W = 48
    seg_idx = np.arange(T) % W
    z_scores = np.zeros((T, N), dtype=np.float32)
    for w in range(W):
        mask = (seg_idx == w)
        z_scores[mask] = (total_flow[mask] - mean_profile[w]) / std_profile[w]
    labels = (np.abs(z_scores) > threshold).astype(np.int8)
    print("Rule: %d INTERVENTION" % labels.sum())
    return labels

def hawkes_stage(features, decay_hours=4.0):
    T, N = features.shape[0], features.shape[1]
    total_flow = features[:, :, 0] + features[:, :, 1]
    alpha = 0.3
    beta = 1.0 / (decay_hours * 2)
    mu = 0.1
    labels = np.full((T, N), -1, dtype=np.int8)
    for n in range(N):
        intensity = np.zeros(T)
        intensity[0] = mu
        for t in range(1, T):
            intensity[t] = intensity[t-1] * np.exp(-beta)
            if t > 1:
                residual = abs(total_flow[t-1, n] - total_flow[t-2, n])
                if residual > 0.15 * (total_flow[t-2, n] + 1):
                    intensity[t] += alpha * np.exp(-beta)
            intensity[t] += mu * (1 - np.exp(-beta))
        baseline = float(total_flow[:, n].mean())
        expected = intensity * baseline
        z = np.abs(total_flow[:, n] - expected) / (expected + 1)
        labels[:, n] = np.where(z > 2.0, 1, np.where(z < 0.5, 0, -1))
    return labels

def combine_labels(rule_labels, hawkes_labels):
    final = np.full_like(rule_labels, -1, dtype=np.int8)
    final[(rule_labels == 1) & (hawkes_labels == 1)] = 1
    final[(rule_labels == 0) & (hawkes_labels == 0)] = 0
    n_int = int((final == 1).sum())
    n_resp = int((final == 0).sum())
    n_unc = int((final == -1).sum())
    total = final.size
    print("INTERVENTION: %d (%.2f%%)" % (n_int, n_int/total*100))
    print("RESPONSE: %d (%.2f%%)" % (n_resp, n_resp/total*100))
    print("UNCERTAIN: %d (%.2f%%)" % (n_unc, n_unc/total*100))
    return final

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="data/nyc_taxi")
    parser.add_argument("--rule-threshold", type=float, default=2.0)
    parser.add_argument("--hawkes-decay", type=float, default=4.0)
    args = parser.parse_args()
    processed_dir = Path(args.data_dir) / "processed"
    print("Loading processed data...")
    flow = np.load(str(processed_dir / "flow_matrices.npz"))["flow"]
    features = np.load(str(processed_dir / "node_features.npy"))
    T, N, D = features.shape
    print("  %d windows, %d zones, %d features" % (T, N, D))
    print()
    print("Stage 1: Rule annotation...")
    mean_profile, std_profile = compute_baseline_stats(features)
    labels_rule = rule_stage(features, mean_profile, std_profile, args.rule_threshold)
    print()
    print("Stage 2: Hawkes annotation...")
    labels_hawkes = hawkes_stage(features, args.hawkes_decay)
    print()
    print("Combining labels...")
    labels_final = combine_labels(labels_rule, labels_hawkes)
    out_path = str(processed_dir / "labels.npy")
    np.save(out_path, labels_final)
    print("Saved to", out_path)

if __name__ == "__main__":
    main()
