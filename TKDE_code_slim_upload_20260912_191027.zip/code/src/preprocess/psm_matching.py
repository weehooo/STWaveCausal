import numpy as np
from pathlib import Path
import argparse
from scipy.stats import wilcoxon
from scipy.spatial.distance import cdist
import warnings
warnings.filterwarnings("ignore")


def encode_combos(labels):
    T, N = labels.shape
    combo_map = {}
    for t in range(T):
        int_zones = np.where(labels[t] == 1)[0]
        if len(int_zones) == 0:
            combo_map[t] = None
        else:
            combo_map[t] = {"combo_id": t, "events": [int(z) for z in int_zones],
                            "n_events": len(int_zones), "is_multi": len(int_zones) > 1}
    return combo_map


def extract_state(features, t, zone, n_hist=3):
    if t < n_hist:
        return features[max(0, t-n_hist):t+1, zone].mean(axis=0)
    return features[t-n_hist:t, zone].mean(axis=0)


def compute_mahalanobis_features(features, t, zone, n_hist=3):
    """Feature vector for matching: [outflow, inflow, out_deg, in_deg, hour_sin]"""
    return extract_state(features, t, zone, n_hist)


def psm_matching(features, labels, combo_map, caliper=0.1, time_buffer=3):
    """Match using Euclidean distance on feature space (Mahalanobis-like)."""
    T, N = features.shape[:2]
    matches = []
    int_events = [(t, z) for t in range(T) if combo_map[t] for z in combo_map[t]["events"]]
    print("  Total intervention events:", len(int_events))
    max_samp = 30000
    if len(int_events) > max_samp:
        rng = np.random.RandomState(42)
        idx = rng.choice(len(int_events), max_samp, replace=False)
        int_events = [int_events[i] for i in idx]
        print("  Sampled", max_samp, "events")
    for i, (t, z) in enumerate(int_events):
        if (i+1) % 5000 == 0:
            print("    matched", i+1, "/", len(int_events))
        v_t = compute_mahalanobis_features(features, t, z)
        best_dist = float("inf")
        best_tt = None
        t_start = max(0, t - 7*48)
        t_end = min(T, t + 7*48)
        for tt in range(t_start, t_end):
            if abs(tt - t) < time_buffer:
                continue
            if labels[tt, z] != 0:
                continue
            v_c = compute_mahalanobis_features(features, tt, z)
            d = float(np.linalg.norm(v_t - v_c))
            if d < best_dist and d < caliper:
                best_dist = d
                best_tt = tt
        if best_tt is not None:
            matches.append({"t": int(t), "t_star": int(best_tt), "zone": int(z),
                            "feature_dist": best_dist})
    print("  Matched:", len(matches), "pairs")
    return matches


def balance_check(matches, features):
    if len(matches) == 0:
        return {"smd": {}, "passed": False}
    treated, control = [], []
    for m in matches:
        treated.append(extract_state(features, m["t"], m["zone"]))
        control.append(extract_state(features, m["t_star"], m["zone"]))
    t_arr = np.array(treated)
    c_arr = np.array(control)
    smd = {}
    for i in range(t_arr.shape[1]):
        mt, mc = t_arr[:, i].mean(), c_arr[:, i].mean()
        vt, vc = t_arr[:, i].var(), c_arr[:, i].var()
        s = np.sqrt((vt + vc) / 2) + 1e-8
        smd["feat_" + str(i)] = float(abs(mt - mc) / s)
    passed = all(v < 0.1 for v in smd.values())
    return {"smd": smd, "passed": passed}


def rosenbaum_sensitivity(matches):
    if len(matches) < 10:
        return {"gamma_max": None, "note": "too few matches"}
    diffs = np.array([m["feature_dist"] for m in matches if not np.isnan(m["feature_dist"])])
    if len(diffs) < 10:
        return {"gamma_max": None, "note": "too few valid diffs"}
    diffs = diffs - diffs.mean()
    if np.all(np.abs(diffs) < 1e-10):
        return {"gamma_max": 1.0, "note": "all diffs near zero"}
    _, p0 = wilcoxon(diffs[np.abs(diffs) > 1e-10], alternative="two-sided")
    gamma = 1.0
    while gamma < 3.0:
        adj = diffs * gamma
        adj_filt = adj[np.abs(adj) > 1e-10]
        if len(adj_filt) < 5:
            break
        _, p_g = wilcoxon(adj_filt, alternative="two-sided")
        if p_g > 0.05:
            break
        gamma += 0.2
    return {"gamma_max": round(gamma, 1), "p_baseline": float(p0)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="data/nyc_taxi")
    parser.add_argument("--caliper", type=float, default=0.1)
    parser.add_argument("--time-buffer", type=int, default=3)
    args = parser.parse_args()
    processed_dir = Path(args.data_dir) / "processed"
    print("Loading data...")
    labels = np.load(str(processed_dir / "labels.npy"))
    features = np.load(str(processed_dir / "node_features.npy"))
    T, N, D = features.shape
    print("  %d windows, %d zones, %d features" % (T, N, D))
    print()
    print("Encoding combos...")
    combo_map = encode_combos(labels)
    n_multi = sum(1 for v in combo_map.values() if v and v["is_multi"])
    print("  Multi-event windows:", n_multi)
    print()
    print("PSM Matching (Mahalanobis distance)...")
    matches = psm_matching(features, labels, combo_map, args.caliper, args.time_buffer)
    np.save(str(processed_dir / "matched_pairs.npy"), matches)
    print("  Saved matched_pairs.npy")
    print()
    print("Balance check (SMD)...")
    bal = balance_check(matches, features)
    smd_vals = list(bal["smd"].values())
    if smd_vals:
        print("  SMD: max=%.4f, mean=%.4f, passed=%s" % (
            max(smd_vals), float(np.mean(smd_vals)), str(bal["passed"])))
        if not bal["passed"]:
            print("  SMD > 0.1, recalibrating caliper...")
            args.caliper = args.caliper * 0.5
            print("  Retrying with caliper =", args.caliper)
            matches = psm_matching(features, labels, combo_map, args.caliper, args.time_buffer)
            np.save(str(processed_dir / "matched_pairs.npy"), matches)
            bal = balance_check(matches, features)
            smd_vals = list(bal["smd"].values())
            if smd_vals:
                print("  SMD: max=%.4f, mean=%.4f, passed=%s" % (
                    max(smd_vals), float(np.mean(smd_vals)), str(bal["passed"])))
    print()
    print("Rosenbaum sensitivity...")
    sens = rosenbaum_sensitivity(matches)
    if sens["gamma_max"]:
        print("  Gamma >= " + str(sens["gamma_max"]) + " to overturn")
    with open(str(processed_dir / "psm_stats.txt"), "w") as f:
        f.write("Pairs: " + str(len(matches)) + "\n")
        f.write(str(bal) + "\n")
        f.write(str(sens) + "\n")
    print()
    print("Done.")

if __name__ == "__main__":
    main()
