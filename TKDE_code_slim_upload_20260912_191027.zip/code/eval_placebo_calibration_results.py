"""Null placebo calibration with the retrained V3 checkpoint and BH q-values."""
import json
import os
import sys
from datetime import datetime, timedelta

import numpy as np
import torch
from scipy.stats import norm

BASE = os.environ.get("PAPERS_BASE", os.path.dirname(os.path.abspath(__file__)))
os.chdir(BASE)
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48
CF_OFFSET = 7 * 7 * SEQ
START = datetime(2011, 1, 1)
EXCLUDE = {
    datetime(2012, 10, 29), datetime(2011, 12, 31),
    datetime(2013, 2, 8), datetime(2011, 1, 26),
}
_adj = np.load("data/nyc_taxi/processed/adj.npy").astype(np.float32)
_adj /= np.maximum(_adj.sum(axis=1, keepdims=True), 1e-6)


def window_v3(zone, t):
    ts = max(0, t - SEQ)
    all_zones = np.asarray(feats[ts:t])
    if len(all_zones) < SEQ:
        pad = np.zeros((SEQ - len(all_zones), all_zones.shape[1],
                        all_zones.shape[2]), dtype=all_zones.dtype)
        all_zones = np.concatenate([pad, all_zones], axis=0)
    raw = all_zones[:, zone]
    ctx = np.einsum("snd,n->sd", all_zones, _adj[zone])
    return np.concatenate([raw, ctx], axis=-1)


def load_model():
    model = STWaveCausalV3(n_zones=265, input_dim=12, output_dim=6,
                           ctx_channels=6).to(device)
    model.load_state_dict(torch.load(
        "data/nyc_taxi/processed/rerun_v3_seed42.pt", map_location=device))
    model.eval()
    return model


def ace(model, zone, t, t_star):
    zid = torch.full((1, SEQ), zone, dtype=torch.long, device=device)
    ff = torch.FloatTensor(window_v3(zone, int(t))).unsqueeze(0).to(device)
    cf = torch.FloatTensor(window_v3(zone, int(t_star))).unsqueeze(0).to(device)
    with torch.no_grad():
        _, pf = model(zid, ff)
        _, pcf = model(zid, cf)
    return float(np.mean(np.abs(pf[0].cpu().numpy() -
                                  pcf[0].cpu().numpy())))


def date_z_scores(model, feats, labels, date, rng, n_placebo=150):
    t0 = int((date - START).total_seconds() / (30 * 60))
    if t0 <= CF_OFFSET + SEQ or t0 + SEQ >= feats.shape[0]:
        return []
    pre = feats[t0 - SEQ:t0, :, 0].mean(axis=0)
    post = feats[t0:t0 + SEQ, :, 0].mean(axis=0)
    zones = np.argsort(np.abs(post - pre))[::-1][:5]
    scores = []
    for zone in zones:
        observed = ace(model, int(zone), t0, t0 - CF_OFFSET)
        placebos = []
        attempts = 0
        while len(placebos) < n_placebo and attempts < 1000:
            t = int(rng.randint(SEQ + 1, feats.shape[0] - 1))
            attempts += 1
            if abs(t - t0) < 1000 or labels[t, zone] != 0:
                continue
            if t <= CF_OFFSET + SEQ:
                continue
            value = ace(model, int(zone), t, t - CF_OFFSET)
            if np.isfinite(value):
                placebos.append(value)
        if len(placebos) >= 30:
            z = (observed - float(np.mean(placebos))) / \
                (float(np.std(placebos)) + 1e-8)
            scores.append({"zone": int(zone), "z": float(z),
                           "p_one_sided": float(norm.sf(z)),
                           "n_placebo": len(placebos)})
    return scores


def benjamini_hochberg(pvalues):
    p = np.asarray(pvalues, dtype=float)
    order = np.argsort(p)
    ranked = p[order]
    q = ranked * len(p) / np.arange(1, len(p) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    q = np.minimum(q, 1.0)
    result = np.empty_like(q)
    result[order] = q
    return result


def main():
    global feats
    model = load_model()
    feats = np.load("data/nyc_taxi/processed/node_features.npy", mmap_mode="r")
    labels = np.load("data/nyc_taxi/processed/labels.npy", mmap_mode="r")
    rng = np.random.RandomState(7)
    dates = []
    while len(dates) < 15:
        date = START + timedelta(days=int(rng.randint(0, 1095)))
        if date in EXCLUDE or date.weekday() >= 5:
            continue
        dates.append(date)

    records = []
    for date in dates:
        scores = date_z_scores(model, feats, labels, date, rng)
        records.extend([{**x, "date": date.strftime("%Y-%m-%d")} for x in scores])
        print("%s pairs=%d" % (date.strftime("%Y-%m-%d"), len(scores)),
              flush=True)
    pvalues = [x["p_one_sided"] for x in records]
    qvalues = benjamini_hochberg(pvalues) if pvalues else []
    for record, q in zip(records, qvalues):
        record["q_bh"] = float(q)
    summary = {
        "n_pairs": len(records),
        "fraction_z_gt_196": float(np.mean([x["z"] > 1.96 for x in records]))
            if records else None,
        "n_q_lt_005": int(sum(q < 0.05 for q in qvalues)),
        "min_q": float(np.min(qvalues)) if len(qvalues) else None,
    }
    with open("placebo_calibration_results.json", "w", encoding="utf-8") as f:
        json.dump({"summary": summary, "pairs": records}, f, indent=2)
    print(json.dumps(summary, indent=2), flush=True)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
