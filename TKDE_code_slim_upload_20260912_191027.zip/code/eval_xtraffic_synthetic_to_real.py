"""XTraffic synthetic-to-real counterfactual magnitude pilot."""
import json

import numpy as np
import pandas as pd

WEEK = 7 * 24 * 12  # 5-minute windows in one week


def ridge_fit_predict(X, y, X_test, lam=1.0):
    X = np.column_stack([np.ones(len(X)), X])
    X_test = np.column_stack([np.ones(len(X_test)), X_test])
    A = X.T @ X + lam * np.eye(X.shape[1])
    w = np.linalg.solve(A, X.T @ y)
    return X_test @ w


def metrics(y_true, y_pred):
    ss_res = float(np.sum((y_true - y_pred) ** 2))
    ss_tot = float(np.sum((y_true - y_true.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    mae = float(np.mean(np.abs(y_true - y_pred)))
    bias = float(np.mean(y_pred - y_true))
    corr = float(np.corrcoef(y_true, y_pred)[0, 1])
    return {"r2": r2, "mae": mae, "bias": bias, "corr": corr}


def window_feature(traffic, node_idx, t0, lookback=12):
    pre_idx = np.arange(max(0, t0 - lookback), t0)
    cf_idx = pre_idx - WEEK
    if pre_idx[0] < 0 or cf_idx[0] < 0 or t0 >= traffic.shape[1]:
        return None
    fact = np.asarray(traffic[node_idx, pre_idx, :], dtype=np.float32)
    cf = np.asarray(traffic[node_idx, cf_idx, :], dtype=np.float32)
    feat = np.concatenate([
        fact.reshape(-1),
        cf.reshape(-1),
        np.array([float((t0 % 288) / 288.0),
                  float(((t0 // 288) % 7) / 7.0)], dtype=np.float32),
    ])
    if not np.isfinite(feat).all():
        return None
    return feat


def main():
    traffic_path = (
        r"C:\Users\weehoo\.cache\kagglehub\datasets\gpxlcj\xtraffic"
        r"\versions\8\year_2023\year_2023\2023_p06.npy"
    )
    node_order_path = (
        r"C:\Users\weehoo\.cache\kagglehub\datasets\gpxlcj\xtraffic"
        r"\versions\8\node_order.npy"
    )
    traffic = np.load(traffic_path, mmap_mode="r")
    node_order = np.load(node_order_path)
    node_to_idx = {int(sid): i for i, sid in enumerate(node_order)}

    val = pd.read_csv("real_incident_validation.csv")
    val["dt"] = pd.to_datetime(val["dt"])
    val["t0"] = ((val["dt"] - pd.Timestamp("2023-06-01"))
                 .dt.total_seconds() // 300).astype(int)
    val = val.dropna(subset=["effect"])

    real_feats = []
    real_effects = []
    for _, row in val.iterrows():
        idx = node_to_idx.get(int(row["sensor_id"]))
        if idx is None:
            continue
        feat = window_feature(traffic, idx, int(row["t0"]))
        if feat is None:
            continue
        if not np.isfinite(float(row["effect"])):
            continue
        real_feats.append(feat)
        real_effects.append(float(row["effect"]))
        if len(real_feats) >= 500:
            break

    rng = np.random.RandomState(20260908)
    node_ids = list(node_to_idx.values())
    synthetic_feats = []
    synthetic_effects = []
    while len(synthetic_feats) < 2000:
        idx = int(rng.choice(node_ids))
        t0 = int(rng.randint(WEEK + 12, traffic.shape[1] - 1))
        base = window_feature(traffic, idx, t0)
        if base is None:
            continue
        factor = float(rng.choice([0.70, 0.80, 0.85]))
        # Create synthetic feature by perturbing the first half of the
        # flattened factual window and keeping the clean-week context fixed.
        synth = base.copy()
        fact_len = 12 * 3
        synth[:fact_len] *= factor
        target = float(np.mean(
            np.asarray(traffic[idx, max(0, t0 - 12):t0, 0], dtype=np.float32) *
            (factor - 1.0)
        ))
        if not np.isfinite(target):
            continue
        synthetic_feats.append(synth)
        synthetic_effects.append(target)

    X_syn = np.stack(synthetic_feats).astype(np.float64)
    y_syn = np.array(synthetic_effects)
    X_real = np.stack(real_feats).astype(np.float64)
    y_real = np.array(real_effects)

    mean = X_syn.mean(axis=0)
    std = X_syn.std(axis=0)
    std = np.where(std > 1e-6, std, 1.0)
    X_syn = (X_syn - mean) / std
    X_real = (X_real - mean) / std
    pred = ridge_fit_predict(X_syn, y_syn, X_real, lam=1.0)
    baseline = np.full_like(y_real, float(y_syn.mean()))
    out = {
        "n_synthetic": int(len(X_syn)),
        "n_real": int(len(X_real)),
        "baseline_mean": metrics(y_real, baseline),
        "synthetic_to_real": metrics(y_real, pred),
    }
    with open("xtraffic_synthetic_to_real.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)


if __name__ == "__main__":
    main()
