"""Donor-free transfer check for the real-data magnitude head.

Train a ridge magnitude head on PEMS-BAY incident embeddings and covariates,
then apply it to NYC natural events. The NYC targets are donor-matched DiD
effects where donors exist, so the test measures whether magnitude signal
transfers across cities and event regimes.
"""
import json
import os
import sys
from datetime import datetime

import numpy as np
import torch

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

import eval_causal_estimators as ec
from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"


def ridge_fit_predict(X, y, X_test, lam):
    X = np.column_stack([np.ones(len(X)), X])
    X_test = np.column_stack([np.ones(len(X_test)), X_test])
    A = X.T @ X + lam * np.eye(X.shape[1])
    w = np.linalg.solve(A, X.T @ y)
    return X_test @ w


def metrics(y_true, y_pred):
    ss_res = float(np.sum((y_true - y_pred) ** 2))
    ss_tot = float(np.sum((y_true - y_true.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    mae = float(np.mean(np.abs(y_true - y_pred)))
    bias = float(np.mean(y_pred - y_true))
    corr = float(np.corrcoef(y_true, y_pred)[0, 1])
    return {"r2": r2, "mae": mae, "bias": bias, "corr": corr}


def main():
    model = STWaveCausalV3(
        n_zones=265, input_dim=12, output_dim=6, ctx_channels=6,
        ctx_gate=True,
    ).to(device)
    model.load_state_dict(torch.load(
        "data/nyc_taxi/processed/rerun_v3_seed42.pt", map_location=device))
    model.eval()

    data = np.load("pemsbay_magnitude_features.npz")
    X_src = data["X"].astype(np.float64)
    y_src = data["y"].astype(np.float64)
    src_cols = list(range(128)) + list(range(144, 148))
    X_src = X_src[:, src_cols]
    mean = X_src.mean(axis=0)
    std = X_src.std(axis=0) + 1e-8
    X_src = (X_src - mean) / std

    # Select ridge lambda on a chronological validation slice of PEMS-BAY.
    order = np.argsort(data["starts"])
    X_src, y_src = X_src[order], y_src[order]
    cut = int(len(X_src) * 0.8)
    best = None
    for lam in [0.1, 1.0, 10.0, 100.0, 1000.0]:
        pred_val = ridge_fit_predict(X_src[:cut], y_src[:cut],
                                     X_src[cut:], lam)
        val_mae = float(np.mean(np.abs(y_src[cut:] - pred_val)))
        if best is None or val_mae < best[0]:
            best = (val_mae, lam)
    _, lam = best

    comparison = json.load(
        open("causal_estimator_comparison.json", encoding="utf-8"))
    rows = comparison["rows"]
    event_dates = {name: datetime.strptime(date, "%Y-%m-%d")
                   for date, name in ec.EVENTS}

    feats = []
    targets = []
    meta = []
    with torch.no_grad():
        for r in rows:
            event = r["event"]
            if event not in event_dates:
                continue
            date = event_dates[event]
            t0 = int((date - ec.start).total_seconds() / 1800)
            t_cf = t0 - ec.CF_OFFSET
            zone = int(r["zone"])
            ff = torch.FloatTensor(
                ec.window_v3(zone, t0)).unsqueeze(0).to(device)
            cf = torch.FloatTensor(
                ec.window_v3(zone, t_cf)).unsqueeze(0).to(device)
            zid = torch.full((1, ec.SEQ), zone, dtype=torch.long,
                             device=device)
            h_f, pred_f = model(zid, ff)
            h_cf, pred_cf = model(zid, cf)
            cov = np.array([
                0.0,
                0.0,
                float((t0 % 48) / 48.0),
                float(((t0 // 48) % 7) / 7.0),
            ], dtype=np.float32)
            feature = np.concatenate([
                h_f[0].cpu().numpy(),
                h_cf[0].cpu().numpy(),
                cov,
            ])
            feats.append(feature)
            targets.append(float(r["did"]))
            meta.append({"event": event, "zone": zone})

    X_tgt = np.stack(feats).astype(np.float64)
    y_tgt = np.array(targets)
    X_tgt = (X_tgt - mean) / std
    pred = ridge_fit_predict(X_src, y_src, X_tgt, lam)
    baseline = np.full_like(y_tgt, float(y_src.mean()))

    out = {
        "n_source": int(len(X_src)),
        "n_target": int(len(y_tgt)),
        "lambda": lam,
        "baseline_mean": metrics(y_tgt, baseline),
        "donor_free_transfer": metrics(y_tgt, pred),
    }
    with open("magnitude_donor_free_transfer.json", "w",
              encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)
    print("Wrote magnitude_donor_free_transfer.json", flush=True)


if __name__ == "__main__":
    main()
