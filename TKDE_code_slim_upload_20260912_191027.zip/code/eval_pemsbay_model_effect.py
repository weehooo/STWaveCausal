"""Compare the PEMS-BAY V3 model effect with the model-free event-study DiD.

For each documented PEMS-BAY incident, the factual window is the affected
sensor history at the incident start. The counterfactual window is the same
sensor seven days earlier, matching the clean-day counterfactual used by the
event study. The signed model effect is predicted counterfactual speed minus
predicted factual speed, compared with the model-free event-study post effect.
"""
import json
import os
import sys

import numpy as np
import torch

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, "src/model")

from stwave_causal_v3 import STWaveCausalV3
from eval_pemsbay_eventsudy import load_incidents

device = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48
CF_OFFSET = 7 * 24 * 12
SPEED_CH = 0


def make_window(feats, adj, zone, t):
    t_start = max(0, t - SEQ)
    w_all = feats[t_start:t]
    if len(w_all) < SEQ:
        pad = np.zeros((SEQ - len(w_all), feats.shape[1], feats.shape[2]),
                       dtype=np.float32)
        w_all = np.concatenate([pad, w_all], axis=0)
    raw = w_all[:, zone].astype(np.float32)
    ctx = np.einsum("snd,n->sd", w_all.astype(np.float32),
                    adj[zone].astype(np.float32))
    ctx = ctx - raw
    return np.concatenate([raw, ctx], axis=-1)


def main():
    sensor_ids = [str(v) for v in
                  np.load("data/pems_bay/processed/sensor_ids.npy",
                          allow_pickle=True)]
    idx = {sensor_id: i for i, sensor_id in enumerate(sensor_ids)}
    feats = np.load("data/pems_bay/processed/node_features.npy",
                    mmap_mode="r")
    adj = np.load("data/pems_bay/processed/adj.npy").astype(np.float32)
    adj = adj / np.maximum(adj.sum(axis=1, keepdims=True), 1e-6)

    model = STWaveCausalV3(
        n_zones=325,
        input_dim=16,
        output_dim=8,
        ctx_channels=8,
        ctx_gate=False,
    ).to(device)
    model.load_state_dict(torch.load(
        "data/pems_bay/processed/stwave_causal_v3_graphctx_grad_pemsbay_best.pt",
        map_location=device,
    ))
    model.eval()

    events = load_incidents(
        "data/pems_bay/raw/kaggle_extract/pems_bay_incidents.csv")
    event_study = json.load(
        open("pemsbay_eventsudy_results.json", encoding="utf-8"))
    study_by_id = {
        row["incident_id"]: row for row in event_study["per_event"]
    }

    rows = []
    with torch.no_grad():
        for e in events:
            sid = e["sensor_id"]
            if sid not in idx or e["incident_id"] not in study_by_id:
                continue
            z = idx[sid]
            t0 = e["start_idx"]
            t_cf = t0 - CF_OFFSET
            if t0 < SEQ or t_cf < 0:
                continue
            ff = torch.FloatTensor(
                make_window(feats, adj, z, t0)).unsqueeze(0).to(device)
            cf = torch.FloatTensor(
                make_window(feats, adj, z, t_cf)).unsqueeze(0).to(device)
            zid = torch.full((1, SEQ), z, dtype=torch.long, device=device)
            _, pred_f = model(zid, ff)
            _, pred_cf = model(zid, cf)
            model_effect = float(pred_cf[0, SPEED_CH].item() -
                                 pred_f[0, SPEED_CH].item())
            curve = study_by_id[e["incident_id"]]["curve"]
            post_effect = float(np.mean(curve[6:]))
            rows.append({
                "incident_id": e["incident_id"],
                "sensor_id": sid,
                "start_idx": int(t0),
                "model_effect": model_effect,
                "event_study_post_effect": post_effect,
            })

    model_effect = np.array([r["model_effect"] for r in rows])
    study_effect = np.array([r["event_study_post_effect"] for r in rows])
    corr = float(np.corrcoef(model_effect, study_effect)[0, 1])
    mae = float(np.abs(model_effect - study_effect).mean())
    ratio = float(np.median(model_effect / (study_effect + 1e-6)))
    within20 = float(np.mean(
        np.abs(model_effect - study_effect) <=
        0.20 * (np.abs(study_effect) + 1e-6)))

    out = {
        "n_events": int(len(rows)),
        "summary": {
            "corr": corr,
            "mae": mae,
            "median_ratio": ratio,
            "within20pct": within20,
        },
        "rows": rows,
    }
    with open("pemsbay_model_effect_comparison.json", "w",
              encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print("n_events=%d corr=%.4f MAE=%.4f median_ratio=%.3f within20=%.3f" %
          (len(rows), corr, mae, ratio, within20), flush=True)
    print("Wrote pemsbay_model_effect_comparison.json", flush=True)


if __name__ == "__main__":
    main()
