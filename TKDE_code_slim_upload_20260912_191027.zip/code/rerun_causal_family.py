"""P3-1: retrain STWaveCausal V3 + STIDCausal on all datasets with new pairs."""
import subprocess
import sys
from datetime import datetime
from pathlib import Path

BASE = Path(r"F:\xuexi\codex\papers")
PY = r"F:\Anaconda3\python.exe"
SEEDS = [42, 1, 2, 3, 4]

DATASETS = {
    "nyc_taxi": {"zones": 265, "dim": 6, "v3_epochs": 50, "v3_pretrain": 0,
                 "ctx_mode": "mean"},
    "pems_bay": {"zones": 325, "dim": 8, "v3_epochs": 70, "v3_pretrain": 50,
                 "ctx_mode": "gradient"},
    "pems08": {"zones": 170, "dim": 1, "v3_epochs": 90, "v3_pretrain": 70,
               "ctx_mode": "mean",
               "meta": "data/datasets/pems08_staeformer/data.npz"},
    "pems04": {"zones": 307, "dim": 1, "v3_epochs": 90, "v3_pretrain": 70,
               "ctx_mode": "mean",
               "meta": "data/datasets/pems04_staeformer/data.npz"},
}


def run(cmd, tag):
    out_log = BASE / ("rerun_%s_out.log" % tag)
    err_log = BASE / ("rerun_%s_err.log" % tag)
    print("[%s] start %s" % (datetime.now().strftime("%H:%M:%S"), tag),
          flush=True)
    with out_log.open("w") as fo, err_log.open("w") as fe:
        p = subprocess.Popen(cmd, cwd=str(BASE), stdout=fo, stderr=fe)
        code = p.wait()
    if code != 0:
        raise SystemExit("%s exited with code %d" % (tag, code))
    print("[%s] done  %s" % (datetime.now().strftime("%H:%M:%S"), tag),
          flush=True)


def v3_cmd(name, cfg, seed):
    data = str(BASE / "data" / name / "processed")
    out = str(Path(data) / ("rerun_v3_seed%d.pt" % seed))
    cmd = [
        PY, "train_causal_v3_full.py",
        "--data", data,
        "--synthetic", str(Path(data) / "synthetic_pairs_v3_graphctx.npy"),
        "--n-zones", str(cfg["zones"]),
        "--feature-dim", str(cfg["dim"]),
        "--epochs", str(cfg["v3_epochs"]),
        "--pretrain-epochs", str(cfg["v3_pretrain"]),
        "--out", out,
        "--seed", str(seed),
        "--graph-ctx",
        "--ctx-mode", cfg["ctx_mode"],
        "--ctx-gate",
    ]
    if cfg.get("meta"):
        cmd += ["--meta-file", str(BASE / cfg["meta"])]
    return cmd


def stid_cmd(name, cfg, seed):
    data = str(BASE / "data" / name / "processed")
    out = str(Path(data) / ("rerun_stid_seed%d.pt" % seed))
    return [
        PY, "train_causal_stid.py",
        "--data", data,
        "--synthetic", str(Path(data) / "synthetic_pairs_fullnode.npy"),
        "--n-zones", str(cfg["zones"]),
        "--feature-dim", str(cfg["dim"]),
        "--epochs", "130",
        "--pretrain-epochs", "110",
        "--batch-size", "8",
        "--out", out,
        "--seed", str(seed),
    ]


def main():
    for name, cfg in DATASETS.items():
        for seed in SEEDS:
            tag_v3 = "%s_v3_seed%d" % (name, seed)
            tag_stid = "%s_stid_seed%d" % (name, seed)
            done_v3 = BASE / ("rerun_%s.done" % tag_v3)
            done_stid = BASE / ("rerun_%s.done" % tag_stid)
            if not done_v3.exists():
                run(v3_cmd(name, cfg, seed), tag_v3)
                done_v3.write_text("done\n", encoding="utf-8")
            else:
                print("skip (done): %s" % tag_v3, flush=True)
            if not done_stid.exists():
                run(stid_cmd(name, cfg, seed), tag_stid)
                done_stid.write_text("done\n", encoding="utf-8")
            else:
                print("skip (done): %s" % tag_stid, flush=True)
    (BASE / "rerun_causal_family.done").write_text("done\n", encoding="utf-8")
    print("ALL P3-1 RERUN DONE", flush=True)


if __name__ == "__main__":
    sys.exit(main())
