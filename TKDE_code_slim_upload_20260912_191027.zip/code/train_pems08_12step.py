"""Train the paper's predictor family under the official PEMS08 12-step
protocol, for a fair comparison against the official STAEformer.

All models use full-graph windows (B, T, N, D). A training-window subsample
is supported to fit the available GPU budget; the official test split is
always evaluated in full.
"""
import argparse
import copy
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn

sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from models_12step import (
    STWave12FG,
    CrossGNN12FG,
    SWPred12FG,
    STIDGraph12,
    STWaveCausal12FG,
)
from train_staeformer_official_pems08 import vrange, StandardScaler


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--model", choices=["stwave", "crossgnn", "predonly", "stidgraph", "v3"],
                   required=True)
    p.add_argument("--data", default="data/datasets/pems08_staeformer")
    p.add_argument("--out", default=None)
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--max-windows", type=int, default=2000)
    p.add_argument("--seed", type=int, default=42)
    return p.parse_args()


def load_data(data_dir, max_windows):
    data = np.load(str(Path(data_dir) / "data.npz"))["data"].astype(np.float32)
    index = np.load(str(Path(data_dir) / "index.npz"))

    def split(key, limit):
        idx = index[key][:limit]
        x = data[vrange(idx[:, 0], idx[:, 1])]
        y = data[vrange(idx[:, 1], idx[:, 2])][..., :1]
        return torch.FloatTensor(x), torch.FloatTensor(y)

    x_train, y_train = split("train", max_windows)
    x_val, y_val = split("val", max_windows)
    x_test, y_test = split("test", None)
    scaler = StandardScaler()
    scaler.fit(x_train[..., 0].numpy())
    for x in (x_train, x_val, x_test):
        x[..., 0] = torch.FloatTensor(scaler.transform(x[..., 0].numpy()))
    return (x_train, y_train), (x_val, y_val), (x_test, y_test), scaler


def mae_rmse_mape(y_true, y_pred):
    mask = np.not_equal(y_true, 0).astype(np.float32)
    mask = mask / max(np.mean(mask), 1e-6)
    mae = np.nan_to_num(np.abs(y_pred - y_true) * mask)
    rmse = np.sqrt(np.mean(np.nan_to_num(np.square(np.abs(y_pred - y_true)) * mask)))
    with np.errstate(divide="ignore", invalid="ignore"):
        mape = np.abs(np.divide((y_pred - y_true).astype(np.float32), y_true))
        mape = np.nan_to_num(mask * mape)
    return float(rmse), float(mae.mean()), float(mape.mean() * 100)


def main():
    args = parse_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Device:", device, flush=True)
    torch.backends.cudnn.benchmark = True
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    (x_train, y_train), (x_val, y_val), (x_test, y_test), scaler = load_data(
        args.data, args.max_windows)
    print("Train/Val/Test windows:",
          x_train.shape, x_val.shape, x_test.shape, flush=True)

    if args.model in ("stidgraph", "v3"):
        adj = torch.FloatTensor(
            np.load("data/pems08/processed/adj.npy")).to(device)
    else:
        adj = None

    def make_loader(x, y, shuffle):
        return torch.utils.data.DataLoader(
            torch.utils.data.TensorDataset(x, y),
            batch_size=args.batch_size, shuffle=shuffle)

    tl = make_loader(x_train, y_train, True)
    vl = make_loader(x_val, y_val, False)
    tsl = make_loader(x_test, y_test, False)

    if args.model == "stwave":
        model = STWave12FG(n_zones=170, input_dim=3, hidden_dim=64,
                           n_blocks=2, seq_len=12, out_steps=12).to(device)
    elif args.model == "crossgnn":
        model = CrossGNN12FG(n_zones=170, input_dim=3, hidden_dim=64,
                             n_blocks=2, n_heads=4, seq_len=12,
                             out_steps=12).to(device)
    elif args.model == "predonly":
        model = SWPred12FG(n_zones=170, input_dim=3, hidden_dim=64,
                           n_blocks=2, seq_len=12, out_steps=12).to(device)
    elif args.model == "stidgraph":
        model = STIDGraph12(n_zones=170, input_dim=3, hidden_dim=64,
                            seq_len=12, n_layers=2, n_days=7,
                            out_steps=12).to(device)
    else:
        model = STWaveCausal12FG(n_zones=170, input_dim=4, hidden_dim=64,
                                 n_blocks=2, seq_len=12, out_steps=12,
                                 adj=adj.cpu().numpy()).to(device)
    print("Params:", sum(p.numel() for p in model.parameters()), flush=True)

    criterion = nn.HuberLoss()
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=args.epochs)
    out = Path(args.out or ("data/pems08/processed/%s_12step_best.pt" % args.model))
    out.parent.mkdir(parents=True, exist_ok=True)
    best_loss = float("inf")
    best_state = None

    def forward_batch(xb):
        if args.model == "stidgraph":
            return model(xb, adj).permute(0, 2, 1, 3)  # (B, out, N, D)
        return model(xb).permute(0, 2, 1, 3)           # (B, out, N, D)

    for ep in range(args.epochs):
        model.train()
        t0 = time.time()
        losses = []
        for xb, yb in tl:
            xb, yb = xb.to(device), yb.to(device)
            pred = forward_batch(xb)
            loss = criterion(scaler.inverse_transform(pred), yb)
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            losses.append(loss.item())
        sched.step()

        model.eval()
        vlosses = []
        with torch.no_grad():
            for xb, yb in vl:
                xb, yb = xb.to(device), yb.to(device)
                pred = forward_batch(xb)
                vlosses.append(criterion(
                    scaler.inverse_transform(pred), yb).item())
        val_loss = float(np.mean(vlosses))
        if val_loss < best_loss:
            best_loss = val_loss
            best_state = copy.deepcopy(model.state_dict())
            torch.save(best_state, str(out))
            print("  * best val %.5f saved (ep %d)" % (best_loss, ep + 1), flush=True)
        if (ep + 1) % 2 == 0 or ep == 0:
            print("Ep %2d/%d: val=%.5f best=%.5f (%.1fs)" %
                  (ep + 1, args.epochs, val_loss, best_loss, time.time() - t0),
                  flush=True)

    if best_state is not None:
        model.load_state_dict(best_state)
    model.eval()
    ys, ps = [], []
    with torch.no_grad():
        for xb, yb in tsl:
            xb, yb = xb.to(device), yb.to(device)
            pred = forward_batch(xb)
            ys.append(yb.cpu().numpy())
            ps.append(scaler.inverse_transform(pred).cpu().numpy())
    y_true = np.concatenate(ys).reshape(-1, 12, 170, 1).squeeze(-1)
    y_pred = np.concatenate(ps).reshape(-1, 12, 170, 1).squeeze(-1)
    rmse, mae, mape = mae_rmse_mape(y_true, y_pred)
    print("Test All Steps RMSE=%.4f MAE=%.4f MAPE=%.4f" % (rmse, mae, mape), flush=True)
    for i in range(12):
        r, m, mp = mae_rmse_mape(y_true[:, i, :], y_pred[:, i, :])
        print("Step %2d RMSE=%.4f MAE=%.4f MAPE=%.4f" % (i + 1, r, m, mp), flush=True)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
