"""Refresh NYC synthetic recovery for the new V3 checkpoint (graph-ctx pairs)."""
import argparse
import os
import sys
import json

import numpy as np
import torch

BASE = os.environ.get("PAPERS_BASE", os.path.dirname(os.path.abspath(__file__)))
os.chdir(BASE)
sys.path.insert(0, "src/model")

from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"


def batch(samples, start, size):
    b = samples[start:start + size]
    zones = torch.zeros(len(b), 48, dtype=torch.long)
    ff = torch.zeros(len(b), 48, 12)
    cf = torch.zeros(len(b), 48, 12)
    ice = torch.zeros(len(b), 6)
    et = torch.full((len(b), 5), -1, dtype=torch.long)
    el = torch.zeros(len(b), 5, 2)
    etm = torch.zeros(len(b), 5)
    zs = torch.zeros(len(b), 5, 12)
    for i, d in enumerate(b):
        zones[i] = d["zone"]
        ff[i] = d["factual"]
        cf[i] = d["cf"]
        ice[i] = d["ice_true"]
        c = d["combo"]
        et[i] = c["event_types"]
        el[i] = c["event_locs"]
        etm[i] = c["event_times"]
        zs[i] = c["zone_states"]
    return {"zones": zones.to(device), "ff": ff.to(device),
            "cf": cf.to(device), "ice": ice.to(device), "et": et.to(device),
            "el": el.to(device), "etm": etm.to(device), "zs": zs.to(device)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", default="data/nyc_taxi/processed/"
                                       "rerun_v3_seed42.pt")
    ap.add_argument("--synthetic", default="data/nyc_taxi/processed/"
                                            "synthetic_pairs_v3_graphctx.npy")
    ap.add_argument("--output", default="synthetic_recovery_new.json")
    args = ap.parse_args()
    syn = np.load(args.synthetic, allow_pickle=True).item()
    test = syn["test"]
    model = STWaveCausalV3(n_zones=265, input_dim=12, output_dim=6,
                           ctx_channels=6).to(device)
    model.load_state_dict(torch.load(args.ckpt, map_location=device))
    model.eval()
    ests = []
    trues = []
    win = []
    last = []
    with torch.no_grad():
        for i in range(0, len(test), 64):
            b = batch(test, i, 64)
            combo = {"event_types": b["et"], "event_locs": b["el"],
                     "event_times": b["etm"], "zone_states": b["zs"]}
            e = model.causal_effect(
                {"zone_ids": b["zones"], "features": b["ff"]},
                {"zone_ids": b["zones"], "features": b["cf"]}, combo)
            ests.append(e[:, 0].cpu().numpy())
            trues.append(b["ice"][:, 0].cpu().numpy())
            ff = b["ff"].cpu().numpy()
            cf = b["cf"].cpu().numpy()
            win.append(np.abs(ff - cf)[..., 0].mean(axis=1))
            last.append(np.abs(ff - cf)[:, -1, 0])
    est = np.concatenate(ests)
    true = np.concatenate(trues)
    rows = {"V3_CausalEffectHead": (est, {}),
            "Window_difference": (np.concatenate(win), {}),
            "Last_step_difference": (np.concatenate(last), {})}
    out = {}
    for name, (x, _) in rows.items():
        out[name] = {
            "corr": float(np.corrcoef(x, true)[0, 1]),
            "median_ratio": float(np.median(x / (true + 1e-6))),
            "mae": float(np.abs(x - true).mean()),
        }
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
