"""Compare V3 ACE with standard causal estimators on real NYC events.

Estimators per affected zone: before-after, difference-in-differences with a
matched donor pool, ridge synthetic control, V3 ACE, PredOnly ACE.
Reference for comparison: synthetic-control effect and observed reduction.
"""
import json
import os
import sys
from datetime import datetime

import numpy as np
import torch
import torch.nn as nn

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, "src/model")

from stwave import STWaveBlock
from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48
CF_OFFSET = 7 * 7 * SEQ
start = datetime(2011, 1, 1)
feats = np.load("data/nyc_taxi/processed/node_features.npy",
                mmap_mode="r")
_adj = np.load("data/nyc_taxi/processed/adj.npy").astype(np.float32)
_adj = _adj / np.maximum(_adj.sum(axis=1, keepdims=True), 1e-6)

EVENTS = [
    ("2012-10-29", "Hurricane Sandy"),
    ("2011-12-31", "New Year's Eve"),
    ("2013-02-08", "Winter Storm Nemo"),
    ("2011-10-29", "October nor'easter"),
    ("2012-11-07", "Post-Sandy nor'easter"),
    ("2011-08-28", "Hurricane Irene"),
]


class SWPred(nn.Module):
    def __init__(self, nz, nd, h=64, b=2):
        super().__init__()
        self.zone_embed = nn.Embedding(nz, h)
        self.input_proj = nn.Linear(nd, h)
        self.pos_embed = nn.Embedding(48, h)
        self.blocks = nn.ModuleList([STWaveBlock(nz, h) for _ in range(b)])
        self.pred_head = nn.Sequential(nn.Linear(h, h), nn.ReLU(),
                                       nn.Linear(h, nd))

    def forward(self, zid, feats):
        B, S, D = feats.shape
        x = self.input_proj(feats)
        pos = torch.arange(S, device=feats.device).unsqueeze(0).expand(B, -1)
        x = (self.zone_embed(zid) + x + self.pos_embed(pos)).unsqueeze(1)
        for blk in self.blocks:
            x = blk(x)
        return self.pred_head(x[:, 0, -1, :])


def window_raw(zone, t):
    ts = max(0, t - SEQ)
    w = feats[ts:t, zone].copy()
    if len(w) < SEQ:
        w = np.concatenate([np.zeros((SEQ - len(w), 6)), w])
    return w


def window_v3(zone, t):
    ts = max(0, t - SEQ)
    w_all = feats[ts:t]
    if len(w_all) < SEQ:
        pad = np.zeros((SEQ - len(w_all), feats.shape[1], feats.shape[2]),
                       dtype=w_all.dtype)
        w_all = np.concatenate([pad, w_all], axis=0)
    raw = w_all[:, zone]
    ctx = np.einsum("snd,n->sd", w_all, _adj[zone])
    return np.concatenate([raw, ctx], axis=-1)


@torch.no_grad()
def ace(model, zone, t, t_star):
    zid = torch.full((1, SEQ), zone, dtype=torch.long, device=device)
    if hasattr(model, "causal_head"):
        ff = torch.FloatTensor(window_v3(zone, t)).unsqueeze(0).to(device)
        cf = torch.FloatTensor(window_v3(zone, t_star)).unsqueeze(0).to(device)
        _, pf = model(zid, ff)
        _, pcf = model(zid, cf)
    else:
        ff = torch.FloatTensor(window_raw(zone, t)).unsqueeze(0).to(device)
        cf = torch.FloatTensor(window_raw(zone, t_star)).unsqueeze(0).to(device)
        pf = model(zid, ff)
        pcf = model(zid, cf)
    return float(np.mean(np.abs(pf[0].cpu().numpy() - pcf[0].cpu().numpy())))


def ridge_sc(y, X):
    """Ridge weights mapping donor flows X to treated flow y."""
    lam = 1e-3
    A = X.T @ X + lam * np.eye(X.shape[1])
    return np.linalg.solve(A, X.T @ y)


def main():
    v3 = STWaveCausalV3(n_zones=265, input_dim=12, output_dim=6,
                        ctx_channels=6, ctx_gate=True).to(device)
    v3.load_state_dict(torch.load(
        "data/nyc_taxi/processed/rerun_v3_seed42.pt",
        map_location=device))
    po = SWPred(265, 6).to(device)
    po.load_state_dict(torch.load(
        "data/nyc_taxi/processed/stwave_predonly_50ep_seed1.pt",
        map_location=device))
    v3.eval()
    po.eval()
    print("Device:", device, flush=True)

    rows = []
    pre_len = 4 * 7 * SEQ
    for dstr, name in EVENTS:
        date = datetime.strptime(dstr, "%Y-%m-%d")
        t0 = int((date - start).total_seconds() / (30 * 60))
        t_star = t0 - CF_OFFSET
        pre_start = t_star - pre_len
        if pre_start < 0 or t0 + SEQ >= feats.shape[0]:
            print("skip", name, "out of range", flush=True)
            continue
        zones = list(range(feats.shape[1]))
        baseline = np.array([feats[t_star:t_star + SEQ, z, 0].mean()
                             for z in zones])
        event_flow = np.array([feats[t0:t0 + SEQ, z, 0].mean()
                               for z in zones])
        drop = (baseline - event_flow) / np.maximum(baseline, 1e-6)
        affected = [z for z in zones
                    if baseline[z] >= 5 and drop[z] > 0.4]
        usable = 0
        donor_counts = []
        if not affected:
            print("no affected zones:", name, flush=True)
            continue
        for z in affected:
            donors = [d for d in zones if d != z and baseline[d] >= 2
                      and drop[d] <= 0.35
                      and 0.25 * baseline[z] <= baseline[d]
                      <= 4.0 * baseline[z]]
            donors.sort(key=lambda d: abs(np.log(
                max(baseline[d], 1e-6) / max(baseline[z], 1e-6))))
            donors = donors[:60]
            if len(donors) < 5:
                continue
            usable += 1
            donor_counts.append(len(donors))
            X = np.stack([feats[pre_start:t_star, d, 0] for d in donors],
                         axis=1).astype(np.float64)
            y = feats[pre_start:t_star, z, 0].astype(np.float64)
            w = ridge_sc(y, X)
            X_ev = np.stack([feats[t0:t0 + SEQ, d, 0] for d in donors],
                            axis=1).astype(np.float64)
            pred_ev = float(np.mean(X_ev @ w))
            sc_effect = max(0.0, pred_ev - float(event_flow[z]))
            control_ev = float(np.mean([event_flow[d] for d in donors]))
            control_base = float(np.mean([baseline[d] for d in donors]))
            before_after = float(baseline[z] - event_flow[z])
            did_effect = before_after - (control_base - control_ev)
            rows.append({
                "event": name, "zone": int(z),
                "actual_drop": float(drop[z]),
                "before_after": before_after,
                "did": float(max(0.0, did_effect)),
                "sc": sc_effect,
                "v3_ace": ace(v3, z, t0, t_star),
                "predonly_ace": ace(po, z, t0, t_star),
            })
        print("%-22s affected=%d usable=%d donors(med)=%.0f total_rows=%d" %
              (name, len(affected), usable,
               float(np.median(donor_counts)) if donor_counts else 0,
               len(rows)), flush=True)

    arr = np.array([[r["actual_drop"], r["before_after"], r["did"],
                     r["sc"], r["v3_ace"], r["predonly_ace"]]
                    for r in rows])
    labels = ["actual_drop", "before_after", "did", "sc", "v3_ace",
              "predonly_ace"]
    ref = arr[:, 3]
    print("\nReference = synthetic control (n=%d zones)" % len(rows))
    print("%-14s %8s %8s %10s %10s" %
          ("estimator", "corr", "MAE", "med ratio", "within20%"))
    out = {}
    for j, lab in enumerate(labels):
        est = arr[:, j]
        corr = float(np.corrcoef(est, ref)[0, 1])
        mae = float(np.abs(est - ref).mean())
        ratio = float(np.median(est / (ref + 1e-6)))
        within = float(np.mean(np.abs(est - ref) <= 0.2 * (ref + 1e-6)))
        print("%-14s %8.3f %8.3f %10.3f %10.3f" %
              (lab, corr, mae, ratio, within))
        out[lab] = {"corr": corr, "mae": mae, "median_ratio": ratio,
                    "within20pct": within}
    with open("causal_estimator_comparison.json", "w",
              encoding="utf-8") as f:
        json.dump({"rows": rows, "summary": out}, f, indent=2)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
