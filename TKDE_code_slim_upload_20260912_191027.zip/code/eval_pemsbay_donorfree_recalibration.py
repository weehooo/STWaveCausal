"""PEMS-BAY donor-free recalibration check for the magnitude head.

The model-free event study provides two targets per incident: a donor-matched
post effect and a donor-free same-clock clean-day post effect. This script
trains a ridge magnitude head on one target and evaluates on the other target
under a chronological split, to test whether the head can be recalibrated for
settings where donor pools are unavailable.
"""
import json

import numpy as np


def ridge_fit_predict(X, y, X_test, lam):
    X = np.column_stack([np.ones(len(X)), X])
    X_test = np.column_stack([np.ones(len(X_test)), X_test])
    A = X.T @ X + lam * np.eye(X.shape[1])
    w = np.linalg.solve(A, X.T @ y)
    return X_test @ w


def metrics(y_true, y_pred):
    ss_res = float(np.sum((y_true - y_pred) ** 2))
    ss_tot = float(np.sum((y_true - y_true.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    mae = float(np.mean(np.abs(y_true - y_pred)))
    bias = float(np.mean(y_pred - y_true))
    corr = float(np.corrcoef(y_true, y_pred)[0, 1])
    return {"r2": r2, "mae": mae, "bias": bias, "corr": corr}


def main():
    data = np.load("pemsbay_magnitude_features.npz")
    X = data["X"].astype(np.float64)
    ids = data["ids"]
    starts = data["starts"]
    study = json.load(open("pemsbay_eventsudy_results.json", encoding="utf-8"))
    by_id = {r["incident_id"]: r for r in study["per_event"]}

    same_clock = []
    donor = []
    valid = []
    for i, incident_id in enumerate(ids):
        row = by_id.get(str(incident_id))
        if row is None:
            continue
        same_clock.append(float(np.mean(row["curve"][6:])))
        donor.append(float(np.mean(row["donor_curve"][6:]))
                     if row.get("donor_curve") else np.nan)
        valid.append(i)

    X = X[np.array(valid)]
    starts = starts[np.array(valid)]
    same_clock = np.array(same_clock)
    donor = np.array(donor)
    order = np.argsort(starts)
    X, starts = X[order], starts[order]
    same_clock, donor = same_clock[order], donor[order]

    n = len(X)
    train = np.arange(0, int(n * 0.70))
    test = np.arange(int(n * 0.70), n)
    mean = X[train].mean(axis=0)
    std = X[train].std(axis=0) + 1e-8
    X_train = (X[train] - mean) / std
    X_test = (X[test] - mean) / std

    def fit_best(ytrain, ytest, target_name):
        best = None
        for lam in [0.1, 1.0, 10.0, 100.0, 1000.0]:
            cut = int(len(X_train) * 0.8)
            pred_val = ridge_fit_predict(X_train[:cut], ytrain[:cut],
                                         X_train[cut:], lam)
            val_mae = float(np.mean(np.abs(ytrain[cut:] - pred_val)))
            if best is None or val_mae < best[0]:
                best = (val_mae, lam)
        _, lam = best
        pred_test = ridge_fit_predict(X_train, ytrain, X_test, lam)
        return {"lambda": lam, "test": metrics(ytest, pred_test)}

    out = {
        "n_train": int(len(train)),
        "n_test": int(len(test)),
        "train_donor_to_test_donor": fit_best(
            donor[train], donor[test], "donor"),
        "train_donor_to_test_donor_free": fit_best(
            donor[train], same_clock[test], "donor_free"),
        "train_donor_free_to_test_donor": fit_best(
            same_clock[train], donor[test], "donor"),
        "train_donor_free_to_test_donor_free": fit_best(
            same_clock[train], same_clock[test], "donor_free"),
    }
    with open("pemsbay_donorfree_recalibration.json", "w",
              encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)
    print("Wrote pemsbay_donorfree_recalibration.json", flush=True)


if __name__ == "__main__":
    main()
