"""Evaluate STIDCausal on PEMS04: val MAE, paired test vs STIDGraph, recovery."""
import os
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy.stats import wilcoxon

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from graph_dataset import GraphTrafficDataset
from stid_graph import STIDGraph
from stid_causal import STIDCausal

DATA = "data/pems04/processed"
device = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48
MAX_EVENTS = 5


def collate_graph(batch):
    return {
        "zone_ids": torch.stack([b["zone_ids"] for b in batch]),
        "features": torch.stack([b["features"] for b in batch]),
        "targets": torch.stack([b["targets"] for b in batch]),
        "adj": batch[0]["adj"],
    }


def preds(model, loader, use_causal=False):
    model.eval()
    ps, ts = [], []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) if isinstance(v, torch.Tensor) else v
                 for k, v in batch.items()}
            if use_causal:
                _, pred = model(f["features"], f["zone_ids"], f["adj"])
            else:
                pred = model(f["features"], f["zone_ids"], f["adj"])
            ps.append(pred.cpu().numpy())
            ts.append(f["targets"].cpu().numpy())
    return np.concatenate(ps, axis=0), np.concatenate(ts, axis=0)


def make_synth_batch(samples, start, size, feature_dim, adj, device):
    batch = samples[start:start + size]
    N = samples[0]["factual"].shape[1]
    factual = torch.zeros(len(batch), SEQ, N, feature_dim)
    cf = torch.zeros(len(batch), SEQ, N, feature_dim)
    ice = torch.zeros(len(batch), feature_dim)
    event_types = torch.full((len(batch), MAX_EVENTS), -1, dtype=torch.long)
    event_locs = torch.zeros(len(batch), MAX_EVENTS, 2)
    event_times = torch.zeros(len(batch), MAX_EVENTS)
    zone_states = torch.zeros(len(batch), MAX_EVENTS, feature_dim)
    zones = torch.zeros(len(batch), dtype=torch.long)
    for i, d in enumerate(batch):
        zones[i] = d["zone"]
        factual[i] = d["factual"]
        cf[i] = d["cf"]
        ice[i] = d["ice_true"]
        combo = d["combo"]
        event_types[i] = combo["event_types"]
        event_locs[i] = combo["event_locs"]
        event_times[i] = combo["event_times"]
        zone_states[i] = combo["zone_states"]
    return {
        "zone_ids": zones.to(device),
        "features": factual.to(device),
        "cf_features": cf.to(device),
        "ice_true": ice.to(device),
        "event_types": event_types.to(device),
        "event_locs": event_locs.to(device),
        "event_times": event_times.to(device),
        "zone_states": zone_states.to(device),
    }


def main():
    print("Device:", device)
    adj = torch.FloatTensor(np.load(str(Path(DATA) / "adj.npy"))).to(device)
    ds = GraphTrafficDataset(DATA, "val", SEQ)
    loader = torch.utils.data.DataLoader(ds, batch_size=16, shuffle=False,
                                         collate_fn=collate_graph)

    sc = STIDCausal(n_zones=307, input_dim=1, output_dim=1).to(device)
    sc.load_state_dict(torch.load(
        str(Path(DATA) / "stid_causal_pems04_best.pt"), map_location=device))
    st = STIDGraph(n_zones=307, input_dim=1, hidden_dim=64, seq_len=48,
                   n_layers=2, n_days=7).to(device)
    st.load_state_dict(torch.load(
        str(Path(DATA) / "stidgraph-pems04_seed2_best.pt"), map_location=device))

    p_sc, t_sc = preds(sc, loader, use_causal=True)
    p_st, t_st = preds(st, loader)
    mae_sc = float(np.abs(p_sc - t_sc).mean())
    mae_st = float(np.abs(p_st - t_st).mean())
    print("STIDCausal val MAE: %.4f" % mae_sc)
    print("STIDGraph best val MAE: %.4f" % mae_st)
    _, p = wilcoxon(np.abs(p_sc - t_sc)[:, 0], np.abs(p_st - t_st)[:, 0])
    print("Wilcoxon STIDCausal vs STIDGraph p=%.4g" % p)

    syn = np.load(str(Path(DATA) / "synthetic_pairs_fullnode.npy"),
                  allow_pickle=True).item()
    test = syn["test"]
    ests, trues = [], []
    sc.eval()
    with torch.no_grad():
        for i in range(0, len(test), 16):
            b = make_synth_batch(test, i, 16, 1, adj, device)
            combo = {"event_types": b["event_types"], "event_locs": b["event_locs"],
                     "event_times": b["event_times"], "zone_states": b["zone_states"]}
            e = sc.causal_effect(
                {"zone_ids": b["zone_ids"], "features": b["features"]},
                {"zone_ids": b["zone_ids"], "features": b["cf_features"]},
                combo, adj)
            ests.append(e[:, 0].cpu().numpy())
            trues.append(b["ice_true"][:, 0].cpu().numpy())
    est = np.concatenate(ests)
    true = np.concatenate(trues)
    corr = float(np.corrcoef(est, true)[0, 1])
    ratio = float(np.median(est / (true + 1e-6)))
    mae = float(np.abs(est - true).mean())
    print("Recovery corr=%.4f ratio=%.3f mae=%.3f" % (corr, ratio, mae))
    print("ALL DONE")


if __name__ == "__main__":
    main()
