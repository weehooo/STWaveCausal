"""Known-DAG recovery benchmark for the event structure learner."""
import argparse
import json
from itertools import permutations

import numpy as np
import torch
from sklearn.linear_model import LassoLarsIC

from src.model.causal_structure import CausalStructureLearner


def random_dag(k, rng, edge_prob=0.35):
    order = rng.permutation(k)
    adj = np.zeros((k, k), dtype=int)
    weights = np.zeros((k, k), dtype=float)
    for b in range(1, k):
        for a in range(b):
            if rng.rand() < edge_prob:
                i, j = order[a], order[b]
                sign = 1.0 if rng.rand() < 0.7 else -1.0
                weight = sign * rng.uniform(0.6, 1.4)
                adj[i, j] = 1
                weights[i, j] = weight
    return order, adj, weights


def observations(adj, weights, k, n_obs, rng, noise=0.8):
    x = rng.normal(size=(n_obs, k))
    # Evaluate nodes in topological numeric order; graphs were built so every
    # parent index is smaller than its child index.
    for j in range(k):
        parents = np.where(adj[:, j] == 1)[0]
        if len(parents):
            x[:, j] += x[:, parents] @ weights[parents, j]
        x[:, j] += rng.normal(size=n_obs) * noise
    return x


def make_model_inputs(x, np_rng, torch_rng, k, n_obs):
    types = torch.randint(0, 8, (n_obs, k), generator=torch_rng)
    locs = torch.rand(n_obs, k, 2, generator=torch_rng) * 2 - 1
    times = torch.arange(k, dtype=torch.float32).repeat(n_obs, 1)
    # Fill all state dimensions with node-specific measurements plus small
    # independent sensor noise so cross-event partial correlations are meaningful.
    states = np.empty((n_obs, k, 12), dtype=np.float32)
    for j in range(k):
        loading = np_rng.uniform(0.75, 1.0)
        states[:, j, :] = x[:, j, None] + np_rng.normal(
            size=(n_obs, 12)) * 0.15 * loading
    states = torch.from_numpy(states)
    return types, locs, times, states


def threshold_symmetric(matrix, threshold):
    skeleton = (np.abs(matrix) >= threshold).astype(int)
    np.fill_diagonal(skeleton, 0)
    return skeleton


def orient_by_order(skeleton):
    directed = np.zeros_like(skeleton)
    k = skeleton.shape[0]
    for i in range(k):
        for j in range(i + 1, k):
            if skeleton[i, j]:
                directed[i, j] = 1
    return directed


def partial_correlation_matrix(x):
    corr = np.corrcoef(x, rowvar=False)
    precision = np.linalg.pinv(corr + np.eye(corr.shape[0]) * 1e-6)
    d = np.sqrt(np.diag(precision))
    partial = -precision / np.outer(d, d)
    np.fill_diagonal(partial, 0)
    return partial


def lasso_adjacency(x, max_nodes):
    k = x.shape[1]
    adj = np.zeros((max_nodes, max_nodes), dtype=int)
    for child in range(k):
        parents = [i for i in range(max_nodes) if i != child]
        model = LassoLarsIC(criterion="aic", fit_intercept=True)
        model.fit(x[:, parents], x[:, child])
        coefs = model.coef_
        sd_x = np.std(x[:, parents]) + 1e-8
        sd_y = np.std(x[:, child]) + 1e-8
        selected = np.abs(coefs) * sd_x / sd_y > 0.05
        for local_parent in np.where(selected)[0]:
            parent = parents[local_parent]
            if parent < child:
                adj[parent, child] = 1
    return adj


def directed_metrics(true, pred):
    true = true.astype(int)
    pred = pred.astype(int)
    correct = int(np.sum((true == 1) & (pred == 1)))
    reverse = int(np.sum((true == 1) & (pred.T == 1) & (pred == 0)))
    extra = int(np.sum((true == 0) & (pred == 1)))
    missing = int(np.sum((true == 1) & (pred == 0)))
    precision = correct / max(1, correct + extra + reverse)
    recall = correct / max(1, correct + missing)
    f1 = 2 * precision * recall / max(1e-12, precision + recall)
    shd = reverse + extra + missing
    return {"precision": precision, "recall": recall, "f1": f1,
            "shd": shd, "correct": correct, "reverse": reverse,
            "extra": extra, "missing": missing}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--graphs-per-seed", type=int, default=60)
    ap.add_argument("--obs-per-graph", type=int, default=192)
    args = ap.parse_args()

    methods = ["structure_learner", "partial_corr", "corr_threshold",
               "lasso_var"]
    runs = {}
    for seed in [42, 1, 2]:
        rng = np.random.RandomState(seed)
        torch_rng = torch.Generator().manual_seed(seed)
        learner = CausalStructureLearner(state_dim=12).eval()
        scores = {method: [] for method in methods}
        for _ in range(args.graphs_per_seed):
            k = int(rng.randint(3, 6))
            order, truth, weights = random_dag(k, rng)
            x = observations(truth, weights, k, args.obs_per_graph, rng)
            types, locs, times, states = make_model_inputs(
                x, rng, torch_rng, k, args.obs_per_graph)
            with torch.no_grad():
                _, _, pred_tensors = learner(types, locs, times, states)
            predictions = {
                "structure_learner": np.mean(
                    pred_tensors.numpy(), axis=0) > 0.5,
                "partial_corr": orient_by_order(threshold_symmetric(
                    partial_correlation_matrix(x), 0.20)),
                "corr_threshold": orient_by_order(threshold_symmetric(
                    np.corrcoef(x, rowvar=False), 0.30)),
                "lasso_var": lasso_adjacency(x, k),
            }
            for method, prediction in predictions.items():
                scores[method].append(directed_metrics(truth[:k, :k],
                                                        prediction[:k, :k]))
        runs[f"seed_{seed}"] = {
            method: {key: float(np.mean([score[key] for score in vals]))
                     for key in vals[0]}
            for method, vals in scores.items()
        }

    summary = {}
    for method in methods:
        summary[method] = {
            key: float(np.mean([runs[f"seed_{seed}"][method][key]
                                for seed in [42, 1, 2]]))
            for key in runs["seed_42"][method]
        }
    output = {"protocol": {
        "graph_sizes": [3, 4, 5], "edge_prob": 0.35,
        "observations_per_graph": args.obs_per_graph,
        "graphs_per_seed": args.graphs_per_seed, "seeds": [42, 1, 2]},
        "per_seed": runs, "summary": summary}
    with open("dag_recovery_results.json", "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2)
    print(json.dumps(summary, indent=2), flush=True)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
