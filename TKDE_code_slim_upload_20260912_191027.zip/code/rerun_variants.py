"""Cloud variant retraining: standard V3 (no graph ctx) and PEMS08 ablations."""
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

BASE = Path(os.environ.get("PAPERS_BASE", r"F:\xuexi\codex\papers"))
PY = os.environ.get("PYTHON_BIN", r"F:\Anaconda3\python.exe")

STD = [
    ("nyc_taxi", 265, 6, 50, 0,
     "synthetic_pairs_v3.npy", "rerun_v3_std_nyc_taxi_seed42.pt"),
    ("pems_bay", 325, 8, 70, 50,
     "synthetic_pairs_v3_pems.npy", "rerun_v3_std_pems_bay_seed42.pt"),
    ("pems08", 170, 1, 90, 70,
     "synthetic_pairs_v3.npy", "rerun_v3_std_pems08_seed42.pt"),
    ("pems04", 307, 1, 90, 70,
     "synthetic_pairs_v3.npy", "rerun_v3_std_pems04_seed42.pt"),
]

ABL_COMMON = [
    "train_causal_v3_full.py",
    "--data", "data/pems08/processed",
    "--n-zones", "170",
    "--feature-dim", "1",
    "--epochs", "90",
    "--pretrain-epochs", "70",
    "--graph-ctx",
    "--ctx-gate",
    "--meta-file", "data/datasets/pems08_staeformer/data.npz",
    "--seed", "42",
]

ABLATIONS = {
    "no_causal": ["--lambda3", "0"],
    "no_contrastive": ["--lambda1", "0"],
    "no_gate": [],
    "no_time": ["--synthetic",
                "data/pems08/processed/synthetic_pairs_v3_graphctx_notime.npy",
                "--no-meta"],
    "no_twostage": ["--pretrain-epochs", "0"],
}


def run(cmd, tag):
    out_log = BASE / ("variant_%s_out.log" % tag)
    err_log = BASE / ("variant_%s_err.log" % tag)
    print("[%s] start %s" % (datetime.now().strftime("%H:%M:%S"), tag),
          flush=True)
    with out_log.open("w") as fo, err_log.open("w") as fe:
        p = subprocess.Popen(cmd, cwd=str(BASE), stdout=fo, stderr=fe)
        code = p.wait()
    if code != 0:
        raise SystemExit("%s exited with code %d" % (tag, code))
    print("[%s] done  %s" % (datetime.now().strftime("%H:%M:%S"), tag),
          flush=True)


def std_cmd(name, zones, dim, epochs, pretrain, syn, out):
    data = str(BASE / "data" / name / "processed")
    return [str(PY), "train_causal_v3_full.py",
            "--data", data,
            "--synthetic", str(Path(data) / syn),
            "--n-zones", str(zones),
            "--feature-dim", str(dim),
            "--epochs", str(epochs),
            "--pretrain-epochs", str(pretrain),
            "--out", str(Path(data) / out),
            "--seed", "42"]


def main():
    for name, zones, dim, epochs, pretrain, syn, out in STD:
        tag = "std_%s" % name
        if (BASE / ("variant_%s.done" % tag)).exists():
            print("skip (done): %s" % tag, flush=True)
            continue
        run(std_cmd(name, zones, dim, epochs, pretrain, syn, out), tag)
        (BASE / ("variant_%s.done" % tag)).write_text("done\n",
                                                      encoding="utf-8")

    for ab in ABLATIONS:
        tag = "pems08_abl_%s" % ab
        if (BASE / ("variant_%s.done" % tag)).exists():
            print("skip (done): %s" % tag, flush=True)
            continue
        cmd = [str(PY)] + list(ABL_COMMON) + list(ABLATIONS[ab])
        if ab == "no_gate":
            cmd.remove("--ctx-gate")
        if ab == "no_time":
            cmd.remove("--meta-file")
            cmd.remove("data/datasets/pems08_staeformer/data.npz")
            cmd.remove("--no-meta")
        out = "data/pems08/processed/rerun_v3_pems08_abl_%s_seed42.pt" % ab
        cmd += ["--out", str(BASE / out)]
        run(cmd, tag)
        (BASE / ("variant_%s.done" % tag)).write_text("done\n",
                                                      encoding="utf-8")
    print("ALL VARIANTS DONE", flush=True)


if __name__ == "__main__":
    sys.exit(main())
