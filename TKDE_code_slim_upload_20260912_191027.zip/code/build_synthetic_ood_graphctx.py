"""Build protocol-shifted synthetic pairs for held-out recovery."""
import argparse
import os

import numpy as np
import torch

SEQ = 48
MAX_EVENTS = 5


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/nyc_taxi/processed")
    ap.add_argument("--n-zones", type=int, default=265)
    ap.add_argument("--feature-dim", type=int, default=6)
    ap.add_argument("--n-samples", type=int, default=2000)
    ap.add_argument("--ctx-mode", choices=["mean", "gradient"], default="mean")
    ap.add_argument("--meta-file", default=None)
    ap.add_argument("--out", default="synthetic_pairs_v3_graphctx_ood.npy")
    args = ap.parse_args()

    path = os.path.join(args.data)
    feats = np.load(os.path.join(path, "node_features.npy")).astype(np.float32)
    labels = np.load(os.path.join(path, "labels.npy"))
    adj = np.load(os.path.join(path, "adj.npy")).astype(np.float32)
    adj /= np.maximum(adj.sum(axis=1, keepdims=True), 1e-6)
    meta = None
    if args.meta_file:
        meta = np.load(args.meta_file)["data"][..., 1:3].astype(np.float32)[:, 0]
        assert np.allclose(meta, meta[:, 0:1], atol=1e-5)
        meta = meta[:, 0]
    N, D = args.n_zones, args.feature_dim
    # These zones were excluded by the training benchmark's active-zone rule,
    # so their windows are protocol- and zone-shifted relative to training.
    means = feats[:, :, 0].mean(axis=0)
    sparse = np.array([(feats[:, z, 0] == 0).mean() >= 0.3
                       for z in range(N)])
    ood_zones = [z for z in range(N) if 20 <= means[z] <= 50 and not sparse[z]]
    if len(ood_zones) < 10:
        raise RuntimeError("fewer than 10 OOD zones available")
    print("OOD zones:", len(ood_zones), flush=True)

    candidates = []
    for z in ood_zones:
        count = 0
        for t in range(SEQ + 8, feats.shape[0] - SEQ):
            if np.all(labels[t:t + 8, z] == 0):
                candidates.append((z, t))
                count += 1
                if count >= 300:
                    break

    def context(t, z):
        return np.einsum("nd,n->d", feats[t], adj[z])

    def state_context(t, z):
        ctx = context(t, z)
        if args.ctx_mode == "gradient":
            ctx = ctx - feats[t, z]
        return np.concatenate([feats[t, z], ctx])

    rng = np.random.RandomState(732)
    factors = np.array([0.55, 0.65, 0.75, 0.85])
    durations = np.array([1, 2, 4])
    samples = []
    for sample_id in range(args.n_samples):
        z, t_end = candidates[rng.randint(len(candidates))]
        t_start = t_end - SEQ
        w = feats[max(0, t_start):t_end]
        if len(w) < SEQ:
            pad = np.zeros((SEQ - len(w), N, D), dtype=w.dtype)
            w = np.concatenate([pad, w], axis=0)
        duration = int(rng.choice(durations))
        affected = slice(SEQ - duration, SEQ)
        mode = rng.rand()
        if mode < 0.6:
            factor = float(rng.choice(factors))
            event_types = [1]
        elif mode < 0.85:
            factor = float(rng.choice(factors))
            event_types = [2]
        else:
            factor = float(np.prod(rng.choice(factors, size=2, replace=True)))
            event_types = [1, 2]
        modified = w.copy()
        modified[affected, z, :min(4, D)] *= factor

        raw_f, ctx_f = w[:, z], np.einsum("snd,n->sd", w, adj[z])
        raw_cf, ctx_cf = modified[:, z], np.einsum("snd,n->sd", modified,
                                                    adj[z])
        if args.ctx_mode == "gradient":
            ctx_f -= raw_f
            ctx_cf -= raw_cf
        parts_f, parts_cf = [raw_f, ctx_f], [raw_cf, ctx_cf]
        if meta is not None:
            m_start = max(0, t_start)
            m_win = meta[m_start:t_end]
            if len(m_win) < SEQ:
                pad = np.zeros((SEQ - len(m_win), meta.shape[1]),
                               dtype=meta.dtype)
                m_win = np.concatenate([pad, m_win], axis=0)
            parts_f.append(m_win)
            parts_cf.append(m_win)

        raw_target = w[affected, z]
        cf_target = modified[affected, z]
        ice_true = np.abs(raw_target.mean(axis=0) -
                          cf_target.mean(axis=0)).astype(np.float32)
        et = torch.full((MAX_EVENTS,), -1, dtype=torch.long)
        for i, event_type in enumerate(event_types):
            et[i] = event_type
        combo = {
            "event_types": et,
            "event_locs": torch.zeros(MAX_EVENTS, 2),
            "event_times": torch.zeros(MAX_EVENTS),
            "zone_states": torch.zeros(MAX_EVENTS, D * 2 +
                                       (0 if meta is None else meta.shape[1])),
        }
        for i in range(len(event_types)):
            combo["event_times"][i] = float(t_end - duration // 2)
            combo["zone_states"][i] = torch.FloatTensor(state_context(t_end - 1, z))
        samples.append({
            "zone": z, "t": t_end,
            "factual": torch.FloatTensor(np.concatenate(parts_f, axis=-1)),
            "cf": torch.FloatTensor(np.concatenate(parts_cf, axis=-1)),
            "ice_true": torch.FloatTensor(ice_true),
            "combo": combo,
            "protocol": {"factor": factor, "duration": duration},
        })

    out = {"train": [], "val": [], "test": samples}
    destination = os.path.join(path, args.out)
    np.save(destination, out, allow_pickle=True)
    print("Saved %s with %d OOD test pairs" % (destination, len(samples)),
          flush=True)


if __name__ == "__main__":
    main()
