"""Fine-tune STIDCausal to calibrate full-node causal-effect recovery.

Attempts: higher lambda3, log-scale causal supervision, longer fine-tuning.
"""
import argparse
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from graph_dataset import GraphTrafficDataset
from stid_causal import STIDCausal

SEQ = 48
MAX_EVENTS = 5


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/pems04/processed")
    p.add_argument("--synthetic", default="synthetic_pairs_fullnode.npy")
    p.add_argument("--n-zones", type=int, default=307)
    p.add_argument("--feature-dim", type=int, default=1)
    p.add_argument("--epochs", type=int, default=30)
    p.add_argument("--lambda1", type=float, default=0.3)
    p.add_argument("--lambda2", type=float, default=0.01)
    p.add_argument("--lambda3", type=float, default=3.0)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--max-batches", type=int, default=0)
    p.add_argument("--init", default=None)
    p.add_argument("--log-scale", action="store_true")
    p.add_argument("--out", default="stid_causal_pems04_calib.pt")
    p.add_argument("--seed", type=int, default=42)
    return p.parse_args()


def collate_graph(batch):
    return {
        "zone_ids": torch.stack([b["zone_ids"] for b in batch]),
        "features": torch.stack([b["features"] for b in batch]),
        "targets": torch.stack([b["targets"] for b in batch]),
        "adj": batch[0]["adj"],
    }


def to_device(d, device):
    return {k: v.to(device) if isinstance(v, torch.Tensor) else v
            for k, v in d.items()}


def make_synth_batch(samples, start, batch_size, feature_dim, device):
    batch = samples[start:start + batch_size]
    N = samples[0]["factual"].shape[1]
    factual = torch.zeros(len(batch), SEQ, N, feature_dim)
    cf = torch.zeros(len(batch), SEQ, N, feature_dim)
    ice = torch.zeros(len(batch), feature_dim)
    event_types = torch.full((len(batch), MAX_EVENTS), -1, dtype=torch.long)
    event_locs = torch.zeros(len(batch), MAX_EVENTS, 2)
    event_times = torch.zeros(len(batch), MAX_EVENTS)
    zone_states = torch.zeros(len(batch), MAX_EVENTS, feature_dim)
    zones = torch.zeros(len(batch), dtype=torch.long)
    for i, d in enumerate(batch):
        zones[i] = d["zone"]
        factual[i] = d["factual"]
        cf[i] = d["cf"]
        ice[i] = d["ice_true"]
        combo = d["combo"]
        event_types[i] = combo["event_types"]
        event_locs[i] = combo["event_locs"]
        event_times[i] = combo["event_times"]
        zone_states[i] = combo["zone_states"]
    return {
        "zone_ids": zones.to(device),
        "features": factual.to(device),
        "cf_features": cf.to(device),
        "ice_true": ice.to(device),
        "event_types": event_types.to(device),
        "event_locs": event_locs.to(device),
        "event_times": event_times.to(device),
        "zone_states": zone_states.to(device),
    }


def recovery_metrics(model, samples, feature_dim, adj, device):
    model.eval()
    ests, trues = [], []
    with torch.no_grad():
        for i in range(0, len(samples), 16):
            b = make_synth_batch(samples, i, 16, feature_dim, device)
            combo = {"event_types": b["event_types"],
                     "event_locs": b["event_locs"],
                     "event_times": b["event_times"],
                     "zone_states": b["zone_states"]}
            e = model.causal_effect(
                {"zone_ids": b["zone_ids"], "features": b["features"]},
                {"zone_ids": b["zone_ids"], "features": b["cf_features"]},
                combo, adj)
            ests.append(e[:, 0].cpu().numpy())
            trues.append(b["ice_true"][:, 0].cpu().numpy())
    est = np.concatenate(ests)
    true = np.concatenate(trues)
    corr = float(np.corrcoef(est, true)[0, 1])
    ratio = float(np.median(est / (true + 1e-6)))
    mae = float(np.abs(est - true).mean())
    return corr, ratio, mae


def main():
    args = parse_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    print("Device:", device, flush=True)
    print("lambda3=%.2f log_scale=%s lr=%g epochs=%d" %
          (args.lambda3, args.log_scale, args.lr, args.epochs), flush=True)

    DATA = Path(args.data)
    adj = torch.FloatTensor(np.load(str(DATA / "adj.npy"))).to(device)
    synthetic = np.load(str(DATA / args.synthetic), allow_pickle=True).item()
    print("Synthetic splits:", len(synthetic["train"]), len(synthetic["val"]),
          len(synthetic["test"]), flush=True)

    td = GraphTrafficDataset(str(DATA), "train", SEQ)
    tl = torch.utils.data.DataLoader(td, batch_size=args.batch_size,
                                     shuffle=True, collate_fn=collate_graph,
                                     num_workers=0, drop_last=True)

    model = STIDCausal(n_zones=args.n_zones, input_dim=args.feature_dim,
                       output_dim=args.feature_dim, hidden_dim=64).to(device)
    if args.init:
        model.load_state_dict(torch.load(args.init, map_location=device))
        print("Loaded init:", args.init, flush=True)
    opt = torch.optim.Adam(model.parameters(), lr=args.lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=args.epochs)

    best_score = float("inf")
    best_state = None
    save_path = DATA / args.out

    for ep in range(args.epochs):
        model.train()
        t0 = time.time()
        totals = {"loss": 0.0, "pred": 0.0, "cs": 0.0, "cm": 0.0,
                  "div": 0.0, "causal": 0.0}
        acc = {k: torch.zeros((), device=device) for k in totals}
        n = 0
        for i, batch in enumerate(tl):
            f = to_device(batch, device)
            if args.max_batches and i + 1 >= args.max_batches:
                break
            s_i = (i * args.batch_size) % len(synthetic["train"])
            sb = make_synth_batch(synthetic["train"], s_i, args.batch_size,
                                  args.feature_dim, device)
            combo = {"event_types": sb["event_types"],
                     "event_locs": sb["event_locs"],
                     "event_times": sb["event_times"],
                     "zone_states": sb["zone_states"]}
            cl = model.contrastive_loss(
                {"zone_ids": f["zone_ids"], "features": f["features"],
                 "targets": f["targets"]},
                {"zone_ids": sb["zone_ids"], "features": sb["cf_features"]},
                {"zone_ids": sb["zone_ids"], "features": sb["cf_features"]},
                combo, adj)
            L_pred = cl["L_pred"]
            L_cs = cl["L_con_single"]
            L_cm = cl["L_con_multi"]
            L_div = cl["L_div"]
            ice_est = model.causal_effect(
                {"zone_ids": sb["zone_ids"], "features": sb["features"]},
                {"zone_ids": sb["zone_ids"], "features": sb["cf_features"]},
                combo, adj)
            if args.log_scale:
                L_causal = F.mse_loss(torch.log1p(ice_est),
                                      torch.log1p(sb["ice_true"]))
            else:
                L_causal = F.mse_loss(ice_est, sb["ice_true"])
            loss = (L_pred + args.lambda1 * (L_cs + L_cm)
                    + args.lambda2 * L_div + args.lambda3 * L_causal)
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            bs = f["targets"].shape[0]
            acc["loss"] += loss.detach() * bs
            acc["pred"] += L_pred.detach() * bs
            acc["cs"] += L_cs.detach() * bs
            acc["cm"] += L_cm.detach() * bs
            acc["div"] += L_div.detach() * bs
            acc["causal"] += L_causal.detach() * bs
            n += bs
        sched.step()
        m = {k: v.item() / max(1, n) for k, v in acc.items()}

        if (ep + 1) % 5 == 0 or ep == 0:
            corr, ratio, mae = recovery_metrics(
                model, synthetic["val"], args.feature_dim, adj, device)
            score = abs(np.log(ratio)) + max(0.0, 0.9 - corr)
            print("Ep %3d/%d loss=%.4f pred=%.4f cs=%.4f cm=%.4f div=%.4f "
                  "causal=%.4f | corr=%.4f ratio=%.4f mae=%.3f score=%.4f "
                  "(%.1fs)" %
                  (ep + 1, args.epochs, m["loss"], m["pred"], m["cs"],
                   m["cm"], m["div"], m["causal"], corr, ratio, mae, score,
                   time.time() - t0), flush=True)
            if score < best_score:
                best_score = score
                best_state = {k: v.cpu() for k, v in model.state_dict().items()}
                torch.save(best_state, str(save_path))
                print("  * saved best (score %.4f)" % score, flush=True)

    if best_state is not None:
        model.load_state_dict(best_state)
    corr, ratio, mae = recovery_metrics(
        model, synthetic["test"], args.feature_dim, adj, device)
    print("FINAL TEST corr=%.4f ratio=%.4f mae=%.3f" %
          (corr, ratio, mae), flush=True)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
