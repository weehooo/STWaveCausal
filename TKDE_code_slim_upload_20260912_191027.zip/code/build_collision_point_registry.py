"""Build a taxi-zone concurrent-collision registry under the frozen H3 rules."""
import argparse
import gzip
import hashlib
import json
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import shapefile
from pyproj import Transformer


EXCLUDED_STORM_TYPES = {
    "hurricane", "typhoon", "tropical storm", "blizzard", "winter storm",
    "ice storm", "storm surge/tide", "storm surge",
}
HOLIDAYS = {
    "2012-07-04", "2012-09-03", "2012-10-08", "2012-11-12",
    "2012-11-22", "2012-12-25", "2013-01-01", "2013-01-21",
    "2013-02-18", "2013-05-27", "2013-07-04", "2013-09-02",
    "2013-10-14", "2013-11-11", "2013-11-28", "2013-12-25",
}


def rings(shape):
    parts = list(shape.parts) + [len(shape.points)]
    for i in range(len(parts) - 1):
        points = shape.points[parts[i]:parts[i + 1]]
        if len(points) >= 3:
            yield points


def point_in_ring(x, y, ring):
    inside = False
    previous = ring[-1]
    for current in ring:
        xi, yi = current
        xj, yj = previous
        if ((yi > y) != (yj > y)) and \
                x < (xj - xi) * (y - yi) / (yj - yi + 1e-15) + xi:
            inside = not inside
        previous = current
    return inside


def point_in_shape(x, y, shape):
    return any(point_in_ring(x, y, ring) for ring in rings(shape))


def haversine_km(lat1, lon1, lat2, lon2):
    values = np.radians([lat1, lon1, lat2, lon2])
    lat1, lon1, lat2, lon2 = values
    dlat, dlon = lat2 - lat1, lon2 - lon1
    h = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * \
        np.sin(dlon / 2) ** 2
    return float(6371.0 * 2.0 * np.arcsin(np.sqrt(h)))


def load_zones(zone_dir):
    reader = shapefile.Reader(str(Path(zone_dir) / "taxi_zones.dbf"))
    fields = [field[0] for field in reader.fields[1:]]
    forward = Transformer.from_crs("EPSG:4326", "EPSG:2263", always_xy=True)
    inverse = Transformer.from_crs("EPSG:2263", "EPSG:4326", always_xy=True)
    zones = []
    for index in range(len(reader)):
        record = dict(zip(fields, reader.record(index)))
        keys = {key.lower(): key for key in record}
        location_key = keys.get("locationid")
        borough_key = keys.get("borough")
        name_key = keys.get("zone")
        if location_key is None:
            continue
        shape = reader.shape(index)
        xmin, ymin, xmax, ymax = shape.bbox
        center_lon, center_lat = inverse.transform((xmin + xmax) / 2,
                                                    (ymin + ymax) / 2)
        zones.append({
            "zone_id": int(record[location_key]),
            "borough": str(record[borough_key]).strip(),
            "zone_name": str(record.get(name_key, "")).strip(),
            "shape": shape,
            "xmin": xmin, "xmax": xmax, "ymin": ymin, "ymax": ymax,
            "center_x": (xmin + xmax) / 2,
            "center_y": (ymin + ymax) / 2,
            "centroid_lat": float(center_lat),
            "centroid_lon": float(center_lon),
        })
    return zones, forward


def assign_zone(latitude, longitude, zones, forward):
    x, y = forward.transform(longitude, latitude)
    candidates = [zone for zone in zones
                  if zone["xmin"] <= x <= zone["xmax"] and
                  zone["ymin"] <= y <= zone["ymax"]]
    matches = [zone for zone in candidates
               if point_in_shape(x, y, zone["shape"])]
    if len(matches) == 1:
        return matches[0], "polygon"
    if len(matches) > 1:
        return min(matches, key=lambda z: (z["center_x"] - x) ** 2 +
                                          (z["center_y"] - y) ** 2), \
            "polygon_overlap"
    if candidates:
        chosen = min(candidates, key=lambda z: (z["center_x"] - x) ** 2 +
                                               (z["center_y"] - y) ** 2)
        return chosen, "bbox_nearest"
    nearest = min(zones, key=lambda z: (z["center_x"] - x) ** 2 +
                                       (z["center_y"] - y) ** 2)
    distance = haversine_km(latitude, longitude, nearest["centroid_lat"],
                            nearest["centroid_lon"])
    return (nearest, "nearest_centroid") if distance <= 1 else (None, "outside")


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def citywide_noaa_dates(pattern):
    frames = []
    hashes = {}
    for path in sorted(glob_glob(pattern)):
        hashes[path] = sha256(path)
        with gzip.open(path, "rt", encoding="utf-8", errors="replace") as f:
            frame = pd.read_csv(f, low_memory=False)
        frame = frame[frame["STATE"].astype(str).str.upper() == "NEW YORK"]
        frame["county"] = frame["CZ_NAME"].astype(str).str.strip().str.lower()
        frame = frame[frame["county"].isin({
            "bronx", "kings", "brooklyn", "new york", "manhattan",
            "queens", "richmond", "staten island"})]
        frames.append(frame)
    if not frames:
        return set(), hashes
    frame = pd.concat(frames, ignore_index=True)
    frame["date"] = pd.to_datetime(frame["BEGIN_DATE_TIME"],
                                   format="%d-%b-%y %H:%M:%S",
                                   errors="coerce").dt.date
    frame["category"] = frame["EVENT_TYPE"].astype(str).str.strip().str.lower()
    excluded_by_type = set(frame.loc[
        frame["category"].isin(EXCLUDED_STORM_TYPES), "date"].dropna())
    excluded_by_spread = {
        date for date, group in frame.groupby("date")
        if group["county"].nunique() >= 3
    }
    return excluded_by_type | excluded_by_spread, hashes


def glob_glob(pattern):
    import glob
    return glob.glob(pattern)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--events", default="data/events/raw/"
                        "collisions_2012H2_2013.csv")
    parser.add_argument("--zones", default="data/events/raw/taxi_zones")
    parser.add_argument("--noaa-pattern", default="data/events/raw/"
                        "StormEvents_details-ftp_v1.0_d*_c*.csv.gz")
    parser.add_argument("--features", default="data/nyc_taxi/processed/"
                        "node_features.npy")
    parser.add_argument("--minimum-records", type=int, default=3)
    parser.add_argument("--severe-score-threshold", type=float, default=None,
                        help="A zone-window also qualifies when its summed "
                             "severity reaches this value (1 = any injury).")
    parser.add_argument("--max-citywide-zone-fraction", type=float,
                        default=0.25)
    parser.add_argument("--max-pairs", type=int, default=100)
    parser.add_argument("--output", default="collision_localized_registry.json")
    args = parser.parse_args()

    zones, forward = load_zones(args.zones)
    feature_count = int(np.load(args.features, mmap_mode="r").shape[0])
    excluded_dates, noaa_hashes = citywide_noaa_dates(args.noaa_pattern)
    aggregates = {}
    assignment_counts = defaultdict(int)
    invalid_coordinates = outside_period = duplicate_keys = 0
    seen_keys = set()
    epoch = datetime(2011, 1, 1)

    for chunk in pd.read_csv(args.events, chunksize=100000):
        parsed = []
        for row in chunk.itertuples(index=False):
            if str(row.event_id) in seen_keys:
                duplicate_keys += 1
                continue
            seen_keys.add(str(row.event_id))
            try:
                timestamp = datetime.fromisoformat(row.timestamp)
                latitude, longitude = float(row.latitude), float(row.longitude)
            except (TypeError, ValueError):
                outside_period += 1
                continue
            if not (datetime(2012, 7, 1) <= timestamp < datetime(2014, 1, 1)):
                outside_period += 1
                continue
            if not (40.45 <= latitude <= 40.95 and
                    -74.30 <= longitude <= -73.65):
                invalid_coordinates += 1
                continue
            parsed.append((timestamp, latitude, longitude, row))
        if not parsed:
            continue
        xs, ys = forward.transform([item[2] for item in parsed],
                                    [item[1] for item in parsed])
        for (timestamp, latitude, longitude, row), x, y in zip(parsed, xs, ys):
            # Reuse assign_zone logic without transforming twice would require a
            # second API; this batch-level cost remains modest for ~0.8M rows.
            zone, assignment = assign_zone(latitude, longitude, zones, forward)
            assignment_counts[assignment] += 1
            if zone is None:
                continue
            time_index = round((timestamp - epoch).total_seconds() / 1800)
            if time_index < 48 or time_index + 48 >= feature_count:
                continue
            key = (zone["zone_id"], time_index)
            entry = aggregates.setdefault(key, {
                "count": 0, "severity": 0.0, "injured": 0, "killed": 0,
            })
            entry["count"] += 1
            entry["severity"] += float(row.severity_score)
            entry["injured"] += int(row.persons_injured)
            entry["killed"] += int(row.persons_killed)

    def is_qualifying(value):
        if value["count"] >= args.minimum_records:
            return True
        return (args.severe_score_threshold is not None and
                value["severity"] >= args.severe_score_threshold)

    qualifying = {key: value for key, value in aggregates.items()
                  if is_qualifying(value)}
    zone_ids = [zone_id for zone_id, _ in qualifying]
    time_indexes = [time_index for _, time_index in qualifying]
    spread_by_day = defaultdict(set)
    for zone_id, time_index in qualifying:
        date = (epoch + timedelta(minutes=30 * time_index)).date().isoformat()
        spread_by_day[date].add(zone_id)
    zone_fraction_limit = args.max_citywide_zone_fraction * len(zones)
    excluded_citylike_days = {date for date, ids in spread_by_day.items()
                              if len(ids) > zone_fraction_limit}
    excluded_all = excluded_dates | excluded_citylike_days | HOLIDAYS
    qualifying = {key: value for key, value in qualifying.items()
                  if (epoch + timedelta(minutes=30 * key[1])).date().isoformat()
                  not in excluded_all}

    by_time = defaultdict(list)
    zone_lookup = {zone["zone_id"]: zone for zone in zones}
    for (zone_id, time_index), value in qualifying.items():
        by_time[time_index].append((zone_id, value))
    all_pairs = []
    for time_index, active in by_time.items():
        for left_index, (zone_a, value_a) in enumerate(active):
            for zone_b, value_b in active[left_index + 1:]:
                left, right = zone_lookup[zone_a], zone_lookup[zone_b]
                distance = haversine_km(left["centroid_lat"],
                                        left["centroid_lon"],
                                        right["centroid_lat"],
                                        right["centroid_lon"])
                all_pairs.append({
                    "pair_id": f"{zone_a}_{time_index}__{zone_b}_{time_index}",
                    "time_index": time_index,
                    "start_time": (epoch + timedelta(
                        minutes=30 * time_index)).isoformat(),
                    "zones": [zone_a, zone_b],
                    "counts": [value_a["count"], value_b["count"]],
                    "severity_scores": [value_a["severity"],
                                        value_b["severity"]],
                    "distance_km": round(distance, 3),
                    "spatial_relation": "adjacent" if distance <= 2
                                        else "disjoint",
                })
    all_pairs.sort(key=lambda pair: (-sum(pair["severity_scores"]),
                                     pair["start_time"]))
    selected, seen_dates = [], set()
    for pair in all_pairs:
        date = pair["start_time"][:10]
        if date not in seen_dates:
            selected.append(pair)
            seen_dates.add(date)
        if len(selected) >= args.max_pairs:
            break

    output = {
        "protocol_name": "NYC localized concurrent-event stress test",
        "analysis_period_amendment":
            "Collisions analyzed from 2012-07-01 through 2013-12-31 because "
            "the accessible historical archive starts in July 2012; amendment "
            "was made before model-outcome evaluation.",
        "status": "event_registry_only_no_model_outcomes",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "input_sha256": {
            args.events: sha256(args.events),
            **noaa_hashes,
        },
        "summary": {
            "mapped_incident_windows": len(aggregates),
            "qualifying_windows_before_exclusions": len(
                [1 for value in aggregates.values() if is_qualifying(value)]),
            "citywide_storm_dates_excluded": len(excluded_dates),
            "high_spatial_spread_dates_excluded":
                len(excluded_citylike_days),
            "holiday_dates_excluded": len(HOLIDAYS),
            "qualifying_windows_after_exclusions": len(qualifying),
            "all_concurrent_candidate_pairs": len(all_pairs),
            "unique_candidate_days": len({p["start_time"][:10]
                                          for p in all_pairs}),
            "selected_pairs_one_per_day": len(selected),
            "selected_pair_relation_counts": {
                relation: sum(p["spatial_relation"] == relation
                              for p in selected)
                for relation in ["adjacent", "disjoint"]
            },
            "assignment_counts": dict(assignment_counts),
            "duplicate_keys_removed": duplicate_keys,
            "invalid_coordinates_or_outside_period":
                invalid_coordinates + outside_period,
        },
        "selected_pairs": selected,
    }
    Path(args.output).write_text(json.dumps(output, indent=2),
                                 encoding="utf-8")
    print(json.dumps(output["summary"], indent=2))


if __name__ == "__main__":
    main()
