"""STIDCausal encoder comparison chain: PEMS08 -> NYC -> PEMS-BAY -> PEMS08 seeds."""
import subprocess
import sys
from datetime import datetime
from pathlib import Path

BASE = Path(r"F:\xuexi\codex\papers")
PY = r"F:\Anaconda3\python.exe"


def build_synthetic(data, n_zones, feature_dim):
    out = str(Path(data) / "synthetic_pairs_fullnode.npy")
    if Path(out).exists():
        print("synthetic exists:", out, flush=True)
        return
    cmd = [
        PY, "build_synthetic_fullnode.py",
        "--data", data,
        "--n-zones", str(n_zones),
        "--feature-dim", str(feature_dim),
        "--active-threshold", "10.0",
        "--n-samples", "20000",
        "--out", "synthetic_pairs_fullnode.npy",
    ]
    print("[%s] building synthetic %s" %
          (datetime.now().strftime("%H:%M:%S"), data), flush=True)
    p = subprocess.run(cmd, cwd=str(BASE))
    if p.returncode != 0:
        raise SystemExit("synthetic build failed for " + data)


def train(data, n_zones, feature_dim, epochs, pretrain, batch, out, seed,
          tag):
    out_log = BASE / "stidcausal_{}_out.log".format(tag)
    err_log = BASE / "stidcausal_{}_err.log".format(tag)
    cmd = [
        PY, "train_causal_stid.py",
        "--data", data,
        "--synthetic", "synthetic_pairs_fullnode.npy",
        "--n-zones", str(n_zones),
        "--feature-dim", str(feature_dim),
        "--epochs", str(epochs),
        "--pretrain-epochs", str(pretrain),
        "--batch-size", str(batch),
        "--out", out,
        "--seed", str(seed),
    ]
    print("[%s] starting %s" % (datetime.now().strftime("%H:%M:%S"), tag),
          flush=True)
    with out_log.open("w") as fo, err_log.open("w") as fe:
        p = subprocess.Popen(cmd, cwd=str(BASE), stdout=fo, stderr=fe)
        code = p.wait()
    if code != 0:
        raise SystemExit("%s exited with code %d" % (tag, code))
    print("[%s] %s done" % (datetime.now().strftime("%H:%M:%S"), tag),
          flush=True)


def main():
    # PEMS08 seed 42
    build_synthetic("data/pems08/processed", 170, 1)
    train("data/pems08/processed", 170, 1, 90, 70, 16,
          "stid_causal_pems08_best.pt", 42, "pems08")
    # NYC seed 42
    build_synthetic("data/nyc_taxi/processed", 265, 6)
    train("data/nyc_taxi/processed", 265, 6, 50, 0, 16,
          "stid_causal_nyc_best.pt", 42, "nyc")
    # PEMS-BAY seed 42
    build_synthetic("data/pems_bay/processed", 325, 8)
    train("data/pems_bay/processed", 325, 8, 70, 50, 16,
          "stid_causal_pemsbay_best.pt", 42, "pemsbay")
    # PEMS08 seeds 1-4
    for seed in (1, 2, 3, 4):
        train("data/pems08/processed", 170, 1, 90, 70, 16,
              "stid_causal_pems08_seed{}.pt".format(seed), seed,
              "pems08_seed{}".format(seed))
    (BASE / "stidcausal_encoders.done").write_text("done\n", encoding="utf-8")
    print("ALL ENCODER COMPARISON DONE", flush=True)


if __name__ == "__main__":
    main()
