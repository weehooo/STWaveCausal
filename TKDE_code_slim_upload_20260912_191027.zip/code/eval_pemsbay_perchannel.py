"""Per-channel val MAE for PEMS-BAY STIDGraph vs STIDCausal (baseline audit)."""
import os
import sys

import numpy as np
import torch

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from graph_dataset import GraphTrafficDataset
from stid_graph import STIDGraph
from stid_causal import STIDCausal

device = "cuda" if torch.cuda.is_available() else "cpu"
DATA = "data/pems_bay/processed"


def collate_graph(batch):
    return {
        "zone_ids": torch.stack([b["zone_ids"] for b in batch]),
        "features": torch.stack([b["features"] for b in batch]),
        "targets": torch.stack([b["targets"] for b in batch]),
        "adj": batch[0]["adj"],
    }


def run(model, loader):
    model.eval()
    ps, ts = [], []
    with torch.no_grad():
        for batch in loader:
            f = {k: v.to(device) if isinstance(v, torch.Tensor) else v
                 for k, v in batch.items()}
            out = model(f["features"], f["zone_ids"], f["adj"])
            pred = out[1] if isinstance(out, tuple) else out
            ps.append(pred.cpu().numpy())
            ts.append(f["targets"].cpu().numpy())
    return np.concatenate(ps), np.concatenate(ts)


def main():
    print("Device:", device)
    ds = GraphTrafficDataset(DATA, "val", 48)
    loader = torch.utils.data.DataLoader(ds, batch_size=64, shuffle=False,
                                         collate_fn=collate_graph)

    st = STIDGraph(n_zones=325, input_dim=8, hidden_dim=64, seq_len=48,
                   n_layers=2, n_days=7).to(device)
    st.load_state_dict(torch.load(DATA + "/stidgraph-pems_best.pt",
                                  map_location=device))
    sc = STIDCausal(n_zones=325, input_dim=8, output_dim=8).to(device)
    sc.load_state_dict(torch.load(DATA + "/stid_causal_pemsbay_best.pt",
                                  map_location=device))

    for name, model in [("STIDGraph", st), ("STIDCausal", sc)]:
        p, t = run(model, loader)
        per_ch = np.abs(p - t).mean(axis=0)
        print("%s total=%.4f per-f=%.4f" %
              (name, per_ch.mean(), per_ch.mean()))
        print("  channels:", " ".join("%.4f" % x for x in per_ch))


if __name__ == "__main__":
    main()
