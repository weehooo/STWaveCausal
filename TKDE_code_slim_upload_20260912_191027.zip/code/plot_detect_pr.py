"""Render the P0 precision/recall curve from detect_calibrated_results.json."""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = Path(r"F:\xuexi\codex\papers")
res = json.load(open(BASE / "detect_calibrated_results.json"))
rows = res["pr_curve"]
recall = [r["recall"] for r in rows]
precision = [r["precision"] for r in rows]

fig, ax = plt.subplots(figsize=(4.2, 3.1), dpi=200)
ax.plot(recall, precision, lw=2.2, color="#1f6fb2")
op = res["operating_point_P>=0.90"]
ax.plot(op["recall"], op["precision"], "o", ms=7, color="#d1495b")
ax.annotate("P=%.2f, R=%.2f" % (op["precision"], op["recall"]),
            xy=(op["recall"], op["precision"]),
            xytext=(op["recall"] - 0.45, op["precision"] + 0.02),
            fontsize=8)
ax.set_xlabel("Recall")
ax.set_ylabel("Precision")
ax.set_xlim(0, 1.02)
ax.set_ylim(0.45, 1.02)
ax.set_title("Learnable detector (AUC=%.3f)" % res["auc_test"], fontsize=10)
ax.grid(alpha=0.3)
fig.tight_layout()
fig.savefig(BASE / "figures" / "detect_pr.png")
fig.savefig(BASE / "paper_tkde" / "figures" / "detect_pr.png")
print("saved figures/detect_pr.png")
