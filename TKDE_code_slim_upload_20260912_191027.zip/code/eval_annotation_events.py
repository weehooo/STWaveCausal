"""Annotation quality on known NYC events: zone-level precision/recall."""
import json
from datetime import datetime

import numpy as np

SEQ = 48
CF_OFFSET = 7 * 7 * SEQ
start = datetime(2011, 1, 1)

feats = np.load("data/nyc_taxi/processed/node_features.npy",
                mmap_mode="r")
labels = np.load("data/nyc_taxi/processed/labels.npy")

EVENTS = [
    ("2012-10-29", "Hurricane Sandy"),
    ("2011-12-31", "New Year's Eve"),
    ("2013-02-08", "Winter Storm Nemo"),
    ("2011-10-29", "October nor'easter"),
    ("2012-11-07", "Post-Sandy nor'easter"),
    ("2011-08-28", "Hurricane Irene"),
]


def main():
    rows = []
    for dstr, name in EVENTS:
        date = datetime.strptime(dstr, "%Y-%m-%d")
        t0 = int((date - start).total_seconds() / (30 * 60))
        t_star = t0 - CF_OFFSET
        if t_star - SEQ < 0 or t0 + SEQ >= feats.shape[0]:
            print("skip", name)
            continue
        baseline = np.array([feats[t_star:t_star + SEQ, z, 0].mean()
                             for z in range(feats.shape[1])])
        event_flow = np.array([feats[t0:t0 + SEQ, z, 0].mean()
                               for z in range(feats.shape[1])])
        drop = (baseline - event_flow) / np.maximum(baseline, 1e-6)
        affected = (baseline >= 5) & (drop > 0.4)
        flagged = labels[t0] == 1
        tp = int((affected & flagged).sum())
        n_aff = int(affected.sum())
        n_flag = int(flagged.sum())
        recall = tp / max(n_aff, 1)
        precision = tp / max(n_flag, 1)
        rows.append({
            "date": dstr, "event": name, "n_affected": n_aff,
            "flagged": n_flag, "tp": tp, "recall": recall,
            "precision": precision,
        })
        print("%-22s affected=%3d flagged=%3d tp=%3d recall=%.2f "
              "precision=%.2f" %
              (name, n_aff, n_flag, tp, recall, precision))

    agg = {
        "total_affected": sum(r["n_affected"] for r in rows),
        "total_tp": sum(r["tp"] for r in rows),
        "pooled_recall": sum(r["tp"] for r in rows) /
                        max(sum(r["n_affected"] for r in rows), 1),
        "pooled_precision": sum(r["tp"] for r in rows) /
                            max(sum(r["flagged"] for r in rows), 1),
    }
    print("AGG", agg)
    with open("annotation_event_quality.json", "w", encoding="utf-8") as f:
        json.dump({"events": rows, "summary": agg}, f, indent=2)
    print("ALL DONE")


if __name__ == "__main__":
    main()
