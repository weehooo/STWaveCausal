﻿import sys, os, numpy as np
os.chdir('F:/xuexi/codex/papers')
sys.path.insert(0, 'src/model')
from pathlib import Path
import torch, torch.nn as nn, torch.nn.functional as F

# ============================================================
# Build synthetic counterfactual pairs with KNOWN ICE ground truth
# - Use active (high-flow) zones only
# - Inject known effects: eff_a=0.7, eff_b=0.8
# - ICE_true is PERFECTLY known: |Y_f - Y_cf|
# ============================================================
device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('Device:', device)

data_dir = 'data/nyc_taxi/processed'
feats = np.load(str(Path(data_dir) / 'node_features.npy'), mmap_mode='r').astype(np.float32)
labels = np.load(str(Path(data_dir) / 'labels.npy'), mmap_mode='r')

seq_len = 48
feature_dim = 6

# Active zones: high avg flow, low sparsity
active = [z for z in range(265) if feats[:, z, 0].mean() > 50 and (feats[:, z, 0] == 0).mean() < 0.3]
print(f'Active zones: {len(active)}')

# Candidate time steps: for each active zone, find windows with no intervention
candidate_windows = []
for z in active:
    cnt = 0
    for t in range(seq_len + 5, feats.shape[0] - 1):
        if labels[t, z] == 0:
            candidate_windows.append((z, t))
            cnt += 1
            if cnt > 500:
                break
print(f'Candidate windows: {len(candidate_windows)}')

def extract_window(z, t):
    f_start = max(0, t - seq_len)
    x = feats[f_start:t, z].copy()
    if len(x) < seq_len:
        x = np.concatenate([np.zeros((seq_len - len(x), feature_dim)), x])
    return x

def inject_effect(x, factor, target_idx=None):
    '''Inject known effect into flow features (0-3), return modified sequence.'''
    x = x.copy()
    for d in [0, 1, 2, 3]:
        x[:, d] = x[:, d] * factor
    return x

# Build synthetic pairs
rng = np.random.RandomState(42)
samples = []
max_events = 5

for _ in range(20000):
    z, t = candidate_windows[rng.randint(len(candidate_windows))]
    
    # Factual: normal (no intervention) sequence
    factual = extract_window(z, t)
    y_f = feats[t, z] if t < feats.shape[0] else factual[-1]
    
    # Randomly choose single-event (70%) or dual-event (30%)
    mode = rng.rand()
    if mode < 0.7:
        # Single event A: -30%
        eff_a = 0.7
        cf_a = inject_effect(factual, eff_a)
        ice_true = np.abs(y_f - feats[t, z] * eff_a).astype(np.float32)
        cf_use = cf_a
        event_types = torch.full((max_events,), -1, dtype=torch.long)
        event_types[0] = 1
        n_events = 1
    elif mode < 0.9:
        # Single event B: -20%
        eff_b = 0.8
        cf_b = inject_effect(factual, eff_b)
        ice_true = np.abs(y_f - feats[t, z] * eff_b).astype(np.float32)
        cf_use = cf_b
        event_types = torch.full((max_events,), -1, dtype=torch.long)
        event_types[0] = 2
        n_events = 1
    else:
        # Dual event: A then B (joint - 44% reduction on flow)
        eff_ab = 0.7 * 0.8  # 0.56
        cf_ab = inject_effect(factual, eff_ab)
        ice_true = np.abs(y_f - feats[t, z] * eff_ab).astype(np.float32)
        cf_use = cf_ab
        event_types = torch.full((max_events,), -1, dtype=torch.long)
        event_types[0] = 1
        event_types[1] = 2
        n_events = 2
    
    # Combo data
    combo = {
        'event_types': event_types,
        'event_locs': torch.zeros(max_events, 2),
        'event_times': torch.zeros(max_events),
        'zone_states': torch.zeros(max_events, feature_dim),
    }
    for i in range(n_events):
        combo['event_times'][i] = float(t)
        combo['zone_states'][i] = torch.FloatTensor(feats[t, z])
    
    samples.append({
        'zone': z,
        't': t,
        'factual': torch.FloatTensor(factual),
        'cf': torch.FloatTensor(cf_use),
        'ice_true': torch.FloatTensor(ice_true),
        'combo': combo,
        'mode': 'single' if mode < 0.9 else 'dual',
    })

print(f'Total synthetic pairs: {len(samples)}')
print(f'  single: {sum(1 for s in samples if s["mode"]=="single")}')
print(f'  dual: {sum(1 for s in samples if s["mode"]=="dual")}')

# Shuffle + split
rng.shuffle(samples)
n = len(samples)
n_train = int(n * 0.8)
n_val = int(n * 0.1)
train = samples[:n_train]
val = samples[n_train:n_train+n_val]
test = samples[n_train+n_val:]
print(f'Train: {len(train)}, Val: {len(val)}, Test: {len(test)}')

# Save to disk
out = {}
for split, data in [('train', train), ('val', val), ('test', test)]:
    arr = [{
        'zone': d['zone'],
        't': d['t'],
        'factual': d['factual'],
        'cf': d['cf'],
        'ice_true': d['ice_true'],
        'combo': d['combo'],
    } for d in data]
    out[split] = arr

np.save(str(Path(data_dir) / 'synthetic_pairs_v3.npy'), out, allow_pickle=True)
print('Saved synthetic_pairs_v3.npy')
print('ALL DONE')
