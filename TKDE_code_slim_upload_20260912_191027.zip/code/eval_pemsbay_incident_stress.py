"""Frozen sensor-level concurrent incident audit on PEMS-BAY."""
import argparse
import hashlib
import json
import os
import random
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import torch
from scipy.stats import spearmanr

BASE = Path(os.environ.get("PAPERS_BASE", Path(__file__).resolve().parent))
os.chdir(BASE)
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from stwave import STWaveBlock
from stwave_causal_v3 import STWaveCausalV3
from stid_causal import STIDCausal


DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48
CF_OFFSET = 7 * 24 * 12
N_SENSORS = 325
RAW_DIM = 8
V3_DIM = 16
EPOCH = datetime(2017, 1, 1)
V3_SEEDS = [42, 1, 2]
STID_SEEDS = [42, 1, 2]
PRED_SEEDS = [1, 2, 3]
MODELS = ["V3", "STID", "Ens"]
RANKS = [10, 25, 50]
HOLIDAYS = {"2017-01-02", "2017-01-16", "2017-02-20", "2017-05-29"}


class SWPred(torch.nn.Module):
    def __init__(self, nz, nd, hidden=64, blocks=2):
        super().__init__()
        self.zone_embed = torch.nn.Embedding(nz, hidden)
        self.input_proj = torch.nn.Linear(nd, hidden)
        self.pos_embed = torch.nn.Embedding(SEQ, hidden)
        self.blocks = torch.nn.ModuleList(
            [STWaveBlock(nz, hidden) for _ in range(blocks)])
        self.pred_head = torch.nn.Sequential(
            torch.nn.Linear(hidden, hidden), torch.nn.ReLU(),
            torch.nn.Linear(hidden, nd))

    def forward(self, zone_ids, features):
        batch, seq, dim = features.shape
        x = self.input_proj(features)
        pos = torch.arange(seq, device=features.device)
        pos = pos.unsqueeze(0).expand(batch, -1)
        x = self.zone_embed(zone_ids) + x + self.pos_embed(pos)
        x = x.unsqueeze(1)
        for block in self.blocks:
            x = block(x)
        return self.pred_head(x[:, 0, -1, :])


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def bh_qvalues(pvalues):
    keys = list(pvalues)
    values = np.asarray([pvalues[key] for key in keys], dtype=float)
    order = np.argsort(values)
    ranked = values[order] * len(values) / np.arange(1, len(values) + 1)
    ranked = np.minimum.accumulate(ranked[::-1])[::-1]
    adjusted = np.empty_like(ranked)
    adjusted[order] = np.minimum(ranked, 1.0)
    return {key: float(value) for key, value in zip(keys, adjusted)}


def event_type_id(event_type):
    if "Collision" in event_type or "Hit and Run" in event_type:
        return 2
    if "Hazard" in event_type:
        return 3
    return 4


def load_sensor_metadata():
    locations = {}
    with open("data/pems_bay/raw/kaggle_extract/sensor_locations.csv",
              encoding="utf-8") as handle:
        for line in handle:
            sensor_id, lat, lon = line.strip().split(",")
            locations[sensor_id] = (float(lat), float(lon))
    sensor_ids = [str(value) for value in
                  np.load("data/pems_bay/processed/sensor_ids.npy",
                          allow_pickle=True)]
    index_to_id = {index: sensor_id for index, sensor_id in
                   enumerate(sensor_ids)}
    return locations, sensor_ids, index_to_id


def build_models():
    v3_models, stid_models, pred_models = {}, {}, {}
    for seed in V3_SEEDS:
        model = STWaveCausalV3(n_zones=N_SENSORS, input_dim=V3_DIM,
                               output_dim=RAW_DIM, ctx_channels=RAW_DIM,
                               ctx_gate=True).to(DEVICE)
        model.load_state_dict(torch.load(
            f"data/pems_bay/processed/rerun_v3_seed{seed}.pt",
            map_location=DEVICE))
        model.eval()
        v3_models[seed] = model
    for seed in STID_SEEDS:
        model = STIDCausal(n_zones=N_SENSORS, input_dim=RAW_DIM,
                           output_dim=RAW_DIM).to(DEVICE)
        model.load_state_dict(torch.load(
            f"data/pems_bay/processed/rerun_stid_seed{seed}.pt",
            map_location=DEVICE))
        model.eval()
        stid_models[seed] = model
    for seed in PRED_SEEDS:
        model = SWPred(N_SENSORS, RAW_DIM).to(DEVICE)
        model.load_state_dict(torch.load(
            f"data/pems_bay/processed/stwave_predonly_50ep_seed{seed}.pt",
            map_location=DEVICE))
        model.eval()
        pred_models[seed] = model
    return v3_models, stid_models, pred_models


def v3_windows_all(t):
    start = max(0, t - SEQ)
    window = np.asarray(feats[start:t], dtype=np.float32)
    if window.shape[0] < SEQ:
        pad = np.zeros((SEQ - window.shape[0], N_SENSORS, RAW_DIM),
                       dtype=np.float32)
        window = np.concatenate([pad, window], axis=0)
    raw = np.transpose(window, (1, 0, 2))
    ctx = np.einsum("snd,mn->msd", window, adj)
    return np.concatenate([raw, ctx - raw], axis=-1)


def fullnode_window(t):
    start = max(0, t - SEQ)
    window = np.asarray(feats[start:t], dtype=np.float32)
    if window.shape[0] < SEQ:
        pad = np.zeros((SEQ - window.shape[0], N_SENSORS, RAW_DIM),
                       dtype=np.float32)
        window = np.concatenate([pad, window], axis=0)
    return window


def raw_windows(t, sensors=None):
    start = max(0, t - SEQ)
    window = np.asarray(feats[start:t], dtype=np.float32)
    if window.shape[0] < SEQ:
        pad = np.zeros((SEQ - window.shape[0], N_SENSORS, RAW_DIM),
                       dtype=np.float32)
        window = np.concatenate([pad, window], axis=0)
    if sensors is None:
        return np.transpose(window, (1, 0, 2))
    return np.transpose(window[:, sensors], (1, 0, 2))


def state_map(t, dim):
    current = np.asarray(feats[t], dtype=np.float32)
    if dim == V3_DIM:
        ctx = adj @ current
        return np.concatenate([current, ctx - current], axis=1)
    return current


def make_combo_batch(events, times, sensors, dim):
    batch = len(times)
    target_count = batch * len(sensors)
    slots = sorted(events, key=lambda event: event["start_idx"])[:5]
    count = len(slots)
    types = torch.full((target_count, count), -1, dtype=torch.long,
                       device=DEVICE)
    locs = torch.zeros(target_count, count, 2, device=DEVICE)
    event_times = torch.zeros(target_count, count, device=DEVICE)
    states = torch.zeros(target_count, count, dim, device=DEVICE)
    for slot, event in enumerate(slots):
        lat, lon = sensor_metadata[event["sensor_id"]]
        types[:, slot] = event_type_id(event["type"])
        locs[:, slot, 0] = lat
        locs[:, slot, 1] = lon
        event_times[:, slot] = float(event["start_idx"])
    for row, (time_value, sensor_index) in enumerate(
            (time_value, sensor_index)
            for time_value in times for sensor_index in sensors):
        state_row = torch.from_numpy(np.ascontiguousarray(
            state_map(time_value, dim)[sensor_index])).to(DEVICE)
        states[row] = state_row.unsqueeze(0).expand(count, -1)
    return {"event_types": types, "event_locs": locs,
            "event_times": event_times, "zone_states": states}


@torch.no_grad()
def causal_maps(model_kind, models, events_a, events_b, t_event, t_cf):
    scenarios = [("ICE_A", events_a), ("ICE_B", events_b),
                 ("JCE_AB", events_a + events_b)]
    maps = {name: [] for name, _ in scenarios}
    for model in models:
        for name, events in scenarios:
            combo = make_combo_batch(events, [t_event],
                                     list(range(N_SENSORS)),
                                     V3_DIM if model_kind == "V3"
                                     else RAW_DIM)
            if model_kind == "V3":
                ids = torch.arange(N_SENSORS, device=DEVICE).repeat(SEQ, 1).T
                factual = {"zone_ids": ids,
                           "features": torch.from_numpy(
                               v3_windows_all(t_event)).to(DEVICE)}
                counterfactual = {"zone_ids": ids,
                                  "features": torch.from_numpy(
                                      v3_windows_all(t_cf)).to(DEVICE)}
                output = model.causal_effect(factual, counterfactual, combo)
            else:
                features = torch.from_numpy(fullnode_window(
                    t_event)).unsqueeze(0).to(DEVICE)
                cf_features = torch.from_numpy(fullnode_window(
                    t_cf)).unsqueeze(0).to(DEVICE)
                ids = torch.arange(N_SENSORS, dtype=torch.long,
                                   device=DEVICE)
                output = model.causal_effect(
                    {"features": features, "zone_ids": ids},
                    {"features": cf_features, "zone_ids": ids},
                    combo, adj_tensor)
            maps[name].append(output.mean(dim=1).cpu().numpy())
    return {name: np.mean(values, axis=0)
            for name, values in maps.items()}


@torch.no_grad()
def selected_v3_jce_batch(model, events, sensors, times):
    batch = len(times)
    features = np.stack([v3_windows_all(time_value)[sensors]
                         for time_value in times])
    flat = features.reshape(batch * len(sensors), SEQ, V3_DIM)
    ids = np.repeat(np.tile(sensors, batch)[:, None], SEQ, axis=1)
    ids_tensor = torch.as_tensor(ids, dtype=torch.long).to(DEVICE)
    cf = np.stack([v3_windows_all(time_value - CF_OFFSET)[sensors]
                   for time_value in times])
    cf_flat = cf.reshape(batch * len(sensors), SEQ, V3_DIM)
    combo = make_combo_batch(events, times, sensors, V3_DIM)
    output = model.causal_effect(
        {"zone_ids": ids_tensor,
         "features": torch.from_numpy(flat).to(DEVICE)},
        {"zone_ids": ids_tensor,
         "features": torch.from_numpy(cf_flat).to(DEVICE)},
        combo)
    return output.mean(dim=1).cpu().numpy().reshape(batch, len(sensors))


@torch.no_grad()
def selected_stid_jce_batch(model, events, sensors, times):
    batch = len(times)
    features = torch.from_numpy(np.stack(
        [fullnode_window(time_value) for time_value in times])).to(DEVICE)
    cf_features = torch.from_numpy(np.stack(
        [fullnode_window(time_value - CF_OFFSET)
         for time_value in times])).to(DEVICE)
    ids = torch.tensor(np.tile(sensors, (batch, 1)), dtype=torch.long,
                       device=DEVICE)
    combo = make_combo_batch(events, times, sensors, RAW_DIM)
    output = model.causal_effect_batched(
        {"features": features, "zone_ids": ids},
        {"features": cf_features, "zone_ids": ids},
        combo, adj_tensor)
    return output.mean(dim=1).cpu().numpy().reshape(batch, len(sensors))


@torch.no_grad()
def selected_predonly_batch(models, sensors, times):
    batch = len(times)
    features = np.stack([raw_windows(time_value, sensors)
                         for time_value in times])
    flat = features.reshape(batch * len(sensors), SEQ, RAW_DIM)
    ids = np.repeat(np.tile(sensors, batch)[:, None], SEQ, axis=1)
    ids_tensor = torch.as_tensor(ids, dtype=torch.long).to(DEVICE)
    values = []
    for model in models:
        output = model(ids_tensor, torch.from_numpy(flat).to(DEVICE))
        values.append(output.mean(dim=1).cpu().numpy().reshape(
            batch, len(sensors)))
    return np.mean(values, axis=0)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--registry",
                        default="pemsbay_incident_registry.json")
    parser.add_argument("--output", default="pemsbay_incident_results.json")
    parser.add_argument("--limit-pairs", type=int, default=0)
    parser.add_argument("--placebos", type=int, default=60)
    parser.add_argument("--permutations", type=int, default=5000)
    parser.add_argument("--bootstrap", type=int, default=2000)
    args = parser.parse_args()

    global feats, adj, adj_tensor, sensor_metadata
    torch.manual_seed(20260827)
    np.random.seed(20260827)
    random.seed(20260827)
    sensor_metadata, sensor_ids, index_to_id = load_sensor_metadata()
    registry = json.loads(Path(args.registry).read_text(encoding="utf-8"))
    all_pairs = registry["selected_pairs"]
    if len(all_pairs) < 30:
        raise RuntimeError("fewer than 30 pairs")
    pairs = all_pairs[:args.limit_pairs] if args.limit_pairs else all_pairs

    feats = np.load("data/pems_bay/processed/node_features.npy",
                    mmap_mode="r")
    adjacency = np.load("data/pems_bay/processed/adj.npy").astype(np.float32)
    adjacency /= np.maximum(adjacency.sum(axis=1, keepdims=True), 1e-6)
    adj = adjacency
    adj_tensor = torch.from_numpy(adjacency).to(DEVICE)
    print("Device:", DEVICE, flush=True)
    v3_models, stid_models, pred_models = build_models()

    all_effects, rank_thresholds, observed = {}, {}, []
    dose_rows, spatial_rows, interaction_rows, predonly_rows = [], [], [], []
    for index, pair in enumerate(pairs):
        t_event = min(event["start_idx"] for event in pair["events"])
        t_cf = t_event - CF_OFFSET
        sensor_a = sensor_ids.index(pair["events"][0]["sensor_id"])
        sensor_b = sensor_ids.index(pair["events"][1]["sensor_id"])
        sensors = [sensor_a, sensor_b]
        events_a = [pair["events"][0]]
        events_b = [pair["events"][1]]
        maps_by_model = {}
        for model_kind, models in [
                ("V3", list(v3_models.values())),
                ("STID", list(stid_models.values()))]:
            maps_by_model[model_kind] = causal_maps(
                model_kind, models, events_a, events_b, t_event, t_cf)
        ensemble = {}
        for scenario in ["ICE_A", "ICE_B", "JCE_AB"]:
            v3_map = maps_by_model["V3"][scenario]
            stid_map = maps_by_model["STID"][scenario]
            v3_z = (v3_map - v3_map.mean()) / (v3_map.std() + 1e-8)
            stid_z = (stid_map - stid_map.mean()) / (stid_map.std() + 1e-8)
            ensemble[scenario] = (v3_z + stid_z) / 2.0
        maps_by_model["Ens"] = ensemble
        all_effects[pair["pair_id"]] = maps_by_model
        rank_thresholds[pair["pair_id"]] = {
            model: {scenario: {
                rank: float(np.partition(maps_by_model[model][scenario],
                                         -rank)[-rank])
                for rank in RANKS}
                for scenario in ["ICE_A", "ICE_B", "JCE_AB"]}
            for model in MODELS}

        for model in MODELS:
            maps = maps_by_model[model]
            for side, sensor in enumerate(sensors):
                scenario = "ICE_A" if side == 0 else "ICE_B"
                score = float(maps[scenario][sensor])
                observed.append({
                    "pair_id": pair["pair_id"], "model": model,
                    "relation": pair["spatial_relation"],
                    "sensor": sensor, "score": score,
                    "duration_minutes": float(
                        pair["events"][side]["duration_minutes"]),
                    "type": pair["events"][side]["type"],
                })
                dose_rows.append({
                    "pair_id": pair["pair_id"], "model": model,
                    "sensor": sensor,
                    "duration_minutes": float(
                        pair["events"][side]["duration_minutes"]),
                    "ice_score": score,
                })
                spatial_p = (1.0 + float(np.sum(
                    maps[scenario] >= score))) / (1.0 + N_SENSORS)
                spatial_rows.append({
                    "pair_id": pair["pair_id"], "model": model,
                    "sensor": sensor,
                    "all_sensor_percentile": float(np.mean(
                        maps[scenario] <= score)),
                    "p_upper": spatial_p,
                })
            residual = (maps["JCE_AB"] - maps["ICE_A"] -
                        maps["ICE_B"])
            boot = residual[np.random.randint(0, N_SENSORS,
                                              size=args.bootstrap)]
            interaction_rows.append({
                "pair_id": pair["pair_id"], "model": model,
                "relation": pair["spatial_relation"],
                "delta_int": float(residual.mean()),
                "ci95": [float(np.quantile(boot, 0.025)),
                         float(np.quantile(boot, 0.975))],
            })

        pred = predonly_difference(pred_models, t_event, t_cf)
        treated = float(np.mean(pred[sensors]))
        predonly_rows.append({
            "pair_id": pair["pair_id"],
            "relation": pair["spatial_relation"],
            "treated_score": treated,
            "all_sensor_percentile": float(np.mean(pred <= treated)),
            "p_upper": (1.0 + float(np.sum(pred >= treated))) /
            (1.0 + N_SENSORS),
        })
        if (index + 1) % 10 == 0 or index + 1 == len(pairs):
            print(f"observed pairs {index + 1}/{len(pairs)}", flush=True)

    primary_tests = []
    rng = random.Random(20260827)
    for model in MODELS:
        for relation in ["adjacent", "disjoint"]:
            relation_pairs = [pair for pair in pairs
                              if pair["spatial_relation"] == relation]
            if not relation_pairs:
                continue
            null_hits = np.zeros((args.permutations, 2 * len(RANKS)),
                                 dtype=np.int16)
            for rep in range(args.permutations):
                total = np.zeros(2 * len(RANKS), dtype=np.int16)
                for pair in relation_pairs:
                    false_a, false_b = rng.sample(range(N_SENSORS), 2)
                    maps = all_effects[pair["pair_id"]][model]
                    thresholds = rank_thresholds[pair["pair_id"]][model]
                    hits = []
                    for side, score in enumerate(
                            [maps["ICE_A"][false_a],
                             maps["ICE_B"][false_b]]):
                        scenario = "ICE_A" if side == 0 else "ICE_B"
                        for rank in RANKS:
                            hits.append(int(score >= thresholds[scenario][rank]))
                    total += np.asarray(hits, dtype=np.int16)
                null_hits[rep] = total
            for rank_index, rank in enumerate(RANKS):
                observed_hits = 0
                for pair in relation_pairs:
                    for side, scenario in enumerate(["ICE_A", "ICE_B"]):
                        sensor = (sensor_ids.index(
                            pair["events"][side]["sensor_id"]))
                        score = all_effects[pair["pair_id"]][model][scenario][
                            sensor]
                        threshold = rank_thresholds[pair["pair_id"]][model][
                            scenario][rank]
                        observed_hits += int(score >= threshold)
                pvalue = (1.0 + float(np.sum(null_hits[:,
                                                       [rank_index,
                                                        rank_index + len(RANKS)]
                                                       ] >= observed_hits))) / \
                    (1.0 + args.permutations)
                primary_tests.append({
                    "model": model, "relation": relation, "rank": rank,
                    "n_pairs": len(relation_pairs),
                    "n_documented_incidents": 2 * len(relation_pairs),
                    "observed_hits": int(observed_hits),
                    "p_upper": pvalue,
                })
    qvalues = bh_qvalues({
        f"{row['model']}|{row['relation']}|top{row['rank']}":
        row["p_upper"] for row in primary_tests})
    for row in primary_tests:
        row["q_bh"] = qvalues[
            f"{row['model']}|{row['relation']}|top{row['rank']}"]

    dose = {}
    for model in MODELS:
        rows = [row for row in dose_rows if row["model"] == model]
        result = spearmanr([row["duration_minutes"] for row in rows],
                           [row["ice_score"] for row in rows])
        dose[model] = {"spearman_rho": float(result.statistic),
                       "spearman_p": float(result.pvalue)}

    spatial_summary = {}
    for model in MODELS:
        rows = [row for row in spatial_rows if row["model"] == model]
        pvalues = {f"{row['pair_id']}:{row['sensor']}": row["p_upper"]
                   for row in rows}
        qs = bh_qvalues(pvalues)
        for row in rows:
            row["q_bh"] = qs[f"{row['pair_id']}:{row['sensor']}"]
        spatial_summary[model] = {
            "median_p_upper": float(np.median([row["p_upper"] for row in rows])),
            "n_bh_q_lt_0_05": sum(row["q_bh"] < 0.05 for row in rows),
        }

    day_ordinals = [datetime.fromisoformat(pair["date"]).toordinal()
                    for pair in pairs]
    valid_times = [t for t in range(CF_OFFSET + SEQ + 48,
                                     feats.shape[0] - SEQ - 48)]
    valid_times = [t for t in valid_times
                   if (EPOCH + timedelta(minutes=5 * t)).date().isoformat()
                   not in HOLIDAYS]
    valid_times = [t for t in valid_times
                   if not any(abs((EPOCH + timedelta(
                       minutes=5 * t)).date().toordinal() - day) <= 7
                       for day in day_ordinals)]
    temporal_rows = []
    for index, pair in enumerate(pairs):
        sensors = [sensor_ids.index(pair["events"][0]["sensor_id"]),
                   sensor_ids.index(pair["events"][1]["sensor_id"])]
        t_event = min(event["start_idx"] for event in pair["events"])
        raw_series = np.asarray(feats[:, sensors, 0], dtype=np.float32)
        baseline_series = np.convolve(
            raw_series.mean(axis=1),
            np.ones(SEQ, dtype=np.float32) / SEQ, mode="same")
        valid_baselines = baseline_series[valid_times]
        edges = np.quantile(valid_baselines, np.linspace(0.1, 0.9, 9))
        baseline_lookup = dict(zip(valid_times, valid_baselines))

        def decile(value):
            return int(np.searchsorted(edges, value, side="right"))

        target_decile = decile(baseline_series[t_event])
        target_weekday = (EPOCH + timedelta(
            minutes=5 * t_event)).weekday()
        exact, loose = [], []
        for candidate, baseline in baseline_lookup.items():
            date = EPOCH + timedelta(minutes=5 * candidate)
            if date.weekday() != target_weekday:
                continue
            loose.append((candidate, baseline))
            if decile(baseline) == target_decile:
                exact.append((candidate, baseline))
        if len(exact) >= args.placebos:
            chosen = [candidate for candidate, _ in exact]
        else:
            loose.sort(key=lambda item: abs(item[1] - baseline_series[t_event]))
            exact_ids = {candidate for candidate, _ in exact}
            chosen = [candidate for candidate, _ in exact]
            chosen += [candidate for candidate, _ in loose
                       if candidate not in exact_ids]
            chosen = chosen[:max(args.placebos, len(exact))]
        if len(chosen) < args.placebos:
            raise RuntimeError(f"only {len(chosen)} placebos")
        chosen = sorted(random.sample(chosen, args.placebos))
        events_a = [pair["events"][0]]
        events_b = [pair["events"][1]]
        values = {"V3": [], "STID": [], "PredOnly": []}
        for start in range(0, len(chosen), 8):
            times = chosen[start:start + 8]
            v3_scores = [selected_v3_jce_batch(
                v3_models[seed], events_a + events_b, sensors, times)
                for seed in V3_SEEDS]
            stid_scores = [selected_stid_jce_batch(
                stid_models[seed], events_a + events_b, sensors, times)
                for seed in STID_SEEDS]
            values["V3"].extend(np.mean(v3_scores, axis=0).mean(axis=1).tolist())
            values["STID"].extend(np.mean(stid_scores, axis=0).mean(axis=1).tolist())
            values["PredOnly"].extend(np.mean(selected_predonly_batch(
                list(pred_models.values()), sensors, times), axis=1).tolist())
        details = {}
        observed_raw = {
            "V3": float(np.mean(all_effects[pair["pair_id"]]["V3"]["JCE_AB"][sensors])),
            "STID": float(np.mean(all_effects[pair["pair_id"]]["STID"]["JCE_AB"][sensors])),
        }
        for model in MODELS + ["PredOnly"]:
            if model == "PredOnly":
                observed_value = next(row["treated_score"] for row
                                       in predonly_rows
                                       if row["pair_id"] == pair["pair_id"])
                placebo_values = values["PredOnly"]
            elif model == "Ens":
                v3 = np.asarray(values["V3"], dtype=float)
                stid = np.asarray(values["STID"], dtype=float)
                v3_z = (v3 - v3.mean()) / (v3.std() + 1e-8)
                stid_z = (stid - stid.mean()) / (stid.std() + 1e-8)
                placebo_values = ((v3_z + stid_z) / 2.0).tolist()
                observed_value = (
                    (observed_raw["V3"] - v3.mean()) / (v3.std() + 1e-8) +
                    (observed_raw["STID"] - stid.mean()) / (stid.std() + 1e-8)) / 2.0
            else:
                observed_value = observed_raw[model]
                placebo_values = values[model]
            pvalue = (1.0 + float(np.sum(np.asarray(placebo_values) >=
                                         observed_value))) / \
                (1.0 + len(placebo_values))
            details[model] = {
                "observed": observed_value,
                "placebo_mean": float(np.mean(placebo_values)),
                "p_upper": pvalue,
            }
        temporal_rows.append({"pair_id": pair["pair_id"],
                               "relation": pair["spatial_relation"],
                               **details})
        if (index + 1) % 10 == 0 or index + 1 == len(pairs):
            print(f"temporal placebos {index + 1}/{len(pairs)}", flush=True)

    temporal_summary = {}
    for model in MODELS + ["PredOnly"]:
        pvalues = {row["pair_id"]: row[model]["p_upper"]
                   for row in temporal_rows}
        qs = bh_qvalues(pvalues)
        for row in temporal_rows:
            row[model]["q_bh"] = qs[row["pair_id"]]
        temporal_summary[model] = {
            "median_placebo_p_upper": float(np.median(list(pvalues.values()))),
            "n_pairs_bh_q_lt_0_05": sum(v < 0.05 for v in qs.values()),
        }

    output = {
        "protocol_name": "PEMS-BAY sensor-level concurrent incident audit",
        "metadata": {
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "python": sys.version.split()[0],
            "torch": torch.__version__,
            "registry_sha256": sha256(args.registry),
        },
        "configuration": {
            "n_pairs": len(pairs), "placebos": args.placebos,
            "permutations": args.permutations,
            "bootstrap": args.bootstrap,
        },
        "summary": {
            "primary": {
                "n_tests": len(primary_tests),
                "n_bh_significant": sum(row["q_bh"] < 0.05
                                         for row in primary_tests),
                "tests": primary_tests,
            },
            "dose_response": dose,
            "spatial_localization": spatial_summary,
            "temporal_specificity": temporal_summary,
            "interaction_median_delta_int": {
                model: float(np.median([
                    row["delta_int"] for row in interaction_rows
                    if row["model"] == model]))
                for model in MODELS
            },
            "predonly_median_all_sensor_percentile": {
                relation: float(np.median([
                    row["all_sensor_percentile"] for row in predonly_rows
                    if row["relation"] == relation]))
                for relation in ["adjacent", "disjoint"]
            },
        },
    }
    Path(args.output).write_text(json.dumps(output, indent=2),
                                 encoding="utf-8")
    print(json.dumps(output["summary"], indent=2), flush=True)
    print("ALL PEMS-BAY INCIDENT AUDIT DONE", flush=True)


@torch.no_grad()
def predonly_difference(models, t_event, t_cf):
    scores = []
    for seed in PRED_SEEDS:
        model = models[seed]
        full = torch.from_numpy(raw_windows(t_event)).to(DEVICE)
        cf_full = torch.from_numpy(raw_windows(t_cf)).to(DEVICE)
        chunks = []
        for start in range(0, N_SENSORS, 64):
            ids = torch.arange(start, min(start + 64, N_SENSORS),
                               device=DEVICE).repeat(SEQ, 1).T
            factual = full[start:start + 64]
            counterfactual = cf_full[start:start + 64]
            diff = (model(ids, factual) - model(ids, counterfactual)).abs()
            chunks.append(diff.mean(dim=1).cpu().numpy())
        scores.append(np.concatenate(chunks))
    return np.mean(scores, axis=0)


if __name__ == "__main__":
    main()
