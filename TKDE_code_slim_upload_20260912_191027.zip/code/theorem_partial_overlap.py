"""Simulation validation for the partial-overlap identifiability theorem.

The theorem bounds the bias of the matched estimator by L*eps + (1-rho)*Delta,
where rho is the matching rate and Delta is the unmatched selection bias.  We
sweep intervention density and caliper, and also study rare event combos whose
coverage may be too low for identification.
"""
import numpy as np
from scipy.stats import norm


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def run_seed(rng, a0, eps, n=30000):
    S1 = rng.uniform(0, 1, n)
    e = sigmoid(a0 + 1.0 * S1)
    T = (rng.rand(n) < e).astype(int)
    Y0 = 1 + 2 * S1 + rng.normal(0, 0.1, n)
    tau = 1.5 + 2.0 * S1  # Lipschitz constant L = 2.0 w.r.t. S1
    Y1 = Y0 + tau

    treated = np.where(T == 1)[0]
    controls = T == 0
    S_sorted = S1[controls]
    order = np.argsort(S_sorted)
    S_sorted = S_sorted[order]
    idx_controls = np.where(controls)[0][order]

    ests = []
    matched_tau = []
    unmatched_tau = []
    for i in treated:
        s = S1[i]
        pos = np.searchsorted(S_sorted, s)
        best = None
        for q in (pos - 1, pos, pos + 1):
            if 0 <= q < len(S_sorted):
                j = idx_controls[q]
                d = abs(S1[j] - s)
                if best is None or d < best[0]:
                    best = (d, j)
        if best is not None and best[0] <= eps:
            j = best[1]
            ests.append(Y1[i] - Y0[j])
            matched_tau.append(tau[i])
        else:
            unmatched_tau.append(tau[i])

    rho = len(ests) / len(treated)
    if len(ests) == 0:
        return None
    est_mean = np.mean(ests)
    true_ace = tau[treated].mean()
    bias = est_mean - true_ace
    delta_true = abs(np.mean(matched_tau) - (np.mean(unmatched_tau)
                                             if unmatched_tau else np.mean(matched_tau)))
    bound_true = 2.0 * eps + (1 - rho) * delta_true
    n_m = len(ests)
    z = norm.ppf(0.95)
    sigma_hat = np.std(ests)
    delta_hat = (np.max(ests) - np.min(ests)) / 2.0
    bound_est = (2.0 * eps + (1 - rho) * delta_hat
                 + z * sigma_hat / np.sqrt(n_m))
    return {
        "p": len(treated) / n,
        "rho": rho,
        "bias": bias,
        "bound_est": bound_est,
        "bound_true": bound_true,
        "covered": abs(true_ace - est_mean) <= bound_est,
        "covered_true": abs(bias) <= bound_true,
    }


def main():
    rng = np.random.RandomState(42)
    print("density/caliper sweep")
    for a0 in [0.5, 1.5, 2.5, 3.5]:
        for eps in [0.001, 0.002, 0.005]:
            res = [r for r in (run_seed(rng, a0, eps) for _ in range(100))
                   if r is not None]
            if not res:
                continue
            p = np.mean([r["p"] for r in res])
            rho = np.mean([r["rho"] for r in res])
            mbias = np.mean([abs(r["bias"]) for r in res])
            mbound = np.mean([r["bound_est"] for r in res])
            mbt = np.mean([r["bound_true"] for r in res])
            cov = np.mean([r["covered"] for r in res])
            covt = np.mean([r["covered_true"] for r in res])
            print("a0=%.1f p=%.3f eps=%.2f rho=%.3f |bias|=%.4f "
                  "bound_est=%.4f cov90=%.3f bound_true=%.4f cov_true=%.3f"
                  % (a0, p, eps, rho, mbias, mbound, cov, mbt, covt))

    print("\ncombo coverage (rare AB)")
    for a0 in [1.5, 2.5]:
        rho_combo = {c: [] for c in ["A", "B", "AB"]}
        cov_combo = {c: [] for c in ["A", "B", "AB"]}
        for _ in range(100):
            n = 20000
            S1 = rng.uniform(0, 1, n)
            combo_raw = rng.rand(n)
            combo = np.where(combo_raw < 0.7, "A",
                             np.where(combo_raw < 0.9, "B", "AB"))
            S1 = np.where(combo == "AB", 0.95 + 0.05 * S1, S1)
            e = sigmoid(a0 + 1.0 * S1)
            T = (rng.rand(n) < e).astype(int)
            Y0 = 1 + 2 * S1 + rng.normal(0, 0.3, n)
            tau = 1.5 + 1.0 * S1
            Y1 = Y0 + tau
            controls = T == 0
            S_sorted = S1[controls]
            order = np.argsort(S_sorted)
            S_sorted = S_sorted[order]
            idx_c = np.where(controls)[0][order]
            for c in ["A", "B", "AB"]:
                tr = np.where((T == 1) & (combo == c))[0]
                if len(tr) == 0:
                    continue
                ests = []
                for i in tr:
                    s = S1[i]
                    pos = np.searchsorted(S_sorted, s)
                    best = None
                    for q in (pos - 1, pos, pos + 1):
                        if 0 <= q < len(S_sorted):
                            d = abs(S1[idx_c[q]] - s)
                            if best is None or d < best[0]:
                                best = (d, idx_c[q])
                    if best is not None and best[0] <= 0.005:
                        ests.append(Y1[i] - Y0[best[1]])
                rho_combo[c].append(len(ests) / len(tr))
                if len(ests) > 0:
                    ace = tau[tr].mean()
                    est = np.mean(ests)
                    sig = np.std(ests)
                    bound = (0.005 + (1 - len(ests) / len(tr))
                             * ((np.max(ests) - np.min(ests)) / 2)
                             + norm.ppf(0.95) * sig / np.sqrt(len(ests)))
                    cov_combo[c].append(abs(ace - est) <= bound)
        for c in ["A", "B", "AB"]:
            if rho_combo[c]:
                print("a0=%.1f combo=%s rho=%.3f cov90=%.3f"
                      % (a0, c, np.mean(rho_combo[c]), np.mean(cov_combo[c])))


if __name__ == "__main__":
    main()
