"""Relative-effect joint recalibration from PEMS-BAY to NYC.

The target is the donor-free event effect divided by the pre-event baseline.
This removes the speed-vs-flow unit mismatch. A weighted ridge is fit jointly
on source PEMS-BAY samples and k target NYC samples, with target samples
upweighted.
"""
import json
import os
import sys
from datetime import datetime

import numpy as np
import torch

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

import eval_causal_estimators as ec
from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"


def metrics(y_true, y_pred):
    ss_res = float(np.sum((y_true - y_pred) ** 2))
    ss_tot = float(np.sum((y_true - y_true.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    mae = float(np.mean(np.abs(y_true - y_pred)))
    bias = float(np.mean(y_pred - y_true))
    corr = float(np.corrcoef(y_true, y_pred)[0, 1])
    return {"r2": r2, "mae": mae, "bias": bias, "corr": corr}


def weighted_ridge_predict(X_src, y_src, X_tgt_cal, y_tgt_cal, X_test,
                           target_weight=10.0, lam=1.0):
    X_all = np.vstack([X_src, X_tgt_cal])
    y_all = np.concatenate([y_src, y_tgt_cal])
    w = np.concatenate([np.ones(len(X_src)),
                        np.full(len(X_tgt_cal), target_weight)])
    X_all = np.column_stack([np.ones(len(X_all)), X_all]) * np.sqrt(w[:, None])
    y_all = y_all * np.sqrt(w)
    X_test_aug = np.column_stack([np.ones(len(X_test)), X_test])
    A = X_all.T @ X_all + lam * np.eye(X_all.shape[1])
    b = X_all.T @ y_all
    beta = np.linalg.solve(A, b)
    return X_test_aug @ beta


def build_nyc_features():
    model = STWaveCausalV3(
        n_zones=265, input_dim=12, output_dim=6, ctx_channels=6,
        ctx_gate=True,
    ).to(device)
    model.load_state_dict(torch.load(
        "data/nyc_taxi/processed/rerun_v3_seed42.pt", map_location=device))
    model.eval()

    comparison = json.load(
        open("causal_estimator_comparison.json", encoding="utf-8"))
    rows = comparison["rows"]
    event_dates = {name: datetime.strptime(date, "%Y-%m-%d")
                   for date, name in ec.EVENTS}
    feats, targets = [], []
    with torch.no_grad():
        for r in rows:
            event = r["event"]
            if event not in event_dates:
                continue
            date = event_dates[event]
            t0 = int((date - ec.start).total_seconds() / 1800)
            t_cf = t0 - ec.CF_OFFSET
            zone = int(r["zone"])
            baseline = float(np.mean(ec.feats[max(0, t0 - 48):t0, zone, 0]))
            if baseline < 1e-6:
                continue
            ff = torch.FloatTensor(
                ec.window_v3(zone, t0)).unsqueeze(0).to(device)
            cf = torch.FloatTensor(
                ec.window_v3(zone, t_cf)).unsqueeze(0).to(device)
            zid = torch.full((1, ec.SEQ), zone, dtype=torch.long,
                             device=device)
            h_f, pred_f = model(zid, ff)
            h_cf, pred_cf = model(zid, cf)
            cov = np.array([
                0.0,
                0.0,
                float((t0 % 48) / 48.0),
                float(((t0 // 48) % 7) / 7.0),
            ], dtype=np.float32)
            feat = np.concatenate([
                h_f[0].cpu().numpy(),
                h_cf[0].cpu().numpy(),
                cov,
            ])
            feats.append(feat)
            targets.append(float(r["did"]) / baseline)
    return np.stack(feats).astype(np.float64), np.array(targets)


def main():
    data = np.load("pemsbay_magnitude_features.npz")
    X_src = data["X"].astype(np.float64)
    ids = data["ids"]
    starts = data["starts"]
    src_cols = list(range(128)) + list(range(144, 148))
    X_src = X_src[:, src_cols]

    study = json.load(open("pemsbay_eventsudy_results.json", encoding="utf-8"))
    by_id = {r["incident_id"]: r for r in study["per_event"]}
    sensor_ids = [str(v) for v in
                  np.load("data/pems_bay/processed/sensor_ids.npy",
                          allow_pickle=True)]
    idx = {sid: i for i, sid in enumerate(sensor_ids)}
    pems_speed = np.load("data/pems_bay/processed/node_features.npy",
                         mmap_mode="r")[:, :, 0]
    y_src = []
    keep = []
    for i, incident_id in enumerate(ids):
        row = by_id.get(str(incident_id))
        if row is None:
            continue
        z = idx[row["sensor_id"]]
        t0 = int(row["start_idx"])
        baseline = float(np.mean(pems_speed[max(0, t0 - 6):t0, z]))
        if baseline < 1e-6:
            continue
        y_src.append(float(np.mean(row["curve"][6:])) / baseline)
        keep.append(i)
    X_src = X_src[np.array(keep)]
    y_src = np.array(y_src)

    mean = X_src.mean(axis=0)
    std = X_src.std(axis=0) + 1e-8
    X_src = (X_src - mean) / std

    X_tgt, y_tgt = build_nyc_features()
    X_tgt = (X_tgt - mean) / std
    rng = np.random.RandomState(20260908)
    out = {"n_source": int(len(X_src)), "n_target": int(len(y_tgt)),
           "joint_weighted": {}}
    for k in [5, 10, 20, 40]:
        if k >= len(y_tgt):
            continue
        vals = []
        for _ in range(200):
            cal_idx = rng.choice(len(y_tgt), k, replace=False)
            test_idx = np.array([i for i in range(len(y_tgt))
                                 if i not in cal_idx])
            pred = weighted_ridge_predict(X_src, y_src,
                                          X_tgt[cal_idx], y_tgt[cal_idx],
                                          X_tgt[test_idx])
            vals.append(metrics(y_tgt[test_idx], pred))
        out["joint_weighted"][str(k)] = {
            "mae_mean": float(np.mean([v["mae"] for v in vals])),
            "mae_std": float(np.std([v["mae"] for v in vals])),
            "corr_mean": float(np.mean([v["corr"] for v in vals])),
            "corr_std": float(np.std([v["corr"] for v in vals])),
            "r2_mean": float(np.mean([v["r2"] for v in vals])),
            "r2_std": float(np.std([v["r2"] for v in vals])),
        }

    with open("nyc_relative_joint_recalibration.json", "w",
              encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)
    print("Wrote nyc_relative_joint_recalibration.json", flush=True)


if __name__ == "__main__":
    main()
