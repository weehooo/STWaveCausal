"""Cross-dataset flow magnitude transfer: PEMS08 -> PEMS04.

Both datasets use the same flow units and graph-context V3 interface. For each
matched intervention, the target is the observed matched-pair effect
Y(t,zone)-Y(t*,zone). Frozen V3 embeddings are extracted for source and target,
then a ridge head is trained on PEMS08 and evaluated on PEMS04 with zero-shot
and few-shot recalibration.
"""
import json
import os
import sys

import numpy as np
import torch

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from graphctx_dataset import GraphCtxCausalDataset
from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48


def ridge_fit_predict(X, y, X_test, lam=1.0):
    X = np.column_stack([np.ones(len(X)), X])
    X_test = np.column_stack([np.ones(len(X_test)), X_test])
    A = X.T @ X + lam * np.eye(X.shape[1])
    w = np.linalg.solve(A, X.T @ y)
    return X_test @ w


def metrics(y_true, y_pred):
    ss_res = float(np.sum((y_true - y_pred) ** 2))
    ss_tot = float(np.sum((y_true - y_true.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    mae = float(np.mean(np.abs(y_true - y_pred)))
    bias = float(np.mean(y_pred - y_true))
    corr = float(np.corrcoef(y_true, y_pred)[0, 1])
    return {"r2": r2, "mae": mae, "bias": bias, "corr": corr}


def affine_fit_predict(s, t, y):
    A = np.column_stack([np.ones(len(s)), s])
    w, *_ = np.linalg.lstsq(A, y, rcond=None)
    return np.column_stack([np.ones(len(t)), t]) @ w


def build_features(name, ckpt, split):
    data_dir = "data/%s/processed" % name
    meta = np.load("data/datasets/%s_staeformer/data.npz" % name)["data"][..., 1:3][:, 0]
    ds = GraphCtxCausalDataset(data_dir, split, SEQ, ctx_mode="mean", meta=meta)
    adj = ds.adj
    model = STWaveCausalV3(
        n_zones=ds.N, input_dim=4, output_dim=1, ctx_channels=1,
        ctx_gate=True,
    ).to(device)
    model.load_state_dict(torch.load(data_dir + "/" + ckpt, map_location=device))
    model.eval()

    feats, targets = [], []
    with torch.no_grad():
        for s in ds.samples:
            zone = int(s["zone"])
            t = int(s["t_factual"])
            t_star = int(s.get("t_counter") or t)
            if t_star < 0 or t_star >= ds.T:
                continue
            factual = torch.FloatTensor(ds._aug_window(t, zone)).unsqueeze(0).to(device)
            counter = torch.FloatTensor(ds._aug_window(t_star, zone)).unsqueeze(0).to(device)
            zid = torch.full((1, SEQ), zone, dtype=torch.long, device=device)
            h_f, _ = model(zid, factual)
            h_cf, _ = model(zid, counter)
            cov = np.array([
                0.0,
                0.0,
                float((t % 48) / 48.0),
                float(((t // 48) % 7) / 7.0),
            ], dtype=np.float32)
            feat = np.concatenate([h_f[0].cpu().numpy(), h_cf[0].cpu().numpy(), cov])
            feats.append(feat)
            targets.append(float(ds.features[t, zone, 0] -
                                 ds.features[t_star, zone, 0]))
    return np.stack(feats).astype(np.float64), np.array(targets)


def main():
    X_src, y_src = build_features("pems08",
                                  "stwave_causal_v3_graphctx_gate_pems08_best.pt",
                                  "train")
    X_tgt, y_tgt = build_features("pems04",
                                  "stwave_causal_v3_graphctx_gate_pems04_seed2.pt",
                                  "test")
    mean = X_src.mean(axis=0)
    std = X_src.std(axis=0) + 1e-8
    X_src = (X_src - mean) / std
    X_tgt = (X_tgt - mean) / std

    zero_pred = ridge_fit_predict(X_src, y_src, X_tgt, lam=1.0)
    out = {
        "n_source": int(len(X_src)),
        "n_target": int(len(X_tgt)),
        "zero_shot": metrics(y_tgt, zero_pred),
        "few_shot": {},
    }
    rng = np.random.RandomState(20260908)
    for k in [5, 10, 20, 40]:
        if k >= len(y_tgt):
            continue
        vals = []
        for _ in range(200):
            cal_idx = rng.choice(len(y_tgt), k, replace=False)
            test_idx = np.array([i for i in range(len(y_tgt))
                                 if i not in cal_idx])
            pred = affine_fit_predict(zero_pred[cal_idx], zero_pred[test_idx],
                                      y_tgt[cal_idx])
            vals.append(metrics(y_tgt[test_idx], pred))
        out["few_shot"][str(k)] = {
            "mae_mean": float(np.mean([v["mae"] for v in vals])),
            "mae_std": float(np.std([v["mae"] for v in vals])),
            "corr_mean": float(np.mean([v["corr"] for v in vals])),
            "corr_std": float(np.std([v["corr"] for v in vals])),
            "r2_mean": float(np.mean([v["r2"] for v in vals])),
            "r2_std": float(np.std([v["r2"] for v in vals])),
        }

    with open("pems_flow_transfer.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)
    print("Wrote pems_flow_transfer.json", flush=True)


if __name__ == "__main__":
    main()
