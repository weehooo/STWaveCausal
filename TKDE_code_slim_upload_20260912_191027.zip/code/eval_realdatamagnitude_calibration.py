"""Post-hoc real-data magnitude calibration on PEMS-BAY incidents.

The model effect is not directly calibrated against the model-free event-study
post effect. This script tests whether a simple chronological calibration can
recover real-data magnitude from (a) the V3 model effect alone or (b) model
effect plus incident covariates. It is intentionally cross-validated by time
order so the evaluation uses future held-out incidents.
"""
import json
from pathlib import Path

import numpy as np

BASE = Path("F:/xuexi/codex/papers")


def load_rows():
    model = json.load(
        (BASE / "pemsbay_model_effect_comparison.json").open("r",
                                                             encoding="utf-8"))
    study = json.load(
        (BASE / "pemsbay_eventsudy_results.json").open("r",
                                                       encoding="utf-8"))
    by_id = {r["incident_id"]: r for r in study["per_event"]}
    rows = []
    for r in model["rows"]:
        e = by_id.get(r["incident_id"])
        if e is None:
            continue
        severity = int(e["type"] in {
            "1183-Trfc Collision-Unkn Inj",
            "1182-Trfc Collision-No Inj",
            "1179-Trfc Collision-1141 Enrt",
            "1181-Trfc Collision-Minor Inj",
            "20001-Hit and Run w/Injuries",
        })
        rows.append({
            "start_idx": int(r["start_idx"]),
            "model_effect": float(r["model_effect"]),
            "post_effect": float(r["event_study_post_effect"]),
            "duration": float(e["duration_minutes"]),
            "severity": float(severity),
            "tod": float((int(r["start_idx"]) % 288) / 288.0),
            "dow": float((int(r["start_idx"]) // 288) % 7 / 7.0),
        })
    rows.sort(key=lambda r: r["start_idx"])
    return rows


def ridge_fit_predict(X, y, X_test, lam=1.0):
    X = np.column_stack([np.ones(len(X)), X])
    X_test = np.column_stack([np.ones(len(X_test)), X_test])
    A = X.T @ X + lam * np.eye(X.shape[1])
    b = X.T @ y
    w = np.linalg.solve(A, b)
    return X_test @ w


def metrics(y_true, y_pred):
    ss_res = float(np.sum((y_true - y_pred) ** 2))
    ss_tot = float(np.sum((y_true - y_true.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    mae = float(np.mean(np.abs(y_true - y_pred)))
    bias = float(np.mean(y_pred - y_true))
    corr = float(np.corrcoef(y_true, y_pred)[0, 1])
    return {"r2": r2, "mae": mae, "bias": bias, "corr": corr}


def main():
    rows = load_rows()
    n = len(rows)
    split = int(n * 0.7)
    train, test = rows[:split], rows[split:]

    model_col = np.array([r["model_effect"] for r in train]).reshape(-1, 1)
    test_model = np.array([r["model_effect"] for r in test]).reshape(-1, 1)
    y_train = np.array([r["post_effect"] for r in train])
    y_test = np.array([r["post_effect"] for r in test])

    cov_cols = ["model_effect", "duration", "severity", "tod", "dow"]
    X_train = np.array([[r[c] for c in cov_cols] for r in train])
    X_test = np.array([[r[c] for c in cov_cols] for r in test])

    baseline_pred = np.full_like(y_test, float(y_train.mean()))
    model_pred = ridge_fit_predict(model_col, y_train, test_model, lam=1.0)
    cov_pred = ridge_fit_predict(X_train, y_train, X_test, lam=1.0)

    out = {
        "n_train": int(len(train)),
        "n_test": int(len(test)),
        "baseline_mean": metrics(y_test, baseline_pred),
        "model_only": metrics(y_test, model_pred),
        "model_plus_covariates": metrics(y_test, cov_pred),
    }
    with open("realdatamagnitude_calibration.json", "w",
              encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)
    print("Wrote realdatamagnitude_calibration.json", flush=True)


if __name__ == "__main__":
    main()
