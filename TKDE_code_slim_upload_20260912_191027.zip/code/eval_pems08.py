"""Evaluate all PEMS08 models with the paper pipeline and print table rows."""
import os
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from dataset import TrafficCausalDataset
from graph_dataset import GraphTrafficDataset
from stwave import STWave, STWaveBlock
from crossgnn import CrossGNN
from stid_graph import STIDGraph
from stwave_causal_v3 import STWaveCausalV3, collate_v3

DATA = "data/pems08/processed"
NZ, ND = 170, 1
device = "cuda" if torch.cuda.is_available() else "cpu"


class SWPred(nn.Module):
    def __init__(self, nz, nd, h=64, b=2):
        super().__init__()
        self.zone_embed = nn.Embedding(nz, h)
        self.input_proj = nn.Linear(nd, h)
        self.pos_embed = nn.Embedding(48, h)
        self.blocks = nn.ModuleList([STWaveBlock(nz, h) for _ in range(b)])
        self.pred_head = nn.Sequential(nn.Linear(h, h), nn.ReLU(), nn.Linear(h, nd))

    def forward(self, zid, feats):
        B, S, D = feats.shape
        x = self.input_proj(feats)
        pos = torch.arange(S, device=feats.device).unsqueeze(0).expand(B, -1)
        x = (self.zone_embed(zid) + x + self.pos_embed(pos)).unsqueeze(1)
        for blk in self.blocks:
            x = blk(x)
        return self.pred_head(x[:, 0, -1, :])


def collate_pred(batch):
    f, _, _, _, _ = zip(*batch)
    def sd(d):
        return {k: torch.stack([x[k] for x in d]) for k in d[0].keys()}
    return sd(f)


def collate_graph(batch):
    return {
        "zone_ids": torch.stack([b["zone_ids"] for b in batch]),
        "features": torch.stack([b["features"] for b in batch]),
        "targets": torch.stack([b["targets"] for b in batch]),
        "adj": batch[0]["adj"],
    }


def eval_val_mae(model, use_graph=False):
    model.eval()
    if use_graph:
        ds = GraphTrafficDataset(DATA, "val", 48)
        loader = torch.utils.data.DataLoader(ds, batch_size=16, shuffle=False,
                                             collate_fn=collate_graph)
        tot, n = 0.0, 0
        with torch.no_grad():
            for batch in loader:
                f = {k: v.to(device) if isinstance(v, torch.Tensor) else v
                     for k, v in batch.items()}
                pred = model(f["features"], f["zone_ids"], f["adj"])
                tot += F.l1_loss(pred, f["targets"], reduction="sum").item()
                n += pred.shape[0]
    else:
        ds = TrafficCausalDataset(DATA, "val", 48)
        loader = torch.utils.data.DataLoader(ds, batch_size=32, shuffle=False,
                                             collate_fn=collate_pred)
        tot, n = 0.0, 0
        with torch.no_grad():
            for batch in loader:
                f = {k: v.to(device) if isinstance(v, torch.Tensor) else v
                     for k, v in batch.items()}
                if hasattr(model, "causal_head"):
                    _, pred = model(f["zone_ids"], f["features"])
                elif hasattr(model, "zone_embed"):
                    pred = model(f["zone_ids"], f["features"])
                else:
                    pred = model(f["features"])
                tot += F.l1_loss(pred, f["targets"], reduction="sum").item()
                n += pred.shape[0]
    return tot / n


def synth_batch(samples, start, size):
    batch = samples[start:start + size]
    zones = torch.zeros(len(batch), 48, dtype=torch.long)
    ff = torch.zeros(len(batch), 48, ND)
    cf = torch.zeros(len(batch), 48, ND)
    ice = torch.zeros(len(batch), ND)
    et = torch.full((len(batch), 5), -1, dtype=torch.long)
    el = torch.zeros(len(batch), 5, 2)
    etm = torch.zeros(len(batch), 5)
    zs = torch.zeros(len(batch), 5, ND)
    for i, d in enumerate(batch):
        zones[i] = d["zone"]
        ff[i] = d["factual"]
        cf[i] = d["cf"]
        ice[i] = d["ice_true"]
        c = d["combo"]
        et[i] = c["event_types"]
        el[i] = c["event_locs"]
        etm[i] = c["event_times"]
        zs[i] = c["zone_states"]
    return {"zones": zones.to(device), "ff": ff.to(device), "cf": cf.to(device),
            "ice": ice.to(device), "et": et.to(device), "el": el.to(device),
            "etm": etm.to(device), "zs": zs.to(device)}


def eval_recovery(model, samples):
    ests, trues = [], []
    model.eval()
    with torch.no_grad():
        for i in range(0, len(samples), 64):
            b = synth_batch(samples, i, 64)
            combo = {"event_types": b["et"], "event_locs": b["el"],
                     "event_times": b["etm"], "zone_states": b["zs"]}
            e = model.causal_effect(
                {"zone_ids": b["zones"], "features": b["ff"]},
                {"zone_ids": b["zones"], "features": b["cf"]}, combo)
            ests.append(e[:, 0].cpu().numpy())
            trues.append(b["ice"][:, 0].cpu().numpy())
    est = np.concatenate(ests)
    true = np.concatenate(trues)
    corr = np.corrcoef(est, true)[0, 1]
    ratio = np.median(est / (true + 1e-6))
    mae = np.abs(est - true).mean()
    return corr, float(ratio), float(mae)


def main():
    print("Device:", device)
    syn = np.load(str(Path(DATA) / "synthetic_pairs_v3.npy"), allow_pickle=True).item()
    test = syn["test"]
    single = [s for s in test if s["combo"]["event_types"][1] == -1]
    dual = [s for s in test if s["combo"]["event_types"][1] != -1]

    rows = []

    def add(name, mae, extra=""):
        rows.append((name, mae, extra))
        print("  %-28s MAE=%.4f (per-f %.4f) %s" %
              (name, mae, mae / ND, extra))

    m = STWave(n_zones=NZ, input_dim=ND, hidden_dim=64, n_blocks=2,
               seq_len=48).to(device)
    m.load_state_dict(torch.load(str(Path(DATA) / "stwave_best.pt"),
                                 map_location=device))
    add("STWave", eval_val_mae(m))

    m = CrossGNN(n_zones=NZ, input_dim=ND, hidden_dim=64, n_blocks=2,
                 n_heads=4, seq_len=48).to(device)
    m.load_state_dict(torch.load(str(Path(DATA) / "crossgnn_best.pt"),
                                 map_location=device))
    add("CrossGNN", eval_val_mae(m))

    m = SWPred(NZ, ND).to(device)
    m.load_state_dict(torch.load(str(Path(DATA) / "stwave_predonly_50ep.pt"),
                                 map_location=device))
    add("PredOnly", eval_val_mae(m))

    m = STIDGraph(n_zones=NZ, input_dim=ND, hidden_dim=64, seq_len=48,
                  n_layers=2, n_days=7).to(device)
    m.load_state_dict(torch.load(
        str(Path(DATA) / "stidgraph-pems08_best.pt"), map_location=device))
    add("STIDGraph", eval_val_mae(m, use_graph=True))

    m = STWaveCausalV3(n_zones=NZ, input_dim=ND).to(device)
    m.load_state_dict(torch.load(
        str(Path(DATA) / "stwave_causal_v3_full_pems08_best.pt"),
        map_location=device))
    v3_mae = eval_val_mae(m)
    c, r, me = eval_recovery(m, test)
    c1, r1, m1 = eval_recovery(m, single)
    c2, r2, m2 = eval_recovery(m, dual)
    add("STWaveCausal V3", v3_mae,
        "recovery corr=%.4f ratio=%.3f mae=%.3f | single %.4f/%.3f/%.3f | dual %.4f/%.3f/%.3f"
        % (c, r, me, c1, r1, m1, c2, r2, m2))

    print("\nrows:")
    for name, mae, extra in rows:
        print("| %s | %.4f (%.4f) | %s |" % (name, mae, mae / ND, extra))


if __name__ == "__main__":
    main()
