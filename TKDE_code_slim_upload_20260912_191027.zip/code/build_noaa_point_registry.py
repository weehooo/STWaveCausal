"""Map point-coordinate NOAA records to TLC zones and select H3 candidates."""
import argparse
import gzip
import hashlib
import glob
import json
import math
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import shapefile
from pyproj import Transformer


COUNTIES = {
    "bronx": "Bronx", "kings": "Brooklyn", "brooklyn": "Brooklyn",
    "new york": "Manhattan", "manhattan": "Manhattan",
    "queens": "Queens", "richmond": "Staten Island",
    "staten island": "Staten Island",
}
EXCLUDED_TYPES = {
    "hurricane", "typhoon", "blizzard", "winter storm", "ice storm",
    "storm surge", "tsunami", "dust storm",
}
HOLIDAYS = {
    "2011-01-17", "2011-02-21", "2011-05-30", "2011-07-04",
    "2011-09-05", "2011-10-10", "2011-11-11", "2011-11-24",
    "2011-12-26", "2012-01-02", "2012-01-16", "2012-02-20",
    "2012-05-28", "2012-07-04", "2012-09-03", "2012-10-08",
    "2012-11-12", "2012-11-22", "2012-12-25", "2013-01-01",
    "2013-01-21", "2013-02-18", "2013-05-27", "2013-07-04",
    "2013-09-02", "2013-10-14", "2013-11-11", "2013-11-28",
    "2013-12-25",
}


def rings(shape):
    if not len(shape.points):
        return
    parts = list(shape.parts) + [len(shape.points)]
    for i in range(len(parts) - 1):
        points = shape.points[parts[i]:parts[i + 1]]
        if len(points) >= 3:
            yield points


def point_in_ring(x, y, ring):
    inside = False
    j = len(ring) - 1
    for i, (xi, yi) in enumerate(ring):
        xj, yj = ring[j]
        if ((yi > y) != (yj > y)) and \
                x < (xj - xi) * (y - yi) / (yj - yi + 1e-15) + xi:
            inside = not inside
        j = i
    return inside


def point_in_shape(x, y, shape):
    return any(point_in_ring(x, y, ring) for ring in rings(shape))


def haversine_km(lat1, lon1, lat2, lon2):
    lat1, lon1, lat2, lon2 = map(np.radians,
                                 [lat1, lon1, lat2, lon2])
    dlat, dlon = lat2 - lat1, lon2 - lon1
    h = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * \
        np.sin(dlon / 2) ** 2
    return float(2 * 6371.0 * np.arcsin(np.sqrt(h)))


def load_zone_shapes(zone_dir):
    reader = shapefile.Reader(str(Path(zone_dir) / "taxi_zones.dbf"))
    fields = [field[0] for field in reader.fields[1:]]
    transformer = Transformer.from_crs("EPSG:4326", "EPSG:2263",
                                       always_xy=True)
    zones = []
    for index in range(len(reader)):
        record = dict(zip(fields, reader.record(index)))
        keys = {key.lower(): key for key in record}
        location_id = keys.get("locationid")
        borough = keys.get("borough")
        zone_name = keys.get("zone")
        if location_id is None:
            continue
        shape = reader.shape(index)
        xmin, ymin, xmax, ymax = shape.bbox
        center_x, center_y = (xmin + xmax) / 2, (ymin + ymax) / 2
        inverse = Transformer.from_crs("EPSG:2263", "EPSG:4326",
                                       always_xy=True)
        center_lon, center_lat = inverse.transform(center_x, center_y)
        zones.append({
            "zone_id": int(record[location_id]),
            "borough": str(record[borough]).strip(),
            "zone_name": str(record.get(zone_name, "")).strip(),
            "shape": shape,
            "center_x": center_x,
            "center_y": center_y,
            "centroid_lat": float(center_lat),
            "centroid_lon": float(center_lon),
        })
    return zones, transformer


def assign_zone(latitude, longitude, zones, transformer):
    x, y = transformer.transform(longitude, latitude)
    matches = [zone for zone in zones
               if point_in_shape(x, y, zone["shape"])]
    if len(matches) == 1:
        chosen = matches[0]
        return chosen, "polygon"
    if len(matches) > 1:
        chosen = min(matches, key=lambda z: (z["center_x"] - x) ** 2 +
                                            (z["center_y"] - y) ** 2)
        return chosen, "polygon_overlap_smallest_center_distance"
    nearest = min(zones, key=lambda z: (z["center_x"] - x) ** 2 +
                                       (z["center_y"] - y) ** 2)
    distance_km = haversine_km(latitude, longitude,
                               nearest["centroid_lat"],
                               nearest["centroid_lon"])
    if distance_km <= 1.0:
        return nearest, f"nearest_centroid_{distance_km:.3f}km"
    return None, f"outside_nearest_{distance_km:.3f}km"


def damage_to_usd(value):
    value = str(value or "").strip().upper()
    if not value or value == "0":
        return 0.0
    number, suffix = value[:-1], value[-1:]
    if suffix not in {"K", "M", "B"} or not number.replace(".", "", 1).isdigit():
        try:
            return float(value)
        except ValueError:
            return 0.0
    return float(number) * {"K": 1e3, "M": 1e6, "B": 1e9}[suffix]


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", default="data/events/raw/"
                        "StormEvents_details-ftp_v1.0_d*_c*.csv.gz")
    parser.add_argument("--zones", default="data/events/raw/taxi_zones")
    parser.add_argument("--features", default="data/nyc_taxi/processed/"
                        "node_features.npy")
    parser.add_argument("--registry", default="noaa_point_registry.json")
    args = parser.parse_args()

    frames = []
    raw_hashes = {}
    for path in sorted(glob.glob(args.pattern)):
        with gzip.open(path, "rt", encoding="utf-8", errors="replace") as f:
            frame = pd.read_csv(f, low_memory=False)
        raw_hashes[path] = sha256(path)
        frame = frame[frame["STATE"].astype(str).str.upper() == "NEW YORK"]
        frame["county_key"] = frame["CZ_NAME"].astype(str).str.strip().str.lower()
        frames.append(frame[frame["county_key"].isin(COUNTIES)])
    frame = pd.concat(frames, ignore_index=True)

    zones, transformer = load_zone_shapes(args.zones)
    feature_count = int(np.load(args.features, mmap_mode="r").shape[0])
    events = []
    assignment_counts = {}
    for _, row in frame.iterrows():
        try:
            start = pd.to_datetime(row["BEGIN_DATE_TIME"],
                                   format="%d-%b-%y %H:%M:%S")
            end = pd.to_datetime(row.get("END_DATE_TIME"),
                                 format="%d-%b-%y %H:%M:%S")
            latitude = float(row["BEGIN_LAT"])
            longitude = float(row["BEGIN_LON"])
        except (KeyError, TypeError, ValueError):
            continue
        if pd.isna(start) or pd.isna(end) or end < start:
            continue
        category = str(row.get("EVENT_TYPE", "")).strip().lower()
        if category in EXCLUDED_TYPES:
            continue
        zone, assignment = assign_zone(latitude, longitude, zones, transformer)
        assignment_counts[assignment.split("_")[0]] = \
            assignment_counts.get(assignment.split("_")[0], 0) + 1
        if zone is None:
            continue
        time_index = round((start.to_pydatetime() -
                            datetime(2011, 1, 1)).total_seconds() / 1800)
        if time_index < 48 or time_index + 48 >= feature_count:
            continue
        injuries = float(row.get("INJURIES_DIRECT", 0) or 0) + \
            float(row.get("INJURIES_INDIRECT", 0) or 0)
        deaths = float(row.get("DEATHS_DIRECT", 0) or 0) + \
            float(row.get("DEATHS_INDIRECT", 0) or 0)
        damage = damage_to_usd(row.get("DAMAGE_PROPERTY")) + \
            damage_to_usd(row.get("DAMAGE_CROPS"))
        magnitude = float(row.get("MAGNITUDE", 0) or 0)
        events.append({
            "event_id": "NOAA-" + str(int(row["EVENT_ID"])),
            "source": "NOAA Storm Events point coordinate fallback",
            "category": category,
            "start_time": start.isoformat(),
            "end_time": end.isoformat(),
            "time_index": int(time_index),
            "latitude": latitude,
            "longitude": longitude,
            "zone_id": zone["zone_id"],
            "zone_name": zone["zone_name"],
            "borough": zone["borough"],
            "county": str(row.get("CZ_NAME", "")),
            "injuries": injuries,
            "deaths": deaths,
            "damage_usd": damage,
            "magnitude": magnitude,
            "severity_score": float(np.log1p(damage) + deaths * 12 +
                                    injuries * 6 + magnitude * 0.5),
            "assignment": assignment,
        })

    events.sort(key=lambda event: (event["start_time"], event["event_id"]))
    pairs = []
    for left_index, left in enumerate(events):
        for right in events[left_index + 1:]:
            if right["zone_id"] == left["zone_id"]:
                continue
            overlap_start = max(pd.Timestamp(left["start_time"]),
                                pd.Timestamp(right["start_time"]))
            overlap_end = min(pd.Timestamp(left["end_time"]),
                              pd.Timestamp(right["end_time"]))
            overlap_minutes = (overlap_end - overlap_start).total_seconds() / 60
            if overlap_minutes < 30:
                continue
            date = overlap_start.strftime("%Y-%m-%d")
            if date in HOLIDAYS:
                continue
            zone_left = next(z for z in zones if z["zone_id"] == left["zone_id"])
            zone_right = next(z for z in zones if z["zone_id"] == right["zone_id"])
            distance = haversine_km(zone_left["centroid_lat"],
                                    zone_left["centroid_lon"],
                                    zone_right["centroid_lat"],
                                    zone_right["centroid_lon"])
            relation = "adjacent" if distance <= 2 else "disjoint"
            pairs.append({
                "pair_id": f"{left['event_id']}__{right['event_id']}",
                "events": [left, right],
                "overlap_minutes": float(overlap_minutes),
                "distance_km": round(distance, 3),
                "spatial_relation": relation,
                "combined_severity": round(left["severity_score"] +
                                           right["severity_score"], 4),
            })
    pairs.sort(key=lambda pair: (-pair["combined_severity"],
                                 -pair["overlap_minutes"]))

    output = {
        "protocol_name": "NYC localized concurrent-event stress test",
        "status": "event_registry_only_no_model_outcomes",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "raw_sha256": raw_hashes,
        "coordinate_fallback_disclosure":
            "NOAA BEGIN_LAT/BEGIN_LON used because collision/311 historical "
            "point sources were unavailable for 2011-2013.",
        "summary": {
            "nyc_rows_read": int(len(frame)),
            "mapped_point_events": len(events),
            "concurrent_candidate_pairs": len(pairs),
            "pairs_by_relation": {
                key: sum(p["spatial_relation"] == key for p in pairs)
                for key in ["adjacent", "disjoint"]
            },
            "unique_event_days": sorted({p["events"][0]["start_time"][:10]
                                         for p in pairs}),
            "assignment_counts": assignment_counts,
        },
        "zones": [{k: v for k, v in zone.items() if k != "shape"}
                  for zone in sorted(zones, key=lambda z: z["zone_id"])],
        "events": events,
        "candidate_pairs": pairs,
    }
    destination = Path(args.registry)
    destination.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output["summary"], indent=2))


if __name__ == "__main__":
    main()
