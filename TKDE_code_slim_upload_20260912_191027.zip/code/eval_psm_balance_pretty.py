"""K3: annotation-driven PSM vs unannotated/random control PSM (SMD balance)."""
import argparse
import json
import sys
from pathlib import Path

import numpy as np

from src.preprocess.psm_matching import balance_check


def precompute_state(features, n_hist=3):
    T, N, D = features.shape
    state = np.zeros((T, N, D), dtype=np.float64)
    for t in range(T):
        lo = max(0, t - n_hist)
        hi = t + 1 if t < n_hist else t
        state[t] = features[lo:hi].mean(axis=0)
    return state


def psm_variant(state, labels, combo_map, caliper=0.1, time_buffer=3,
                use_labels=True, random_control=False, seed=42):
    T, N, D = state.shape
    rng = np.random.RandomState(seed)
    matches = []
    int_events = [(t, z) for t in range(T)
                  if combo_map[t] for z in combo_map[t]["events"]]
    max_samp = 30000
    if len(int_events) > max_samp:
        idx = rng.choice(len(int_events), max_samp, replace=False)
        int_events = [int_events[i] for i in idx]

    for (t, z) in int_events:
        t_start = max(0, t - 7 * 48)
        t_end = min(T, t + 7 * 48)
        if t_end - t_start <= 0:
            continue
        idxs = np.arange(t_start, t_end)
        mask = np.abs(idxs - t) >= time_buffer
        if use_labels:
            mask = mask & (labels[idxs, z] == 0)
        if not mask.any():
            continue
        cand = idxs[mask]
        if random_control:
            best_tt = int(cand[0])
        else:
            d = np.linalg.norm(state[cand, z] - state[t, z], axis=1)
            keep = d < caliper
            if not keep.any():
                continue
            best_tt = int(cand[keep][np.argmin(d[keep])])
        matches.append({"t": int(t), "t_star": best_tt, "zone": int(z),
                        "feature_dist": 0.0})
    return matches


def summarize(matches, features, labels=None):
    bal = balance_check(matches, features)
    smd = list(bal["smd"].values())
    contaminated = 0
    if labels is not None and matches:
        contaminated = sum(1 for m in matches if labels[m["t_star"], m["zone"]] != 0)
    if not smd:
        return {"pairs": 0, "max_smd": None, "mean_smd": None, "passed": False,
                "contaminated_controls": contaminated}
    return {"pairs": len(matches), "max_smd": float(max(smd)),
            "mean_smd": float(np.mean(smd)), "passed": bool(bal["passed"]),
            "contaminated_controls": contaminated}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dirs", nargs="+",
                        default=["data/nyc_taxi", "data/pems_bay"])
    parser.add_argument("--caliper", type=float, default=0.1)
    parser.add_argument("--time-buffer", type=int, default=3)
    args = parser.parse_args()

    out = {}
    for data_dir in args.data_dirs:
        name = Path(data_dir).name
        processed = Path(data_dir) / "processed"
        labels = np.load(str(processed / "labels.npy"))
        features = np.load(str(processed / "node_features.npy"))
        combo_map = {}
        for t in range(len(labels)):
            z = np.where(labels[t] == 1)[0]
            combo_map[t] = {"events": [int(x) for x in z]} if z.size else None
        T, N, D = features.shape
        print("[%s] %d windows, %d zones, %d features" % (name, T, N, D),
              flush=True)
        state = precompute_state(features)

        for variant, kw in [
                ("annotated_psm", dict(use_labels=True)),
                ("unannotated_psm", dict(use_labels=False)),
                ("random_control", dict(use_labels=False, random_control=True))]:
            m = psm_variant(state, labels, combo_map, args.caliper,
                            args.time_buffer, **kw)
            res = summarize(m, features, labels)
            out.setdefault(name, {})[variant] = res
            print("  %-18s pairs=%d max_smd=%s mean_smd=%s passed=%s contam=%d"
                  % (variant, res["pairs"], _f(res["max_smd"]),
                     _f(res["mean_smd"]), res["passed"],
                     res["contaminated_controls"]), flush=True)

    with open("eval_psm_balance_results.json", "w") as f:
        json.dump(out, f, indent=2)
    print("Saved eval_psm_balance_results.json")


def _f(x):
    return "n/a" if x is None else ("%.4f" % x)


if __name__ == "__main__":
    sys.exit(main())
