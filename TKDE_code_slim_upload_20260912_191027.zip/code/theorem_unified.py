"""Joint partial-overlap + spatial-interference bound validation.

Unified bound checked: |E tau_hat - ACE| <= L*eps + (1-rho)*Delta
                                             + Gamma*d_max*delta_T
where the last term is the interference bias and delta_T is the mean
neighbor-treatment difference between factual and counterfactual windows.
"""
import numpy as np
from scipy.stats import norm


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def run(rng, gamma, eps, n=20000, n_units=20, p_edge=0.3, a0=1.5):
    A = (rng.rand(n_units, n_units) < p_edge).astype(np.float64)
    A = np.triu(A, 1)
    A = A + A.T
    deg = A.sum(1)
    d_max = int(deg.max())

    S = rng.uniform(0, 1, n)
    T_t = np.array([rng.binomial(1, 0.5, n_units) for _ in range(n)])
    T_c = np.array([rng.binomial(1, 0.3, n_units) for _ in range(n)])
    unit = rng.randint(n_units, size=n)
    nb_diff = (A[unit] * (T_t - T_c)).sum(1)
    e = sigmoid(a0 + 1.0 * S)
    T = (rng.rand(n) < e).astype(int)
    tau = 1.0 + 0.5 * S
    Y0 = 1 + 2 * S + rng.normal(0, 0.1, n)
    Y1 = Y0 + tau + gamma * nb_diff

    treated = np.where(T == 1)[0]
    controls = T == 0
    S_sorted = S[controls]
    order = np.argsort(S_sorted)
    S_sorted = S_sorted[order]
    idx_c = np.where(controls)[0][order]

    ests = []
    matched_tau = []
    matched_diff = []
    unmatched_tau = []
    for i in treated:
        s = S[i]
        pos = np.searchsorted(S_sorted, s)
        best = None
        for q in (pos - 1, pos, pos + 1):
            if 0 <= q < len(S_sorted):
                j = idx_c[q]
                d = abs(S[j] - s)
                if best is None or d < best[0]:
                    best = (d, j)
        if best is not None and best[0] <= eps:
            j = best[1]
            ests.append(Y1[i] - Y0[j])
            matched_tau.append(tau[i])
            matched_diff.append(nb_diff[i])
        else:
            unmatched_tau.append(tau[i])

    if not ests:
        return None
    rho = len(ests) / len(treated)
    est = np.array(ests)
    mtau = np.array(matched_tau)
    md = np.array(matched_diff)
    true_ace = tau[treated].mean()
    bias = est.mean() - true_ace

    delta = abs(mtau.mean() - (np.mean(unmatched_tau)
                               if unmatched_tau else mtau.mean()))
    delta_t = float(np.mean(np.abs(md)))
    bound_true = (2.0 * eps + (1 - rho) * delta
                  + gamma * d_max * delta_t)
    sigma = np.std(est)
    bound_est = (2.0 * eps + (1 - rho)
                 * ((est.max() - est.min()) / 2.0)
                 + norm.ppf(0.95) * sigma / np.sqrt(len(est))
                 + gamma * d_max * delta_t)

    slope = np.polyfit(md, est, 1)[0]
    corrected = (est - slope * md).mean()
    corrected_bias = abs(corrected - true_ace)
    return {
        "rho": rho, "bias": abs(bias), "bound_est": bound_est,
        "covered": abs(bias) <= bound_est,
        "covered_true": abs(bias) <= bound_true,
        "corrected_bias": corrected_bias, "d_max": d_max,
        "delta_t": delta_t,
    }


def main():
    rng = np.random.RandomState(42)
    print("eps  gamma  rho   |bias|  bound_est  cov90  cov_true  corrected  dmax")
    for eps in [0.001, 0.005]:
        for gamma in [0.0, 0.3, 0.8]:
            rows = [r for r in (run(rng, gamma, eps) for _ in range(50))
                    if r is not None]
            if not rows:
                continue
            print("%.3f %.1f  %.3f  %.4f  %.4f  %.3f  %.3f  %.4f  %d" % (
                eps, gamma,
                np.mean([r["rho"] for r in rows]),
                np.mean([r["bias"] for r in rows]),
                np.mean([r["bound_est"] for r in rows]),
                np.mean([r["covered"] for r in rows]),
                np.mean([r["covered_true"] for r in rows]),
                np.mean([r["corrected_bias"] for r in rows]),
                rows[0]["d_max"]))


if __name__ == "__main__":
    main()
