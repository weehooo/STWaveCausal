"""Framework-native second-stage fine-tune for real-data magnitude.

This script subclasses the frozen STWaveCausalV3 backbone and trains a small
RealMagnitudeHead on PEMS-BAY incident windows. The supervision target is the
model-free event-study post effect, and the split is chronological.
"""
import json
import os
import sys

import numpy as np
import torch
import torch.nn as nn

os.chdir("F:/xuexi/codex/papers")
sys.path.insert(0, "src/model")

from stwave_causal_v3 import STWaveCausalV3
from eval_pemsbay_eventsudy import load_incidents

device = "cuda" if torch.cuda.is_available() else "cpu"
SEQ = 48
CF_OFFSET = 7 * 24 * 12


class STWaveCausalV3Real(STWaveCausalV3):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.real_head = nn.Sequential(
            nn.Linear(self.hidden_dim * 2, self.hidden_dim),
            nn.ReLU(),
            nn.Linear(self.hidden_dim, self.hidden_dim),
            nn.ReLU(),
            nn.Linear(self.hidden_dim, 1),
        )

    def real_magnitude(self, zone_ids, factual, counterfactual):
        h_f = self.encode(zone_ids, factual)
        h_cf = self.encode(zone_ids, counterfactual)
        return self.real_head(torch.cat([h_f, h_cf], dim=-1)).squeeze(-1)


def make_window(feats, adj, zone, t):
    t_start = max(0, t - SEQ)
    w_all = feats[t_start:t]
    if len(w_all) < SEQ:
        pad = np.zeros((SEQ - len(w_all), feats.shape[1], feats.shape[2]),
                       dtype=np.float32)
        w_all = np.concatenate([pad, w_all], axis=0)
    raw = w_all[:, zone].astype(np.float32)
    ctx = np.einsum("snd,n->sd", w_all.astype(np.float32),
                    adj[zone].astype(np.float32))
    ctx = ctx - raw
    return np.concatenate([raw, ctx], axis=-1)


def metrics(y_true, y_pred):
    ss_res = float(np.sum((y_true - y_pred) ** 2))
    ss_tot = float(np.sum((y_true - y_true.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    mae = float(np.mean(np.abs(y_true - y_pred)))
    bias = float(np.mean(y_pred - y_true))
    corr = float(np.corrcoef(y_true, y_pred)[0, 1])
    return {"r2": r2, "mae": mae, "bias": bias, "corr": corr}


def main():
    sensor_ids = [str(v) for v in
                  np.load("data/pems_bay/processed/sensor_ids.npy",
                          allow_pickle=True)]
    idx = {sensor_id: i for i, sensor_id in enumerate(sensor_ids)}
    feats = np.load("data/pems_bay/processed/node_features.npy",
                    mmap_mode="r")
    adj = np.load("data/pems_bay/processed/adj.npy").astype(np.float32)
    adj = adj / np.maximum(adj.sum(axis=1, keepdims=True), 1e-6)

    model = STWaveCausalV3Real(
        n_zones=325, input_dim=16, output_dim=8, ctx_channels=8,
        ctx_gate=False,
    ).to(device)
    base = torch.load(
        "data/pems_bay/processed/stwave_causal_v3_graphctx_grad_pemsbay_best.pt",
        map_location=device,
    )
    model.load_state_dict(base, strict=False)
    for name, param in model.named_parameters():
        if not name.startswith("real_head"):
            param.requires_grad_(False)

    events = load_incidents(
        "data/pems_bay/raw/kaggle_extract/pems_bay_incidents.csv")
    study = json.load(open("pemsbay_eventsudy_results.json", encoding="utf-8"))
    by_id = {r["incident_id"]: r for r in study["per_event"]}

    samples = []
    for e in events:
        sid = e["sensor_id"]
        if sid not in idx or e["incident_id"] not in by_id:
            continue
        z = idx[sid]
        t0 = e["start_idx"]
        t_cf = t0 - CF_OFFSET
        if t0 < SEQ or t_cf < 0:
            continue
        curve = by_id[e["incident_id"]]["curve"]
        target = float(np.mean(curve[6:]))
        samples.append((z, t0, t_cf, target))
    samples.sort(key=lambda s: s[1])

    n = len(samples)
    train = samples[:int(n * 0.60)]
    val = samples[int(n * 0.60):int(n * 0.80)]
    test = samples[int(n * 0.80):]

    opt = torch.optim.Adam(model.real_head.parameters(), lr=1e-3)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=20)
    loss_fn = nn.MSELoss()

    def batch_eval(subset, batch_size=128):
        model.eval()
        preds, trues = [], []
        with torch.no_grad():
            for i in range(0, len(subset), batch_size):
                batch = subset[i:i + batch_size]
                zones = torch.zeros(len(batch), SEQ, dtype=torch.long)
                ff = torch.zeros(len(batch), SEQ, 16)
                cf = torch.zeros(len(batch), SEQ, 16)
                y = torch.zeros(len(batch))
                for j, (z, t0, t_cf, target) in enumerate(batch):
                    zones[j] = z
                    ff[j] = torch.FloatTensor(make_window(feats, adj, z, t0))
                    cf[j] = torch.FloatTensor(make_window(feats, adj, z, t_cf))
                    y[j] = target
                pred = model.real_magnitude(zones.to(device), ff.to(device),
                                            cf.to(device))
                preds.append(pred.cpu().numpy())
                trues.append(y.numpy())
        return np.concatenate(preds), np.concatenate(trues)

    for ep in range(20):
        model.train()
        order = np.random.permutation(len(train))
        total = 0.0
        for start in range(0, len(order), 128):
            idxs = order[start:start + 128]
            batch = [train[j] for j in idxs]
            zones = torch.zeros(len(batch), SEQ, dtype=torch.long)
            ff = torch.zeros(len(batch), SEQ, 16)
            cf = torch.zeros(len(batch), SEQ, 16)
            y = torch.zeros(len(batch))
            for j, (z, t0, t_cf, target) in enumerate(batch):
                zones[j] = z
                ff[j] = torch.FloatTensor(make_window(feats, adj, z, t0))
                cf[j] = torch.FloatTensor(make_window(feats, adj, z, t_cf))
                y[j] = target
            pred = model.real_magnitude(zones.to(device), ff.to(device),
                                        cf.to(device))
            loss = loss_fn(pred, y.to(device))
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.real_head.parameters(), 5.0)
            opt.step()
            total += loss.item()
        sched.step()
        if ep == 0 or (ep + 1) % 5 == 0:
            val_pred, val_true = batch_eval(val)
            print("Ep %02d loss=%.4f val_mae=%.4f" %
                  (ep + 1, total / max(1, len(order) // 128),
                   float(np.mean(np.abs(val_pred - val_true)))),
                  flush=True)

    test_pred, test_true = batch_eval(test)
    baseline = np.full_like(test_true, float(np.mean([s[3] for s in train])))
    out = {
        "n_train": int(len(train)),
        "n_val": int(len(val)),
        "n_test": int(len(test)),
        "baseline_mean": metrics(test_true, baseline),
        "real_magnitude_head": metrics(test_true, test_pred),
    }
    torch.save(model.real_head.state_dict(), "real_magnitude_head.pt")
    with open("real_magnitude_head_results.json", "w",
              encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2), flush=True)
    print("Wrote real_magnitude_head_results.json", flush=True)


if __name__ == "__main__":
    main()
