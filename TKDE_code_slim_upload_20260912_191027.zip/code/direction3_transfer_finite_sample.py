"""Finite-sample confidence bound for the transferred recovery theorem.

This script estimates the observable components of Theorem `thm:transfer` on
held-out synthetic data and produces finite-sample bootstrap intervals plus a
high-probability upper bound under the same Lipschitz / bounded-loss
assumptions used in the paper. It is not a new training run: it reuses the
same checkpoint and synthetic pair tensors as `direction1_transfer_bound.py`.
"""

import argparse
import json
import os
import sys

import numpy as np
from scipy import stats
import torch

os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "src/model")

from stwave_causal_v3 import STWaveCausalV3


device = "cuda" if torch.cuda.is_available() else "cpu"


def batch(samples, start, size):
    b = samples[start:start + size]
    zones = torch.zeros(len(b), 48, dtype=torch.long)
    ff = torch.zeros(len(b), 48, 12)
    cf = torch.zeros(len(b), 48, 12)
    ice = torch.zeros(len(b), 6)
    et = torch.full((len(b), 5), -1, dtype=torch.long)
    el = torch.zeros(len(b), 5, 2)
    etm = torch.zeros(len(b), 5)
    zs = torch.zeros(len(b), 5, 12)
    for i, d in enumerate(b):
        zones[i] = d["zone"]
        ff[i] = d["factual"]
        cf[i] = d["cf"]
        ice[i] = d["ice_true"]
        c = d["combo"]
        et[i] = c["event_types"]
        el[i] = c["event_locs"]
        etm[i] = c["event_times"]
        zs[i] = c["zone_states"]
    return {"zones": zones.to(device), "ff": ff.to(device),
            "cf": cf.to(device), "ice": ice.to(device), "et": et.to(device),
            "el": el.to(device), "etm": etm.to(device), "zs": zs.to(device)}


def recover(samples, model):
    ests, trues = [], []
    with torch.no_grad():
        for i in range(0, len(samples), 64):
            b = batch(samples, i, 64)
            combo = {"event_types": b["et"], "event_locs": b["el"],
                     "event_times": b["etm"], "zone_states": b["zs"]}
            e = model.causal_effect(
                {"zone_ids": b["zones"], "features": b["ff"]},
                {"zone_ids": b["zones"], "features": b["cf"]}, combo)
            ests.append(e[:, 0].cpu().numpy())
            trues.append(b["ice"][:, 0].cpu().numpy())
    return np.concatenate(ests), np.concatenate(trues)


def summary_feature(samples):
    """Target-zone mean flow over the input window, used for the finite-sample
    shift demonstration."""
    return np.asarray([np.asarray(s["factual"])[-12:, 0].mean()
                       for s in samples], dtype=float)


def window_feature(samples):
    """L2-normalized full factual window, used for the sliced-Wasserstein
    shift demonstration."""
    feats = np.asarray([np.asarray(s["factual"], dtype=float).reshape(-1)
                        for s in samples], dtype=float)
    norms = np.linalg.norm(feats, axis=1, keepdims=True)
    return feats / np.maximum(norms, 1e-9)


def sliced_wasserstein(x, y, n_projections=64, seed=20260907):
    """Empirical sliced 1-Wasserstein distance between two samples."""
    rng = np.random.RandomState(seed)
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    dim = x.shape[1]
    proj = rng.randn(dim, n_projections)
    proj = proj / np.maximum(np.linalg.norm(proj, axis=0, keepdims=True), 1e-9)
    xp = x @ proj
    yp = y @ proj
    vals = [stats.wasserstein_distance(xp[:, j], yp[:, j])
            for j in range(n_projections)]
    return float(np.mean(vals))


def bootstrap_ci(values, n_boot=1000, seed=20260907, alpha=0.05):
    rng = np.random.RandomState(seed)
    vals = np.asarray(values, dtype=float)
    means = np.empty(n_boot, dtype=float)
    for i in range(n_boot):
        idx = rng.randint(0, len(vals), size=len(vals))
        means[i] = vals[idx].mean()
    return float(np.quantile(means, alpha / 2)), float(np.quantile(means, 1 - alpha / 2))


def wasserstein_bootstrap_ci(x, y, n_boot=300, seed=20260907, alpha=0.05):
    rng = np.random.RandomState(seed)
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    vals = np.empty(n_boot, dtype=float)
    for i in range(n_boot):
        xb = x[rng.randint(0, len(x), size=len(x))]
        yb = y[rng.randint(0, len(y), size=len(y))]
        vals[i] = stats.wasserstein_distance(xb, yb)
    return float(np.quantile(vals, alpha / 2)), float(np.quantile(vals, 1 - alpha / 2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--in-pairs",
                        default="data/nyc_taxi/processed/"
                                "synthetic_pairs_v3_graphctx.npy")
    parser.add_argument("--ood-pairs",
                        default="data/nyc_taxi/processed/"
                                "synthetic_pairs_v3_graphctx_ood.npy")
    parser.add_argument("--output",
                        default="direction3_transfer_finite_sample.json")
    parser.add_argument("--seeds", nargs="+", type=int, default=[42, 1, 2])
    parser.add_argument("--rng-seed", type=int, default=20260907)
    parser.add_argument("--n-projections", type=int, default=64)
    args = parser.parse_args()

    ind = np.load(args.in_pairs, allow_pickle=True).item()["test"]
    ood = np.load(args.ood_pairs, allow_pickle=True).item()["test"]
    feat_ind = window_feature(ind)
    feat_ood = window_feature(ood)
    delta_max_json = json.load(open("direction2_misspec_bound.json",
                                    encoding="utf-8"))
    delta_max = float(delta_max_json["in_family_dispersion"]["p90"])

    seed_rows = []
    for model_seed in args.seeds:
        checkpoint = (f"data/nyc_taxi/processed/rerun_v3_seed{model_seed}.pt"
                      if model_seed == 42 else
                      f"data/nyc_taxi/processed/rerun_v3_seed{model_seed}.pt")
        model = STWaveCausalV3(n_zones=265, input_dim=12, output_dim=6,
                               ctx_channels=6).to(device)
        model.load_state_dict(torch.load(checkpoint, map_location=device))
        model.eval()

        est_i, true_i = recover(ind, model)
        est_o, true_o = recover(ood, model)
        sq_i = (np.abs(est_i - true_i) ** 2)
        sq_o = (np.abs(est_o - true_o) ** 2)

        max_true = float(max(true_i.max(), true_o.max()))
        scale = max_true
        fitting = float(sq_i.mean() / (scale ** 2))
        fit_lo, fit_hi = bootstrap_ci(sq_i, seed=args.rng_seed)
        fit_lo = float(fit_lo / (scale ** 2))
        fit_hi = float(fit_hi / (scale ** 2))
        B = float(np.max(sq_i / (scale ** 2)))
        delta_max_norm = delta_max / scale
        w1 = sliced_wasserstein(feat_ind, feat_ood,
                                n_projections=args.n_projections,
                                seed=args.rng_seed)
        n, m = len(sq_i), len(sq_o)
        delta = 0.05
        conc_mean = B * np.sqrt(np.log(2 / delta) / (2 * n))
        conc_w1 = 2.0 * np.sqrt((1 / (2 * n) + 1 / (2 * m))
                                * np.log(2 / delta))
        finite_bound = 2 * (fitting + conc_mean + (w1 + conc_w1)
                            + delta_max_norm ** 2)
        seed_rows.append({
            "model_seed": int(model_seed),
            "fitting_mean_squared_error": fitting,
            "fitting_bootstrap_ci95": [fit_lo, fit_hi],
            "sliced_w1": w1,
            "effect_scale": scale,
            "loss_bound_B": B,
            "delta_max_normalized": delta_max_norm,
            "finite_sample_upper_bound": finite_bound,
        })

    bounds = np.asarray([r["finite_sample_upper_bound"] for r in seed_rows])
    sliced_w = np.asarray([r["sliced_w1"] for r in seed_rows])
    fit_vals = np.asarray([r["fitting_mean_squared_error"] for r in seed_rows])
    out = {
        "protocol_name": "Finite-sample transferred recovery confidence bound",
        "status": "complete",
        "model_seeds": args.seeds,
        "sample_counts": {"in_distribution": len(ind),
                          "shifted": len(ood)},
        "normalization": {
            "metric": "L2-normalized full factual window, sliced-W1",
            "summary_diameter": 2.0,
            "lipschitz_constant": 1.0,
            "n_projections": args.n_projections,
        },
        "per_seed": seed_rows,
        "aggregate": {
            "sliced_w1_mean": float(sliced_w.mean()),
            "sliced_w1_std": float(sliced_w.std(ddof=1)),
            "fitting_mean_squared_error_mean": float(fit_vals.mean()),
            "finite_sample_upper_bound_mean": float(bounds.mean()),
            "finite_sample_upper_bound_std": float(bounds.std(ddof=1)),
            "finite_sample_upper_bound_min": float(bounds.min()),
            "finite_sample_upper_bound_max": float(bounds.max()),
        },
        "misspecification_term": {
            "delta_max": float(delta_max),
        },
    }
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2, default=str), flush=True)


if __name__ == "__main__":
    main()
