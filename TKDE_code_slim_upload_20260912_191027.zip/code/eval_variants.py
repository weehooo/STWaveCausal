"""Evaluate variant checkpoints (std V3, PEMS08 ablations) on the shared
matched-pair validation split."""
import os
import sys
import json

import numpy as np
import torch
import torch.nn as nn

BASE = os.environ.get("PAPERS_BASE", os.path.dirname(os.path.abspath(__file__)))
os.chdir(BASE)
sys.path.insert(0, ".")
sys.path.insert(0, "src/model")

from dataset import TrafficCausalDataset
from graphctx_dataset import GraphCtxCausalDataset
from stwave_causal_v3 import STWaveCausalV3

device = "cuda" if torch.cuda.is_available() else "cpu"


def collate_pred(batch):
    factual, _, _, _, _ = zip(*batch)
    return {k: torch.stack([x[k] for x in factual]) for k in factual[0].keys()}


def collate_ctx(batch):
    factual, _, _, _, _ = zip(*batch)
    return {k: torch.stack([x[k] for x in factual]) for k in factual[0].keys()}


def loader_for(ds, collate_fn, batch=64):
    return torch.utils.data.DataLoader(ds, batch_size=batch, shuffle=False,
                                       collate_fn=collate_fn, num_workers=0)


VARIANTS = [
    ("std_nyc_taxi", "nyc_taxi", "traffic", 265, 6, 0, True),
    ("std_pems_bay", "pems_bay", "traffic", 325, 8, 0, True),
    ("std_pems08", "pems08", "traffic", 170, 1, 0, True),
    ("std_pems04", "pems04", "traffic", 307, 1, 0, True),
    ("pems08_abl_no_causal", "pems08", "ctx", 170, 1, 1, True),
    ("pems08_abl_no_contrastive", "pems08", "ctx", 170, 1, 1, True),
    ("pems08_abl_no_gate", "pems08", "ctx", 170, 1, 1, False),
    ("pems08_abl_no_time", "pems08", "ctx_notime", 170, 1, 1, True),
    ("pems08_abl_no_twostage", "pems08", "ctx", 170, 1, 1, True),
]


def main():
    meta08 = np.load("data/datasets/pems08_staeformer/data.npz")["data"][..., 1:3][:, 0]
    out = {}
    for tag, dset, kind, nz, dim, ctxc, gate in VARIANTS:
        if tag.startswith("std_"):
            ckpt = "data/%s/processed/rerun_v3_std_%s_seed42.pt" % (dset, dset)
        else:
            ckpt = ("data/pems08/processed/rerun_v3_pems08_abl_%s_seed42.pt"
                    % tag.replace("pems08_abl_", ""))
        if not os.path.exists(ckpt):
            print("missing:", ckpt, flush=True)
            continue
        data_dir = "data/%s/processed" % dset
        if kind == "traffic":
            ds = TrafficCausalDataset(data_dir, "val", 48)
            loader = loader_for(ds, collate_pred)
            ind = dim
        else:
            meta = None if kind == "ctx_notime" else meta08
            ds = GraphCtxCausalDataset(data_dir, "val", 48,
                                       ctx_mode="mean", meta=meta)
            loader = loader_for(ds, collate_ctx)
            ind = dim * 2 + (2 if meta is not None else 0)
        model = STWaveCausalV3(n_zones=nz, input_dim=ind, output_dim=dim,
                               ctx_channels=ctxc if kind != "traffic" else 0,
                               ctx_gate=gate).to(device)
        model.load_state_dict(torch.load(ckpt, map_location=device))
        model.eval()
        tot = 0.0
        n = 0
        with torch.no_grad():
            for batch in loader:
                f = {k: v.to(device) for k, v in batch.items()}
                _, pred = model(f["zone_ids"], f["features"])
                tot += torch.abs(pred - f["targets"]).mean().item() * pred.shape[0]
                n += pred.shape[0]
        mae = float(tot / max(1, n))
        out[tag] = {"mae": mae, "per_feature": mae / max(1, dim)}
        print(tag, out[tag], flush=True)
        del ds, loader, model
        import gc
        gc.collect()
        torch.cuda.empty_cache()
    with open("eval_variants_results.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
