﻿import sys, os, torch, torch.nn as nn, torch.nn.functional as F, numpy as np
os.chdir('F:/xuexi/codex/papers')
sys.path.insert(0, 'src/model')
from pathlib import Path
from stwave_causal import STWaveCausal
from stwave_causal_v3 import STWaveCausalV3
from stwave import STWaveBlock

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('Device:', device)

class SWPred(nn.Module):
    def __init__(self, nz=265, nd=6):
        super().__init__()
        self.zone_embed = nn.Embedding(nz, 64); self.input_proj = nn.Linear(nd, 64)
        self.pos_embed = nn.Embedding(48, 64)
        self.blocks = nn.ModuleList([STWaveBlock(nz, 64) for _ in range(2)])
        self.pred_head = nn.Sequential(nn.Linear(64, 64), nn.ReLU(), nn.Linear(64, nd))
    def forward(self, zid, f):
        B,S,D = f.shape; x = self.input_proj(f); pos = torch.arange(S, device=f.device).unsqueeze(0).expand(B, -1)
        x = (self.zone_embed(zid) + x + self.pos_embed(pos)).unsqueeze(1)
        for b in self.blocks: x = b(x)
        return self.pred_head(x[:,0,-1,:])

# Load models
print('Loading models...')
predonly = SWPred().to(device)
predonly.load_state_dict(torch.load('data/nyc_taxi/processed/stwave_predonly_50ep.pt', map_location=device))
predonly.eval()

swc_v2 = STWaveCausal(n_zones=265, input_dim=6).to(device)
swc_v2.load_state_dict(torch.load('data/nyc_taxi/processed/stwave_causal_pull_lcon03_ldiv001.pt', map_location=device))
swc_v2.eval()

swc_v3 = STWaveCausalV3(n_zones=265, input_dim=6).to(device)
swc_v3.load_state_dict(torch.load('data/nyc_taxi/processed/stwave_causal_v3_full_best.pt', map_location=device))
swc_v3.eval()

# Load synthetic test set
synthetic = np.load('data/nyc_taxi/processed/synthetic_pairs_v3.npy', allow_pickle=True).item()
test = synthetic['test']
print(f'Test size: {len(test)}')

seq_len = 48
feature_dim = 6

def batch_to_inputs(samples, start, size):
    batch = samples[start:start+size]
    zones = torch.zeros(len(batch), seq_len, dtype=torch.long).to(device)
    feats_f = torch.zeros(len(batch), seq_len, feature_dim).to(device)
    feats_cf = torch.zeros(len(batch), seq_len, feature_dim).to(device)
    ice_true = torch.zeros(len(batch), feature_dim).to(device)
    for i, d in enumerate(batch):
        zones[i] = d['zone']
        feats_f[i] = d['factual']
        feats_cf[i] = d['cf']
        ice_true[i] = d['ice_true']
    return {
        'zone_ids': zones,
        'features': feats_f,
        'cf_features': feats_cf,
        'ice_true': ice_true,
    }

@torch.no_grad()
def eval_effect_recovery(model, samples, slice_size=64):
    '''Evaluate effect recovery: model's predicted causal effect vs true effect.'''
    est_all = []
    true_all = []
    for i in range(0, len(samples), slice_size):
        inp = batch_to_inputs(samples, i, slice_size)
        # For PredOnly/STWaveCausal v2 (no causal head): estimate effect via prediction diff
        # For STWaveCausalV3: use causal head directly
        if hasattr(model, 'causal_head'):
            # Use causal head
            bs = inp['features'].shape[0]
            combo = {
                'event_types': torch.full((bs, 5), 1, dtype=torch.long).to(device),
                'event_locs': torch.zeros(bs, 5, 2).to(device),
                'event_times': torch.zeros(bs, 5).to(device),
                'zone_states': inp['features'][:, -1, :].unsqueeze(1).repeat(1, 5, 1),
            }
            ice_est = model.causal_effect(
                {'zone_ids': inp['zone_ids'], 'features': inp['features']},
                {'zone_ids': inp['zone_ids'], 'features': inp['cf_features']},
                combo)
        else:
            # Estimate via difference in next-step predictions
            out = model(inp['zone_ids'], inp['features']); h_f, pred_f = out if isinstance(out, tuple) else (None, out)
            out_cf = model(inp['zone_ids'], inp['cf_features']); _, pred_cf = out_cf if isinstance(out_cf, tuple) else (None, out_cf)
            ice_est = torch.abs(pred_f - pred_cf)
        
        est_all.append(ice_est[:, 0].cpu().numpy())
        true_all.append(inp['ice_true'][:, 0].cpu().numpy())
    
    est = np.concatenate(est_all)
    true = np.concatenate(true_all)
    corr = np.corrcoef(est, true)[0, 1]
    ratio = est / (true + 1e-6)
    med_ratio = np.median(ratio)
    mae_effect = np.abs(est - true).mean()
    return corr, med_ratio, mae_effect, est, true

print()
print('='*70)
print('  CAUSAL EFFECT RECOVERY COMPARISON')
print('='*70)
print()

# PredOnly
c, r, m, _, _ = eval_effect_recovery(predonly, test)
print(f'PredOnly:')
print(f'  Correlation: {c:.4f}')
print(f'  Median Recovery Ratio: {r:.3f}')
print(f'  MAE(est, true): {m:.2f}')
print()

# SWC v2 (pull)
c, r, m, _, _ = eval_effect_recovery(swc_v2, test)
print(f'STWaveCausal V2 (pull, no causal head):')
print(f'  Correlation: {c:.4f}')
print(f'  Median Recovery Ratio: {r:.3f}')
print(f'  MAE(est, true): {m:.2f}')
print()

# SWC v3 (with causal head)
c, r, m, _, _ = eval_effect_recovery(swc_v3, test)
print(f'STWaveCausal V3 (with CausalEffectHead):')
print(f'  Correlation: {c:.4f}')
print(f'  Median Recovery Ratio: {r:.3f}')
print(f'  MAE(est, true): {m:.2f}')
print()

# Split single vs dual for V3
single_test = [s for s in test if s['combo']['event_types'][1] == -1]
dual_test = [s for s in test if s['combo']['event_types'][1] != -1]
print(f'Single-event test: {len(single_test)}, Dual-event test: {len(dual_test)}')

c_s, r_s, m_s, _, _ = eval_effect_recovery(swc_v3, single_test)
print(f'V3 Single-event recovery: corr={c_s:.4f}, ratio={r_s:.3f}, MAE={m_s:.2f}')
c_d, r_d, m_d, _, _ = eval_effect_recovery(swc_v3, dual_test)
print(f'V3 Dual-event recovery: corr={c_d:.4f}, ratio={r_d:.3f}, MAE={m_d:.2f}')

print()
print('== PREDICTED vs TRUE CAUSAL EFFECT (sample first 10) ==')
est_v3, true_v3, _, _ = [None]*4
c_v3, r_v3, m_v3, est_v3, true_v3 = eval_effect_recovery(swc_v3, test[:10])
for i in range(10):
    print(f'  sample {i}: true={true_v3[i]:.1f} est={est_v3[i]:.1f}')

print()
print('ALL DONE')

